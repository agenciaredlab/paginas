<?php
/**
 * V74 - GEMSTONE SELECTOR ADVANCED
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', 'gp_gemstone_selector_widget');

function gp_gemstone_selector_widget() {
    global $product;
    
    if (get_post_meta($product->get_id(), '_has_gemstone_options', true) !== 'yes') {
        return;
    }
    
    $gems = array(
        'diamante' => array('name' => 'Diamante', 'price' => 1000000, 'emoji' => '💎', 'hardness' => '10'),
        'esmeralda' => array('name' => 'Esmeralda', 'price' => 700000, 'emoji' => '💚', 'hardness' => '7.5-8'),
        'rubi' => array('name' => 'Rubí', 'price' => 800000, 'emoji' => '❤️', 'hardness' => '9'),
        'zafiro' => array('name' => 'Zafiro', 'price' => 650000, 'emoji' => '💙', 'hardness' => '9'),
        'amatista' => array('name' => 'Amatista', 'price' => 200000, 'emoji' => '💜', 'hardness' => '7'),
        'topacio' => array('name' => 'Topacio', 'price' => 300000, 'emoji' => '🧡', 'hardness' => '8'),
    );
    ?>
    
    <div class="gp-gemstone-selector" style="background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); padding: 25px; border-radius: 12px; margin-bottom: 20px;">
        <h4 style="margin-top: 0;">💎 Selecciona la Piedra Preciosa</h4>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
            <?php foreach ($gems as $key => $gem): ?>
            <label style="cursor: pointer;">
                <input type="radio" name="selected_gemstone" value="<?php echo $key; ?>" data-price="<?php echo $gem['price']; ?>" style="display: none;">
                <div class="gem-card" style="background: white; padding: 20px; border-radius: 10px; text-align: center; border: 3px solid transparent; transition: all 0.3s; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <div style="font-size: 40px; margin-bottom: 8px;"><?php echo $gem['emoji']; ?></div>
                    <strong><?php echo $gem['name']; ?></strong>
                    <div style="font-size: 11px; color: #666; margin: 5px 0;">Dureza: <?php echo $gem['hardness']; ?></div>
                    <div style="color: #D4AF37; font-weight: 600; margin-top: 8px;">$<?php echo number_format($gem['price'], 0, ',', '.'); ?></div>
                </div>
            </label>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('input[name="selected_gemstone"]').on('change', function() {
            $('.gem-card').css('border-color', 'transparent');
            $(this).siblings('.gem-card').css('border-color', '#D4AF37');
        });
    });
    </script>
    
    <?php
}

add_action('add_meta_boxes', function() {
    add_meta_box('gp_gemstone_options', 'Opciones de Piedras', function($post) {
        $value = get_post_meta($post->ID, '_has_gemstone_options', true);
        echo '<label><input type="checkbox" name="_has_gemstone_options" value="yes" ' . checked($value, 'yes', false) . '> Habilitar selector de piedras</label>';
    }, 'product', 'side');
});

add_action('save_post_product', function($post_id) {
    if (isset($_POST['_has_gemstone_options'])) {
        update_post_meta($post_id, '_has_gemstone_options', 'yes');
    } else {
        delete_post_meta($post_id, '_has_gemstone_options');
    }
});
