<?php
/**
 * Golden Phoenix Jewelry - Integración PSE
 * Pagos Seguros en Línea (Colombia)
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// PASARELA DE PAGO PSE
// ============================================

/**
 * Clase para Pasarela PSE
 */
class GP_PSE_Gateway extends WC_Payment_Gateway {
    
    public function __construct() {
        $this->id = 'gp_pse';
        $this->icon = GOLDEN_PHOENIX_URI . '/assets/images/pse-logo.png';
        $this->has_fields = true;
        $this->method_title = 'PSE - Pagos Seguros en Línea';
        $this->method_description = 'Permite pagos mediante transferencia bancaria instantánea con PSE (Colombia)';
        
        // Soporta: productos simples, suscripciones, pre-órdenes
        $this->supports = array(
            'products',
            'subscriptions',
            'subscription_cancellation',
            'subscription_suspension',
            'subscription_reactivation',
            'subscription_amount_changes',
            'subscription_date_changes',
            'subscription_payment_method_change',
            'refunds',
            'pre-orders'
        );
        
        // Cargar configuración
        $this->init_form_fields();
        $this->init_settings();
        
        // Definir propiedades
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'yes' === $this->get_option('testmode');
        
        // Credenciales
        $this->merchant_id = $this->testmode ? $this->get_option('test_merchant_id') : $this->get_option('merchant_id');
        $this->api_key = $this->testmode ? $this->get_option('test_api_key') : $this->get_option('api_key');
        $this->api_login = $this->testmode ? $this->get_option('test_api_login') : $this->get_option('api_login');
        
        // URL de la API
        $this->api_url = $this->testmode ? 
            'https://sandbox.gateway.payulatam.com/ppp-web-gateway/' : 
            'https://gateway.payulatam.com/ppp-web-gateway/';
        
        // Hooks
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_gp_pse_response', array($this, 'handle_response'));
        add_action('woocommerce_api_gp_pse_confirmation', array($this, 'handle_confirmation'));
    }
    
    /**
     * Campos de configuración
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilitar/Deshabilitar',
                'type' => 'checkbox',
                'label' => 'Habilitar PSE',
                'default' => 'no'
            ),
            'title' => array(
                'title' => 'Título',
                'type' => 'text',
                'description' => 'Título que ve el usuario en el checkout',
                'default' => 'PSE - Pago Seguro en Línea',
                'desc_tip' => true,
            ),
            'description' => array(
                'title' => 'Descripción',
                'type' => 'textarea',
                'description' => 'Descripción que ve el usuario',
                'default' => 'Paga de forma segura mediante transferencia bancaria con PSE. Todos los bancos de Colombia.',
            ),
            'testmode' => array(
                'title' => 'Modo de Prueba',
                'label' => 'Habilitar modo de prueba',
                'type' => 'checkbox',
                'description' => 'Usar credenciales de prueba (sandbox)',
                'default' => 'yes',
                'desc_tip' => true,
            ),
            'merchant_id' => array(
                'title' => 'Merchant ID (Producción)',
                'type' => 'text',
                'description' => 'ID de comercio proporcionado por PayU',
                'desc_tip' => true,
            ),
            'api_key' => array(
                'title' => 'API Key (Producción)',
                'type' => 'password',
                'description' => 'API Key de producción',
                'desc_tip' => true,
            ),
            'api_login' => array(
                'title' => 'API Login (Producción)',
                'type' => 'text',
                'description' => 'API Login de producción',
                'desc_tip' => true,
            ),
            'test_merchant_id' => array(
                'title' => 'Test Merchant ID',
                'type' => 'text',
                'description' => 'ID de comercio de prueba',
                'default' => '508029',
                'desc_tip' => true,
            ),
            'test_api_key' => array(
                'title' => 'Test API Key',
                'type' => 'password',
                'description' => 'API Key de prueba',
                'default' => '4Vj8eK4rloUd272L48hsrarnUA',
                'desc_tip' => true,
            ),
            'test_api_login' => array(
                'title' => 'Test API Login',
                'type' => 'text',
                'description' => 'API Login de prueba',
                'default' => 'pRRXKOl8ikMmt9u',
                'desc_tip' => true,
            ),
            'account_id' => array(
                'title' => 'Account ID',
                'type' => 'text',
                'description' => 'ID de cuenta de PayU',
                'default' => '512321',
                'desc_tip' => true,
            ),
        );
    }
    
    /**
     * Campos del formulario de pago
     */
    public function payment_fields() {
        if ($this->description) {
            echo wpautop(wp_kses_post($this->description));
        }
        
        if ($this->testmode) {
            echo '<p style="background: #fff3cd; padding: 10px; border-left: 3px solid #ffc107;">MODO DE PRUEBA ACTIVADO</p>';
        }
        
        ?>
        <div class="gp-pse-payment-fields">
            <p class="form-row form-row-wide">
                <label for="gp-pse-bank">
                    Selecciona tu Banco <span class="required">*</span>
                </label>
                <select id="gp-pse-bank" name="gp_pse_bank" class="input-text" required>
                    <option value="">-- Selecciona un banco --</option>
                    <?php echo $this->get_banks_options(); ?>
                </select>
            </p>
            
            <p class="form-row form-row-wide">
                <label for="gp-pse-person-type">
                    Tipo de Persona <span class="required">*</span>
                </label>
                <select id="gp-pse-person-type" name="gp_pse_person_type" class="input-text" required>
                    <option value="">-- Selecciona --</option>
                    <option value="N">Persona Natural</option>
                    <option value="J">Persona Jurídica</option>
                </select>
            </p>
            
            <p class="form-row form-row-first">
                <label for="gp-pse-document-type">
                    Tipo de Documento <span class="required">*</span>
                </label>
                <select id="gp-pse-document-type" name="gp_pse_document_type" class="input-text" required>
                    <option value="">-- Selecciona --</option>
                    <option value="CC">Cédula de Ciudadanía</option>
                    <option value="CE">Cédula de Extranjería</option>
                    <option value="NIT">NIT</option>
                    <option value="TI">Tarjeta de Identidad</option>
                    <option value="PP">Pasaporte</option>
                    <option value="IDC">Identificación Cliente</option>
                    <option value="CEL">Línea Celular</option>
                    <option value="RC">Registro Civil</option>
                    <option value="DE">Documento Extranjero</option>
                </select>
            </p>
            
            <p class="form-row form-row-last">
                <label for="gp-pse-document-number">
                    Número de Documento <span class="required">*</span>
                </label>
                <input type="text" id="gp-pse-document-number" name="gp_pse_document_number" 
                       class="input-text" placeholder="Sin puntos ni guiones" required>
            </p>
            
            <div class="clear"></div>
            
            <p class="gp-pse-info" style="background: #e8f4f8; padding: 15px; border-radius: 5px; margin-top: 15px;">
                <strong>ℹ️ Información importante:</strong><br>
                • Serás redirigido al sitio seguro de tu banco<br>
                • Completa la transacción en la página de tu banco<br>
                • Recibirás confirmación por email<br>
                • El pago es procesado inmediatamente
            </p>
        </div>
        <?php
    }
    
    /**
     * Obtener lista de bancos PSE
     */
    private function get_banks_options() {
        $banks = array(
            '1007' => 'Bancolombia',
            '1019' => 'Scotiabank Colpatria',
            '1040' => 'Banco Agrario',
            '1052' => 'Banco AV Villas',
            '1001' => 'Banco de Bogotá',
            '1023' => 'Banco de Occidente',
            '1062' => 'Banco Falabella',
            '1012' => 'Banco GNB Sudameris',
            '1006' => 'Banco Itaú',
            '1060' => 'Banco Pichincha',
            '1002' => 'Banco Popular',
            '1058' => 'Banco Procredit Colombia',
            '1065' => 'Banco Santander',
            '1066' => 'Banco Cooperativo Coopcentral',
            '1051' => 'Banco Davivienda',
            '1009' => 'Citibank Colombia',
            '1014' => 'BBVA Colombia',
            '1013' => 'BANCO CAJA SOCIAL - BCSC',
            '1022' => 'Banco Finandina',
            '1032' => 'Banco W',
            '1292' => 'Confiar',
            '1283' => 'CFA Cooperativa Financiera',
            '1289' => 'Cotrafa Cooperativa Financiera',
            '1370' => 'Coltefinanciera',
            '1551' => 'Daviplata',
            '1303' => 'Movii',
            '1069' => 'Nequi',
            '1801' => 'Banco Serfinanza'
        );
        
        $options = '';
        foreach ($banks as $code => $name) {
            $options .= sprintf('<option value="%s">%s</option>', esc_attr($code), esc_html($name));
        }
        
        return $options;
    }
    
    /**
     * Validar campos del formulario
     */
    public function validate_fields() {
        if (empty($_POST['gp_pse_bank'])) {
            wc_add_notice('Por favor selecciona tu banco', 'error');
            return false;
        }
        
        if (empty($_POST['gp_pse_person_type'])) {
            wc_add_notice('Por favor selecciona el tipo de persona', 'error');
            return false;
        }
        
        if (empty($_POST['gp_pse_document_type'])) {
            wc_add_notice('Por favor selecciona el tipo de documento', 'error');
            return false;
        }
        
        if (empty($_POST['gp_pse_document_number'])) {
            wc_add_notice('Por favor ingresa tu número de documento', 'error');
            return false;
        }
        
        return true;
    }
    
    /**
     * Procesar el pago
     */
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        
        // Guardar información PSE en la orden
        update_post_meta($order_id, '_gp_pse_bank', sanitize_text_field($_POST['gp_pse_bank']));
        update_post_meta($order_id, '_gp_pse_person_type', sanitize_text_field($_POST['gp_pse_person_type']));
        update_post_meta($order_id, '_gp_pse_document_type', sanitize_text_field($_POST['gp_pse_document_type']));
        update_post_meta($order_id, '_gp_pse_document_number', sanitize_text_field($_POST['gp_pse_document_number']));
        
        // Generar referencia única
        $reference = $this->merchant_id . '_' . $order_id . '_' . time();
        update_post_meta($order_id, '_gp_pse_reference', $reference);
        
        // Preparar datos para PayU
        $amount = $order->get_total();
        $currency = get_woocommerce_currency();
        $description = sprintf('Orden #%s - %s', $order->get_order_number(), get_bloginfo('name'));
        
        // URLs de respuesta
        $response_url = WC()->api_request_url('gp_pse_response');
        $confirmation_url = WC()->api_request_url('gp_pse_confirmation');
        
        // Generar firma
        $signature = $this->generate_signature($reference, $amount, $currency);
        
        // Datos del comprador
        $buyer_email = $order->get_billing_email();
        $buyer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        $buyer_phone = $order->get_billing_phone();
        
        // Crear formulario de redirección a PayU
        $form_data = array(
            'merchantId' => $this->merchant_id,
            'accountId' => $this->get_option('account_id'),
            'description' => $description,
            'referenceCode' => $reference,
            'amount' => number_format($amount, 2, '.', ''),
            'tax' => '0',
            'taxReturnBase' => '0',
            'currency' => $currency,
            'signature' => $signature,
            'test' => $this->testmode ? '1' : '0',
            'buyerEmail' => $buyer_email,
            'buyerFullName' => $buyer_name,
            'telephone' => $buyer_phone,
            'responseUrl' => $response_url,
            'confirmationUrl' => $confirmation_url,
            'extra1' => $order_id,
            'paymentMethod' => 'PSE',
            'pseBankId' => sanitize_text_field($_POST['gp_pse_bank']),
            'psePersonType' => sanitize_text_field($_POST['gp_pse_person_type']),
            'pseDocumentType' => sanitize_text_field($_POST['gp_pse_document_type']),
            'pseDocumentNumber' => sanitize_text_field($_POST['gp_pse_document_number'])
        );
        
        // Marcar orden como pendiente
        $order->update_status('pending', 'Esperando pago PSE');
        
        // Reducir stock
        wc_reduce_stock_levels($order_id);
        
        // Vaciar carrito
        WC()->cart->empty_cart();
        
        // Retornar redirección
        return array(
            'result' => 'success',
            'redirect' => $this->get_payment_url($form_data)
        );
    }
    
    /**
     * Generar URL de pago
     */
    private function get_payment_url($data) {
        return add_query_arg($data, $this->api_url);
    }
    
    /**
     * Generar firma MD5
     */
    private function generate_signature($reference, $amount, $currency) {
        $amount_formatted = number_format($amount, 1, '.', '');
        $string = $this->api_key . '~' . $this->merchant_id . '~' . $reference . '~' . $amount_formatted . '~' . $currency;
        return md5($string);
    }
    
    /**
     * Manejar respuesta de PSE (página de respuesta)
     */
    public function handle_response() {
        $order_id = isset($_REQUEST['extra1']) ? intval($_REQUEST['extra1']) : 0;
        
        if (!$order_id) {
            wp_die('Orden no encontrada');
        }
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_die('Orden no válida');
        }
        
        $transaction_state = isset($_REQUEST['transactionState']) ? intval($_REQUEST['transactionState']) : 0;
        
        switch ($transaction_state) {
            case 4: // Aprobada
                $order->payment_complete();
                $order->add_order_note('Pago PSE aprobado. ID de transacción: ' . sanitize_text_field($_REQUEST['transactionId']));
                wp_redirect($this->get_return_url($order));
                break;
                
            case 6: // Rechazada
                $order->update_status('failed', 'Pago PSE rechazado');
                wc_add_notice('Tu pago fue rechazado. Por favor intenta nuevamente.', 'error');
                wp_redirect(wc_get_checkout_url());
                break;
                
            case 7: // Pendiente
                $order->update_status('on-hold', 'Pago PSE pendiente de confirmación');
                wc_add_notice('Tu pago está siendo procesado. Te notificaremos cuando se confirme.', 'notice');
                wp_redirect($this->get_return_url($order));
                break;
                
            default:
                wc_add_notice('Estado de pago desconocido', 'error');
                wp_redirect(wc_get_checkout_url());
        }
        
        exit;
    }
    
    /**
     * Manejar confirmación de PSE (webhook)
     */
    public function handle_confirmation() {
        $order_id = isset($_REQUEST['extra1']) ? intval($_REQUEST['extra1']) : 0;
        
        if (!$order_id) {
            status_header(400);
            die('Order ID missing');
        }
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            status_header(404);
            die('Order not found');
        }
        
        // Validar firma
        $signature_received = isset($_REQUEST['signature']) ? sanitize_text_field($_REQUEST['signature']) : '';
        $reference = isset($_REQUEST['referenceCode']) ? sanitize_text_field($_REQUEST['referenceCode']) : '';
        $amount = isset($_REQUEST['TX_VALUE']) ? floatval($_REQUEST['TX_VALUE']) : 0;
        $currency = isset($_REQUEST['currency']) ? sanitize_text_field($_REQUEST['currency']) : '';
        $state_pol = isset($_REQUEST['state_pol']) ? intval($_REQUEST['state_pol']) : 0;
        
        // Generar firma esperada
        $expected_signature = md5($this->api_key . '~' . $this->merchant_id . '~' . $reference . '~' . 
                                  number_format($amount, 1, '.', '') . '~' . $currency . '~' . $state_pol);
        
        if ($signature_received !== $expected_signature) {
            $order->add_order_note('PSE: Firma inválida en confirmación');
            status_header(400);
            die('Invalid signature');
        }
        
        // Procesar según estado
        switch ($state_pol) {
            case 4: // Aprobada
                if ($order->get_status() !== 'completed' && $order->get_status() !== 'processing') {
                    $order->payment_complete();
                    $order->add_order_note(sprintf(
                        'Pago PSE confirmado. Transacción: %s, Referencia: %s',
                        sanitize_text_field($_REQUEST['transactionId']),
                        $reference
                    ));
                }
                break;
                
            case 6: // Rechazada
                $order->update_status('failed', 'Pago PSE rechazado en confirmación');
                break;
                
            case 5: // Expirada
                $order->update_status('cancelled', 'Pago PSE expirado');
                break;
        }
        
        // Responder OK a PayU
        status_header(200);
        die('OK');
    }
    
    /**
     * Procesar reembolso
     */
    public function process_refund($order_id, $amount = null, $reason = '') {
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return new WP_Error('invalid_order', 'Orden inválida');
        }
        
        // Implementar lógica de reembolso con API de PayU
        // Nota: PSE generalmente no soporta reembolsos automáticos
        // Se debe hacer manualmente
        
        $order->add_order_note(sprintf(
            'Solicitud de reembolso: %s. Razón: %s. NOTA: Los reembolsos PSE deben procesarse manualmente.',
            wc_price($amount),
            $reason
        ));
        
        return true;
    }
}

// ============================================
// REGISTRAR PASARELA PSE
// ============================================

function gp_add_pse_gateway($gateways) {
    $gateways[] = 'GP_PSE_Gateway';
    return $gateways;
}
add_filter('woocommerce_payment_gateways', 'gp_add_pse_gateway');

// ============================================
// ESTILOS PARA PSE
// ============================================

add_action('wp_head', function() {
    ?>
    <style>
    .gp-pse-payment-fields {
        background: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        margin-top: 15px;
    }
    
    .gp-pse-payment-fields .form-row {
        margin-bottom: 15px;
    }
    
    .gp-pse-payment-fields label {
        font-weight: 600;
        display: block;
        margin-bottom: 5px;
        color: #333;
    }
    
    .gp-pse-payment-fields select,
    .gp-pse-payment-fields input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
    }
    
    .gp-pse-payment-fields select:focus,
    .gp-pse-payment-fields input:focus {
        border-color: #D4AF37;
        outline: none;
        box-shadow: 0 0 0 2px rgba(212, 175, 55, 0.1);
    }
    
    .gp-pse-info {
        font-size: 13px;
        line-height: 1.6;
    }
    
    .payment_method_gp_pse img {
        max-height: 30px;
        margin-left: 10px;
    }
    </style>
    <?php
});

// ============================================
// WEBHOOK PARA NOTIFICACIONES
// ============================================

/**
 * Endpoint para recibir notificaciones de PayU
 */
add_action('rest_api_init', function() {
    register_rest_route('golden-phoenix/v1', '/pse/webhook', array(
        'methods' => 'POST',
        'callback' => 'gp_pse_webhook_handler',
        'permission_callback' => '__return_true'
    ));
});

function gp_pse_webhook_handler($request) {
    $data = $request->get_json_params();
    
    // Log para debugging
    error_log('PSE Webhook recibido: ' . print_r($data, true));
    
    if (isset($data['reference_pol'])) {
        // Procesar notificación
        $reference = sanitize_text_field($data['reference_pol']);
        
        // Buscar orden por referencia
        $orders = wc_get_orders(array(
            'meta_key' => '_gp_pse_reference',
            'meta_value' => $reference,
            'limit' => 1
        ));
        
        if (!empty($orders)) {
            $order = $orders[0];
            
            // Actualizar estado según respuesta
            if (isset($data['state_pol'])) {
                switch ($data['state_pol']) {
                    case 4:
                        $order->payment_complete();
                        break;
                    case 6:
                        $order->update_status('failed');
                        break;
                }
            }
        }
    }
    
    return new WP_REST_Response(array('status' => 'ok'), 200);
}
