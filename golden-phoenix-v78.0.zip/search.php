<?php
/**
 * Search Results Template
 * Plantilla para resultados de búsqueda
 */

get_header();
?>

<div class="search-results-wrapper" style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); min-height: 100vh; padding: 80px 0;">
    
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        
        <!-- HEADER BÚSQUEDA -->
        <header class="search-header" style="margin-bottom: 50px; text-align: center;">
            
            <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 20px;">
                🔍 Resultados de búsqueda
            </h1>
            
            <p style="font-size: 20px; color: #999; margin: 0 0 30px;">
                Buscaste: <span style="color: #c9a961; font-weight: 600;">"<?php echo get_search_query(); ?>"</span>
            </p>
            
            <!-- FORMULARIO DE BÚSQUEDA -->
            <div style="max-width: 600px; margin: 0 auto;">
                <form role="search" method="get" action="<?php echo home_url('/'); ?>" style="display: flex; gap: 10px;">
                    <input type="search" name="s" value="<?php echo get_search_query(); ?>" placeholder="Buscar de nuevo..." style="flex: 1; padding: 15px 25px; border: 2px solid rgba(201,169,97,0.3); border-radius: 50px; background: rgba(255,255,255,0.05); color: #fff; font-size: 16px;">
                    <button type="submit" style="background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 15px 40px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer; transition: all 0.3s;">
                        Buscar
                    </button>
                </form>
            </div>
            
        </header>
        
        <?php if (have_posts()): ?>
            
            <!-- CONTADOR DE RESULTADOS -->
            <div style="margin-bottom: 30px; color: #ccc; font-size: 16px;">
                Se encontraron <strong style="color: #c9a961;"><?php echo $wp_query->found_posts; ?></strong> resultados
            </div>
            
            <!-- GRID DE RESULTADOS -->
            <div class="search-results-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 30px; margin-bottom: 60px;">
                
                <?php while (have_posts()): the_post(); ?>
                    
                    <article class="search-result-item" style="background: rgba(255,255,255,0.05); border-radius: 15px; overflow: hidden; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                        
                        <?php if (has_post_thumbnail()): ?>
                            <div class="result-thumbnail" style="height: 200px; overflow: hidden;">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('medium', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="result-content" style="padding: 25px;">
                            
                            <!-- TIPO DE CONTENIDO -->
                            <div style="margin-bottom: 10px;">
                                <?php
                                $post_type = get_post_type();
                                $type_label = '';
                                $type_icon = '';
                                
                                if ($post_type === 'product') {
                                    $type_label = 'Producto';
                                    $type_icon = '🛍️';
                                } elseif ($post_type === 'post') {
                                    $type_label = 'Blog';
                                    $type_icon = '📝';
                                } else {
                                    $type_label = 'Página';
                                    $type_icon = '📄';
                                }
                                ?>
                                <span style="display: inline-block; background: rgba(201,169,97,0.2); color: #c9a961; padding: 5px 15px; border-radius: 50px; font-size: 12px; font-weight: 600;">
                                    <?php echo $type_icon . ' ' . $type_label; ?>
                                </span>
                            </div>
                            
                            <!-- TÍTULO -->
                            <h2 style="font-size: 20px; font-weight: 600; margin: 0 0 15px;">
                                <a href="<?php the_permalink(); ?>" style="color: #fff; text-decoration: none; transition: color 0.3s;">
                                    <?php the_title(); ?>
                                </a>
                            </h2>
                            
                            <!-- EXCERPT -->
                            <div style="color: #ccc; font-size: 14px; line-height: 1.6; margin-bottom: 20px;">
                                <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
                            </div>
                            
                            <!-- PRECIO (si es producto) -->
                            <?php if ($post_type === 'product'): ?>
                                <div style="margin-bottom: 15px;">
                                    <?php
                                    $product = wc_get_product(get_the_ID());
                                    if ($product) {
                                        echo '<span style="color: #c9a961; font-size: 24px; font-weight: 700;">' . $product->get_price_html() . '</span>';
                                    }
                                    ?>
                                </div>
                            <?php endif; ?>
                            
                            <!-- BOTÓN -->
                            <a href="<?php the_permalink(); ?>" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 10px 25px; border-radius: 50px; text-decoration: none; font-weight: 600; font-size: 14px; transition: all 0.3s;">
                                Ver <?php echo $type_label; ?> →
                            </a>
                            
                        </div>
                        
                    </article>
                    
                <?php endwhile; ?>
                
            </div>
            
            <!-- PAGINACIÓN -->
            <div class="pagination">
                <?php
                echo paginate_links(array(
                    'prev_text' => '← Anterior',
                    'next_text' => 'Siguiente →',
                ));
                ?>
            </div>
            
        <?php else: ?>
            
            <!-- SIN RESULTADOS -->
            <div style="text-align: center; padding: 80px 20px; background: rgba(255,255,255,0.05); border-radius: 20px;">
                
                <div style="font-size: 80px; margin-bottom: 30px;">😔</div>
                
                <h2 style="color: #fff; font-size: 32px; margin: 0 0 20px;">
                    No se encontraron resultados
                </h2>
                
                <p style="color: #999; font-size: 18px; margin: 0 0 40px; max-width: 600px; margin-left: auto; margin-right: auto;">
                    No pudimos encontrar nada para "<strong style="color: #c9a961;"><?php echo get_search_query(); ?></strong>". 
                    Intenta con otros términos o explora nuestras categorías.
                </p>
                
                <!-- SUGERENCIAS -->
                <div style="max-width: 800px; margin: 0 auto 40px; padding: 30px; background: rgba(255,255,255,0.03); border-radius: 15px; text-align: left;">
                    <h3 style="color: #c9a961; font-size: 20px; margin: 0 0 20px;">💡 Sugerencias:</h3>
                    <ul style="color: #ccc; font-size: 16px; line-height: 2;">
                        <li>Verifica la ortografía de las palabras</li>
                        <li>Intenta con palabras clave diferentes</li>
                        <li>Usa términos más generales</li>
                        <li>Prueba con sinónimos</li>
                    </ul>
                </div>
                
                <!-- CATEGORÍAS POPULARES -->
                <div style="margin-bottom: 30px;">
                    <h3 style="color: #fff; font-size: 20px; margin: 0 0 20px;">Categorías Populares:</h3>
                    <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 10px;">
                        <?php
                        $categories = get_categories(array('number' => 6));
                        foreach ($categories as $category):
                        ?>
                            <a href="<?php echo get_category_link($category->term_id); ?>" style="background: rgba(201,169,97,0.2); color: #c9a961; padding: 10px 20px; border-radius: 50px; text-decoration: none; transition: all 0.3s;">
                                <?php echo $category->name; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- BOTONES DE ACCIÓN -->
                <div style="display: flex; justify-content: center; gap: 15px;">
                    <a href="<?php echo home_url('/'); ?>" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 15px 40px; border-radius: 50px; text-decoration: none; font-weight: 600; font-size: 16px;">
                        🏠 Volver al Inicio
                    </a>
                    <?php if (function_exists('WC')): ?>
                        <a href="<?php echo wc_get_page_permalink('shop'); ?>" style="display: inline-block; background: rgba(255,255,255,0.1); color: #fff; padding: 15px 40px; border-radius: 50px; text-decoration: none; font-weight: 600; font-size: 16px; border: 2px solid rgba(201,169,97,0.3);">
                            🛍️ Ver Tienda
                        </a>
                    <?php endif; ?>
                </div>
                
            </div>
            
        <?php endif; ?>
        
    </div>
    
</div>

<?php get_footer(); ?>
