<?php
/**
 * Template Name: Colecciones
 * Página de Colecciones de Joyería
 * 
 * @package Golden_Phoenix
 */

get_header();
?>

<div class="collections-page">
    
    <!-- Hero de Colecciones -->
    <section class="collections-hero" style="background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%); padding: 100px 20px; text-align: center; color: white;">
        <div class="container">
            <h1 style="font-size: 48px; margin-bottom: 20px; font-family: 'Playfair Display', serif;">
                <?php echo gp_get_text('gp_collections_title', 'Nuestras Colecciones'); ?>
            </h1>
            <p style="font-size: 18px; max-width: 600px; margin: 0 auto; opacity: 0.9;">
                <?php echo gp_get_text('gp_collections_subtitle', 'Descubre nuestras exclusivas líneas de joyería de alta gama'); ?>
            </p>
        </div>
    </section>
    
    <!-- Grid de Colecciones -->
    <section class="collections-grid" style="padding: 80px 20px; background: white;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            
            <?php
            // Obtener categorías de productos como colecciones
            $collections = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
                'parent' => 0 // Solo categorías principales
            ));
            
            if ($collections && !is_wp_error($collections)) :
            ?>
            
            <div class="collections-grid-container" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 40px;">
                
                <?php foreach ($collections as $collection) : 
                    $thumbnail_id = get_term_meta($collection->term_id, 'thumbnail_id', true);
                    $image = wp_get_attachment_url($thumbnail_id);
                    
                    // Si no hay imagen, usar placeholder
                    if (!$image) {
                        $image = 'https://via.placeholder.com/600x400/0A0A0A/D4AF37?text=' . urlencode($collection->name);
                    }
                    
                    $collection_link = get_term_link($collection);
                ?>
                
                <div class="collection-card" style="position: relative; overflow: hidden; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); transition: transform 0.3s;">
                    
                    <!-- Imagen de la colección -->
                    <div class="collection-image" style="height: 400px; overflow: hidden;">
                        <a href="<?php echo esc_url($collection_link); ?>">
                            <img src="<?php echo esc_url($image); ?>" 
                                 alt="<?php echo esc_attr($collection->name); ?>"
                                 style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s;"
                                 onmouseover="this.style.transform='scale(1.1)'"
                                 onmouseout="this.style.transform='scale(1)'">
                        </a>
                    </div>
                    
                    <!-- Info de la colección -->
                    <div class="collection-info" style="padding: 30px; background: white;">
                        <h3 style="font-size: 24px; margin-bottom: 10px; font-family: 'Playfair Display', serif;">
                            <a href="<?php echo esc_url($collection_link); ?>" style="color: #0A0A0A; text-decoration: none;">
                                <?php echo esc_html($collection->name); ?>
                            </a>
                        </h3>
                        
                        <?php if ($collection->description) : ?>
                        <p style="color: #666; margin-bottom: 20px; line-height: 1.6;">
                            <?php echo esc_html(wp_trim_words($collection->description, 15)); ?>
                        </p>
                        <?php endif; ?>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #D4AF37; font-weight: 600;">
                                <?php echo $collection->count; ?> Piezas
                            </span>
                            
                            <a href="<?php echo esc_url($collection_link); ?>" 
                               class="collection-button"
                               style="background: #D4AF37; color: white; padding: 12px 30px; border-radius: 4px; text-decoration: none; font-weight: 600; transition: background 0.3s;"
                               onmouseover="this.style.background='#0A0A0A'"
                               onmouseout="this.style.background='#D4AF37'">
                                Ver Colección →
                            </a>
                        </div>
                    </div>
                    
                </div>
                
                <?php endforeach; ?>
                
            </div>
            
            <?php else : ?>
            
            <div style="text-align: center; padding: 60px 20px;">
                <h2 style="font-size: 32px; margin-bottom: 20px;">No hay colecciones disponibles</h2>
                <p style="color: #666; margin-bottom: 30px;">
                    Crea categorías de productos en WooCommerce para mostrarlas aquí como colecciones.
                </p>
                <a href="<?php echo admin_url('edit-tags.php?taxonomy=product_cat&post_type=product'); ?>" 
                   style="background: #D4AF37; color: white; padding: 15px 40px; border-radius: 4px; text-decoration: none; display: inline-block;">
                    Crear Colecciones
                </a>
            </div>
            
            <?php endif; ?>
            
        </div>
    </section>
    
    <!-- Call to Action -->
    <section class="collections-cta" style="background: #F8F8F8; padding: 80px 20px; text-align: center;">
        <div class="container" style="max-width: 800px; margin: 0 auto;">
            <h2 style="font-size: 36px; margin-bottom: 20px; font-family: 'Playfair Display', serif;">
                ¿Buscas algo especial?
            </h2>
            <p style="color: #666; font-size: 18px; margin-bottom: 30px;">
                Nuestros expertos están listos para ayudarte a encontrar la joya perfecta o crear una pieza personalizada.
            </p>
            <a href="<?php echo home_url('/contacto'); ?>" 
               style="background: #D4AF37; color: white; padding: 18px 50px; border-radius: 4px; text-decoration: none; font-size: 16px; font-weight: 600; display: inline-block; transition: background 0.3s;"
               onmouseover="this.style.background='#0A0A0A'"
               onmouseout="this.style.background='#D4AF37'">
                Contactar Asesor
            </a>
        </div>
    </section>
    
</div>

<style>
.collection-card:hover {
    transform: translateY(-10px);
}

@media (max-width: 768px) {
    .collections-grid-container {
        grid-template-columns: 1fr !important;
    }
    
    .collections-hero h1 {
        font-size: 32px !important;
    }
}
</style>

<?php get_footer(); ?>
