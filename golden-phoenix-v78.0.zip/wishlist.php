<?php
/**
 * Golden Phoenix - Sistema de Wishlist/Lista de Deseos
 * Permite guardar productos favoritos sin registro
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// CREAR PÁGINA DE WISHLIST
// ============================================

// DESHABILITADO - Causaba loop infinito
// La página se crea en functions.php con after_switch_theme
// add_action('init', 'gp_create_wishlist_page');

function gp_create_wishlist_page() {
    // Crear página de wishlist si no existe
    $wishlist_page = get_page_by_path('lista-de-deseos');
    
    if (!$wishlist_page) {
        $page_id = wp_insert_post(array(
            'post_title' => 'Lista de Deseos',
            'post_name' => 'lista-de-deseos',
            'post_content' => '[golden_phoenix_wishlist]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'comment_status' => 'closed'
        ));
        
        update_option('gp_wishlist_page_id', $page_id);
    }
}

// ============================================
// SHORTCODE PARA WISHLIST
// ============================================

add_shortcode('golden_phoenix_wishlist', 'gp_wishlist_shortcode');

function gp_wishlist_shortcode() {
    ob_start();
    
    $wishlist = gp_get_wishlist();
    
    ?>
    <div class="gp-wishlist-page">
        <div class="wishlist-header" style="text-align: center; margin-bottom: 50px;">
            <h1 style="font-size: 48px; font-family: 'Playfair Display', serif; margin-bottom: 15px;">
                💎 Mi Lista de Deseos
            </h1>
            <p style="color: #666; font-size: 18px;">
                Tus joyas favoritas guardadas para después
            </p>
        </div>
        
        <?php if (empty($wishlist)) : ?>
        
        <div class="wishlist-empty" style="text-align: center; padding: 80px 20px; background: white; border-radius: 8px;">
            <div style="font-size: 80px; margin-bottom: 20px; opacity: 0.3;">💔</div>
            <h2 style="font-size: 28px; margin-bottom: 15px;">Tu lista está vacía</h2>
            <p style="color: #666; margin-bottom: 30px;">
                Explora nuestras colecciones y guarda tus joyas favoritas
            </p>
            <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
               style="display: inline-block; background: #D4AF37; color: white; padding: 18px 45px; border-radius: 4px; text-decoration: none; font-weight: 600;">
                Explorar Joyas
            </a>
        </div>
        
        <?php else : ?>
        
        <div class="wishlist-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
            
            <?php foreach ($wishlist as $product_id) : 
                $product = wc_get_product($product_id);
                if (!$product) continue;
            ?>
            
            <div class="wishlist-item" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 15px rgba(0,0,0,0.08); position: relative;">
                
                <!-- Botón eliminar -->
                <button class="remove-wishlist" 
                        onclick="removeFromWishlist(<?php echo $product_id; ?>)"
                        style="position: absolute; top: 15px; right: 15px; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.9); border: none; cursor: pointer; z-index: 10; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1);"
                        onmouseover="this.style.background='#dc3545'; this.querySelector('i').style.color='white';"
                        onmouseout="this.style.background='rgba(255,255,255,0.9)'; this.querySelector('i').style.color='#dc3545';">
                    <i class="fas fa-times" style="color: #dc3545; font-size: 16px; transition: color 0.3s;"></i>
                </button>
                
                <!-- Imagen -->
                <a href="<?php echo get_permalink($product_id); ?>">
                    <div style="height: 350px; overflow: hidden; background: #f9f9f9;">
                        <?php echo $product->get_image('large', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                    </div>
                </a>
                
                <!-- Info -->
                <div style="padding: 25px;">
                    <h3 style="font-size: 18px; margin-bottom: 10px;">
                        <a href="<?php echo get_permalink($product_id); ?>" style="text-decoration: none; color: #0A0A0A;">
                            <?php echo $product->get_name(); ?>
                        </a>
                    </h3>
                    
                    <div style="color: #D4AF37; font-size: 22px; font-weight: 700; margin-bottom: 15px;">
                        <?php echo $product->get_price_html(); ?>
                    </div>
                    
                    <?php if ($product->is_in_stock()) : ?>
                    <button onclick="addToCartFromWishlist(<?php echo $product_id; ?>)" 
                            style="width: 100%; background: #D4AF37; color: white; border: none; padding: 12px; border-radius: 4px; font-weight: 600; cursor: pointer; transition: background 0.3s;"
                            onmouseover="this.style.background='#0A0A0A'"
                            onmouseout="this.style.background='#D4AF37'">
                        Agregar al Carrito
                    </button>
                    <?php else : ?>
                    <button disabled style="width: 100%; background: #ccc; color: #666; border: none; padding: 12px; border-radius: 4px; font-weight: 600;">
                        Agotado
                    </button>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php endforeach; ?>
            
        </div>
        
        <!-- Compartir Wishlist -->
        <div style="margin-top: 50px; text-align: center; padding: 30px; background: #f9f9f9; border-radius: 8px;">
            <h3 style="font-size: 20px; margin-bottom: 15px;">Compartir mi lista</h3>
            <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                <button onclick="shareWishlist('whatsapp')" style="background: #25D366; color: white; border: none; padding: 12px 30px; border-radius: 4px; cursor: pointer; font-weight: 600;">
                    <i class="fab fa-whatsapp"></i> WhatsApp
                </button>
                <button onclick="shareWishlist('email')" style="background: #0A0A0A; color: white; border: none; padding: 12px 30px; border-radius: 4px; cursor: pointer; font-weight: 600;">
                    <i class="fas fa-envelope"></i> Email
                </button>
                <button onclick="shareWishlist('copy')" style="background: #D4AF37; color: white; border: none; padding: 12px 30px; border-radius: 4px; cursor: pointer; font-weight: 600;">
                    <i class="fas fa-link"></i> Copiar Enlace
                </button>
            </div>
        </div>
        
        <?php endif; ?>
        
    </div>
    
    <style>
    @media (max-width: 768px) {
        .wishlist-grid {
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)) !important;
        }
    }
    
    @media (max-width: 480px) {
        .wishlist-grid {
            grid-template-columns: 1fr !important;
        }
    }
    </style>
    
    <script>
    // Eliminar de wishlist
    function removeFromWishlist(productId) {
        if (!confirm('¿Eliminar de tu lista de deseos?')) return;
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=remove_from_wishlist&product_id=' + productId
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        });
    }
    
    // Agregar al carrito desde wishlist
    function addToCartFromWishlist(productId) {
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=add_to_cart&product_id=' + productId + '&quantity=1'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('¡Agregado al carrito!');
                location.href = '<?php echo wc_get_cart_url(); ?>';
            }
        });
    }
    
    // Compartir wishlist
    function shareWishlist(method) {
        const url = window.location.href;
        const text = 'Mira mi lista de joyas favoritas en Golden Phoenix';
        
        switch(method) {
            case 'whatsapp':
                window.open('https://wa.me/?text=' + encodeURIComponent(text + ' ' + url));
                break;
            case 'email':
                window.location.href = 'mailto:?subject=' + encodeURIComponent(text) + '&body=' + encodeURIComponent(url);
                break;
            case 'copy':
                navigator.clipboard.writeText(url).then(() => {
                    alert('¡Enlace copiado al portapapeles!');
                });
                break;
        }
    }
    </script>
    <?php
    
    return ob_get_clean();
}

// ============================================
// FUNCIONES DE WISHLIST
// ============================================

// Obtener wishlist
function gp_get_wishlist() {
    if (is_user_logged_in()) {
        $wishlist = get_user_meta(get_current_user_id(), 'gp_wishlist', true);
    } else {
        $wishlist = isset($_COOKIE['gp_wishlist']) ? json_decode(stripslashes($_COOKIE['gp_wishlist']), true) : array();
    }
    
    return is_array($wishlist) ? $wishlist : array();
}

// Guardar wishlist
function gp_save_wishlist($wishlist) {
    if (is_user_logged_in()) {
        update_user_meta(get_current_user_id(), 'gp_wishlist', $wishlist);
    } else {
        setcookie('gp_wishlist', json_encode($wishlist), time() + (86400 * 30), '/');
    }
}

// Agregar a wishlist
add_action('wp_ajax_add_to_wishlist', 'gp_add_to_wishlist');
add_action('wp_ajax_nopriv_add_to_wishlist', 'gp_add_to_wishlist');

function gp_add_to_wishlist() {
    $product_id = intval($_POST['product_id']);
    $wishlist = gp_get_wishlist();
    
    if (!in_array($product_id, $wishlist)) {
        $wishlist[] = $product_id;
        gp_save_wishlist($wishlist);
    }
    
    wp_send_json_success(array(
        'count' => count($wishlist),
        'message' => 'Agregado a favoritos'
    ));
}

// Eliminar de wishlist
add_action('wp_ajax_remove_from_wishlist', 'gp_remove_from_wishlist');
add_action('wp_ajax_nopriv_remove_from_wishlist', 'gp_remove_from_wishlist');

function gp_remove_from_wishlist() {
    $product_id = intval($_POST['product_id']);
    $wishlist = gp_get_wishlist();
    
    $key = array_search($product_id, $wishlist);
    if ($key !== false) {
        unset($wishlist[$key]);
        $wishlist = array_values($wishlist);
        gp_save_wishlist($wishlist);
    }
    
    wp_send_json_success(array(
        'count' => count($wishlist),
        'message' => 'Eliminado de favoritos'
    ));
}

// Verificar si está en wishlist
add_action('wp_ajax_check_wishlist', 'gp_check_wishlist');
add_action('wp_ajax_nopriv_check_wishlist', 'gp_check_wishlist');

function gp_check_wishlist() {
    $product_id = intval($_POST['product_id']);
    $wishlist = gp_get_wishlist();
    
    wp_send_json_success(array(
        'in_wishlist' => in_array($product_id, $wishlist),
        'count' => count($wishlist)
    ));
}

// ============================================
// BOTÓN DE WISHLIST EN PRODUCTOS
// ============================================

add_action('woocommerce_after_add_to_cart_button', 'gp_wishlist_button');

function gp_wishlist_button() {
    global $product;
    $product_id = $product->get_id();
    $wishlist = gp_get_wishlist();
    $in_wishlist = in_array($product_id, $wishlist);
    
    ?>
    <button type="button" 
            class="gp-wishlist-toggle" 
            data-product-id="<?php echo $product_id; ?>"
            style="width: 100%; margin-top: 15px; background: transparent; border: 2px solid <?php echo $in_wishlist ? '#dc3545' : '#D4AF37'; ?>; color: <?php echo $in_wishlist ? '#dc3545' : '#D4AF37'; ?>; padding: 12px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: all 0.3s;">
        <i class="fas fa-heart<?php echo $in_wishlist ? '' : '-o'; ?>"></i>
        <span><?php echo $in_wishlist ? 'En Favoritos' : 'Agregar a Favoritos'; ?></span>
    </button>
    
    <script>
    document.querySelector('.gp-wishlist-toggle').addEventListener('click', function() {
        const btn = this;
        const productId = btn.dataset.productId;
        const isInWishlist = btn.querySelector('i').classList.contains('fa-heart');
        
        const action = isInWishlist ? 'remove_from_wishlist' : 'add_to_wishlist';
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=${action}&product_id=${productId}`
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                if (isInWishlist) {
                    btn.querySelector('i').classList.remove('fa-heart');
                    btn.querySelector('i').classList.add('fa-heart-o');
                    btn.querySelector('span').textContent = 'Agregar a Favoritos';
                    btn.style.borderColor = '#D4AF37';
                    btn.style.color = '#D4AF37';
                } else {
                    btn.querySelector('i').classList.remove('fa-heart-o');
                    btn.querySelector('i').classList.add('fa-heart');
                    btn.querySelector('span').textContent = 'En Favoritos';
                    btn.style.borderColor = '#dc3545';
                    btn.style.color = '#dc3545';
                }
                
                // Actualizar contador en header
                const counter = document.querySelector('.wishlist-count');
                if (counter) counter.textContent = data.data.count;
            }
        });
    });
    </script>
    <?php
}

// ============================================
// ACTUALIZAR CONTADOR EN HEADER
// ============================================

add_action('wp_footer', 'gp_wishlist_counter_script');

function gp_wishlist_counter_script() {
    $wishlist = gp_get_wishlist();
    $count = count($wishlist);
    ?>
    <script>
    // Actualizar contador al cargar
    document.addEventListener('DOMContentLoaded', function() {
        const counter = document.querySelector('.wishlist-count');
        if (counter) {
            counter.textContent = '<?php echo $count; ?>';
            if (<?php echo $count; ?> > 0) {
                counter.style.display = 'flex';
            }
        }
    });
    </script>
    <?php
}
