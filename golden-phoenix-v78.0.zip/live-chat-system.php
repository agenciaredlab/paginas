<?php
/**
 * GOLDEN PHOENIX V65 - CHAT EN VIVO CON AGENTES HUMANOS
 * Integración: Panel Admin + Chatwoot + N8N + Transferencia Bot→Humano
 */

if (!defined('ABSPATH')) exit;

class GP_Live_Chat_System {
    
    private $db_version = '1.0';
    private $table_conversations;
    private $table_messages;
    private $table_agents;
    
    public function __construct() {
        global $wpdb;
        $this->table_conversations = $wpdb->prefix . 'gp_conversations';
        $this->table_messages = $wpdb->prefix . 'gp_messages';
        $this->table_agents = $wpdb->prefix . 'gp_agents';
        
        // Hooks
        add_action('admin_menu', array($this, 'add_admin_pages'));
        add_action('wp_ajax_gp_chat_send_message', array($this, 'handle_send_message'));
        add_action('wp_ajax_nopriv_gp_chat_send_message', array($this, 'handle_send_message'));
        add_action('wp_ajax_gp_chat_get_messages', array($this, 'get_new_messages'));
        add_action('wp_ajax_nopriv_gp_chat_get_messages', array($this, 'get_new_messages'));
        add_action('wp_ajax_gp_chat_transfer_to_human', array($this, 'transfer_to_human'));
        add_action('wp_ajax_nopriv_gp_chat_transfer_to_human', array($this, 'transfer_to_human'));
        add_action('wp_ajax_gp_agent_reply', array($this, 'agent_reply'));
        add_action('wp_ajax_gp_get_agent_conversations', array($this, 'get_agent_conversations'));
        add_action('wp_ajax_gp_close_conversation', array($this, 'close_conversation'));
        
        // Crear tablas
        register_activation_hook(__FILE__, array($this, 'create_tables'));
    }
    
    // =============================================
    // CREAR TABLAS EN BASE DE DATOS
    // =============================================
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Tabla de conversaciones
        $sql1 = "CREATE TABLE IF NOT EXISTS {$this->table_conversations} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            user_name varchar(255) DEFAULT NULL,
            user_email varchar(255) DEFAULT NULL,
            user_phone varchar(50) DEFAULT NULL,
            status varchar(20) DEFAULT 'active',
            assigned_agent int(11) DEFAULT NULL,
            mode varchar(20) DEFAULT 'bot',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY status (status)
        ) $charset_collate;";
        
        // Tabla de mensajes
        $sql2 = "CREATE TABLE IF NOT EXISTS {$this->table_messages} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            conversation_id bigint(20) NOT NULL,
            sender_type varchar(20) NOT NULL,
            sender_id int(11) DEFAULT NULL,
            message text NOT NULL,
            metadata text DEFAULT NULL,
            is_read tinyint(1) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY conversation_id (conversation_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Tabla de agentes
        $sql3 = "CREATE TABLE IF NOT EXISTS {$this->table_agents} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            display_name varchar(255) NOT NULL,
            avatar_url varchar(500) DEFAULT NULL,
            status varchar(20) DEFAULT 'offline',
            last_seen datetime DEFAULT NULL,
            active_conversations int(11) DEFAULT 0,
            total_conversations int(11) DEFAULT 0,
            rating_avg decimal(3,2) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql1);
        dbDelta($sql2);
        dbDelta($sql3);
    }
    
    // =============================================
    // AGREGAR PÁGINAS AL ADMIN
    // =============================================
    public function add_admin_pages() {
        // Página principal
        add_menu_page(
            'Chat en Vivo',
            'Chat en Vivo',
            'read',
            'gp-live-chat',
            array($this, 'render_chat_dashboard'),
            'dashicons-format-chat',
            25
        );
        
        // Subpágina: Panel de chat
        add_submenu_page(
            'gp-live-chat',
            'Panel de Chat',
            'Panel de Chat',
            'read',
            'gp-live-chat',
            array($this, 'render_chat_dashboard')
        );
        
        // Subpágina: Configuración
        add_submenu_page(
            'gp-live-chat',
            'Configuración',
            'Configuración',
            'manage_options',
            'gp-live-chat-settings',
            array($this, 'render_settings_page')
        );
        
        // Subpágina: Estadísticas
        add_submenu_page(
            'gp-live-chat',
            'Estadísticas',
            'Estadísticas',
            'manage_options',
            'gp-live-chat-stats',
            array($this, 'render_stats_page')
        );
    }
    
    // =============================================
    // PANEL DE CHAT PARA AGENTES
    // =============================================
    public function render_chat_dashboard() {
        $current_user = wp_get_current_user();
        $agent = $this->get_or_create_agent($current_user->ID);
        ?>
        <div class="wrap gp-chat-dashboard">
            <h1>💬 Panel de Chat en Vivo</h1>
            
            <div class="gp-chat-container" style="display: flex; gap: 20px; margin-top: 20px;">
                
                <!-- COLUMNA IZQUIERDA: Lista de conversaciones -->
                <div class="gp-conversations-list" style="width: 350px; background: #fff; border: 1px solid #ccc; border-radius: 8px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h2 style="margin: 0;">Conversaciones</h2>
                        <div class="gp-agent-status">
                            <select id="gp-agent-status-select" onchange="gpChat.updateAgentStatus(this.value)" style="padding: 5px 10px; border-radius: 4px;">
                                <option value="online" <?php selected($agent->status, 'online'); ?>>🟢 En línea</option>
                                <option value="away" <?php selected($agent->status, 'away'); ?>>🟡 Ausente</option>
                                <option value="offline" <?php selected($agent->status, 'offline'); ?>>🔴 Desconectado</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="gp-filter-tabs" style="display: flex; gap: 10px; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                        <button class="gp-tab active" onclick="gpChat.filterConversations('active')">Activas (<span id="count-active">0</span>)</button>
                        <button class="gp-tab" onclick="gpChat.filterConversations('waiting')">En espera (<span id="count-waiting">0</span>)</button>
                        <button class="gp-tab" onclick="gpChat.filterConversations('closed')">Cerradas (<span id="count-closed">0</span>)</button>
                    </div>
                    
                    <div id="gp-conversations-list-container" style="max-height: 600px; overflow-y: auto;">
                        <!-- Se llena con JavaScript -->
                    </div>
                </div>
                
                <!-- COLUMNA DERECHA: Chat activo -->
                <div class="gp-active-chat" style="flex: 1; background: #fff; border: 1px solid #ccc; border-radius: 8px; display: flex; flex-direction: column;">
                    
                    <div id="gp-no-chat-selected" style="display: flex; align-items: center; justify-content: center; height: 100%; color: #999;">
                        <div style="text-align: center;">
                            <div style="font-size: 64px; margin-bottom: 20px;">💬</div>
                            <p>Selecciona una conversación para comenzar</p>
                        </div>
                    </div>
                    
                    <div id="gp-active-chat-content" style="display: none; flex: 1; flex-direction: column;">
                        <!-- Header del chat -->
                        <div class="gp-chat-header" style="padding: 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <h3 id="gp-chat-user-name" style="margin: 0;">Usuario</h3>
                                <p id="gp-chat-user-info" style="margin: 5px 0 0; color: #666; font-size: 14px;"></p>
                            </div>
                            <div style="display: flex; gap: 10px;">
                                <button onclick="gpChat.sendToN8n()" class="button" title="Enviar a N8N">🔄 Automatizar</button>
                                <button onclick="gpChat.sendToChatwoot()" class="button" title="Enviar a Chatwoot">📤 Chatwoot</button>
                                <button onclick="gpChat.closeConversation()" class="button button-primary">✓ Cerrar</button>
                            </div>
                        </div>
                        
                        <!-- Mensajes -->
                        <div id="gp-chat-messages" style="flex: 1; overflow-y: auto; padding: 20px; background: #f5f5f5;">
                            <!-- Se llena con JavaScript -->
                        </div>
                        
                        <!-- Input -->
                        <div class="gp-chat-input" style="padding: 20px; border-top: 1px solid #eee; display: flex; gap: 10px;">
                            <textarea id="gp-agent-message-input" placeholder="Escribe tu respuesta..." style="flex: 1; padding: 12px; border: 1px solid #ccc; border-radius: 4px; resize: none; height: 60px;"></textarea>
                            <button onclick="gpChat.sendAgentMessage()" class="button button-primary" style="padding: 0 30px;">Enviar</button>
                        </div>
                        
                        <!-- Respuestas rápidas -->
                        <div class="gp-quick-responses" style="padding: 0 20px 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                            <button onclick="gpChat.insertQuickResponse('¡Hola! Estoy aquí para ayudarte. ¿En qué puedo asistirte?')" class="button button-small">👋 Saludo</button>
                            <button onclick="gpChat.insertQuickResponse('Déjame revisar eso para ti. Un momento por favor...')" class="button button-small">⏳ Revisando</button>
                            <button onclick="gpChat.insertQuickResponse('¿Hay algo más en lo que pueda ayudarte?')" class="button button-small">❓ Más ayuda</button>
                            <button onclick="gpChat.insertQuickResponse('Gracias por contactarnos. ¡Que tengas un excelente día!')" class="button button-small">👋 Despedida</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .gp-tab {
            padding: 8px 16px;
            background: none;
            border: none;
            cursor: pointer;
            color: #666;
            font-weight: 500;
        }
        .gp-tab.active {
            color: #D4AF37;
            border-bottom: 2px solid #D4AF37;
        }
        .gp-conversation-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
            transition: background 0.2s;
        }
        .gp-conversation-item:hover {
            background: #f5f5f5;
        }
        .gp-conversation-item.active {
            background: #fff9e6;
            border-left: 3px solid #D4AF37;
        }
        .gp-conversation-item.unread {
            background: #fffbf0;
            font-weight: 600;
        }
        .gp-message {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
        }
        .gp-message.user {
            justify-content: flex-start;
        }
        .gp-message.agent {
            justify-content: flex-end;
        }
        .gp-message-bubble {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 12px;
        }
        .gp-message.user .gp-message-bubble {
            background: #fff;
            border: 1px solid #ddd;
        }
        .gp-message.agent .gp-message-bubble {
            background: #D4AF37;
            color: #000;
        }
        .gp-message-time {
            font-size: 11px;
            color: #999;
            margin-top: 5px;
        }
        </style>
        
        <script>
        const gpChat = {
            currentConversation: null,
            agentId: <?php echo $current_user->ID; ?>,
            pollInterval: null,
            
            init: function() {
                this.loadConversations();
                this.startPolling();
                
                // Enter para enviar
                document.getElementById('gp-agent-message-input')?.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        this.sendAgentMessage();
                    }
                });
            },
            
            loadConversations: function() {
                fetch(ajaxurl + '?action=gp_get_agent_conversations&agent_id=' + this.agentId)
                    .then(r => r.json())
                    .then(data => {
                        this.renderConversations(data.conversations);
                        this.updateCounts(data.counts);
                    });
            },
            
            renderConversations: function(conversations) {
                const container = document.getElementById('gp-conversations-list-container');
                container.innerHTML = '';
                
                conversations.forEach(conv => {
                    const item = document.createElement('div');
                    item.className = 'gp-conversation-item' + (conv.unread ? ' unread' : '');
                    item.onclick = () => this.selectConversation(conv.id);
                    
                    item.innerHTML = `
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <div>
                                <strong>${conv.user_name || 'Usuario Anónimo'}</strong>
                                ${conv.unread ? '<span style="background: #D4AF37; color: #000; padding: 2px 6px; border-radius: 10px; font-size: 11px; margin-left: 5px;">' + conv.unread + '</span>' : ''}
                            </div>
                            <span style="font-size: 12px; color: #999;">${this.formatTime(conv.updated_at)}</span>
                        </div>
                        <div style="font-size: 13px; color: #666; margin-top: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            ${conv.last_message || 'Sin mensajes'}
                        </div>
                        <div style="margin-top: 5px; display: flex; gap: 10px;">
                            ${conv.user_email ? '<span style="font-size: 12px;">📧 ' + conv.user_email + '</span>' : ''}
                            ${conv.mode === 'human' ? '<span style="background: #4CAF50; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px;">👤 Agente</span>' : '<span style="background: #2196F3; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px;">🤖 Bot</span>'}
                        </div>
                    `;
                    
                    container.appendChild(item);
                });
            },
            
            selectConversation: function(convId) {
                this.currentConversation = convId;
                
                // Marcar como activa
                document.querySelectorAll('.gp-conversation-item').forEach(item => {
                    item.classList.remove('active');
                });
                event.currentTarget.classList.add('active');
                
                // Cargar mensajes
                this.loadMessages(convId);
                
                // Mostrar panel de chat
                document.getElementById('gp-no-chat-selected').style.display = 'none';
                document.getElementById('gp-active-chat-content').style.display = 'flex';
            },
            
            loadMessages: function(convId) {
                fetch(ajaxurl + '?action=gp_chat_get_messages&conversation_id=' + convId)
                    .then(r => r.json())
                    .then(data => {
                        this.renderMessages(data.messages);
                        document.getElementById('gp-chat-user-name').textContent = data.conversation.user_name || 'Usuario Anónimo';
                        document.getElementById('gp-chat-user-info').textContent = (data.conversation.user_email || '') + (data.conversation.user_phone ? ' • ' + data.conversation.user_phone : '');
                    });
            },
            
            renderMessages: function(messages) {
                const container = document.getElementById('gp-chat-messages');
                container.innerHTML = '';
                
                messages.forEach(msg => {
                    const div = document.createElement('div');
                    div.className = 'gp-message ' + msg.sender_type;
                    
                    div.innerHTML = `
                        <div class="gp-message-bubble">
                            <div>${msg.message}</div>
                            <div class="gp-message-time">${this.formatTime(msg.created_at)}</div>
                        </div>
                    `;
                    
                    container.appendChild(div);
                });
                
                container.scrollTop = container.scrollHeight;
            },
            
            sendAgentMessage: function() {
                const input = document.getElementById('gp-agent-message-input');
                const message = input.value.trim();
                
                if (!message || !this.currentConversation) return;
                
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'gp_agent_reply',
                        conversation_id: this.currentConversation,
                        message: message,
                        agent_id: this.agentId
                    })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        input.value = '';
                        this.loadMessages(this.currentConversation);
                    }
                });
            },
            
            insertQuickResponse: function(text) {
                document.getElementById('gp-agent-message-input').value = text;
                document.getElementById('gp-agent-message-input').focus();
            },
            
            closeConversation: function() {
                if (!confirm('¿Cerrar esta conversación?')) return;
                
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'gp_close_conversation',
                        conversation_id: this.currentConversation
                    })
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        this.currentConversation = null;
                        document.getElementById('gp-no-chat-selected').style.display = 'flex';
                        document.getElementById('gp-active-chat-content').style.display = 'none';
                        this.loadConversations();
                    }
                });
            },
            
            sendToN8n: function() {
                // Implementación N8N
                alert('Enviando conversación a N8N para automatización...');
            },
            
            sendToChatwoot: function() {
                // Implementación Chatwoot
                alert('Transfiriendo a Chatwoot...');
            },
            
            updateAgentStatus: function(status) {
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'gp_update_agent_status',
                        agent_id: this.agentId,
                        status: status
                    })
                });
            },
            
            startPolling: function() {
                this.pollInterval = setInterval(() => {
                    if (this.currentConversation) {
                        this.loadMessages(this.currentConversation);
                    }
                    this.loadConversations();
                }, 3000); // Poll cada 3 segundos
            },
            
            formatTime: function(datetime) {
                const date = new Date(datetime);
                const now = new Date();
                const diff = now - date;
                
                if (diff < 60000) return 'Ahora';
                if (diff < 3600000) return Math.floor(diff / 60000) + 'm';
                if (diff < 86400000) return Math.floor(diff / 3600000) + 'h';
                return date.toLocaleDateString();
            },
            
            updateCounts: function(counts) {
                document.getElementById('count-active').textContent = counts.active || 0;
                document.getElementById('count-waiting').textContent = counts.waiting || 0;
                document.getElementById('count-closed').textContent = counts.closed || 0;
            }
        };
        
        // Inicializar
        document.addEventListener('DOMContentLoaded', () => gpChat.init());
        </script>
        <?php
    }
    
    // =============================================
    // AJAX HANDLERS
    // =============================================
    
    public function get_agent_conversations() {
        global $wpdb;
        
        $conversations = $wpdb->get_results("
            SELECT c.*, 
                   (SELECT message FROM {$this->table_messages} WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message,
                   (SELECT COUNT(*) FROM {$this->table_messages} WHERE conversation_id = c.id AND sender_type = 'user' AND is_read = 0) as unread
            FROM {$this->table_conversations} c
            WHERE c.status IN ('active', 'waiting')
            ORDER BY c.updated_at DESC
            LIMIT 50
        ");
        
        $counts = array(
            'active' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_conversations} WHERE status = 'active'"),
            'waiting' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_conversations} WHERE status = 'waiting'"),
            'closed' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_conversations} WHERE status = 'closed' AND DATE(updated_at) = CURDATE()")
        );
        
        wp_send_json(array('conversations' => $conversations, 'counts' => $counts));
    }
    
    public function agent_reply() {
        global $wpdb;
        
        $conversation_id = intval($_POST['conversation_id']);
        $message = sanitize_textarea_field($_POST['message']);
        $agent_id = intval($_POST['agent_id']);
        
        // Insertar mensaje
        $wpdb->insert($this->table_messages, array(
            'conversation_id' => $conversation_id,
            'sender_type' => 'agent',
            'sender_id' => $agent_id,
            'message' => $message,
            'created_at' => current_time('mysql')
        ));
        
        // Actualizar conversación
        $wpdb->update(
            $this->table_conversations,
            array('mode' => 'human', 'updated_at' => current_time('mysql')),
            array('id' => $conversation_id)
        );
        
        wp_send_json_success();
    }
    
    public function close_conversation() {
        global $wpdb;
        
        $conversation_id = intval($_POST['conversation_id']);
        
        $wpdb->update(
            $this->table_conversations,
            array('status' => 'closed', 'updated_at' => current_time('mysql')),
            array('id' => $conversation_id)
        );
        
        wp_send_json_success();
    }
    
    private function get_or_create_agent($user_id) {
        global $wpdb;
        
        $agent = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_agents} WHERE user_id = %d",
            $user_id
        ));
        
        if (!$agent) {
            $user = get_userdata($user_id);
            $wpdb->insert($this->table_agents, array(
                'user_id' => $user_id,
                'display_name' => $user->display_name,
                'status' => 'offline'
            ));
            $agent = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->table_agents} WHERE user_id = %d",
                $user_id
            ));
        }
        
        return $agent;
    }
    
    // Continuará con páginas de configuración y estadísticas...
}

// Inicializar
new GP_Live_Chat_System();
