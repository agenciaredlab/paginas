<?php
/**
 * Golden Phoenix Jewelry - MEGA BLOQUES V5.0
 * 50+ Bloques Gutenberg Ultra Completos
 * 
 * @package Golden_Phoenix
 * @version 5.0
 */

if (!defined('ABSPATH')) exit;

// ============================================
// CATEGORÍA 1: COMERCIO ELECTRÓNICO (12 bloques)
// ============================================

// Bloque 1: Búsqueda de Productos con IA
register_block_type('golden-phoenix/ai-product-search', array(
    'render_callback' => 'gp_render_ai_search',
    'attributes' => array(
        'placeholder' => array('type' => 'string', 'default' => 'Describe la joya que buscas...'),
        'enableVoice' => array('type' => 'boolean', 'default' => true),
        'suggestions' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 2: Quick View Modal
register_block_type('golden-phoenix/quick-view', array(
    'render_callback' => 'gp_render_quick_view',
    'attributes' => array(
        'productIds' => array('type' => 'array', 'default' => array()),
        'showSpecs' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 3: Catálogo Virtual 360°
register_block_type('golden-phoenix/catalog-360', array(
    'render_callback' => 'gp_render_catalog_360',
    'attributes' => array(
        'products' => array('type' => 'array', 'default' => array()),
        'autoRotate' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 4: Bundle Builder (Arma tu Set)
register_block_type('golden-phoenix/bundle-builder', array(
    'render_callback' => 'gp_render_bundle_builder',
    'attributes' => array(
        'baseProduct' => array('type' => 'number', 'default' => 0),
        'recommendations' => array('type' => 'array', 'default' => array()),
        'discount' => array('type' => 'number', 'default' => 10),
    )
));

// Bloque 5: Size Guide Interactive
register_block_type('golden-phoenix/size-guide', array(
    'render_callback' => 'gp_render_size_guide',
    'attributes' => array(
        'type' => array('type' => 'string', 'default' => 'rings'),
        'measurementTool' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 6: Product Wishlist Display
register_block_type('golden-phoenix/wishlist-display', array(
    'render_callback' => 'gp_render_wishlist_display',
    'attributes' => array(
        'layout' => array('type' => 'string', 'default' => 'grid'),
        'allowShare' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 7: Stock Alert Subscription
register_block_type('golden-phoenix/stock-alert', array(
    'render_callback' => 'gp_render_stock_alert',
    'attributes' => array(
        'productId' => array('type' => 'number', 'default' => 0),
        'showEstimatedDate' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 8: Recently Viewed Products
register_block_type('golden-phoenix/recently-viewed', array(
    'render_callback' => 'gp_render_recently_viewed',
    'attributes' => array(
        'limit' => array('type' => 'number', 'default' => 8),
        'style' => array('type' => 'string', 'default' => 'carousel'),
    )
));

// Bloque 9: Product Variants Selector
register_block_type('golden-phoenix/variant-selector', array(
    'render_callback' => 'gp_render_variant_selector',
    'attributes' => array(
        'productId' => array('type' => 'number', 'default' => 0),
        'displayType' => array('type' => 'string', 'default' => 'swatches'),
    )
));

// Bloque 10: Cross-Sell Dynamic
register_block_type('golden-phoenix/cross-sell', array(
    'render_callback' => 'gp_render_cross_sell',
    'attributes' => array(
        'basedOn' => array('type' => 'string', 'default' => 'cart'),
        'algorithm' => array('type' => 'string', 'default' => 'ai'),
    )
));

// Bloque 11: Price Drop Alert
register_block_type('golden-phoenix/price-drop', array(
    'render_callback' => 'gp_render_price_drop',
    'attributes' => array(
        'threshold' => array('type' => 'number', 'default' => 10),
        'notification' => array('type' => 'string', 'default' => 'email'),
    )
));

// Bloque 12: Gift Wrapping Options
register_block_type('golden-phoenix/gift-wrap', array(
    'render_callback' => 'gp_render_gift_wrap',
    'attributes' => array(
        'options' => array('type' => 'array', 'default' => array()),
        'addPrice' => array('type' => 'boolean', 'default' => true),
    )
));

// ============================================
// CATEGORÍA 2: ENGAGEMENT Y SOCIAL (10 bloques)
// ============================================

// Bloque 13: Live Social Feed
register_block_type('golden-phoenix/social-feed', array(
    'render_callback' => 'gp_render_social_feed',
    'attributes' => array(
        'sources' => array('type' => 'array', 'default' => array('instagram', 'facebook')),
        'limit' => array('type' => 'number', 'default' => 12),
    )
));

// Bloque 14: User Generated Content Gallery
register_block_type('golden-phoenix/ugc-gallery', array(
    'render_callback' => 'gp_render_ugc_gallery',
    'attributes' => array(
        'hashtag' => array('type' => 'string', 'default' => ''),
        'moderation' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 15: Live Chat Trigger
register_block_type('golden-phoenix/chat-trigger', array(
    'render_callback' => 'gp_render_chat_trigger',
    'attributes' => array(
        'message' => array('type' => 'string', 'default' => '¿Necesitas ayuda?'),
        'delay' => array('type' => 'number', 'default' => 5000),
    )
));

// Bloque 16: Customer Stories/Testimonials Carousel
register_block_type('golden-phoenix/stories-carousel', array(
    'render_callback' => 'gp_render_stories',
    'attributes' => array(
        'stories' => array('type' => 'array', 'default' => array()),
        'autoplay' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 17: Referral Program Widget
register_block_type('golden-phoenix/referral-widget', array(
    'render_callback' => 'gp_render_referral',
    'attributes' => array(
        'reward' => array('type' => 'string', 'default' => '10% descuento'),
        'shareButtons' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 18: Rating & Review Form
register_block_type('golden-phoenix/review-form', array(
    'render_callback' => 'gp_render_review_form',
    'attributes' => array(
        'productId' => array('type' => 'number', 'default' => 0),
        'requirePurchase' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 19: Share Product Widget
register_block_type('golden-phoenix/share-product', array(
    'render_callback' => 'gp_render_share_product',
    'attributes' => array(
        'networks' => array('type' => 'array', 'default' => array()),
        'style' => array('type' => 'string', 'default' => 'minimal'),
    )
));

// Bloque 20: Community Forum Preview
register_block_type('golden-phoenix/forum-preview', array(
    'render_callback' => 'gp_render_forum',
    'attributes' => array(
        'topics' => array('type' => 'number', 'default' => 5),
        'category' => array('type' => 'string', 'default' => 'all'),
    )
));

// Bloque 21: Contest/Giveaway Entry
register_block_type('golden-phoenix/giveaway', array(
    'render_callback' => 'gp_render_giveaway',
    'attributes' => array(
        'endDate' => array('type' => 'string', 'default' => ''),
        'prize' => array('type' => 'string', 'default' => ''),
    )
));

// Bloque 22: Poll/Survey Block
register_block_type('golden-phoenix/poll', array(
    'render_callback' => 'gp_render_poll',
    'attributes' => array(
        'question' => array('type' => 'string', 'default' => ''),
        'options' => array('type' => 'array', 'default' => array()),
    )
));

// ============================================
// CATEGORÍA 3: MULTIMEDIA Y VISUAL (8 bloques)
// ============================================

// Bloque 23: 3D Product Viewer
register_block_type('golden-phoenix/3d-viewer', array(
    'render_callback' => 'gp_render_3d_viewer',
    'attributes' => array(
        'modelUrl' => array('type' => 'string', 'default' => ''),
        'autoRotate' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 24: AR Try-On (Augmented Reality)
register_block_type('golden-phoenix/ar-tryon', array(
    'render_callback' => 'gp_render_ar_tryon',
    'attributes' => array(
        'productId' => array('type' => 'number', 'default' => 0),
        'cameraType' => array('type' => 'string', 'default' => 'front'),
    )
));

// Bloque 25: Video Testimonials
register_block_type('golden-phoenix/video-testimonials', array(
    'render_callback' => 'gp_render_video_testimonials',
    'attributes' => array(
        'videos' => array('type' => 'array', 'default' => array()),
        'layout' => array('type' => 'string', 'default' => 'grid'),
    )
));

// Bloque 26: Lookbook Interactive
register_block_type('golden-phoenix/lookbook', array(
    'render_callback' => 'gp_render_lookbook',
    'attributes' => array(
        'images' => array('type' => 'array', 'default' => array()),
        'hotspots' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 27: Image Hotspot Product Tags
register_block_type('golden-phoenix/image-hotspots', array(
    'render_callback' => 'gp_render_hotspots',
    'attributes' => array(
        'image' => array('type' => 'string', 'default' => ''),
        'tags' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 28: Zoom & Pan Image Gallery
register_block_type('golden-phoenix/zoom-gallery', array(
    'render_callback' => 'gp_render_zoom_gallery',
    'attributes' => array(
        'images' => array('type' => 'array', 'default' => array()),
        'zoomLevel' => array('type' => 'number', 'default' => 3),
    )
));

// Bloque 29: Parallax Showcase
register_block_type('golden-phoenix/parallax', array(
    'render_callback' => 'gp_render_parallax',
    'attributes' => array(
        'layers' => array('type' => 'array', 'default' => array()),
        'speed' => array('type' => 'number', 'default' => 0.5),
    )
));

// Bloque 30: YouTube/Vimeo Embed Enhanced
register_block_type('golden-phoenix/video-enhanced', array(
    'render_callback' => 'gp_render_video_enhanced',
    'attributes' => array(
        'url' => array('type' => 'string', 'default' => ''),
        'autoplay' => array('type' => 'boolean', 'default' => false),
    )
));

// ============================================
// CATEGORÍA 4: CONVERSION Y MARKETING (10 bloques)
// ============================================

// Bloque 31: Exit Intent Popup
register_block_type('golden-phoenix/exit-intent', array(
    'render_callback' => 'gp_render_exit_intent',
    'attributes' => array(
        'offer' => array('type' => 'string', 'default' => ''),
        'delay' => array('type' => 'number', 'default' => 3000),
    )
));

// Bloque 32: Scarcity Timer (FOMO)
register_block_type('golden-phoenix/scarcity-timer', array(
    'render_callback' => 'gp_render_scarcity',
    'attributes' => array(
        'message' => array('type' => 'string', 'default' => 'Solo quedan X unidades'),
        'threshold' => array('type' => 'number', 'default' => 5),
    )
));

// Bloque 33: Abandoned Cart Recovery Bar
register_block_type('golden-phoenix/cart-recovery', array(
    'render_callback' => 'gp_render_cart_recovery',
    'attributes' => array(
        'message' => array('type' => 'string', 'default' => '¡No olvides tu carrito!'),
        'incentive' => array('type' => 'string', 'default' => ''),
    )
));

// Bloque 34: Free Shipping Bar
register_block_type('golden-phoenix/shipping-bar', array(
    'render_callback' => 'gp_render_shipping_bar',
    'attributes' => array(
        'threshold' => array('type' => 'number', 'default' => 100000),
        'position' => array('type' => 'string', 'default' => 'top'),
    )
));

// Bloque 35: Loyalty Points Display
register_block_type('golden-phoenix/loyalty-points', array(
    'render_callback' => 'gp_render_loyalty_points',
    'attributes' => array(
        'showBalance' => array('type' => 'boolean', 'default' => true),
        'showHistory' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 36: Upsell Modal
register_block_type('golden-phoenix/upsell-modal', array(
    'render_callback' => 'gp_render_upsell_modal',
    'attributes' => array(
        'trigger' => array('type' => 'string', 'default' => 'add_to_cart'),
        'products' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 37: Dynamic Pricing Display
register_block_type('golden-phoenix/dynamic-pricing', array(
    'render_callback' => 'gp_render_dynamic_pricing',
    'attributes' => array(
        'rules' => array('type' => 'array', 'default' => array()),
        'showSavings' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 38: Subscription Upsell
register_block_type('golden-phoenix/subscription-upsell', array(
    'render_callback' => 'gp_render_subscription_upsell',
    'attributes' => array(
        'discount' => array('type' => 'number', 'default' => 15),
        'frequency' => array('type' => 'string', 'default' => 'monthly'),
    )
));

// Bloque 39: Member-Only Content
register_block_type('golden-phoenix/members-only', array(
    'render_callback' => 'gp_render_members_only',
    'attributes' => array(
        'requiredLevel' => array('type' => 'string', 'default' => ''),
        'teaser' => array('type' => 'string', 'default' => ''),
    )
));

// Bloque 40: Flash Sale Banner
register_block_type('golden-phoenix/flash-sale', array(
    'render_callback' => 'gp_render_flash_sale',
    'attributes' => array(
        'endTime' => array('type' => 'string', 'default' => ''),
        'products' => array('type' => 'array', 'default' => array()),
    )
));

// ============================================
// CATEGORÍA 5: INFORMACIÓN Y EDUCACIÓN (10 bloques)
// ============================================

// Bloque 41: Product Care Instructions
register_block_type('golden-phoenix/care-instructions', array(
    'render_callback' => 'gp_render_care_instructions',
    'attributes' => array(
        'material' => array('type' => 'string', 'default' => ''),
        'instructions' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 42: Certification Badges
register_block_type('golden-phoenix/certifications', array(
    'render_callback' => 'gp_render_certifications',
    'attributes' => array(
        'certificates' => array('type' => 'array', 'default' => array()),
        'layout' => array('type' => 'string', 'default' => 'grid'),
    )
));

// Bloque 43: Gemstone Encyclopedia
register_block_type('golden-phoenix/gemstone-info', array(
    'render_callback' => 'gp_render_gemstone_info',
    'attributes' => array(
        'gemstone' => array('type' => 'string', 'default' => ''),
        'showProperties' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 44: Metal Guide
register_block_type('golden-phoenix/metal-guide', array(
    'render_callback' => 'gp_render_metal_guide',
    'attributes' => array(
        'metals' => array('type' => 'array', 'default' => array()),
        'comparison' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 45: Craftsmanship Process
register_block_type('golden-phoenix/craftsmanship', array(
    'render_callback' => 'gp_render_craftsmanship',
    'attributes' => array(
        'steps' => array('type' => 'array', 'default' => array()),
        'showVideo' => array('type' => 'boolean', 'default' => true),
    )
));

// Bloque 46: Warranty Information
register_block_type('golden-phoenix/warranty', array(
    'render_callback' => 'gp_render_warranty',
    'attributes' => array(
        'duration' => array('type' => 'string', 'default' => ''),
        'coverage' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 47: Sustainability Info
register_block_type('golden-phoenix/sustainability', array(
    'render_callback' => 'gp_render_sustainability',
    'attributes' => array(
        'practices' => array('type' => 'array', 'default' => array()),
        'certifications' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 48: Return Policy
register_block_type('golden-phoenix/return-policy', array(
    'render_callback' => 'gp_render_return_policy',
    'attributes' => array(
        'days' => array('type' => 'number', 'default' => 30),
        'conditions' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 49: Sizing Chart Advanced
register_block_type('golden-phoenix/sizing-chart', array(
    'render_callback' => 'gp_render_sizing_chart',
    'attributes' => array(
        'type' => array('type' => 'string', 'default' => 'rings'),
        'measurements' => array('type' => 'array', 'default' => array()),
    )
));

// Bloque 50: Knowledge Base Articles
register_block_type('golden-phoenix/kb-articles', array(
    'render_callback' => 'gp_render_kb_articles',
    'attributes' => array(
        'category' => array('type' => 'string', 'default' => ''),
        'limit' => array('type' => 'number', 'default' => 5),
    )
));

// ============================================
// FUNCIONES DE RENDERIZADO AVANZADAS
// ============================================

function gp_render_ai_search($attributes) {
    ob_start();
    ?>
    <div class="gp-ai-search-block">
        <div class="search-container">
            <input type="text" 
                   class="gp-ai-search-input" 
                   placeholder="<?php echo esc_attr($attributes['placeholder']); ?>"
                   id="gp-ai-search">
            
            <?php if ($attributes['enableVoice']): ?>
            <button class="voice-search-btn" id="gp-voice-search">
                <span class="mic-icon">🎤</span>
            </button>
            <?php endif; ?>
            
            <button class="search-btn" id="gp-search-btn">
                <span class="search-icon">🔍</span>
            </button>
        </div>
        
        <?php if ($attributes['suggestions']): ?>
        <div class="search-suggestions" id="gp-suggestions" style="display:none;">
            <!-- Sugerencias dinámicas -->
        </div>
        <?php endif; ?>
        
        <div class="search-results" id="gp-search-results"></div>
    </div>
    
    <script>
    (function() {
        const searchInput = document.getElementById('gp-ai-search');
        const voiceBtn = document.getElementById('gp-voice-search');
        const searchBtn = document.getElementById('gp-search-btn');
        const results = document.getElementById('gp-search-results');
        
        // Búsqueda con IA
        let searchTimeout;
        searchInput.addEventListener('input', function(e) {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                performAISearch(e.target.value);
            }, 300);
        });
        
        // Búsqueda por voz
        if (voiceBtn && 'webkitSpeechRecognition' in window) {
            const recognition = new webkitSpeechRecognition();
            recognition.lang = 'es-CO';
            
            voiceBtn.addEventListener('click', function() {
                recognition.start();
            });
            
            recognition.onresult = function(event) {
                const transcript = event.results[0][0].transcript;
                searchInput.value = transcript;
                performAISearch(transcript);
            };
        }
        
        function performAISearch(query) {
            if (query.length < 3) return;
            
            fetch('/wp-json/golden-phoenix/v1/search/ai', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: query })
            })
            .then(res => res.json())
            .then(data => {
                displayResults(data.products);
            });
        }
        
        function displayResults(products) {
            results.innerHTML = products.map(p => `
                <div class="search-result-item">
                    <img src="${p.image}" alt="${p.name}">
                    <h4>${p.name}</h4>
                    <p>${p.price}</p>
                    <a href="${p.url}">Ver Producto</a>
                </div>
            `).join('');
        }
    })();
    </script>
    <?php
    return ob_get_clean();
}

function gp_render_ar_tryon($attributes) {
    $product_id = $attributes['productId'];
    
    ob_start();
    ?>
    <div class="gp-ar-tryon-block">
        <h3>👓 Pruébatelo Virtualmente</h3>
        <p>Usa tu cámara para ver cómo te queda esta joya</p>
        
        <button class="ar-launch-btn" id="launch-ar">
            📸 Activar Cámara AR
        </button>
        
        <div class="ar-viewer" id="ar-viewer" style="display:none;">
            <video id="ar-video" autoplay playsinline></video>
            <canvas id="ar-canvas"></canvas>
            <button class="ar-close" id="ar-close">✕</button>
        </div>
    </div>
    
    <script>
    document.getElementById('launch-ar').addEventListener('click', async function() {
        const viewer = document.getElementById('ar-viewer');
        const video = document.getElementById('ar-video');
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: '<?php echo esc_js($attributes['cameraType']); ?>' } 
            });
            
            video.srcObject = stream;
            viewer.style.display = 'block';
            
            // Cargar modelo 3D del producto
            loadARModel(<?php echo $product_id; ?>);
            
        } catch (err) {
            alert('No se pudo acceder a la cámara');
        }
    });
    
    document.getElementById('ar-close').addEventListener('click', function() {
        const video = document.getElementById('ar-video');
        const stream = video.srcObject;
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
        document.getElementById('ar-viewer').style.display = 'none';
    });
    
    function loadARModel(productId) {
        // Implementar carga de modelo 3D con Three.js
        // y tracking facial con MediaPipe
    }
    </script>
    <?php
    return ob_get_clean();
}

function gp_render_bundle_builder($attributes) {
    ob_start();
    ?>
    <div class="gp-bundle-builder">
        <h3>🎁 Arma tu Set Personalizado</h3>
        <p>Combina productos y obtén <strong><?php echo $attributes['discount']; ?>% de descuento</strong></p>
        
        <div class="bundle-container">
            <div class="bundle-products" id="bundle-products">
                <!-- Productos seleccionables -->
            </div>
            
            <div class="bundle-summary">
                <h4>Tu Bundle</h4>
                <div id="selected-products"></div>
                <div class="bundle-total">
                    <span>Total:</span>
                    <span id="bundle-price">$0</span>
                </div>
                <div class="bundle-savings">
                    Ahorras: <span id="bundle-savings">$0</span>
                </div>
                <button class="add-bundle-cart">Agregar Bundle al Carrito</button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Continuar con más implementaciones...
