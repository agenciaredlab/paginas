<?php
/**
 * Golden Phoenix V72 - FIX CUSTOMIZER WHATSAPP
 * Hace que los cambios se vean en tiempo real en el customizer
 */

if (!defined('ABSPATH')) exit;

// ========================================
// MEJORAR CUSTOMIZER WHATSAPP CON PREVIEW
// ========================================

add_action('customize_register', 'gp_v72_whatsapp_customizer_improved');

function gp_v72_whatsapp_customizer_improved($wp_customize) {
    
    // Modificar configuración existente para preview en vivo
    $wp_customize->get_setting('gp_whatsapp_number')->transport = 'postMessage';
    $wp_customize->get_setting('gp_whatsapp_floating_enabled')->transport = 'postMessage';
    $wp_customize->get_setting('gp_whatsapp_message')->transport = 'postMessage';
}

// JavaScript para preview en vivo
add_action('customize_preview_init', 'gp_v72_customizer_preview_js');

function gp_v72_customizer_preview_js() {
    wp_enqueue_script(
        'gp-customizer-preview',
        get_template_directory_uri() . '/assets/js/customizer-preview.js',
        array('jquery', 'customize-preview'),
        '72.0',
        true
    );
}

// Crear archivo JS si no existe
add_action('admin_init', 'gp_v72_create_customizer_js');

function gp_v72_create_customizer_js() {
    $js_dir = get_template_directory() . '/assets/js';
    $js_file = $js_dir . '/customizer-preview.js';
    
    if (file_exists($js_file)) {
        return;
    }
    
    if (!file_exists($js_dir)) {
        mkdir($js_dir, 0755, true);
    }
    
    $js_content = <<<'JS'
/**
 * Customizer Preview Live Changes
 */
(function($) {
    'use strict';
    
    // WhatsApp Number
    wp.customize('gp_whatsapp_number', function(value) {
        value.bind(function(to) {
            // Actualizar todos los enlaces de WhatsApp
            $('.gp-whatsapp-button, .gp-whatsapp-checkout, .gp-whatsapp-float').each(function() {
                var href = $(this).attr('href');
                if (href) {
                    var newHref = href.replace(/wa\.me\/[0-9]+/, 'wa.me/' + to);
                    $(this).attr('href', newHref);
                }
            });
        });
    });
    
    // WhatsApp Floating Enabled
    wp.customize('gp_whatsapp_floating_enabled', function(value) {
        value.bind(function(to) {
            if (to) {
                $('.gp-whatsapp-float').show();
            } else {
                $('.gp-whatsapp-float').hide();
            }
        });
    });
    
    // WhatsApp Message
    wp.customize('gp_whatsapp_message', function(value) {
        value.bind(function(to) {
            $('.gp-whatsapp-float').each(function() {
                var href = $(this).attr('href');
                if (href) {
                    var newHref = href.replace(/text=([^&]*)/, 'text=' + encodeURIComponent(to));
                    $(this).attr('href', newHref);
                }
            });
        });
    });
    
})(jQuery);
JS;
    
    file_put_contents($js_file, $js_content);
}

// ========================================
// AGREGAR CONTROLES VISUALES EN CUSTOMIZER
// ========================================

add_action('customize_register', 'gp_v72_add_visual_controls');

function gp_v72_add_visual_controls($wp_customize) {
    
    // Control de posición del botón flotante
    $wp_customize->add_setting('gp_whatsapp_position', array(
        'default' => 'bottom-right',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_whatsapp_position', array(
        'label' => 'Posición del Botón Flotante',
        'section' => 'gp_whatsapp_section',
        'type' => 'select',
        'choices' => array(
            'bottom-right' => 'Abajo Derecha',
            'bottom-left' => 'Abajo Izquierda',
            'top-right' => 'Arriba Derecha',
            'top-left' => 'Arriba Izquierda',
        ),
    ));
    
    // Color del botón flotante
    $wp_customize->add_setting('gp_whatsapp_color', array(
        'default' => '#25D366',
        'transport' => 'postMessage',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_whatsapp_color', array(
        'label' => 'Color del Botón WhatsApp',
        'section' => 'gp_whatsapp_section',
    )));
    
    // Tamaño del botón flotante
    $wp_customize->add_setting('gp_whatsapp_size', array(
        'default' => '60',
        'transport' => 'postMessage',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control('gp_whatsapp_size', array(
        'label' => 'Tamaño del Botón (px)',
        'section' => 'gp_whatsapp_section',
        'type' => 'number',
        'input_attrs' => array(
            'min' => 40,
            'max' => 80,
            'step' => 5,
        ),
    ));
}

// Aplicar estilos dinámicos del customizer
add_action('wp_head', 'gp_v72_whatsapp_dynamic_styles', 100);

function gp_v72_whatsapp_dynamic_styles() {
    $position = get_theme_mod('gp_whatsapp_position', 'bottom-right');
    $color = get_theme_mod('gp_whatsapp_color', '#25D366');
    $size = get_theme_mod('gp_whatsapp_size', '60');
    
    // Calcular posición
    $css_position = '';
    switch ($position) {
        case 'bottom-right':
            $css_position = 'bottom: 20px; right: 20px;';
            break;
        case 'bottom-left':
            $css_position = 'bottom: 20px; left: 20px;';
            break;
        case 'top-right':
            $css_position = 'top: 100px; right: 20px;';
            break;
        case 'top-left':
            $css_position = 'top: 100px; left: 20px;';
            break;
    }
    ?>
    
    <style id="gp-whatsapp-dynamic-styles">
    .gp-whatsapp-float {
        <?php echo $css_position; ?>
        width: <?php echo esc_attr($size); ?>px !important;
        height: <?php echo esc_attr($size); ?>px !important;
        background: <?php echo esc_attr($color); ?> !important;
    }
    
    .gp-whatsapp-button,
    .gp-whatsapp-checkout {
        background: <?php echo esc_attr($color); ?> !important;
        border-color: <?php echo esc_attr($color); ?> !important;
    }
    
    .gp-whatsapp-button:hover,
    .gp-whatsapp-checkout:hover {
        background: <?php echo esc_attr(gp_darken_color($color, 10)); ?> !important;
    }
    </style>
    
    <?php
}

// Función auxiliar para oscurecer color
function gp_darken_color($hex, $percent) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r - ($r * $percent / 100)));
    $g = max(0, min(255, $g - ($g * $percent / 100)));
    $b = max(0, min(255, $b - ($b * $percent / 100)));
    
    return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
}

// Actualizar customizer preview JS con nuevos controles
add_action('admin_init', 'gp_v72_update_customizer_js');

function gp_v72_update_customizer_js() {
    $js_file = get_template_directory() . '/assets/js/customizer-preview.js';
    
    if (!file_exists($js_file)) {
        return;
    }
    
    // Leer contenido actual
    $current = file_get_contents($js_file);
    
    // Si ya tiene los nuevos controles, no agregar
    if (strpos($current, 'gp_whatsapp_position') !== false) {
        return;
    }
    
    // Agregar nuevos controles
    $additional_js = <<<'JS'

    // WhatsApp Position
    wp.customize('gp_whatsapp_position', function(value) {
        value.bind(function(to) {
            var positions = {
                'bottom-right': 'bottom: 20px; right: 20px; top: auto; left: auto;',
                'bottom-left': 'bottom: 20px; left: 20px; top: auto; right: auto;',
                'top-right': 'top: 100px; right: 20px; bottom: auto; left: auto;',
                'top-left': 'top: 100px; left: 20px; bottom: auto; right: auto;'
            };
            $('.gp-whatsapp-float').attr('style', function(i, style) {
                return style.replace(/(top|bottom|left|right):\s*[^;]+;?/g, '') + positions[to];
            });
        });
    });
    
    // WhatsApp Color
    wp.customize('gp_whatsapp_color', function(value) {
        value.bind(function(to) {
            $('.gp-whatsapp-float, .gp-whatsapp-button, .gp-whatsapp-checkout').css('background-color', to);
        });
    });
    
    // WhatsApp Size
    wp.customize('gp_whatsapp_size', function(value) {
        value.bind(function(to) {
            $('.gp-whatsapp-float').css({
                'width': to + 'px',
                'height': to + 'px'
            });
        });
    });
JS;
    
    // Insertar antes del cierre
    $updated = str_replace('})(jQuery);', $additional_js . "\n})(jQuery);", $current);
    file_put_contents($js_file, $updated);
}
