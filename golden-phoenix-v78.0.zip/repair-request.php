<?php
/**
 * V76 - REPAIR REQUEST
 * Formulario solicitud reparación joyas
 */
if (!defined('ABSPATH')) exit;

add_action('after_switch_theme', function() {
    if (get_option('gp_repair_page_created')) return;
    wp_insert_post(array(
        'post_title' => 'Solicitar Reparación',
        'post_name' => 'reparacion',
        'post_content' => '[repair_request_form]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    update_option('gp_repair_page_created', true);
});

add_shortcode('repair_request_form', function() {
    ob_start();
    ?>
    <div style="max-width: 600px; margin: 0 auto;">
        <h2 style="text-align: center;">🔧 Solicitar Reparación de Joya</h2>
        
        <form id="repair-form" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Tipo de Joya:</label>
                <select name="jewelry_type" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="anillo">Anillo</option>
                    <option value="collar">Collar</option>
                    <option value="pulsera">Pulsera</option>
                    <option value="aretes">Aretes</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Problema:</label>
                <select name="issue" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="cambio-talla">Cambio de talla</option>
                    <option value="pulido">Pulido/limpieza</option>
                    <option value="piedra-perdida">Piedra perdida</option>
                    <option value="cadena-rota">Cadena rota</option>
                    <option value="broche-dañado">Broche dañado</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Descripción:</label>
                <textarea name="description" rows="4" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;"></textarea>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Tu Nombre:</label>
                <input type="text" name="name" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Email:</label>
                <input type="email" name="email" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Teléfono:</label>
                <input type="tel" name="phone" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <button type="submit" style="width: 100%; padding: 15px; background: #D4AF37; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;">
                📧 Enviar Solicitud
            </button>
        </form>
        
        <div id="repair-result" style="margin-top: 20px;"></div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#repair-form').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            
            $.post('<?php echo admin_url('admin-ajax.php'); ?>', formData + '&action=gp_submit_repair', function(response) {
                $('#repair-result').html('<div style="background: #D4F4DD; padding: 20px; border-radius: 8px; text-align: center;"><h3>✅ Solicitud Enviada</h3><p>Te contactaremos pronto</p></div>');
                $('#repair-form')[0].reset();
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
});

add_action('wp_ajax_gp_submit_repair', 'gp_process_repair_request');
add_action('wp_ajax_nopriv_gp_submit_repair', 'gp_process_repair_request');

function gp_process_repair_request() {
    $to = get_option('admin_email');
    $subject = 'Nueva Solicitud de Reparación';
    $message = sprintf(
        "Tipo: %s\nProblema: %s\nDescripción: %s\nNombre: %s\nEmail: %s\nTeléfono: %s",
        $_POST['jewelry_type'],
        $_POST['issue'],
        $_POST['description'],
        $_POST['name'],
        $_POST['email'],
        $_POST['phone']
    );
    
    wp_mail($to, $subject, $message);
    wp_send_json_success();
}
