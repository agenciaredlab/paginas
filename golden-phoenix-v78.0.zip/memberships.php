<?php
/**
 * Golden Phoenix Jewelry - Sistema Avanzado de Membresías
 * Gestión completa de miembros VIP con beneficios personalizables
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// CUSTOM POST TYPE: NIVELES DE MEMBRESÍA
// ============================================

/**
 * Registrar CPT para Niveles de Membresía
 */
function gp_register_membership_levels_cpt() {
    register_post_type('membership_level', array(
        'labels' => array(
            'name' => 'Niveles de Membresía',
            'singular_name' => 'Nivel de Membresía',
            'add_new' => 'Agregar Nivel',
            'add_new_item' => 'Agregar Nuevo Nivel',
            'edit_item' => 'Editar Nivel',
            'view_item' => 'Ver Nivel',
        ),
        'public' => true,
        'show_in_menu' => 'gp-memberships',
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-groups',
        'show_in_rest' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'membership-levels'),
    ));
}
add_action('init', 'gp_register_membership_levels_cpt');

// ============================================
// MENÚ DE ADMINISTRACIÓN DE MEMBRESÍAS
// ============================================

/**
 * Agregar menú principal de membresías
 */
function gp_add_memberships_menu() {
    add_menu_page(
        'Membresías VIP',
        'Membresías VIP',
        'manage_options',
        'gp-memberships',
        'gp_memberships_dashboard',
        'dashicons-groups',
        25
    );
    
    add_submenu_page(
        'gp-memberships',
        'Dashboard',
        'Dashboard',
        'manage_options',
        'gp-memberships',
        'gp_memberships_dashboard'
    );
    
    add_submenu_page(
        'gp-memberships',
        'Todos los Miembros',
        'Todos los Miembros',
        'manage_options',
        'gp-members-list',
        'gp_members_list_page'
    );
    
    add_submenu_page(
        'gp-memberships',
        'Beneficios',
        'Beneficios',
        'manage_options',
        'gp-benefits',
        'gp_benefits_page'
    );
    
    add_submenu_page(
        'gp-memberships',
        'Configuración',
        'Configuración',
        'manage_options',
        'gp-membership-settings',
        'gp_membership_settings_page'
    );
}
add_action('admin_menu', 'gp_add_memberships_menu');

// ============================================
// DASHBOARD DE MEMBRESÍAS
// ============================================

function gp_memberships_dashboard() {
    global $wpdb;
    
    // Obtener estadísticas
    $total_members = count(get_users(array('meta_key' => 'gp_membership_level')));
    $active_members = count(get_users(array(
        'meta_key' => 'gp_membership_level',
        'meta_value' => '',
        'meta_compare' => '!='
    )));
    
    // Ingresos por membresías este mes
    $current_month = date('Y-m');
    $membership_revenue = $wpdb->get_var($wpdb->prepare("
        SELECT SUM(meta_value) 
        FROM {$wpdb->usermeta} 
        WHERE meta_key = 'gp_membership_revenue'
        AND user_id IN (
            SELECT user_id FROM {$wpdb->usermeta} 
            WHERE meta_key = 'gp_membership_start_date' 
            AND meta_value LIKE %s
        )
    ", $current_month . '%'));
    
    // Miembros por nivel
    $levels_count = array();
    $all_levels = get_posts(array('post_type' => 'membership_level', 'posts_per_page' => -1));
    foreach ($all_levels as $level) {
        $count = count(get_users(array(
            'meta_key' => 'gp_membership_level',
            'meta_value' => $level->ID
        )));
        $levels_count[$level->post_title] = $count;
    }
    
    ?>
    <div class="wrap gp-memberships-dashboard">
        <h1>🏆 Dashboard de Membresías VIP</h1>
        
        <div class="gp-stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 30px 0;">
            
            <div class="gp-stat-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; color: #666; margin-bottom: 8px;">Total de Miembros</div>
                <div style="font-size: 36px; font-weight: bold; color: #D4AF37;"><?php echo $total_members; ?></div>
            </div>
            
            <div class="gp-stat-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; color: #666; margin-bottom: 8px;">Miembros Activos</div>
                <div style="font-size: 36px; font-weight: bold; color: #2ECC71;"><?php echo $active_members; ?></div>
            </div>
            
            <div class="gp-stat-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; color: #666; margin-bottom: 8px;">Ingresos Este Mes</div>
                <div style="font-size: 36px; font-weight: bold; color: #3498DB;">$<?php echo number_format($membership_revenue, 2); ?></div>
            </div>
            
            <div class="gp-stat-card" style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; color: #666; margin-bottom: 8px;">Niveles Activos</div>
                <div style="font-size: 36px; font-weight: bold; color: #9B59B6;"><?php echo count($all_levels); ?></div>
            </div>
            
        </div>
        
        <h2>Miembros por Nivel</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Nivel</th>
                    <th>Miembros</th>
                    <th>Porcentaje</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($levels_count as $level_name => $count): 
                    $percentage = $total_members > 0 ? ($count / $total_members) * 100 : 0;
                ?>
                <tr>
                    <td><strong><?php echo esc_html($level_name); ?></strong></td>
                    <td><?php echo $count; ?></td>
                    <td>
                        <div style="background: #f0f0f0; height: 20px; border-radius: 10px; overflow: hidden;">
                            <div style="background: #D4AF37; height: 100%; width: <?php echo $percentage; ?>%;"></div>
                        </div>
                        <?php echo round($percentage, 1); ?>%
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <h2 style="margin-top: 40px;">Miembros Recientes</h2>
        <?php
        $recent_members = get_users(array(
            'meta_key' => 'gp_membership_level',
            'meta_value' => '',
            'meta_compare' => '!=',
            'number' => 10,
            'orderby' => 'registered',
            'order' => 'DESC'
        ));
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Miembro</th>
                    <th>Email</th>
                    <th>Nivel</th>
                    <th>Fecha de Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_members as $member):
                    $level_id = get_user_meta($member->ID, 'gp_membership_level', true);
                    $level = get_post($level_id);
                ?>
                <tr>
                    <td><strong><?php echo esc_html($member->display_name); ?></strong></td>
                    <td><?php echo esc_html($member->user_email); ?></td>
                    <td><span style="background: #D4AF37; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px;"><?php echo $level ? $level->post_title : 'Sin nivel'; ?></span></td>
                    <td><?php echo date('d/m/Y', strtotime($member->user_registered)); ?></td>
                    <td>
                        <a href="<?php echo admin_url('user-edit.php?user_id=' . $member->ID); ?>" class="button button-small">Ver Perfil</a>
                        <a href="<?php echo admin_url('admin.php?page=gp-member-detail&member_id=' . $member->ID); ?>" class="button button-small">Historial</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ============================================
// LISTA DE MIEMBROS
// ============================================

function gp_members_list_page() {
    $members = get_users(array(
        'meta_key' => 'gp_membership_level',
        'meta_value' => '',
        'meta_compare' => '!='
    ));
    
    ?>
    <div class="wrap">
        <h1>Todos los Miembros VIP</h1>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Nivel</th>
                    <th>Fecha Inicio</th>
                    <th>Total Gastado</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($members as $member):
                    $level_id = get_user_meta($member->ID, 'gp_membership_level', true);
                    $level = get_post($level_id);
                    $start_date = get_user_meta($member->ID, 'gp_membership_start_date', true);
                    $total_spent = gp_get_customer_total_spent($member->ID);
                    $status = get_user_meta($member->ID, 'gp_membership_status', true) ?: 'active';
                ?>
                <tr>
                    <td><?php echo $member->ID; ?></td>
                    <td><strong><?php echo esc_html($member->display_name); ?></strong></td>
                    <td><?php echo esc_html($member->user_email); ?></td>
                    <td><?php echo $level ? $level->post_title : '-'; ?></td>
                    <td><?php echo $start_date ? date('d/m/Y', strtotime($start_date)) : '-'; ?></td>
                    <td>$<?php echo number_format($total_spent, 2); ?></td>
                    <td>
                        <span style="background: <?php echo $status === 'active' ? '#2ECC71' : '#E74C3C'; ?>; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px;">
                            <?php echo $status === 'active' ? 'Activo' : 'Inactivo'; ?>
                        </span>
                    </td>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=gp-member-detail&member_id=' . $member->ID); ?>" class="button button-small">Ver Detalle</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ============================================
// DETALLE DE MIEMBRO INDIVIDUAL
// ============================================

add_action('admin_menu', function() {
    add_submenu_page(
        null, // Parent null = página oculta del menú
        'Detalle de Miembro',
        'Detalle de Miembro',
        'manage_options',
        'gp-member-detail',
        'gp_member_detail_page'
    );
});

function gp_member_detail_page() {
    if (!isset($_GET['member_id'])) {
        echo '<div class="wrap"><h1>Miembro no encontrado</h1></div>';
        return;
    }
    
    $member_id = intval($_GET['member_id']);
    $member = get_userdata($member_id);
    
    if (!$member) {
        echo '<div class="wrap"><h1>Miembro no encontrado</h1></div>';
        return;
    }
    
    $level_id = get_user_meta($member_id, 'gp_membership_level', true);
    $level = get_post($level_id);
    $start_date = get_user_meta($member_id, 'gp_membership_start_date', true);
    $benefits_used = get_user_meta($member_id, 'gp_benefits_used', true) ?: array();
    
    // Historial de compras
    $orders = wc_get_orders(array(
        'customer_id' => $member_id,
        'limit' => -1
    ));
    
    // Métodos de pago guardados
    $saved_payment_methods = gp_get_saved_payment_methods($member_id);
    
    ?>
    <div class="wrap">
        <h1>👤 <?php echo esc_html($member->display_name); ?></h1>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 30px 0;">
            
            <!-- Información General -->
            <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2>Información General</h2>
                <table class="form-table">
                    <tr>
                        <th>Email:</th>
                        <td><?php echo esc_html($member->user_email); ?></td>
                    </tr>
                    <tr>
                        <th>Nivel VIP:</th>
                        <td><strong style="color: #D4AF37;"><?php echo $level ? $level->post_title : 'Sin nivel'; ?></strong></td>
                    </tr>
                    <tr>
                        <th>Miembro desde:</th>
                        <td><?php echo $start_date ? date('d/m/Y', strtotime($start_date)) : '-'; ?></td>
                    </tr>
                    <tr>
                        <th>Total Gastado:</th>
                        <td><strong>$<?php echo number_format(gp_get_customer_total_spent($member_id), 2); ?></strong></td>
                    </tr>
                    <tr>
                        <th>Total de Órdenes:</th>
                        <td><?php echo count($orders); ?></td>
                    </tr>
                </table>
            </div>
            
            <!-- Beneficios Utilizados -->
            <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2>Beneficios Utilizados</h2>
                <?php if (!empty($benefits_used)): ?>
                    <ul>
                        <?php foreach ($benefits_used as $benefit): ?>
                            <li>
                                <strong><?php echo esc_html($benefit['name']); ?></strong>
                                <br>
                                <small>Usado el: <?php echo date('d/m/Y H:i', strtotime($benefit['date'])); ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No ha utilizado beneficios aún.</p>
                <?php endif; ?>
            </div>
            
        </div>
        
        <!-- Historial de Compras -->
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h2>📦 Historial de Compras (<?php echo count($orders); ?> órdenes)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Orden</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Productos</th>
                        <th>Total</th>
                        <th>Método de Pago</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong>#<?php echo $order->get_order_number(); ?></strong></td>
                        <td><?php echo $order->get_date_created()->format('d/m/Y H:i'); ?></td>
                        <td><?php echo wc_get_order_status_name($order->get_status()); ?></td>
                        <td>
                            <?php 
                            $items = $order->get_items();
                            echo count($items) . ' producto(s)';
                            ?>
                        </td>
                        <td><strong><?php echo $order->get_formatted_order_total(); ?></strong></td>
                        <td><?php echo $order->get_payment_method_title(); ?></td>
                        <td>
                            <a href="<?php echo $order->get_edit_order_url(); ?>" class="button button-small">Ver Orden</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Métodos de Pago Guardados -->
        <div style="background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2>💳 Métodos de Pago Guardados</h2>
            <?php if (!empty($saved_payment_methods)): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>Detalles</th>
                            <th>Expira</th>
                            <th>Predeterminado</th>
                            <th>Agregado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($saved_payment_methods as $method): ?>
                        <tr>
                            <td>
                                <?php if ($method['type'] === 'card'): ?>
                                    💳 Tarjeta
                                <?php else: ?>
                                    🏦 <?php echo ucfirst($method['type']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($method['type'] === 'card'): ?>
                                    <?php echo esc_html($method['brand']); ?> •••• <?php echo esc_html($method['last4']); ?>
                                <?php else: ?>
                                    <?php echo esc_html($method['details']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($method['exp_month']) && isset($method['exp_year'])): ?>
                                    <?php echo esc_html($method['exp_month']); ?>/<?php echo esc_html($method['exp_year']); ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($method['is_default']): ?>
                                    <span style="background: #2ECC71; color: white; padding: 4px 12px; border-radius: 12px; font-size: 12px;">Sí</span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y', strtotime($method['created'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay métodos de pago guardados.</p>
            <?php endif; ?>
        </div>
        
    </div>
    <?php
}

// ============================================
// GESTIÓN DE BENEFICIOS
// ============================================

function gp_benefits_page() {
    // Guardar beneficios
    if (isset($_POST['gp_save_benefits'])) {
        check_admin_referer('gp_benefits_nonce');
        
        $level_id = intval($_POST['level_id']);
        $benefits = array();
        
        if (isset($_POST['benefits']) && is_array($_POST['benefits'])) {
            foreach ($_POST['benefits'] as $benefit) {
                if (!empty($benefit['name'])) {
                    $benefits[] = array(
                        'name' => sanitize_text_field($benefit['name']),
                        'description' => sanitize_textarea_field($benefit['description']),
                        'type' => sanitize_text_field($benefit['type']),
                        'value' => sanitize_text_field($benefit['value']),
                        'limit' => intval($benefit['limit'])
                    );
                }
            }
        }
        
        update_post_meta($level_id, 'gp_membership_benefits', $benefits);
        
        echo '<div class="notice notice-success"><p>Beneficios guardados correctamente.</p></div>';
    }
    
    $levels = get_posts(array('post_type' => 'membership_level', 'posts_per_page' => -1));
    $selected_level = isset($_GET['level']) ? intval($_GET['level']) : ($levels ? $levels[0]->ID : 0);
    $current_benefits = get_post_meta($selected_level, 'gp_membership_benefits', true) ?: array();
    
    ?>
    <div class="wrap">
        <h1>🎁 Gestión de Beneficios VIP</h1>
        
        <form method="get" action="">
            <input type="hidden" name="page" value="gp-benefits">
            <select name="level" onchange="this.form.submit()" style="padding: 8px; font-size: 14px;">
                <?php foreach ($levels as $level): ?>
                    <option value="<?php echo $level->ID; ?>" <?php selected($selected_level, $level->ID); ?>>
                        <?php echo esc_html($level->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        
        <form method="post" action="" style="margin-top: 30px;">
            <?php wp_nonce_field('gp_benefits_nonce'); ?>
            <input type="hidden" name="level_id" value="<?php echo $selected_level; ?>">
            
            <div id="benefits-container">
                <?php if (!empty($current_benefits)): ?>
                    <?php foreach ($current_benefits as $index => $benefit): ?>
                        <?php echo gp_render_benefit_row($index, $benefit); ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php echo gp_render_benefit_row(0); ?>
                <?php endif; ?>
            </div>
            
            <button type="button" class="button" onclick="addBenefit()">+ Agregar Beneficio</button>
            
            <?php submit_button('Guardar Beneficios', 'primary', 'gp_save_benefits'); ?>
        </form>
        
        <script>
        let benefitIndex = <?php echo !empty($current_benefits) ? count($current_benefits) : 1; ?>;
        
        function addBenefit() {
            const container = document.getElementById('benefits-container');
            const newRow = `<?php echo str_replace(array("\n", "\r"), '', gp_render_benefit_row('REPLACE_INDEX')); ?>`.replace(/REPLACE_INDEX/g, benefitIndex);
            container.insertAdjacentHTML('beforeend', newRow);
            benefitIndex++;
        }
        
        function removeBenefit(btn) {
            btn.closest('.benefit-row').remove();
        }
        </script>
    </div>
    <?php
}

function gp_render_benefit_row($index, $benefit = array()) {
    $benefit = wp_parse_args($benefit, array(
        'name' => '',
        'description' => '',
        'type' => 'discount',
        'value' => '',
        'limit' => 0
    ));
    
    ob_start();
    ?>
    <div class="benefit-row" style="background: white; padding: 20px; margin-bottom: 15px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); position: relative;">
        <button type="button" onclick="removeBenefit(this)" style="position: absolute; top: 10px; right: 10px; background: #E74C3C; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer;">Eliminar</button>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <div>
                <label><strong>Nombre del Beneficio:</strong></label>
                <input type="text" name="benefits[<?php echo $index; ?>][name]" value="<?php echo esc_attr($benefit['name']); ?>" class="regular-text" placeholder="Ej: Descuento en todos los productos">
            </div>
            
            <div>
                <label><strong>Tipo:</strong></label>
                <select name="benefits[<?php echo $index; ?>][type]" style="width: 100%;">
                    <option value="discount" <?php selected($benefit['type'], 'discount'); ?>>Descuento</option>
                    <option value="free_shipping" <?php selected($benefit['type'], 'free_shipping'); ?>>Envío Gratis</option>
                    <option value="early_access" <?php selected($benefit['type'], 'early_access'); ?>>Acceso Anticipado</option>
                    <option value="personal_shopper" <?php selected($benefit['type'], 'personal_shopper'); ?>>Asesor Personal</option>
                    <option value="custom_design" <?php selected($benefit['type'], 'custom_design'); ?>>Diseño Personalizado</option>
                    <option value="priority_support" <?php selected($benefit['type'], 'priority_support'); ?>>Soporte Prioritario</option>
                    <option value="exclusive_events" <?php selected($benefit['type'], 'exclusive_events'); ?>>Eventos Exclusivos</option>
                    <option value="other" <?php selected($benefit['type'], 'other'); ?>>Otro</option>
                </select>
            </div>
        </div>
        
        <div style="margin-top: 15px;">
            <label><strong>Descripción:</strong></label>
            <textarea name="benefits[<?php echo $index; ?>][description]" class="large-text" rows="2" placeholder="Describe el beneficio en detalle"><?php echo esc_textarea($benefit['description']); ?></textarea>
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 15px;">
            <div>
                <label><strong>Valor:</strong></label>
                <input type="text" name="benefits[<?php echo $index; ?>][value]" value="<?php echo esc_attr($benefit['value']); ?>" class="regular-text" placeholder="Ej: 15% o 50 USD">
            </div>
            
            <div>
                <label><strong>Límite de Uso (0 = ilimitado):</strong></label>
                <input type="number" name="benefits[<?php echo $index; ?>][limit]" value="<?php echo esc_attr($benefit['limit']); ?>" min="0" class="small-text">
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

/**
 * Obtener total gastado por cliente
 */
function gp_get_customer_total_spent($user_id) {
    $orders = wc_get_orders(array(
        'customer_id' => $user_id,
        'status' => array('completed', 'processing'),
        'limit' => -1
    ));
    
    $total = 0;
    foreach ($orders as $order) {
        $total += $order->get_total();
    }
    
    return $total;
}

/**
 * Obtener métodos de pago guardados
 */
function gp_get_saved_payment_methods($user_id) {
    $methods = get_user_meta($user_id, 'gp_saved_payment_methods', true);
    return is_array($methods) ? $methods : array();
}

/**
 * Guardar método de pago
 */
function gp_save_payment_method($user_id, $method_data) {
    $methods = gp_get_saved_payment_methods($user_id);
    
    $method = array(
        'id' => uniqid('pm_'),
        'type' => sanitize_text_field($method_data['type']),
        'created' => current_time('mysql'),
        'is_default' => empty($methods)
    );
    
    if ($method_data['type'] === 'card') {
        $method['brand'] = sanitize_text_field($method_data['brand']);
        $method['last4'] = sanitize_text_field($method_data['last4']);
        $method['exp_month'] = sanitize_text_field($method_data['exp_month']);
        $method['exp_year'] = sanitize_text_field($method_data['exp_year']);
        $method['token'] = sanitize_text_field($method_data['token']); // Token de la pasarela (Stripe, etc)
    } else {
        $method['details'] = sanitize_text_field($method_data['details']);
    }
    
    $methods[] = $method;
    update_user_meta($user_id, 'gp_saved_payment_methods', $methods);
    
    return $method['id'];
}

/**
 * Eliminar método de pago
 */
function gp_delete_payment_method($user_id, $method_id) {
    $methods = gp_get_saved_payment_methods($user_id);
    
    foreach ($methods as $key => $method) {
        if ($method['id'] === $method_id) {
            unset($methods[$key]);
            break;
        }
    }
    
    update_user_meta($user_id, 'gp_saved_payment_methods', array_values($methods));
}

/**
 * Registrar uso de beneficio
 */
function gp_log_benefit_usage($user_id, $benefit_name, $details = '') {
    $benefits_used = get_user_meta($user_id, 'gp_benefits_used', true) ?: array();
    
    $benefits_used[] = array(
        'name' => $benefit_name,
        'details' => $details,
        'date' => current_time('mysql')
    );
    
    update_user_meta($user_id, 'gp_benefits_used', $benefits_used);
}

// ============================================
// META BOXES PARA USUARIOS
// ============================================

/**
 * Agregar meta box en perfil de usuario
 */
function gp_add_user_meta_boxes() {
    add_meta_box(
        'gp_membership_info',
        '👑 Información de Membresía VIP',
        'gp_render_user_membership_meta_box',
        'user',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes_user', 'gp_add_user_meta_boxes');

function gp_render_user_membership_meta_box($user) {
    $level_id = get_user_meta($user->ID, 'gp_membership_level', true);
    $levels = get_posts(array('post_type' => 'membership_level', 'posts_per_page' => -1));
    $status = get_user_meta($user->ID, 'gp_membership_status', true) ?: 'active';
    
    ?>
    <table class="form-table">
        <tr>
            <th><label>Nivel VIP</label></th>
            <td>
                <select name="gp_membership_level" style="width: 100%; max-width: 400px;">
                    <option value="">Sin membresía</option>
                    <?php foreach ($levels as $level): ?>
                        <option value="<?php echo $level->ID; ?>" <?php selected($level_id, $level->ID); ?>>
                            <?php echo esc_html($level->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th><label>Estado</label></th>
            <td>
                <select name="gp_membership_status" style="width: 200px;">
                    <option value="active" <?php selected($status, 'active'); ?>>Activo</option>
                    <option value="inactive" <?php selected($status, 'inactive'); ?>>Inactivo</option>
                    <option value="suspended" <?php selected($status, 'suspended'); ?>>Suspendido</option>
                </select>
            </td>
        </tr>
    </table>
    <?php
}

/**
 * Guardar datos de membresía del usuario
 */
function gp_save_user_membership_data($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return;
    }
    
    if (isset($_POST['gp_membership_level'])) {
        $old_level = get_user_meta($user_id, 'gp_membership_level', true);
        $new_level = sanitize_text_field($_POST['gp_membership_level']);
        
        update_user_meta($user_id, 'gp_membership_level', $new_level);
        
        // Si es nuevo miembro, guardar fecha
        if (empty($old_level) && !empty($new_level)) {
            update_user_meta($user_id, 'gp_membership_start_date', current_time('mysql'));
        }
    }
    
    if (isset($_POST['gp_membership_status'])) {
        update_user_meta($user_id, 'gp_membership_status', sanitize_text_field($_POST['gp_membership_status']));
    }
}
add_action('personal_options_update', 'gp_save_user_membership_data');
add_action('edit_user_profile_update', 'gp_save_user_membership_data');
