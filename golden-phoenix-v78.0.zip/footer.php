<footer class="site-footer">
    <div class="footer-main">
        
        <?php if (is_active_sidebar('footer-1')) : ?>
        <div class="footer-column footer-brand">
            <?php dynamic_sidebar('footer-1'); ?>
        </div>
        <?php else: ?>
        <div class="footer-column footer-brand">
            <h3 class="footer-brand-name"><?php bloginfo('name'); ?></h3>
            <p class="footer-tagline"><?php echo get_bloginfo('description') ? esc_html(get_bloginfo('description')) : 'Joyería de Lujo'; ?></p>
            <div class="footer-social">
                <?php
                $facebook = get_theme_mod('gp_facebook', '');
                $instagram = get_theme_mod('gp_instagram', '');
                $pinterest = get_theme_mod('gp_pinterest', '');
                $twitter = get_theme_mod('gp_twitter', '');
                
                if ($facebook || $instagram || $pinterest || $twitter) :
                    if ($instagram) : ?>
                        <a href="<?php echo esc_url($instagram); ?>" target="_blank" class="social-icon" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                    <?php endif;
                    if ($facebook) : ?>
                        <a href="<?php echo esc_url($facebook); ?>" target="_blank" class="social-icon" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                    <?php endif;
                    if ($pinterest) : ?>
                        <a href="<?php echo esc_url($pinterest); ?>" target="_blank" class="social-icon" aria-label="Pinterest">
                            <i class="fab fa-pinterest-p"></i>
                        </a>
                    <?php endif;
                    if ($twitter) : ?>
                        <a href="<?php echo esc_url($twitter); ?>" target="_blank" class="social-icon" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                        </a>
                    <?php endif;
                endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (is_active_sidebar('footer-2')) : ?>
        <div class="footer-column">
            <?php dynamic_sidebar('footer-2'); ?>
        </div>
        <?php else: ?>
        <div class="footer-column">
            <h4>Navegación</h4>
            <?php
            wp_nav_menu(array(
                'theme_location' => 'footer-1',
                'container' => false,
                'menu_class' => 'footer-links',
                'fallback_cb' => function() {
                    echo '<ul class="footer-links">';
                    echo '<li><a href="' . esc_url(home_url('/')) . '">Inicio</a></li>';
                    if (class_exists('WooCommerce')) {
                        echo '<li><a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '">Tienda</a></li>';
                    }
                    echo '<li><a href="' . esc_url(home_url('/nosotros')) . '">Nosotros</a></li>';
                    echo '<li><a href="' . esc_url(home_url('/contacto')) . '">Contacto</a></li>';
                    echo '</ul>';
                }
            ));
            ?>
        </div>
        <?php endif; ?>
        
        <?php if (is_active_sidebar('footer-3')) : ?>
        <div class="footer-column">
            <?php dynamic_sidebar('footer-3'); ?>
        </div>
        <?php else: ?>
        <div class="footer-column">
            <h4>Atención al Cliente</h4>
            <ul class="footer-links">
                <?php if (class_exists('WooCommerce')) : ?>
                <li><a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>">Mi Cuenta</a></li>
                <?php endif; ?>
                <li><a href="<?php echo esc_url(home_url('/wishlist')); ?>">Lista de Deseos</a></li>
                <li><a href="<?php echo esc_url(home_url('/preguntas-frecuentes')); ?>">Preguntas Frecuentes</a></li>
                <li><a href="<?php echo esc_url(home_url('/envios')); ?>">Envíos y Devoluciones</a></li>
            </ul>
        </div>
        <?php endif; ?>
        
        <?php if (is_active_sidebar('footer-4')) : ?>
        <div class="footer-column">
            <?php dynamic_sidebar('footer-4'); ?>
        </div>
        <?php else: ?>
        <div class="footer-column">
            <h4>Contacto</h4>
            <ul class="footer-links footer-contact">
                <?php
                $phone = get_theme_mod('gp_phone', '');
                $email = get_theme_mod('gp_email', '');
                $address = get_theme_mod('gp_address', '');
                
                if ($phone) : ?>
                <li>
                    <i class="fas fa-phone"></i>
                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>"><?php echo esc_html($phone); ?></a>
                </li>
                <?php endif;
                
                if ($email) : ?>
                <li>
                    <i class="fas fa-envelope"></i>
                    <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
                </li>
                <?php endif;
                
                if ($address) : ?>
                <li>
                    <i class="fas fa-map-marker-alt"></i>
                    <?php echo esc_html($address); ?>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <?php endif; ?>
        
    </div>
    
    <div class="footer-bottom">
        <div class="footer-copyright">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Todos los derechos reservados.</p>
        </div>
        
        <div class="footer-payment">
            <span class="payment-methods">Aceptamos: Visa • Mastercard • American Express • PayPal</span>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<button class="back-to-top" id="backToTop" aria-label="Volver arriba">
    <i class="fas fa-chevron-up"></i>
</button>

<?php wp_footer(); ?>

<style>
/* Footer Professional Styles */
.footer-brand-name {
    font-family: 'Playfair Display', serif;
    font-size: 1.5rem;
    color: #D4AF37;
    margin: 0 0 0.5rem 0;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 2px;
}

.footer-tagline {
    color: #B0B0B0;
    font-size: 0.875rem;
    margin-bottom: 1.5rem;
    line-height: 1.6;
}

.footer-contact {
    list-style: none;
    padding: 0;
}

.footer-contact li {
    display: flex;
    align-items: flex-start;
    margin-bottom: 0.75rem;
    color: #E0E0E0;
}

.footer-contact li i {
    color: #D4AF37;
    margin-right: 0.75rem;
    margin-top: 0.25rem;
    font-size: 0.875rem;
}

.footer-contact li a {
    color: #E0E0E0;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-contact li a:hover {
    color: #D4AF37;
}

.payment-methods {
    color: #D4AF37;
    font-size: 0.875rem;
    letter-spacing: 0.5px;
}

/* Footer Widgets */
.footer-widget {
    margin-bottom: 2rem;
}

.footer-widget-title {
    font-family: 'Playfair Display', serif;
    font-size: 1.25rem;
    color: #D4AF37;
    margin-bottom: 1rem;
    font-weight: 600;
}

.footer-widget ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.footer-widget ul li {
    margin-bottom: 0.75rem;
    line-height: 1.6;
}

.footer-widget ul li a {
    color: #E0E0E0;
    text-decoration: none;
    transition: color 0.3s ease;
}

.footer-widget ul li a:hover {
    color: #D4AF37;
}

.footer-widget p {
    color: #E0E0E0;
    line-height: 1.8;
    margin-bottom: 1rem;
}

/* Widget de texto */
.textwidget {
    color: #E0E0E0;
    line-height: 1.6;
}

.textwidget a {
    color: #D4AF37;
    text-decoration: none;
}

.textwidget a:hover {
    text-decoration: underline;
}

/* Social icons */
.footer-social {
    display: flex;
    gap: 1rem;
    margin-top: 1.5rem;
}

.social-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 2px solid rgba(212, 175, 55, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    color: #D4AF37;
    transition: all 0.3s ease;
    text-decoration: none;
    font-size: 1.125rem;
}

.social-icon:hover {
    background: #D4AF37;
    color: #0A0A0A;
    border-color: #D4AF37;
    transform: translateY(-3px);
}

/* Back to Top Button */
.back-to-top {
    position: fixed;
    bottom: 2rem;
    right: 2rem;
    width: 50px;
    height: 50px;
    background: var(--gold-primary);
    border: none;
    border-radius: 50%;
    color: var(--black-deep);
    font-size: 1.25rem;
    cursor: pointer;
    z-index: 9998;
    opacity: 0;
    visibility: hidden;
    transition: var(--transition-smooth);
    box-shadow: 0 4px 20px rgba(212, 175, 55, 0.4);
}

.back-to-top.visible {
    opacity: 1;
    visibility: visible;
}

.back-to-top:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(212, 175, 55, 0.6);
}

.footer-links li {
    display: flex;
    align-items: flex-start;
}

@media (max-width: 768px) {
    .back-to-top {
        bottom: 1rem;
        right: 1rem;
        width: 45px;
        height: 45px;
    }
}
</style>

<script>
// Back to top button
const backToTop = document.getElementById('backToTop');

window.addEventListener('scroll', function() {
    if (window.pageYOffset > 500) {
        backToTop.classList.add('visible');
    } else {
        backToTop.classList.remove('visible');
    }
});

backToTop.addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Newsletter form handler
document.querySelectorAll('.newsletter-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        const emailInput = this.querySelector('input[type="email"]');
        if (emailInput.value) {
            // Aquí puedes agregar tu lógica de suscripción
            alert('¡Gracias por suscribirte! Te mantendremos informado de nuestras novedades exclusivas.');
        }
    });
});

// Animación de números en estadísticas (si están visibles)
const animateNumbers = function() {
    const stats = document.querySelectorAll('.stat-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const finalValue = target.textContent;
                const isYear = finalValue.includes('1892');
                const hasPlus = finalValue.includes('+');
                const numericValue = parseInt(finalValue.replace(/\D/g, ''));
                
                let currentValue = 0;
                const increment = isYear ? 10 : Math.ceil(numericValue / 50);
                const duration = 2000;
                const stepTime = duration / (numericValue / increment);
                
                const counter = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= numericValue) {
                        currentValue = numericValue;
                        clearInterval(counter);
                    }
                    target.textContent = currentValue + (hasPlus ? '+' : '');
                }, stepTime);
                
                observer.unobserve(target);
            }
        });
    }, { threshold: 0.5 });
    
    stats.forEach(stat => observer.observe(stat));
};

// Ejecutar animación cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', animateNumbers);
} else {
    animateNumbers();
}

// Mejorar experiencia de wishlist
let wishlistCount = 0;
document.querySelectorAll('.product-wishlist').forEach(icon => {
    icon.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const isAdded = this.innerHTML === '♥';
        
        if (isAdded) {
            wishlistCount--;
        } else {
            wishlistCount++;
        }
        
        // Actualizar contador en header
        const wishlistCountEl = document.querySelector('.wishlist-count');
        if (wishlistCountEl) {
            wishlistCountEl.textContent = wishlistCount;
            if (wishlistCount > 0) {
                wishlistCountEl.classList.add('has-items');
            } else {
                wishlistCountEl.classList.remove('has-items');
            }
        }
    });
});
</script>

</body>
</html>
