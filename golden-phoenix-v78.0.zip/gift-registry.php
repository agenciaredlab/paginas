<?php
/**
 * V76 - GIFT REGISTRY
 * Registro de regalos para bodas/eventos
 */
if (!defined('ABSPATH')) exit;

add_action('after_switch_theme', function() {
    if (get_option('gp_registry_page_created')) return;
    wp_insert_post(array(
        'post_title' => 'Crear Registro de Regalos',
        'post_name' => 'registro-regalos',
        'post_content' => '[create_gift_registry]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    update_option('gp_registry_page_created', true);
});

add_shortcode('create_gift_registry', function() {
    ob_start();
    ?>
    <div style="max-width: 800px; margin: 0 auto;">
        <h1 style="text-align: center;">🎁 Crea tu Registro de Regalos</h1>
        <p style="text-align: center; color: #666;">Ideal para bodas, cumpleaños, baby showers</p>
        
        <form id="registry-form" style="background: white; padding: 40px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-top: 30px;">
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Tipo de Evento:</label>
                <select name="event_type" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="boda">💍 Boda</option>
                    <option value="cumpleaños">🎂 Cumpleaños</option>
                    <option value="baby-shower">👶 Baby Shower</option>
                    <option value="aniversario">💕 Aniversario</option>
                    <option value="otro">🎉 Otro</option>
                </select>
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Nombre(s):</label>
                <input type="text" name="registry_name" placeholder="Ej: María & Juan" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Fecha del Evento:</label>
                <input type="date" name="event_date" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Email de Contacto:</label>
                <input type="email" name="contact_email" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">Mensaje Personalizado:</label>
                <textarea name="message" rows="4" placeholder="Mensaje para tus invitados..." style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;"></textarea>
            </div>
            
            <button type="submit" style="width: 100%; padding: 15px; background: #D4AF37; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 16px; cursor: pointer;">
                🎁 Crear Mi Registro
            </button>
        </form>
        
        <div id="registry-result" style="margin-top: 30px;"></div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#registry-form').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();
            
            $.post('<?php echo admin_url('admin-ajax.php'); ?>', formData + '&action=gp_create_registry', function(response) {
                if (response.success) {
                    $('#registry-result').html('<div style="background: #D4F4DD; padding: 30px; border-radius: 12px; text-align: center;"><h2>✅ Registro Creado</h2><p>Tu link:</p><input type="text" value="' + response.data.link + '" readonly style="width: 100%; padding: 10px; margin: 10px 0;"><button onclick="navigator.clipboard.writeText(\'' + response.data.link + '\'); alert(\'Link copiado!\');" class="button">Copiar Link</button></div>');
                    $('#registry-form').hide();
                }
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
});

add_action('wp_ajax_gp_create_registry', 'gp_process_create_registry');
add_action('wp_ajax_nopriv_gp_create_registry', 'gp_process_create_registry');

function gp_process_create_registry() {
    $registry_id = uniqid('reg_');
    
    $registry_data = array(
        'type' => sanitize_text_field($_POST['event_type']),
        'name' => sanitize_text_field($_POST['registry_name']),
        'date' => sanitize_text_field($_POST['event_date']),
        'email' => sanitize_email($_POST['contact_email']),
        'message' => sanitize_textarea_field($_POST['message']),
        'created' => current_time('mysql'),
    );
    
    update_option('gp_registry_' . $registry_id, $registry_data);
    
    $link = home_url('/registro/' . $registry_id);
    
    wp_send_json_success(array('link' => $link, 'id' => $registry_id));
}
