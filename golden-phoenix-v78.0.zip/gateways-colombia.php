<?php
/**
 * Golden Phoenix Jewelry - PASARELAS COLOMBIANAS
 * PSE + Wompi + Mercado Pago + Más
 * 
 * @package Golden_Phoenix
 * @version 5.0
 */

if (!defined('ABSPATH')) exit;

// ============================================
// WOMPI - COLOMBIA
// ============================================

class GP_Wompi_Gateway extends WC_Payment_Gateway {
    
    public function __construct() {
        $this->id = 'gp_wompi';
        $this->icon = GOLDEN_PHOENIX_URI . '/assets/images/wompi-logo.png';
        $this->has_fields = false;
        $this->method_title = 'Wompi - Bancolombia';
        $this->method_description = 'Paga con tarjeta, PSE, Nequi y más con Wompi';
        
        $this->supports = array(
            'products',
            'subscriptions',
            'refunds',
            'tokenization'
        );
        
        $this->init_form_fields();
        $this->init_settings();
        
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'yes' === $this->get_option('testmode');
        
        // Credenciales
        $this->public_key = $this->testmode ? 
            $this->get_option('test_public_key') : 
            $this->get_option('public_key');
        
        $this->private_key = $this->testmode ? 
            $this->get_option('test_private_key') : 
            $this->get_option('private_key');
        
        $this->api_url = $this->testmode ?
            'https://sandbox.wompi.co/v1/' :
            'https://production.wompi.co/v1/';
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_gp_wompi_webhook', array($this, 'handle_webhook'));
    }
    
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilitar/Deshabilitar',
                'type' => 'checkbox',
                'label' => 'Habilitar Wompi',
                'default' => 'no'
            ),
            'title' => array(
                'title' => 'Título',
                'type' => 'text',
                'default' => 'Wompi - Pago Fácil y Seguro',
            ),
            'description' => array(
                'title' => 'Descripción',
                'type' => 'textarea',
                'default' => 'Paga con tarjeta, PSE, Nequi o transferencia Bancolombia',
            ),
            'testmode' => array(
                'title' => 'Modo de Prueba',
                'type' => 'checkbox',
                'label' => 'Habilitar modo de prueba',
                'default' => 'yes',
            ),
            'public_key' => array(
                'title' => 'Public Key (Producción)',
                'type' => 'text',
                'description' => 'Llave pública de Wompi',
            ),
            'private_key' => array(
                'title' => 'Private Key (Producción)',
                'type' => 'password',
            ),
            'test_public_key' => array(
                'title' => 'Test Public Key',
                'type' => 'text',
                'default' => 'pub_test_tXHf7HNpPXBxwpfKaGEbsP9yNgspttVa',
            ),
            'test_private_key' => array(
                'title' => 'Test Private Key',
                'type' => 'password',
                'default' => 'prv_test_qIorS2v5nJHUNt2aeThFPBYtM8wP1DSU',
            ),
            'payment_methods' => array(
                'title' => 'Métodos de Pago',
                'type' => 'multiselect',
                'options' => array(
                    'CARD' => 'Tarjetas',
                    'PSE' => 'PSE',
                    'NEQUI' => 'Nequi',
                    'BANCOLOMBIA_TRANSFER' => 'Transferencia Bancolombia'
                ),
                'default' => array('CARD', 'PSE', 'NEQUI'),
            ),
        );
    }
    
    public function payment_fields() {
        if ($this->description) {
            echo wpautop(wp_kses_post($this->description));
        }
        
        if ($this->testmode) {
            echo '<p style="background: #fff3cd; padding: 10px;">MODO DE PRUEBA</p>';
        }
        
        $payment_methods = $this->get_option('payment_methods');
        ?>
        <div class="gp-wompi-payment">
            <p><strong>Selecciona cómo pagar:</strong></p>
            
            <?php if (in_array('CARD', $payment_methods)): ?>
            <label class="wompi-method">
                <input type="radio" name="wompi_payment_method" value="CARD" checked>
                💳 Tarjeta de Crédito/Débito
            </label>
            <?php endif; ?>
            
            <?php if (in_array('PSE', $payment_methods)): ?>
            <label class="wompi-method">
                <input type="radio" name="wompi_payment_method" value="PSE">
                🏦 PSE (Transferencia Bancaria)
            </label>
            <?php endif; ?>
            
            <?php if (in_array('NEQUI', $payment_methods)): ?>
            <label class="wompi-method">
                <input type="radio" name="wompi_payment_method" value="NEQUI">
                📱 Nequi
            </label>
            <?php endif; ?>
            
            <?php if (in_array('BANCOLOMBIA_TRANSFER', $payment_methods)): ?>
            <label class="wompi-method">
                <input type="radio" name="wompi_payment_method" value="BANCOLOMBIA_TRANSFER">
                🏛️ Transferencia Bancolombia
            </label>
            <?php endif; ?>
        </div>
        
        <style>
        .wompi-method {
            display: block;
            padding: 12px;
            margin: 8px 0;
            border: 2px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .wompi-method:hover {
            border-color: #D4AF37;
            background: #f9f9f9;
        }
        .wompi-method input[type="radio"] {
            margin-right: 10px;
        }
        </style>
        <?php
    }
    
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $payment_method = isset($_POST['wompi_payment_method']) ? 
            sanitize_text_field($_POST['wompi_payment_method']) : 'CARD';
        
        // Crear transacción en Wompi
        $transaction_data = array(
            'amount_in_cents' => intval($order->get_total() * 100),
            'currency' => 'COP',
            'customer_email' => $order->get_billing_email(),
            'payment_method' => array(
                'type' => $payment_method
            ),
            'reference' => 'GP_' . $order_id . '_' . time(),
            'redirect_url' => $this->get_return_url($order)
        );
        
        $response = $this->create_transaction($transaction_data);
        
        if (isset($response['data']['id'])) {
            // Guardar ID de transacción
            update_post_meta($order_id, '_wompi_transaction_id', $response['data']['id']);
            
            // Redirigir a Wompi
            return array(
                'result' => 'success',
                'redirect' => $response['data']['payment_link_url']
            );
        }
        
        wc_add_notice('Error al procesar el pago', 'error');
        return array('result' => 'failure');
    }
    
    private function create_transaction($data) {
        $response = wp_remote_post($this->api_url . 'transactions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->private_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        return json_decode(wp_remote_retrieve_body($response), true);
    }
    
    public function handle_webhook() {
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);
        
        if (isset($data['event']) && $data['event'] === 'transaction.updated') {
            $transaction = $data['data']['transaction'];
            $reference = $transaction['reference'];
            
            // Extraer order_id de la referencia
            $parts = explode('_', $reference);
            $order_id = isset($parts[1]) ? intval($parts[1]) : 0;
            
            if ($order_id) {
                $order = wc_get_order($order_id);
                
                if ($transaction['status'] === 'APPROVED') {
                    $order->payment_complete();
                    $order->add_order_note('Pago Wompi aprobado');
                } elseif ($transaction['status'] === 'DECLINED') {
                    $order->update_status('failed', 'Pago Wompi rechazado');
                }
            }
        }
        
        status_header(200);
        die('OK');
    }
}

// ============================================
// MERCADO PAGO - COLOMBIA
// ============================================

class GP_MercadoPago_Gateway extends WC_Payment_Gateway {
    
    public function __construct() {
        $this->id = 'gp_mercadopago';
        $this->icon = GOLDEN_PHOENIX_URI . '/assets/images/mercadopago-logo.png';
        $this->has_fields = true;
        $this->method_title = 'Mercado Pago';
        $this->method_description = 'Acepta pagos con Mercado Pago (tarjetas, PSE, efectivo)';
        
        $this->supports = array(
            'products',
            'refunds',
            'subscriptions'
        );
        
        $this->init_form_fields();
        $this->init_settings();
        
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'yes' === $this->get_option('testmode');
        
        $this->public_key = $this->testmode ? 
            $this->get_option('test_public_key') : 
            $this->get_option('public_key');
        
        $this->access_token = $this->testmode ? 
            $this->get_option('test_access_token') : 
            $this->get_option('access_token');
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_gp_mercadopago_webhook', array($this, 'handle_webhook'));
        add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
    }
    
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilitar/Deshabilitar',
                'type' => 'checkbox',
                'label' => 'Habilitar Mercado Pago',
                'default' => 'no'
            ),
            'title' => array(
                'title' => 'Título',
                'type' => 'text',
                'default' => 'Mercado Pago',
            ),
            'description' => array(
                'title' => 'Descripción',
                'type' => 'textarea',
                'default' => 'Paga con tarjeta, PSE, Baloto, Efecty y más',
            ),
            'testmode' => array(
                'title' => 'Modo de Prueba',
                'type' => 'checkbox',
                'default' => 'yes',
            ),
            'public_key' => array(
                'title' => 'Public Key',
                'type' => 'text',
            ),
            'access_token' => array(
                'title' => 'Access Token',
                'type' => 'password',
            ),
            'test_public_key' => array(
                'title' => 'Test Public Key',
                'type' => 'text',
                'default' => 'TEST-xxxx',
            ),
            'test_access_token' => array(
                'title' => 'Test Access Token',
                'type' => 'password',
                'default' => 'TEST-xxxx',
            ),
            'installments' => array(
                'title' => 'Cuotas Máximas',
                'type' => 'number',
                'default' => 12,
            ),
        );
    }
    
    public function payment_scripts() {
        if (!is_checkout()) return;
        
        wp_enqueue_script('mercadopago-js', 'https://sdk.mercadopago.com/js/v2', array(), null, true);
        
        wp_add_inline_script('mercadopago-js', "
            const mp = new MercadoPago('" . esc_js($this->public_key) . "');
            const cardForm = mp.cardForm({
                amount: '" . WC()->cart->get_total('') . "',
                autoMount: true,
                form: {
                    id: 'mercadopago-form',
                    cardholderName: {
                        id: 'mp-cardholder-name',
                        placeholder: 'Titular de la tarjeta',
                    },
                    cardholderEmail: {
                        id: 'mp-cardholder-email',
                        placeholder: 'Email',
                    },
                    cardNumber: {
                        id: 'mp-card-number',
                        placeholder: 'Número de tarjeta',
                    },
                    expirationDate: {
                        id: 'mp-expiration-date',
                        placeholder: 'MM/YY',
                    },
                    securityCode: {
                        id: 'mp-security-code',
                        placeholder: 'CVV',
                    },
                    installments: {
                        id: 'mp-installments',
                    },
                    identificationType: {
                        id: 'mp-id-type',
                    },
                    identificationNumber: {
                        id: 'mp-id-number',
                        placeholder: 'Número de documento',
                    },
                    issuer: {
                        id: 'mp-issuer',
                    }
                },
                callbacks: {
                    onFormMounted: error => {
                        if (error) console.error(error);
                    },
                    onSubmit: event => {
                        event.preventDefault();
                        const form = document.getElementById('mercadopago-form');
                        const formData = new FormData(form);
                        
                        fetch('/wp-json/golden-phoenix/v1/mercadopago/process', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                window.location.href = data.redirect_url;
                            } else {
                                alert(data.message);
                            }
                        });
                    }
                }
            });
        ");
    }
    
    public function payment_fields() {
        echo wpautop(wp_kses_post($this->description));
        
        ?>
        <form id="mercadopago-form">
            <div class="mp-field">
                <input type="text" id="mp-cardholder-name" />
            </div>
            
            <div class="mp-field">
                <input type="email" id="mp-cardholder-email" />
            </div>
            
            <div class="mp-field">
                <input type="text" id="mp-card-number" />
            </div>
            
            <div class="mp-field-row">
                <input type="text" id="mp-expiration-date" />
                <input type="text" id="mp-security-code" />
            </div>
            
            <div class="mp-field">
                <select id="mp-id-type"></select>
            </div>
            
            <div class="mp-field">
                <input type="text" id="mp-id-number" />
            </div>
            
            <div class="mp-field">
                <select id="mp-installments"></select>
            </div>
            
            <select id="mp-issuer" style="display:none;"></select>
        </form>
        
        <style>
        .mp-field {
            margin-bottom: 15px;
        }
        .mp-field input,
        .mp-field select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .mp-field-row {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 10px;
        }
        </style>
        <?php
    }
    
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        
        // Crear preferencia de pago
        $preference_data = array(
            'items' => array(
                array(
                    'title' => 'Orden #' . $order->get_order_number(),
                    'quantity' => 1,
                    'unit_price' => floatval($order->get_total())
                )
            ),
            'payer' => array(
                'email' => $order->get_billing_email(),
                'name' => $order->get_billing_first_name(),
                'surname' => $order->get_billing_last_name(),
            ),
            'back_urls' => array(
                'success' => $this->get_return_url($order),
                'failure' => wc_get_checkout_url(),
                'pending' => $this->get_return_url($order)
            ),
            'auto_return' => 'approved',
            'external_reference' => 'GP_' . $order_id,
            'notification_url' => WC()->api_request_url('gp_mercadopago_webhook')
        );
        
        $response = wp_remote_post('https://api.mercadopago.com/checkout/preferences', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->access_token,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($preference_data),
            'timeout' => 30
        ));
        
        if (!is_wp_error($response)) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            
            if (isset($data['init_point'])) {
                return array(
                    'result' => 'success',
                    'redirect' => $data['init_point']
                );
            }
        }
        
        wc_add_notice('Error al procesar el pago', 'error');
        return array('result' => 'failure');
    }
    
    public function handle_webhook() {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (isset($data['type']) && $data['type'] === 'payment') {
            $payment_id = $data['data']['id'];
            
            $response = wp_remote_get('https://api.mercadopago.com/v1/payments/' . $payment_id, array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->access_token
                )
            ));
            
            $payment = json_decode(wp_remote_retrieve_body($response), true);
            
            if (isset($payment['external_reference'])) {
                $parts = explode('_', $payment['external_reference']);
                $order_id = isset($parts[1]) ? intval($parts[1]) : 0;
                
                if ($order_id) {
                    $order = wc_get_order($order_id);
                    
                    if ($payment['status'] === 'approved') {
                        $order->payment_complete();
                    } elseif ($payment['status'] === 'rejected') {
                        $order->update_status('failed');
                    }
                }
            }
        }
        
        status_header(200);
        die('OK');
    }
}

// ============================================
// ADDI - COMPRA AHORA PAGA DESPUÉS
// ============================================

class GP_Addi_Gateway extends WC_Payment_Gateway {
    
    public function __construct() {
        $this->id = 'gp_addi';
        $this->icon = GOLDEN_PHOENIX_URI . '/assets/images/addi-logo.png';
        $this->has_fields = false;
        $this->method_title = 'Addi - Compra ahora, paga después';
        $this->method_description = 'Financia tus compras con Addi';
        
        $this->init_form_fields();
        $this->init_settings();
        
        $this->title = 'Paga en cuotas con Addi';
        $this->description = 'Aprobación inmediata. Paga en 3, 6 o 12 cuotas sin tarjeta de crédito';
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }
    
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => 'Habilitar Addi',
                'type' => 'checkbox',
                'default' => 'no'
            ),
            'api_key' => array(
                'title' => 'API Key',
                'type' => 'password'
            ),
            'min_amount' => array(
                'title' => 'Monto Mínimo',
                'type' => 'number',
                'default' => 50000
            ),
            'max_amount' => array(
                'title' => 'Monto Máximo',
                'type' => 'number',
                'default' => 5000000
            ),
        );
    }
}

// ============================================
// REGISTRAR TODAS LAS PASARELAS
// ============================================

add_filter('woocommerce_payment_gateways', function($gateways) {
    $gateways[] = 'GP_PSE_Gateway'; // Ya creada anteriormente
    $gateways[] = 'GP_Wompi_Gateway';
    $gateways[] = 'GP_MercadoPago_Gateway';
    $gateways[] = 'GP_Addi_Gateway';
    return $gateways;
});

// ============================================
// API ENDPOINT PARA MERCADO PAGO
// ============================================

add_action('rest_api_init', function() {
    register_rest_route('golden-phoenix/v1', '/mercadopago/process', array(
        'methods' => 'POST',
        'callback' => 'gp_process_mercadopago_payment',
        'permission_callback' => '__return_true'
    ));
});

function gp_process_mercadopago_payment($request) {
    // Procesar pago de Mercado Pago
    $token = $request->get_param('token');
    $installments = $request->get_param('installments');
    
    // Lógica de procesamiento
    return new WP_REST_Response(array(
        'success' => true,
        'redirect_url' => wc_get_checkout_url()
    ), 200);
}
