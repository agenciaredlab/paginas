<?php
/**
 * V75 - HELP PAGE
 * Guía visual de todas las funciones
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function() {
    add_submenu_page(
        'golden-phoenix-settings',
        'Ayuda',
        '❓ Ayuda',
        'manage_options',
        'gp-help',
        'gp_help_page'
    );
});

function gp_help_page() {
    ?>
    <div class="wrap">
        <h1>❓ Golden Phoenix - Guía de Funciones</h1>
        
        <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin: 20px 0;">
            
            <h2>🚀 Inicio Rápido</h2>
            <ol style="font-size: 16px; line-height: 2;">
                <li>Ve a <a href="<?php echo admin_url('admin.php?page=golden-phoenix-settings'); ?>"><strong>GP Settings</strong></a></li>
                <li>Configura cada sección según tus necesidades</li>
                <li>Activa/desactiva funciones con checkboxes</li>
                <li>Guarda cambios</li>
            </ol>
            
            <hr style="margin: 40px 0;">
            
            <h2>📋 42 Funciones Disponibles</h2>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px;">
                
                <!-- E-commerce -->
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 12px;">
                    <h3 style="margin-top: 0;">🛍️ E-commerce (7)</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li>✅ WhatsApp Direct Order</li>
                        <li>✅ Multi-Currency (5 monedas)</li>
                        <li>✅ Gift Finder</li>
                        <li>✅ Bundle Discounts</li>
                        <li>✅ Instagram Shop</li>
                        <li>✅ Facebook Shop</li>
                        <li>✅ Order Tracking</li>
                    </ul>
                    <a href="<?php echo admin_url('admin.php?page=gp-ecommerce-settings'); ?>" class="button" style="background: white; color: #667eea;">Configurar →</a>
                </div>
                
                <!-- Joyería -->
                <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 25px; border-radius: 12px;">
                    <h3 style="margin-top: 0;">💎 Joyería (7)</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li>✅ Metal Selector</li>
                        <li>✅ Gemstone Selector</li>
                        <li>✅ Certificate Authenticity</li>
                        <li>✅ Ring Size Guide</li>
                        <li>✅ Engraving Options</li>
                        <li>✅ Custom Jewelry Builder</li>
                        <li>✅ Price Calculator</li>
                    </ul>
                    <a href="<?php echo admin_url('admin.php?page=gp-jewelry-settings'); ?>" class="button" style="background: white; color: #f5576c;">Configurar →</a>
                </div>
                
                <!-- Chats -->
                <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 25px; border-radius: 12px;">
                    <h3 style="margin-top: 0;">💬 Comunicación (4)</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li>✅ Chat en Vivo</li>
                        <li>✅ WhatsApp Flotante</li>
                        <li>✅ 4 Integraciones Chat</li>
                        <li>✅ Email Marketing</li>
                    </ul>
                    <a href="<?php echo admin_url('admin.php?page=gp-chat-settings'); ?>" class="button" style="background: white; color: #00f2fe;">Configurar →</a>
                </div>
                
                <!-- Analytics -->
                <div style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 25px; border-radius: 12px;">
                    <h3 style="margin-top: 0;">📊 Analytics (3)</h3>
                    <ul style="list-style: none; padding: 0;">
                        <li>✅ Dashboard KPIs</li>
                        <li>✅ Customer Segmentation</li>
                        <li>✅ Advanced Tracking</li>
                    </ul>
                    <a href="<?php echo admin_url('admin.php?page=gp-analytics'); ?>" class="button" style="background: white; color: #38f9d7;">Ver Analytics →</a>
                </div>
                
            </div>
            
            <hr style="margin: 40px 0;">
            
            <h2>📺 Video Tutoriales</h2>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                
                <div style="border: 2px solid #ddd; padding: 20px; border-radius: 8px; text-align: center;">
                    <h4>1️⃣ Configuración Inicial</h4>
                    <p>Configura WhatsApp, monedas y descuentos</p>
                    <span style="font-size: 12px; color: #666;">⏱ 3 min</span>
                </div>
                
                <div style="border: 2px solid #ddd; padding: 20px; border-radius: 8px; text-align: center;">
                    <h4>2️⃣ Selectores Joyería</h4>
                    <p>Activa metales, piedras y grabado</p>
                    <span style="font-size: 12px; color: #666;">⏱ 5 min</span>
                </div>
                
                <div style="border: 2px solid #ddd; padding: 20px; border-radius: 8px; text-align: center;">
                    <h4>3️⃣ Custom Builder</h4>
                    <p>Crea joyas personalizadas paso a paso</p>
                    <span style="font-size: 12px; color: #666;">⏱ 4 min</span>
                </div>
                
            </div>
            
            <hr style="margin: 40px 0;">
            
            <h2>🆘 Soporte</h2>
            
            <div style="background: #f9f9f9; padding: 20px; border-radius: 8px;">
                <p><strong>¿Necesitas ayuda?</strong></p>
                <ul>
                    <li>📧 Email: <a href="mailto:ventas@agenciaredlab.com">ventas@agenciaredlab.com</a></li>
                    <li>📱 WhatsApp: <a href="https://wa.me/573001234567">+57 300 123 4567</a></li>
                    <li>🌐 Web: <a href="https://agenciaredlab.com" target="_blank">agenciaredlab.com</a></li>
                </ul>
            </div>
            
        </div>
    </div>
    <?php
}
