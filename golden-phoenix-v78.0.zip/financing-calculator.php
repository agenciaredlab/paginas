<?php
/**
 * V77 - FINANCING CALCULATOR
 * Calculadora cuotas y financiamiento
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_single_product_summary', 'gp_financing_calculator', 25);

function gp_financing_calculator() {
    global $product;
    
    $price = $product->get_price();
    if ($price < 100000) return; // Solo productos >$100k
    ?>
    
    <div class="gp-financing-calc" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 25px; border-radius: 12px; margin: 20px 0;">
        <h4 style="margin-top: 0; color: white;">💳 Calculadora de Financiamiento</h4>
        
        <div style="margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 8px;">Cuotas:</label>
            <select id="gp-installments" style="width: 100%; padding: 10px; border-radius: 6px; border: none;">
                <option value="3">3 cuotas</option>
                <option value="6">6 cuotas</option>
                <option value="12" selected>12 cuotas</option>
                <option value="18">18 cuotas</option>
                <option value="24">24 cuotas</option>
            </select>
        </div>
        
        <div style="background: rgba(255,255,255,0.2); padding: 20px; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span>Precio:</span>
                <strong>$<?php echo number_format($price, 0, ',', '.'); ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span>Cuota mensual:</span>
                <strong id="gp-monthly-payment">$<?php echo number_format($price / 12, 0, ',', '.'); ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 12px; opacity: 0.9;">
                <span>Interés aprox:</span>
                <span id="gp-interest">2.5% mensual</span>
            </div>
        </div>
        
        <p style="font-size: 12px; margin: 15px 0 0 0; opacity: 0.9;">
            * Ejemplo ilustrativo. Consulta condiciones reales en el checkout.
        </p>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var basePrice = <?php echo $price; ?>;
        
        $('#gp-installments').on('change', function() {
            var months = parseInt($(this).val());
            var interest = 0.025; // 2.5% mensual
            var totalWithInterest = basePrice * (1 + (interest * months));
            var monthly = totalWithInterest / months;
            
            $('#gp-monthly-payment').text('$' + monthly.toLocaleString('es-CO', {maximumFractionDigits: 0}));
        });
    });
    </script>
    
    <?php
}
