<?php
/**
 * V74 - CERTIFICATE OF AUTHENTICITY
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_order_status_completed', 'gp_generate_certificate');

function gp_generate_certificate($order_id) {
    $order = wc_get_order($order_id);
    
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();
        
        if (get_post_meta($product->get_id(), '_includes_certificate', true) === 'yes') {
            $cert_id = 'CERT-' . $order_id . '-' . $product->get_id();
            $cert_data = array(
                'id' => $cert_id,
                'product_name' => $product->get_name(),
                'date' => date('Y-m-d'),
                'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'order_id' => $order_id,
            );
            
            update_post_meta($order_id, '_certificate_' . $product->get_id(), $cert_data);
        }
    }
}

add_shortcode('view_certificate', function($atts) {
    $order_id = intval($atts['order_id']);
    $product_id = intval($atts['product_id']);
    $cert = get_post_meta($order_id, '_certificate_' . $product_id, true);
    
    if (!$cert) return 'Certificado no encontrado';
    
    ob_start();
    ?>
    <div style="max-width: 600px; margin: 40px auto; padding: 40px; background: white; border: 3px solid #D4AF37; border-radius: 12px; box-shadow: 0 8px 30px rgba(0,0,0,0.1);">
        <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #D4AF37; margin: 0; font-family: 'Playfair Display', serif;">CERTIFICADO DE AUTENTICIDAD</h1>
            <div style="width: 60px; height: 3px; background: #D4AF37; margin: 20px auto;"></div>
        </div>
        
        <div style="margin-bottom: 20px;">
            <strong>Certificado N°:</strong> <?php echo $cert['id']; ?>
        </div>
        <div style="margin-bottom: 20px;">
            <strong>Producto:</strong> <?php echo $cert['product_name']; ?>
        </div>
        <div style="margin-bottom: 20px;">
            <strong>Propietario:</strong> <?php echo $cert['customer']; ?>
        </div>
        <div style="margin-bottom: 20px;">
            <strong>Fecha de Emisión:</strong> <?php echo date('d/m/Y', strtotime($cert['date'])); ?>
        </div>
        
        <div style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #f0f0f0; text-align: center;">
            <p style="font-size: 12px; color: #666; margin: 0;">Este certificado garantiza la autenticidad de la pieza adquirida</p>
            <p style="font-size: 12px; color: #666; margin: 5px 0;">Golden Phoenix Jewelry</p>
        </div>
    </div>
    <?php
    return ob_get_clean();
});

add_action('add_meta_boxes', function() {
    add_meta_box('gp_certificate', 'Certificado', function($post) {
        $value = get_post_meta($post->ID, '_includes_certificate', true);
        echo '<label><input type="checkbox" name="_includes_certificate" value="yes" ' . checked($value, 'yes', false) . '> Incluye certificado de autenticidad</label>';
    }, 'product', 'side');
});

add_action('save_post_product', function($post_id) {
    if (isset($_POST['_includes_certificate'])) {
        update_post_meta($post_id, '_includes_certificate', 'yes');
    } else {
        delete_post_meta($post_id, '_includes_certificate');
    }
});
