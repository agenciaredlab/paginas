<?php
/**
 * Golden Phoenix - Búsqueda Avanzada con Filtros
 * Búsqueda instantánea con AJAX y filtros múltiples
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// WIDGET DE BÚSQUEDA AVANZADA
// ============================================

add_action('wp_footer', 'gp_advanced_search_widget');

function gp_advanced_search_widget() {
    ?>
    <div id="gp-advanced-search-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 99999; overflow-y: auto;">
        <div style="max-width: 1200px; margin: 50px auto; background: white; border-radius: 12px; padding: 40px; position: relative;">
            
            <!-- Cerrar -->
            <button id="close-search" style="position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: #f0f0f0; border: none; cursor: pointer; font-size: 20px;">
                ×
            </button>
            
            <!-- Título -->
            <h2 style="font-size: 32px; font-family: 'Playfair Display', serif; margin-bottom: 30px; text-align: center;">
                🔍 Búsqueda Avanzada de Joyas
            </h2>
            
            <!-- Barra de búsqueda -->
            <div style="margin-bottom: 30px;">
                <input type="text" 
                       id="search-input-advanced" 
                       placeholder="Buscar por nombre, categoría, material..."
                       style="width: 100%; padding: 18px 25px; font-size: 18px; border: 2px solid #D4AF37; border-radius: 50px; outline: none;">
            </div>
            
            <!-- Filtros -->
            <div class="search-filters" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                
                <!-- Categoría -->
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">Categoría</label>
                    <select id="filter-category" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">Todas las categorías</option>
                        <?php
                        $categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
                        foreach ($categories as $cat) {
                            echo '<option value="' . $cat->slug . '">' . $cat->name . '</option>';
                        }
                        ?>
                    </select>
                </div>
                
                <!-- Rango de precio -->
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">Precio</label>
                    <select id="filter-price" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">Cualquier precio</option>
                        <option value="0-500000">Menos de $500,000</option>
                        <option value="500000-1000000">$500,000 - $1,000,000</option>
                        <option value="1000000-2000000">$1,000,000 - $2,000,000</option>
                        <option value="2000000-5000000">$2,000,000 - $5,000,000</option>
                        <option value="5000000-999999999">Más de $5,000,000</option>
                    </select>
                </div>
                
                <!-- Ordenar -->
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">Ordenar por</label>
                    <select id="filter-orderby" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="date">Más recientes</option>
                        <option value="price-asc">Precio: Menor a Mayor</option>
                        <option value="price-desc">Precio: Mayor a Menor</option>
                        <option value="popularity">Más populares</option>
                        <option value="rating">Mejor calificados</option>
                    </select>
                </div>
                
                <!-- Disponibilidad -->
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">Disponibilidad</label>
                    <select id="filter-stock" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">Todos</option>
                        <option value="instock">En stock</option>
                        <option value="outofstock">Agotados</option>
                    </select>
                </div>
                
            </div>
            
            <!-- Resultados -->
            <div id="search-results" style="min-height: 300px;">
                <div style="text-align: center; padding: 60px 20px; color: #999;">
                    <i class="fas fa-search" style="font-size: 48px; margin-bottom: 20px; opacity: 0.3;"></i>
                    <p>Comienza a buscar para ver resultados...</p>
                </div>
            </div>
            
            <!-- Loader -->
            <div id="search-loader" style="display: none; text-align: center; padding: 40px;">
                <div style="display: inline-block; width: 50px; height: 50px; border: 5px solid #f3f3f3; border-top-color: #D4AF37; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            </div>
            
        </div>
    </div>
    
    <style>
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    @media (max-width: 768px) {
        #gp-advanced-search-modal > div {
            margin: 20px;
            padding: 20px;
        }
        
        .search-filters {
            grid-template-columns: 1fr !important;
        }
    }
    </style>
    
    <script>
    let searchTimeout;
    
    // Abrir modal de búsqueda
    document.querySelector('.search-toggle').addEventListener('click', function() {
        document.getElementById('gp-advanced-search-modal').style.display = 'block';
        document.getElementById('search-input-advanced').focus();
    });
    
    // Cerrar modal
    document.getElementById('close-search').addEventListener('click', function() {
        document.getElementById('gp-advanced-search-modal').style.display = 'none';
    });
    
    // Cerrar al hacer click fuera
    document.getElementById('gp-advanced-search-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.style.display = 'none';
        }
    });
    
    // Búsqueda en tiempo real
    function performSearch() {
        clearTimeout(searchTimeout);
        
        searchTimeout = setTimeout(function() {
            const query = document.getElementById('search-input-advanced').value;
            const category = document.getElementById('filter-category').value;
            const price = document.getElementById('filter-price').value;
            const orderby = document.getElementById('filter-orderby').value;
            const stock = document.getElementById('filter-stock').value;
            
            if (query.length < 2 && !category && !price && !stock) {
                document.getElementById('search-results').innerHTML = 
                    '<div style="text-align: center; padding: 60px 20px; color: #999;">' +
                    '<i class="fas fa-search" style="font-size: 48px; margin-bottom: 20px; opacity: 0.3;"></i>' +
                    '<p>Comienza a buscar para ver resultados...</p>' +
                    '</div>';
                return;
            }
            
            document.getElementById('search-results').style.display = 'none';
            document.getElementById('search-loader').style.display = 'block';
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=advanced_search&query=${encodeURIComponent(query)}&category=${category}&price=${price}&orderby=${orderby}&stock=${stock}`
            })
            .then(r => r.json())
            .then(data => {
                document.getElementById('search-loader').style.display = 'none';
                document.getElementById('search-results').style.display = 'block';
                
                if (data.success && data.data.products.length > 0) {
                    let html = '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px;">';
                    
                    data.data.products.forEach(product => {
                        html += `
                            <div style="background: #f9f9f9; border-radius: 8px; overflow: hidden; transition: transform 0.3s;" onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='translateY(0)'">
                                <a href="${product.permalink}">
                                    <img src="${product.image}" alt="${product.name}" style="width: 100%; height: 250px; object-fit: cover;">
                                </a>
                                <div style="padding: 20px;">
                                    <h3 style="font-size: 16px; margin-bottom: 10px;">
                                        <a href="${product.permalink}" style="text-decoration: none; color: #0A0A0A;">${product.name}</a>
                                    </h3>
                                    <div style="color: #D4AF37; font-weight: 700; font-size: 18px; margin-bottom: 15px;">${product.price}</div>
                                    <a href="${product.add_to_cart_url}" style="display: block; text-align: center; background: #D4AF37; color: white; padding: 10px; border-radius: 4px; text-decoration: none; font-weight: 600;">
                                        Agregar al Carrito
                                    </a>
                                </div>
                            </div>
                        `;
                    });
                    
                    html += '</div>';
                    html += `<div style="text-align: center; margin-top: 30px; color: #666;">Se encontraron ${data.data.total} productos</div>`;
                    
                    document.getElementById('search-results').innerHTML = html;
                } else {
                    document.getElementById('search-results').innerHTML = 
                        '<div style="text-align: center; padding: 60px 20px;">' +
                        '<div style="font-size: 60px; margin-bottom: 20px;">😔</div>' +
                        '<h3>No se encontraron productos</h3>' +
                        '<p style="color: #666;">Intenta con otros términos de búsqueda o filtros</p>' +
                        '</div>';
                }
            });
        }, 500);
    }
    
    // Event listeners
    document.getElementById('search-input-advanced').addEventListener('input', performSearch);
    document.getElementById('filter-category').addEventListener('change', performSearch);
    document.getElementById('filter-price').addEventListener('change', performSearch);
    document.getElementById('filter-orderby').addEventListener('change', performSearch);
    document.getElementById('filter-stock').addEventListener('change', performSearch);
    </script>
    <?php
}

// ============================================
// AJAX BÚSQUEDA AVANZADA
// ============================================

add_action('wp_ajax_advanced_search', 'gp_ajax_advanced_search');
add_action('wp_ajax_nopriv_advanced_search', 'gp_ajax_advanced_search');

function gp_ajax_advanced_search() {
    $query = sanitize_text_field($_POST['query']);
    $category = sanitize_text_field($_POST['category']);
    $price_range = sanitize_text_field($_POST['price']);
    $orderby = sanitize_text_field($_POST['orderby']);
    $stock_status = sanitize_text_field($_POST['stock']);
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 20,
        'post_status' => 'publish',
    );
    
    // Búsqueda por texto
    if (!empty($query)) {
        $args['s'] = $query;
    }
    
    // Filtro de categoría
    if (!empty($category)) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $category,
            ),
        );
    }
    
    // Ordenamiento
    switch ($orderby) {
        case 'price-asc':
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = '_price';
            $args['order'] = 'ASC';
            break;
        case 'price-desc':
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = '_price';
            $args['order'] = 'DESC';
            break;
        case 'popularity':
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = 'total_sales';
            $args['order'] = 'DESC';
            break;
        case 'rating':
            $args['orderby'] = 'meta_value_num';
            $args['meta_key'] = '_wc_average_rating';
            $args['order'] = 'DESC';
            break;
        default:
            $args['orderby'] = 'date';
            $args['order'] = 'DESC';
    }
    
    $query_obj = new WP_Query($args);
    
    $products = array();
    
    if ($query_obj->have_posts()) {
        while ($query_obj->have_posts()) {
            $query_obj->the_post();
            $product = wc_get_product(get_the_ID());
            
            // Filtro de precio
            if (!empty($price_range)) {
                list($min, $max) = explode('-', $price_range);
                $product_price = $product->get_price();
                if ($product_price < $min || $product_price > $max) {
                    continue;
                }
            }
            
            // Filtro de stock
            if (!empty($stock_status)) {
                if ($stock_status === 'instock' && !$product->is_in_stock()) continue;
                if ($stock_status === 'outofstock' && $product->is_in_stock()) continue;
            }
            
            $products[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'price' => $product->get_price_html(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
                'permalink' => get_permalink(),
                'add_to_cart_url' => $product->add_to_cart_url(),
            );
        }
        wp_reset_postdata();
    }
    
    wp_send_json_success(array(
        'products' => $products,
        'total' => count($products)
    ));
}
