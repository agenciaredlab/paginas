# Maison Luxe Jewelry - WordPress Theme

Tema Premium de WordPress diseñado específicamente para joyerías de alta gama que compiten visualmente con marcas como Bvlgari, Versace, Cartier y otras casas de lujo.

## 🌟 Características Principales

### Diseño Ultra Premium
- Paleta de colores elegante: Oro (#D4AF37), Negro profundo, Blanco crema
- Tipografía luxury: Playfair Display, Montserrat, Bodoni Moda
- Animaciones suaves y transiciones elegantes
- Efectos de paralaje y hover sofisticados
- Diseño minimalista y refinado

### Funcionalidades Avanzadas
- ✅ Compatibilidad total con WooCommerce
- ✅ Sistema de colecciones personalizadas
- ✅ Galería de productos con efectos luxury
- ✅ Testimonios de clientes
- ✅ Newsletter integrado
- ✅ Búsqueda avanzada con overlay
- ✅ Wishlist (lista de deseos)
- ✅ Carrito de compras elegante
- ✅ Menú móvil responsive
- ✅ Integración con redes sociales

### Rendimiento Optimizado
- Código limpio y optimizado
- Carga rápida de página
- SEO friendly
- Compatible con caché
- Optimización de imágenes

## 📋 Requisitos

- WordPress 6.0 o superior
- PHP 7.4 o superior
- WooCommerce 7.0 o superior (opcional pero recomendado)
- Memoria PHP: Mínimo 128MB

## 🚀 Instalación

### Método 1: Desde el Panel de WordPress

1. Descarga el archivo `maison-luxe-jewelry.zip`
2. Ve a **Apariencia > Temas** en tu panel de WordPress
3. Haz clic en **Añadir nuevo**
4. Haz clic en **Subir tema**
5. Selecciona el archivo ZIP y haz clic en **Instalar ahora**
6. Una vez instalado, haz clic en **Activar**

### Método 2: FTP

1. Descomprime el archivo ZIP
2. Sube la carpeta `luxury-jewelry-theme` a `/wp-content/themes/`
3. Ve a **Apariencia > Temas** y activa el tema

## ⚙️ Configuración Inicial

### 1. Configuración Básica

```
Apariencia > Personalizar
```

- **Identidad del sitio**: Configura el logo y nombre de tu joyería
- **Colores Luxury**: Personaliza la paleta de colores dorados
- **Información de contacto**: Agrega teléfono, email, dirección
- **Redes sociales**: Conecta tus perfiles sociales

### 2. Menús de Navegación

```
Apariencia > Menús
```

Crea dos menús:
- **Menú Principal**: Para el header
- **Menú Footer**: Para el pie de página

Asigna las ubicaciones correspondientes.

### 3. Configurar WooCommerce

Si vas a vender productos:

1. Instala y activa WooCommerce
2. Sigue el asistente de configuración
3. El tema ya está optimizado para WooCommerce

### 4. Páginas Recomendadas

Crea las siguientes páginas:

- **Inicio** (asigna como página principal)
- **Tienda** (página de WooCommerce)
- **Colecciones**
- **Nosotros**
- **Contacto**
- **FAQ**
- **Política de Privacidad**
- **Términos y Condiciones**

## 🎨 Personalización

### Colores del Tema

El tema usa variables CSS que puedes personalizar en `style.css`:

```css
:root {
    --gold-primary: #D4AF37;
    --gold-light: #F4E4C1;
    --gold-dark: #B8941E;
    --black-deep: #0A0A0A;
    --black-soft: #1A1A1A;
    --white-pure: #FFFFFF;
    --white-cream: #FAF9F6;
}
```

### Tipografía

El tema utiliza Google Fonts:
- **Headings**: Playfair Display, Cormorant Garamond
- **Body**: Montserrat, Lato
- **Accent**: Bodoni Moda

### Imágenes Recomendadas

Para mejores resultados, usa imágenes de alta calidad:

- **Hero Section**: 1920x1080px
- **Productos**: 1000x1000px (cuadradas)
- **Colecciones**: 800x1066px (3:4 ratio)
- **Parallax**: 1920x1080px

## 📱 Secciones del Tema

### Hero Section
Sección principal con imagen de fondo, título impactante y llamados a la acción.

### Colecciones Destacadas
Grid de colecciones con efectos hover elegantes.

### Productos Destacados
Galería de productos con quick view y wishlist.

### Sección Parallax
Efecto de paralaje para destacar artesanía.

### Heritage / About
Historia de la marca con estadísticas.

### Testimonios
Opiniones de clientes destacados.

### Newsletter
Formulario de suscripción elegante.

## 🔧 Post Types Personalizados

### Colecciones
Para crear colecciones de joyas:
```
WordPress Admin > Colecciones > Agregar Nueva
```

Campos personalizados:
- Número de piezas
- Colección destacada (checkbox)

### Testimonios
Para agregar testimonios de clientes:
```
WordPress Admin > Testimonios > Agregar Nuevo
```

Campos personalizados:
- Título del autor
- Calificación (1-5 estrellas)

## 🎯 Shortcodes Disponibles

### Newsletter
```php
[maison_luxe_newsletter]
```

### Productos Destacados
```php
[maison_luxe_featured_products limit="6"]
```

### Colecciones
```php
[maison_luxe_collections limit="3"]
```

## 🌐 Integración con WooCommerce

El tema está completamente integrado con WooCommerce:

- Páginas de productos personalizadas
- Carrito optimizado
- Checkout elegante
- My Account personalizado
- Badge de "Nuevo", "Exclusivo", "Bestseller"

### Configurar Badges de Productos

En el editor de productos, puedes agregar badges personalizados.

## 📊 Widgets

El tema incluye las siguientes áreas de widgets:

- **Sidebar Principal**: Para blog/páginas
- **Footer Columna 1**: Primera columna del footer
- **Footer Columna 2**: Segunda columna del footer
- **Footer Columna 3**: Tercera columna del footer

## 🔐 Seguridad

El tema incluye:
- Validación y sanitización de datos
- Nonces para formularios
- Protección CSRF
- Escape de salida de datos
- Verificación de permisos

## ⚡ Optimización

### Rendimiento
- Scripts cargados en footer
- CSS minificado
- Lazy loading de imágenes
- Caché del navegador
- jQuery Migrate removido
- Emojis deshabilitados

### SEO
- Schema.org markup
- Open Graph tags
- Twitter Cards
- Breadcrumbs
- Sitemap XML compatible

## 🆘 Soporte y Documentación

### Preguntas Frecuentes

**¿Necesito WooCommerce obligatoriamente?**
No, pero se recomienda si quieres vender productos.

**¿El tema es responsive?**
Sí, completamente responsive en todos los dispositivos.

**¿Puedo traducir el tema?**
Sí, el tema está listo para traducción (.pot file incluido).

**¿Incluye actualizaciones?**
Sí, recibirás actualizaciones gratuitas.

### Contacto

- **Email**: info@redlab.com
- **Website**: https://redlab.com
- **Soporte**: https://redlab.com/soporte

## 📝 Changelog

### Versión 1.0.0 - 2025-11-27
- Lanzamiento inicial
- Diseño luxury completo
- Integración WooCommerce
- Custom Post Types
- Sistema de newsletter
- Responsive design
- Optimizaciones de rendimiento

## 📄 Licencia

Este tema está licenciado bajo GPL v2 o posterior.

## 👨‍💻 Créditos

- **Desarrollado por**: RedLab Agency
- **Diseño**: Inspirado en marcas de lujo como Bvlgari, Versace, Cartier
- **Fonts**: Google Fonts
- **Icons**: Font Awesome

---

**¡Gracias por elegir Maison Luxe Jewelry Theme!**

Para cualquier consulta o soporte, no dudes en contactarnos.
