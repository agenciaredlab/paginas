<?php
/**
 * GOLDEN PHOENIX V64 - CHATBOT INTELIGENTE
 * 3 Niveles: Básico, OpenAI GPT-4, Híbrido
 */

if (!defined('ABSPATH')) exit;

class GP_Chatbot_System {
    
    private $mode = 'basic'; // basic, openai, hybrid
    private $openai_key = '';
    
    public function __construct() {
        $this->openai_key = get_option('gp_openai_api_key', '');
        $this->mode = get_option('gp_chatbot_mode', 'basic');
        
        add_action('wp_footer', array($this, 'render_chatbot'));
        add_action('wp_ajax_gp_chatbot_message', array($this, 'handle_message'));
        add_action('wp_ajax_nopriv_gp_chatbot_message', array($this, 'handle_message'));
        add_action('admin_menu', array($this, 'add_settings_page'));
    }
    
    // =============================================
    // RENDERIZAR CHATBOT EN FRONTEND
    // =============================================
    public function render_chatbot() {
        ?>
        <!-- CHATBOT WIDGET -->
        <div id="gp-chatbot-widget" style="position: fixed; bottom: 30px; right: 30px; z-index: 99999;">
            
            <!-- BOTÓN FLOTANTE -->
            <button id="gp-chatbot-toggle" class="gp-chatbot-btn" style="
                width: 60px; 
                height: 60px; 
                border-radius: 50%; 
                background: linear-gradient(135deg, #D4AF37, #C19A2E);
                border: none;
                box-shadow: 0 4px 20px rgba(212, 175, 55, 0.4);
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: transform 0.3s, box-shadow 0.3s;
                position: relative;
            ">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                
                <!-- BADGE DE NOTIFICACIÓN -->
                <span id="gp-chatbot-badge" style="
                    position: absolute;
                    top: -5px;
                    right: -5px;
                    background: #FF4444;
                    color: white;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    display: none;
                    align-items: center;
                    justify-content: center;
                    font-size: 12px;
                    font-weight: 700;
                ">1</span>
            </button>
            
            <!-- VENTANA DE CHAT -->
            <div id="gp-chatbot-window" style="
                position: absolute;
                bottom: 80px;
                right: 0;
                width: 380px;
                max-width: calc(100vw - 40px);
                height: 600px;
                max-height: calc(100vh - 120px);
                background: #000;
                border: 2px solid #D4AF37;
                border-radius: 16px;
                display: none;
                flex-direction: column;
                overflow: hidden;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
            ">
                
                <!-- HEADER -->
                <div class="gp-chatbot-header" style="
                    background: linear-gradient(135deg, #D4AF37, #C19A2E);
                    padding: 20px;
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                ">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <div style="
                            width: 40px;
                            height: 40px;
                            background: #000;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            font-size: 20px;
                        ">💎</div>
                        <div>
                            <div style="font-weight: 700; color: #000; font-size: 16px;">Asistente Golden Phoenix</div>
                            <div style="font-size: 12px; color: rgba(0,0,0,0.7);">
                                <span id="gp-bot-status">En línea</span> • 
                                <span id="gp-bot-mode"><?php echo $this->mode === 'openai' ? 'IA Avanzada' : 'Asistente Virtual'; ?></span>
                            </div>
                        </div>
                    </div>
                    <button onclick="gpChatbot.close()" style="
                        background: none;
                        border: none;
                        color: #000;
                        font-size: 24px;
                        cursor: pointer;
                        padding: 0;
                        width: 30px;
                        height: 30px;
                    ">×</button>
                </div>
                
                <!-- MENSAJES -->
                <div id="gp-chatbot-messages" style="
                    flex: 1;
                    overflow-y: auto;
                    padding: 20px;
                    background: #0A0A0A;
                    display: flex;
                    flex-direction: column;
                    gap: 12px;
                ">
                    <!-- Mensaje de bienvenida -->
                    <div class="gp-bot-message" style="
                        background: #1A1A1A;
                        padding: 12px 16px;
                        border-radius: 16px 16px 16px 4px;
                        color: #CCCCCC;
                        max-width: 80%;
                        align-self: flex-start;
                        border: 1px solid #333;
                    ">
                        👋 ¡Hola! Soy el asistente de Golden Phoenix. ¿En qué puedo ayudarte hoy?
                    </div>
                    
                    <!-- BOTONES RÁPIDOS -->
                    <div class="gp-quick-replies" style="
                        display: flex;
                        flex-wrap: wrap;
                        gap: 8px;
                        margin-top: 8px;
                    ">
                        <button onclick="gpChatbot.quickReply('Ver colecciones')" class="gp-quick-btn">🖼️ Ver colecciones</button>
                        <button onclick="gpChatbot.quickReply('Precios')" class="gp-quick-btn">💰 Precios</button>
                        <button onclick="gpChatbot.quickReply('Envíos')" class="gp-quick-btn">📦 Envíos</button>
                        <button onclick="gpChatbot.quickReply('Contacto')" class="gp-quick-btn">📞 Contacto</button>
                    </div>
                </div>
                
                <!-- INPUT -->
                <div class="gp-chatbot-input" style="
                    padding: 15px;
                    background: #000;
                    border-top: 1px solid #333;
                    display: flex;
                    gap: 10px;
                    align-items: center;
                ">
                    <input 
                        type="text" 
                        id="gp-chatbot-input-field" 
                        placeholder="Escribe tu mensaje..."
                        style="
                            flex: 1;
                            padding: 12px 16px;
                            background: #1A1A1A;
                            border: 1px solid #333;
                            border-radius: 24px;
                            color: #FFF;
                            font-size: 14px;
                        "
                    >
                    <button onclick="gpChatbot.sendMessage()" style="
                        width: 44px;
                        height: 44px;
                        border-radius: 50%;
                        background: linear-gradient(135deg, #D4AF37, #C19A2E);
                        border: none;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    ">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2">
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                    </button>
                </div>
                
                <!-- TYPING INDICATOR -->
                <div id="gp-typing-indicator" style="
                    padding: 12px 16px;
                    background: #1A1A1A;
                    margin: 0 20px 20px;
                    border-radius: 16px 16px 16px 4px;
                    display: none;
                    max-width: 80px;
                ">
                    <div style="display: flex; gap: 4px;">
                        <div class="gp-typing-dot"></div>
                        <div class="gp-typing-dot"></div>
                        <div class="gp-typing-dot"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .gp-chatbot-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 30px rgba(212, 175, 55, 0.6);
        }
        
        .gp-quick-btn {
            padding: 8px 16px;
            background: #1A1A1A;
            border: 1px solid #333;
            border-radius: 20px;
            color: #D4AF37;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
        }
        
        .gp-quick-btn:hover {
            background: #D4AF37;
            color: #000;
            border-color: #D4AF37;
        }
        
        .gp-typing-dot {
            width: 8px;
            height: 8px;
            background: #D4AF37;
            border-radius: 50%;
            animation: typing 1.4s infinite;
        }
        
        .gp-typing-dot:nth-child(2) { animation-delay: 0.2s; }
        .gp-typing-dot:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); opacity: 0.7; }
            30% { transform: translateY(-10px); opacity: 1; }
        }
        
        #gp-chatbot-messages::-webkit-scrollbar {
            width: 6px;
        }
        
        #gp-chatbot-messages::-webkit-scrollbar-track {
            background: #0A0A0A;
        }
        
        #gp-chatbot-messages::-webkit-scrollbar-thumb {
            background: #D4AF37;
            border-radius: 3px;
        }
        </style>
        
        <script>
        const gpChatbot = {
            mode: '<?php echo $this->mode; ?>',
            conversationHistory: [],
            
            init: function() {
                // Toggle chatbot
                document.getElementById('gp-chatbot-toggle').addEventListener('click', () => {
                    this.toggle();
                });
                
                // Enter to send
                document.getElementById('gp-chatbot-input-field').addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        this.sendMessage();
                    }
                });
                
                // Auto-open después de 3 segundos (primera vez)
                if (!localStorage.getItem('gp-chatbot-seen')) {
                    setTimeout(() => {
                        this.open();
                        localStorage.setItem('gp-chatbot-seen', 'true');
                    }, 3000);
                }
            },
            
            toggle: function() {
                const window = document.getElementById('gp-chatbot-window');
                if (window.style.display === 'none' || !window.style.display) {
                    this.open();
                } else {
                    this.close();
                }
            },
            
            open: function() {
                document.getElementById('gp-chatbot-window').style.display = 'flex';
                document.getElementById('gp-chatbot-badge').style.display = 'none';
                this.scrollToBottom();
            },
            
            close: function() {
                document.getElementById('gp-chatbot-window').style.display = 'none';
            },
            
            quickReply: function(text) {
                document.getElementById('gp-chatbot-input-field').value = text;
                this.sendMessage();
            },
            
            sendMessage: function() {
                const input = document.getElementById('gp-chatbot-input-field');
                const message = input.value.trim();
                
                if (!message) return;
                
                // Añadir mensaje del usuario
                this.addMessage(message, 'user');
                input.value = '';
                
                // Mostrar typing indicator
                this.showTyping();
                
                // Enviar a backend
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'gp_chatbot_message',
                        message: message,
                        history: JSON.stringify(this.conversationHistory)
                    })
                })
                .then(response => response.json())
                .then(data => {
                    this.hideTyping();
                    this.addMessage(data.message, 'bot');
                    
                    if (data.suggestions) {
                        this.addSuggestions(data.suggestions);
                    }
                })
                .catch(error => {
                    this.hideTyping();
                    this.addMessage('Lo siento, hubo un error. Por favor intenta de nuevo.', 'bot');
                });
            },
            
            addMessage: function(text, sender) {
                const messagesContainer = document.getElementById('gp-chatbot-messages');
                const messageDiv = document.createElement('div');
                
                if (sender === 'user') {
                    messageDiv.className = 'gp-user-message';
                    messageDiv.style.cssText = `
                        background: linear-gradient(135deg, #D4AF37, #C19A2E);
                        padding: 12px 16px;
                        border-radius: 16px 16px 4px 16px;
                        color: #000;
                        max-width: 80%;
                        align-self: flex-end;
                        font-weight: 500;
                    `;
                    this.conversationHistory.push({role: 'user', content: text});
                } else {
                    messageDiv.className = 'gp-bot-message';
                    messageDiv.style.cssText = `
                        background: #1A1A1A;
                        padding: 12px 16px;
                        border-radius: 16px 16px 16px 4px;
                        color: #CCCCCC;
                        max-width: 80%;
                        align-self: flex-start;
                        border: 1px solid #333;
                    `;
                    this.conversationHistory.push({role: 'assistant', content: text});
                }
                
                messageDiv.textContent = text;
                messagesContainer.appendChild(messageDiv);
                
                this.scrollToBottom();
            },
            
            addSuggestions: function(suggestions) {
                const messagesContainer = document.getElementById('gp-chatbot-messages');
                const suggestionsDiv = document.createElement('div');
                suggestionsDiv.className = 'gp-suggestions';
                suggestionsDiv.style.cssText = `
                    display: flex;
                    flex-wrap: wrap;
                    gap: 8px;
                    margin-top: 8px;
                `;
                
                suggestions.forEach(suggestion => {
                    const btn = document.createElement('button');
                    btn.className = 'gp-quick-btn';
                    btn.textContent = suggestion;
                    btn.onclick = () => this.quickReply(suggestion);
                    suggestionsDiv.appendChild(btn);
                });
                
                messagesContainer.appendChild(suggestionsDiv);
                this.scrollToBottom();
            },
            
            showTyping: function() {
                document.getElementById('gp-typing-indicator').style.display = 'block';
                this.scrollToBottom();
            },
            
            hideTyping: function() {
                document.getElementById('gp-typing-indicator').style.display = 'none';
            },
            
            scrollToBottom: function() {
                const container = document.getElementById('gp-chatbot-messages');
                setTimeout(() => {
                    container.scrollTop = container.scrollHeight;
                }, 100);
            }
        };
        
        // Inicializar cuando carga la página
        document.addEventListener('DOMContentLoaded', () => {
            gpChatbot.init();
        });
        </script>
        <?php
    }
    
    // =============================================
    // MANEJAR MENSAJES DEL USUARIO
    // =============================================
    public function handle_message() {
        $message = sanitize_text_field($_POST['message']);
        $history = json_decode(stripslashes($_POST['history']), true);
        
        $response = array(
            'message' => '',
            'suggestions' => array()
        );
        
        // Decidir qué modo usar
        if ($this->mode === 'openai' && !empty($this->openai_key)) {
            $response = $this->get_openai_response($message, $history);
        } elseif ($this->mode === 'hybrid') {
            // Intentar respuesta básica primero
            $basic_response = $this->get_basic_response($message);
            if ($basic_response['confidence'] < 0.7) {
                // Si confianza baja, usar OpenAI
                $response = $this->get_openai_response($message, $history);
            } else {
                $response = $basic_response;
            }
        } else {
            // Modo básico
            $response = $this->get_basic_response($message);
        }
        
        wp_send_json($response);
    }
    
    // =============================================
    // RESPUESTAS BÁSICAS (REGLAS)
    // =============================================
    private function get_basic_response($message) {
        $message = strtolower($message);
        $response = array('message' => '', 'suggestions' => array(), 'confidence' => 0);
        
        // BASE DE CONOCIMIENTO
        $knowledge_base = array(
            // Saludos
            array(
                'patterns' => array('hola', 'buenos días', 'buenas tardes', 'buenas noches', 'hey', 'hi'),
                'responses' => array(
                    '¡Hola! 👋 Bienvenido a Golden Phoenix. ¿En qué puedo ayudarte?',
                    '¡Hola! Estoy aquí para ayudarte con cualquier duda sobre nuestras joyas. ¿Qué necesitas?'
                ),
                'suggestions' => array('Ver colecciones', 'Consultar precios', 'Información de envíos'),
                'confidence' => 1.0
            ),
            
            // Colecciones
            array(
                'patterns' => array('colecciones', 'colección', 'productos', 'catálogo', 'ver joyas'),
                'responses' => array(
                    'Tenemos varias colecciones exclusivas: Anillos de Compromiso 💍, Collares Elegantes, Pulseras de Lujo, Aretes Únicos, y Relojes Premium. ¿Cuál te interesa?'
                ),
                'suggestions' => array('Ver anillos', 'Ver collares', 'Ver todo el catálogo'),
                'confidence' => 0.9
            ),
            
            // Precios
            array(
                'patterns' => array('precio', 'costo', 'cuánto cuesta', 'valor', 'cuánto vale'),
                'responses' => array(
                    'Nuestros precios varían según el diseño y materiales. Los anillos de oro 18K comienzan desde $1,200 USD. ¿Te gustaría ver alguna colección específica?'
                ),
                'suggestions' => array('Ver anillos', 'Calcular cuotas', 'Hablar con asesor'),
                'confidence' => 0.9
            ),
            
            // Envíos
            array(
                'patterns' => array('envío', 'envíos', 'entrega', 'shipping', 'delivery', 'cuánto tarda'),
                'responses' => array(
                    '📦 Ofrecemos envío GRATIS en compras superiores a $500 USD. El tiempo de entrega es de 3-5 días hábiles a nivel nacional y 7-12 días internacional. ¿A dónde necesitas el envío?'
                ),
                'suggestions' => array('Ver políticas', 'Rastrear pedido'),
                'confidence' => 0.95
            ),
            
            // Materiales
            array(
                'patterns' => array('oro', 'plata', 'platino', 'diamante', 'material', 'quilates'),
                'responses' => array(
                    'Trabajamos con oro 18K, plata 925, platino y diamantes certificados. Todos nuestros materiales cuentan con certificación de autenticidad. ¿Qué material prefieres?'
                ),
                'suggestions' => array('Comparar materiales', 'Ver certificaciones'),
                'confidence' => 0.85
            ),
            
            // Garantía
            array(
                'patterns' => array('garantía', 'devolución', 'cambio', 'warranty'),
                'responses' => array(
                    '✅ Ofrecemos garantía de por vida en defectos de fabricación y 30 días para cambios/devoluciones si no estás 100% satisfecho. Tu inversión está protegida.'
                ),
                'suggestions' => array('Ver política completa', 'Solicitar devolución'),
                'confidence' => 0.9
            ),
            
            // Contacto
            array(
                'patterns' => array('contacto', 'teléfono', 'whatsapp', 'email', 'llamar', 'hablar'),
                'responses' => array(
                    '📞 Puedes contactarnos por WhatsApp: +57 300 123 4567, Email: info@goldenphoenix.com, o agendar una videollamada con nuestros asesores. ¿Qué prefieres?'
                ),
                'suggestions' => array('Abrir WhatsApp', 'Agendar videollamada', 'Enviar email'),
                'confidence' => 0.95
            ),
            
            // Financiamiento
            array(
                'patterns' => array('cuotas', 'financiamiento', 'crédito', 'pagar en cuotas', 'meses'),
                'responses' => array(
                    '💳 Aceptamos pagos en cuotas: 3, 6, o 12 meses sin intereses. También aceptamos tarjetas de crédito, PayPal y transferencia bancaria. ¿Cuántas cuotas necesitas?'
                ),
                'suggestions' => array('Calcular cuotas', 'Ver métodos de pago'),
                'confidence' => 0.9
            ),
        );
        
        // Buscar coincidencia
        foreach ($knowledge_base as $kb) {
            foreach ($kb['patterns'] as $pattern) {
                if (strpos($message, $pattern) !== false) {
                    $response['message'] = $kb['responses'][array_rand($kb['responses'])];
                    $response['suggestions'] = $kb['suggestions'];
                    $response['confidence'] = $kb['confidence'];
                    return $response;
                }
            }
        }
        
        // Respuesta por defecto
        $response['message'] = 'Interesante pregunta. Te recomiendo hablar con uno de nuestros asesores especializados para darte la mejor información. ¿Te gustaría que te contactemos?';
        $response['suggestions'] = array('Hablar con asesor', 'Ver FAQ', 'Volver al menú');
        $response['confidence'] = 0.3;
        
        return $response;
    }
    
    // =============================================
    // RESPUESTAS CON OPENAI GPT-4
    // =============================================
    private function get_openai_response($message, $history) {
        $response = array('message' => '', 'suggestions' => array());
        
        // Preparar historial para OpenAI
        $messages = array(
            array(
                'role' => 'system',
                'content' => 'Eres un asistente virtual de Golden Phoenix, una joyería de lujo especializada en anillos de compromiso, collares, pulseras, aretes y relojes de alta gama. Tu tono es elegante, profesional y servicial. Respondes en español. Conocimientos clave: Oro 18K desde $1,200, envío gratis >$500, garantía de por vida, 30 días devolución, pagos en 3/6/12 cuotas sin intereses, WhatsApp +57 300 123 4567. Mantén respuestas concisas (máximo 3 líneas).'
            )
        );
        
        // Añadir historial
        if (!empty($history)) {
            foreach ($history as $msg) {
                $messages[] = array(
                    'role' => $msg['role'],
                    'content' => $msg['content']
                );
            }
        }
        
        // Añadir mensaje actual
        $messages[] = array(
            'role' => 'user',
            'content' => $message
        );
        
        // Llamar a OpenAI API
        $api_response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->openai_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'model' => 'gpt-4',
                'messages' => $messages,
                'max_tokens' => 150,
                'temperature' => 0.7
            ))
        ));
        
        if (is_wp_error($api_response)) {
            $response['message'] = 'Lo siento, estoy teniendo problemas técnicos. ¿Puedo ayudarte de otra forma?';
            $response['suggestions'] = array('Hablar con humano', 'Ver FAQ');
            return $response;
        }
        
        $body = json_decode(wp_remote_retrieve_body($api_response), true);
        
        if (isset($body['choices'][0]['message']['content'])) {
            $response['message'] = $body['choices'][0]['message']['content'];
            $response['suggestions'] = array('Saber más', 'Hablar con asesor', 'Ver productos');
        } else {
            $response['message'] = 'Disculpa, no pude procesar eso. ¿Podrías reformular tu pregunta?';
        }
        
        return $response;
    }
    
    // =============================================
    // PÁGINA DE CONFIGURACIÓN EN ADMIN
    // =============================================
    public function add_settings_page() {
        add_options_page(
            'Configuración Chatbot',
            'Chatbot IA',
            'manage_options',
            'gp-chatbot-settings',
            array($this, 'render_settings_page')
        );
    }
    
    public function render_settings_page() {
        if (isset($_POST['gp_save_chatbot_settings'])) {
            update_option('gp_chatbot_mode', sanitize_text_field($_POST['chatbot_mode']));
            update_option('gp_openai_api_key', sanitize_text_field($_POST['openai_key']));
            echo '<div class="updated"><p>✅ Configuración guardada</p></div>';
        }
        
        $current_mode = get_option('gp_chatbot_mode', 'basic');
        $current_key = get_option('gp_openai_api_key', '');
        ?>
        <div class="wrap">
            <h1>🤖 Configuración del Chatbot</h1>
            
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th>Modo del Chatbot</th>
                        <td>
                            <select name="chatbot_mode">
                                <option value="basic" <?php selected($current_mode, 'basic'); ?>>Básico (Gratis - Reglas)</option>
                                <option value="openai" <?php selected($current_mode, 'openai'); ?>>OpenAI GPT-4 (Requiere API Key)</option>
                                <option value="hybrid" <?php selected($current_mode, 'hybrid'); ?>>Híbrido (Básico + IA cuando necesario)</option>
                            </select>
                            <p class="description">
                                <strong>Básico:</strong> Respuestas pre-programadas rápidas<br>
                                <strong>OpenAI:</strong> Inteligencia artificial avanzada (requiere cuenta OpenAI)<br>
                                <strong>Híbrido:</strong> Lo mejor de ambos
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>OpenAI API Key</th>
                        <td>
                            <input type="password" name="openai_key" value="<?php echo esc_attr($current_key); ?>" class="regular-text">
                            <p class="description">
                                Obtén tu API key en: <a href="https://platform.openai.com/api-keys" target="_blank">https://platform.openai.com/api-keys</a><br>
                                Costo aproximado: $0.01 - $0.05 por conversación
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="gp_save_chatbot_settings" class="button button-primary" value="Guardar Configuración">
                </p>
            </form>
            
            <hr>
            
            <h2>📊 Estadísticas</h2>
            <p>Próximamente: Conversaciones totales, tasa de resolución, mensajes por día</p>
            
            <h2>💡 Consejos</h2>
            <ul>
                <li>✅ El modo <strong>Básico</strong> es perfecto para empezar (100% gratis)</li>
                <li>✅ Añade más respuestas personalizadas en el código</li>
                <li>✅ El modo <strong>Híbrido</strong> optimiza costos usando IA solo cuando necesario</li>
                <li>✅ Puedes personalizar el saludo, colores y posición del chatbot</li>
            </ul>
        </div>
        <?php
    }
}

// Inicializar chatbot
new GP_Chatbot_System();
