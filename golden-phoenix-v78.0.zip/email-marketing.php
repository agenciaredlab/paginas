<?php
/**
 * Golden Phoenix - Email Marketing & Newsletter
 * Sistema completo de suscripción y campañas automáticas
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// POPUP DE NEWSLETTER
// ============================================

add_action('wp_footer', 'gp_newsletter_popup');

function gp_newsletter_popup() {
    // No mostrar si ya está suscrito
    if (isset($_COOKIE['gp_newsletter_subscribed'])) {
        return;
    }
    
    // No mostrar si cerró recientemente
    if (isset($_COOKIE['gp_newsletter_closed'])) {
        return;
    }
    
    ?>
    <div id="newsletter-popup" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 999998; align-items: center; justify-content: center; padding: 20px;">
        <div style="max-width: 600px; background: white; border-radius: 20px; overflow: hidden; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
            
            <!-- Cerrar -->
            <button onclick="closeNewsletterPopup()" style="position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: rgba(0,0,0,0.5); border: none; color: white; cursor: pointer; font-size: 24px; z-index: 10; transition: background 0.3s;"
                    onmouseover="this.style.background='rgba(220,53,69,1)'"
                    onmouseout="this.style.background='rgba(0,0,0,0.5)'">
                ×
            </button>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr;">
                
                <!-- Lado izquierdo: Imagen -->
                <div style="background: linear-gradient(135deg, #D4AF37 0%, #FFD700 100%); padding: 50px 30px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
                    <div style="font-size: 80px; margin-bottom: 20px;">💎</div>
                    <h3 style="font-size: 28px; color: #0A0A0A; font-family: 'Playfair Display', serif; margin-bottom: 15px;">
                        ¡Ofertas Exclusivas!
                    </h3>
                    <p style="color: rgba(0,0,0,0.8); font-size: 14px;">
                        Sé el primero en conocer nuevas colecciones y descuentos especiales
                    </p>
                </div>
                
                <!-- Lado derecho: Formulario -->
                <div style="padding: 50px 40px;">
                    <h2 style="font-size: 24px; margin-bottom: 10px; color: #0A0A0A;">
                        Únete a Nuestro Club VIP
                    </h2>
                    <p style="color: #666; margin-bottom: 30px; font-size: 14px;">
                        Y recibe <strong style="color: #D4AF37;">10% de descuento</strong> en tu primera compra
                    </p>
                    
                    <form id="newsletter-form" style="display: flex; flex-direction: column; gap: 15px;">
                        <input type="hidden" name="action" value="subscribe_newsletter">
                        
                        <input type="text" 
                               name="name" 
                               placeholder="Tu nombre" 
                               required
                               style="padding: 15px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px; transition: border-color 0.3s;"
                               onfocus="this.style.borderColor='#D4AF37'"
                               onblur="this.style.borderColor='#e0e0e0'">
                        
                        <input type="email" 
                               name="email" 
                               placeholder="tu@email.com" 
                               required
                               style="padding: 15px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 16px; transition: border-color 0.3s;"
                               onfocus="this.style.borderColor='#D4AF37'"
                               onblur="this.style.borderColor='#e0e0e0'">
                        
                        <label style="display: flex; align-items: center; gap: 10px; font-size: 12px; color: #666;">
                            <input type="checkbox" name="terms" required style="width: 18px; height: 18px;">
                            Acepto recibir emails con ofertas y novedades
                        </label>
                        
                        <button type="submit" style="background: #D4AF37; color: white; border: none; padding: 18px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; transition: all 0.3s;"
                                onmouseover="this.style.background='#0A0A0A'"
                                onmouseout="this.style.background='#D4AF37'">
                            🎁 Obtener Mi Descuento
                        </button>
                    </form>
                    
                    <div id="newsletter-response" style="margin-top: 15px;"></div>
                    
                    <p style="font-size: 11px; color: #999; margin-top: 20px; text-align: center;">
                        No spam. Puedes desuscribirte cuando quieras.
                    </p>
                </div>
                
            </div>
        </div>
    </div>
    
    <style>
    @media (max-width: 768px) {
        #newsletter-popup > div > div {
            grid-template-columns: 1fr !important;
        }
        
        #newsletter-popup > div > div > div:first-child {
            padding: 30px 20px !important;
        }
        
        #newsletter-popup > div > div > div:last-child {
            padding: 30px 20px !important;
        }
    }
    </style>
    
    <script>
    // Mostrar popup después de 15 segundos O al scrollear 50%
    let newsletterShown = false;
    
    setTimeout(function() {
        if (!newsletterShown) {
            showNewsletterPopup();
        }
    }, 15000);
    
    window.addEventListener('scroll', function() {
        if (newsletterShown) return;
        
        const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
        
        if (scrollPercent > 50) {
            showNewsletterPopup();
        }
    });
    
    function showNewsletterPopup() {
        newsletterShown = true;
        document.getElementById('newsletter-popup').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    
    function closeNewsletterPopup() {
        document.getElementById('newsletter-popup').style.display = 'none';
        document.body.style.overflow = '';
        
        // Guardar cookie para no mostrar de nuevo por 7 días
        document.cookie = 'gp_newsletter_closed=1; max-age=' + (86400 * 7) + '; path=/';
    }
    
    // Enviar formulario
    document.getElementById('newsletter-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const form = this;
        const btn = form.querySelector('button[type="submit"]');
        const response = document.getElementById('newsletter-response');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Suscribiendo...';
        btn.disabled = true;
        
        const formData = new FormData(form);
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                response.innerHTML = '<div style="padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 8px; color: #155724; text-align: center;"><strong>¡Bienvenido!</strong><br>Revisa tu email para tu cupón de descuento 🎉</div>';
                form.style.display = 'none';
                
                // Guardar cookie de suscrito
                document.cookie = 'gp_newsletter_subscribed=1; max-age=' + (86400 * 365) + '; path=/';
                
                // Cerrar después de 3 segundos
                setTimeout(closeNewsletterPopup, 3000);
            } else {
                response.innerHTML = '<div style="padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 8px; color: #721c24; text-align: center;">' + data.data.message + '</div>';
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        });
    });
    
    // Cerrar con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeNewsletterPopup();
    });
    </script>
    <?php
}

// ============================================
// AJAX SUSCRIBIRSE
// ============================================

add_action('wp_ajax_subscribe_newsletter', 'gp_subscribe_newsletter');
add_action('wp_ajax_nopriv_subscribe_newsletter', 'gp_subscribe_newsletter');

function gp_subscribe_newsletter() {
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Email inválido'));
    }
    
    // Verificar si ya existe
    $existing = get_option('gp_newsletter_subscribers', array());
    
    if (in_array($email, array_column($existing, 'email'))) {
        wp_send_json_success(array('message' => 'Ya estás suscrito a nuestra lista'));
    }
    
    // Agregar suscriptor
    $subscriber = array(
        'name' => $name,
        'email' => $email,
        'date' => current_time('mysql'),
        'ip' => $_SERVER['REMOTE_ADDR'],
        'source' => 'popup'
    );
    
    $existing[] = $subscriber;
    update_option('gp_newsletter_subscribers', $existing);
    
    // Crear cupón de bienvenida
    $coupon_code = 'NEWSLETTER10';
    $coupon_id = wc_get_coupon_id_by_code($coupon_code);
    
    if (!$coupon_id) {
        $coupon = array(
            'post_title' => $coupon_code,
            'post_status' => 'publish',
            'post_type' => 'shop_coupon'
        );
        
        $new_coupon_id = wp_insert_post($coupon);
        
        update_post_meta($new_coupon_id, 'discount_type', 'percent');
        update_post_meta($new_coupon_id, 'coupon_amount', '10');
        update_post_meta($new_coupon_id, 'individual_use', 'yes');
    }
    
    // Enviar email de bienvenida
    $subject = '¡Bienvenido a Golden Phoenix! 🎁 Aquí está tu descuento';
    
    $message = '
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; }
            .header { background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%); color: white; padding: 40px; text-align: center; }
            .content { background: white; padding: 40px; }
            .coupon { background: linear-gradient(135deg, #D4AF37 0%, #FFD700 100%); color: #0A0A0A; padding: 30px; text-align: center; border-radius: 12px; margin: 30px 0; }
            .coupon-code { font-size: 36px; font-weight: 700; letter-spacing: 5px; margin: 20px 0; font-family: monospace; }
            .button { display: inline-block; background: #D4AF37; color: white; padding: 15px 40px; text-decoration: none; border-radius: 50px; font-weight: 600; margin: 20px 0; }
            .footer { background: #f9f9f9; padding: 30px; text-align: center; color: #666; font-size: 14px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1 style="margin: 0; font-family: Playfair Display, serif; font-size: 36px;">Golden Phoenix</h1>
                <p style="margin: 10px 0 0 0; opacity: 0.9;">Joyería de Lujo</p>
            </div>
            
            <div class="content">
                <h2 style="color: #D4AF37;">¡Hola ' . esc_html($name) . '!</h2>
                
                <p>Bienvenido a nuestra exclusiva comunidad de amantes de la joyería fina.</p>
                
                <p>Como agradecimiento por unirte, queremos regalarte un <strong>10% de descuento</strong> en tu primera compra.</p>
                
                <div class="coupon">
                    <div style="font-size: 18px; margin-bottom: 10px;">Tu Código de Descuento</div>
                    <div class="coupon-code">NEWSLETTER10</div>
                    <div style="font-size: 14px; margin-top: 10px;">Válido para compras superiores a $200,000</div>
                </div>
                
                <div style="text-align: center;">
                    <a href="' . home_url('/tienda') . '" class="button">
                        Explorar Colección
                    </a>
                </div>
                
                <h3 style="color: #0A0A0A; margin-top: 40px;">¿Qué puedes esperar?</h3>
                
                <ul style="line-height: 2;">
                    <li>✨ Acceso anticipado a nuevas colecciones</li>
                    <li>💎 Descuentos exclusivos para suscriptores</li>
                    <li>🎁 Regalos especiales en tu cumpleaños</li>
                    <li>📧 Contenido y consejos sobre joyería</li>
                </ul>
                
                <p style="margin-top: 30px;">Si tienes alguna pregunta, responde este email. ¡Estamos para ayudarte!</p>
                
                <p style="margin-top: 20px;">Con cariño,<br><strong>El equipo de Golden Phoenix</strong></p>
            </div>
            
            <div class="footer">
                <p>Golden Phoenix Jewelry | Medellín, Colombia</p>
                <p>Email: ventas@agenciaredlab.com</p>
                <p style="font-size: 12px; margin-top: 20px;">
                    <a href="#" style="color: #666;">Ver en navegador</a> | 
                    <a href="#" style="color: #666;">Desuscribirse</a>
                </p>
            </div>
        </div>
    </body>
    </html>
    ';
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: Golden Phoenix <ventas@agenciaredlab.com>'
    );
    
    wp_mail($email, $subject, $message, $headers);
    
    wp_send_json_success(array('message' => '¡Gracias por suscribirte!'));
}

// ============================================
// WIDGET NEWSLETTER EN FOOTER
// ============================================

add_shortcode('newsletter_footer', 'gp_newsletter_footer_widget');

function gp_newsletter_footer_widget() {
    ?>
    <div class="newsletter-footer-widget" style="background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%); padding: 50px 20px; text-align: center; color: white;">
        <div class="container" style="max-width: 600px; margin: 0 auto;">
            
            <div style="font-size: 48px; margin-bottom: 20px;">💎</div>
            
            <h3 style="font-size: 32px; font-family: 'Playfair Display', serif; margin-bottom: 15px;">
                Suscríbete a Nuestro Newsletter
            </h3>
            
            <p style="opacity: 0.9; margin-bottom: 30px; font-size: 16px;">
                Recibe ofertas exclusivas y sé el primero en conocer nuestras nuevas colecciones
            </p>
            
            <form id="footer-newsletter-form" style="display: flex; gap: 10px; max-width: 500px; margin: 0 auto;">
                <input type="hidden" name="action" value="subscribe_newsletter">
                <input type="hidden" name="name" value="Suscriptor">
                
                <input type="email" 
                       name="email" 
                       placeholder="tu@email.com" 
                       required
                       style="flex: 1; padding: 15px 20px; border: 2px solid #D4AF37; border-radius: 50px; font-size: 16px; background: transparent; color: white;">
                
                <button type="submit" style="background: #D4AF37; color: #0A0A0A; border: none; padding: 15px 40px; border-radius: 50px; font-weight: 600; cursor: pointer; transition: all 0.3s;"
                        onmouseover="this.style.transform='scale(1.05)'"
                        onmouseout="this.style.transform='scale(1)'">
                    Suscribirse
                </button>
            </form>
            
            <div id="footer-newsletter-response" style="margin-top: 20px;"></div>
            
        </div>
    </div>
    
    <script>
    document.getElementById('footer-newsletter-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const form = this;
        const btn = form.querySelector('button');
        const response = document.getElementById('footer-newsletter-response');
        const originalText = btn.textContent;
        
        btn.textContent = 'Enviando...';
        btn.disabled = true;
        
        const formData = new FormData(form);
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                response.innerHTML = '<div style="color: #28a745;">✓ ¡Suscrito! Revisa tu email</div>';
                form.querySelector('input[type="email"]').value = '';
            } else {
                response.innerHTML = '<div style="color: #dc3545;">' + data.data.message + '</div>';
            }
            
            btn.textContent = originalText;
            btn.disabled = false;
        });
    });
    </script>
    
    <style>
    @media (max-width: 768px) {
        #footer-newsletter-form {
            flex-direction: column !important;
        }
        
        #footer-newsletter-form input,
        #footer-newsletter-form button {
            width: 100% !important;
        }
    }
    </style>
    <?php
}

// ============================================
// PÁGINA ADMIN DE SUSCRIPTORES
// ============================================

add_action('admin_menu', 'gp_newsletter_admin_menu');

function gp_newsletter_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Newsletter Suscriptores',
        '<span style="color: #D4AF37;">📧 Newsletter</span>',
        'manage_woocommerce',
        'newsletter-subscribers',
        'gp_newsletter_admin_page'
    );
}

function gp_newsletter_admin_page() {
    $subscribers = get_option('gp_newsletter_subscribers', array());
    $total = count($subscribers);
    
    // Últimos 7 días
    $last_week = array_filter($subscribers, function($sub) {
        return strtotime($sub['date']) > strtotime('-7 days');
    });
    
    ?>
    <div class="wrap">
        <h1>📧 Newsletter - Suscriptores</h1>
        
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 30px 0;">
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Total Suscriptores</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #D4AF37;"><?php echo $total; ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Últimos 7 Días</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #28a745;"><?php echo count($last_week); ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Tasa de Crecimiento</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #0A0A0A;">
                    <?php echo $total > 0 ? round((count($last_week) / $total) * 100) : 0; ?>%
                </p>
            </div>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Lista de Suscriptores</h2>
                <button class="button button-primary" onclick="exportSubscribers()">
                    Exportar a CSV
                </button>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Fecha</th>
                        <th>Fuente</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($subscribers)) : ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">
                                No hay suscriptores aún
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach (array_reverse($subscribers) as $sub) : ?>
                            <tr>
                                <td><?php echo esc_html($sub['name']); ?></td>
                                <td><?php echo esc_html($sub['email']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($sub['date'])); ?></td>
                                <td>
                                    <span style="background: #f0f0f0; padding: 5px 10px; border-radius: 3px; font-size: 12px;">
                                        <?php echo ucfirst($sub['source']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
    function exportSubscribers() {
        window.location.href = '<?php echo admin_url('admin-ajax.php'); ?>?action=export_newsletter_subscribers';
    }
    </script>
    <?php
}

// Exportar CSV
add_action('wp_ajax_export_newsletter_subscribers', 'gp_export_newsletter_subscribers');

function gp_export_newsletter_subscribers() {
    $subscribers = get_option('gp_newsletter_subscribers', array());
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="suscriptores-' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    fputcsv($output, array('Nombre', 'Email', 'Fecha', 'Fuente'));
    
    foreach ($subscribers as $sub) {
        fputcsv($output, array(
            $sub['name'],
            $sub['email'],
            $sub['date'],
            $sub['source']
        ));
    }
    
    fclose($output);
    exit;
}
