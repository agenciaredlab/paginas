<?php
/**
 * Golden Phoenix - SEO Completo y Schema Markup
 * Optimización para Google, posicionamiento y rich snippets
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// SCHEMA MARKUP PARA PRODUCTOS (RICH SNIPPETS)
// ============================================

add_action('wp_head', 'gp_product_schema_markup');

function gp_product_schema_markup() {
    if (!is_product()) {
        return;
    }
    
    global $product;
    
    $schema = array(
        '@context' => 'https://schema.org/',
        '@type' => 'Product',
        'name' => $product->get_name(),
        'description' => wp_strip_all_tags($product->get_description()),
        'image' => wp_get_attachment_url($product->get_image_id()),
        'sku' => $product->get_sku(),
        'brand' => array(
            '@type' => 'Brand',
            'name' => get_bloginfo('name')
        ),
        'offers' => array(
            '@type' => 'Offer',
            'url' => get_permalink(),
            'priceCurrency' => 'COP',
            'price' => $product->get_price(),
            'availability' => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            'priceValidUntil' => date('Y-12-31'),
            'seller' => array(
                '@type' => 'Organization',
                'name' => get_bloginfo('name')
            )
        )
    );
    
    // Agregar rating si existe
    if ($product->get_average_rating()) {
        $schema['aggregateRating'] = array(
            '@type' => 'AggregateRating',
            'ratingValue' => $product->get_average_rating(),
            'reviewCount' => $product->get_review_count(),
            'bestRating' => '5',
            'worstRating' => '1'
        );
    }
    
    // Agregar reseñas
    $reviews = get_comments(array(
        'post_id' => $product->get_id(),
        'status' => 'approve',
        'type' => 'review'
    ));
    
    if (!empty($reviews)) {
        $schema['review'] = array();
        foreach ($reviews as $review) {
            $rating = get_comment_meta($review->comment_ID, 'rating', true);
            $schema['review'][] = array(
                '@type' => 'Review',
                'author' => array(
                    '@type' => 'Person',
                    'name' => $review->comment_author
                ),
                'datePublished' => date('Y-m-d', strtotime($review->comment_date)),
                'reviewBody' => $review->comment_content,
                'reviewRating' => array(
                    '@type' => 'Rating',
                    'ratingValue' => $rating ?: '5',
                    'bestRating' => '5',
                    'worstRating' => '1'
                )
            );
        }
    }
    
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

// ============================================
// SCHEMA BREADCRUMBS
// ============================================

add_action('wp_head', 'gp_breadcrumb_schema');

function gp_breadcrumb_schema() {
    if (is_front_page()) {
        return;
    }
    
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'BreadcrumbList',
        'itemListElement' => array()
    );
    
    // Inicio
    $schema['itemListElement'][] = array(
        '@type' => 'ListItem',
        'position' => 1,
        'name' => 'Inicio',
        'item' => home_url()
    );
    
    $position = 2;
    
    if (is_product_category()) {
        $term = get_queried_object();
        $schema['itemListElement'][] = array(
            '@type' => 'ListItem',
            'position' => $position,
            'name' => $term->name,
            'item' => get_term_link($term)
        );
    } elseif (is_product()) {
        global $post;
        $categories = get_the_terms($post->ID, 'product_cat');
        
        if ($categories) {
            $category = array_shift($categories);
            $schema['itemListElement'][] = array(
                '@type' => 'ListItem',
                'position' => $position++,
                'name' => $category->name,
                'item' => get_term_link($category)
            );
        }
        
        $schema['itemListElement'][] = array(
            '@type' => 'ListItem',
            'position' => $position,
            'name' => get_the_title(),
            'item' => get_permalink()
        );
    }
    
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

// ============================================
// SCHEMA ORGANIZACIÓN
// ============================================

add_action('wp_head', 'gp_organization_schema');

function gp_organization_schema() {
    if (!is_front_page()) {
        return;
    }
    
    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'JewelryStore',
        'name' => get_bloginfo('name'),
        'description' => get_bloginfo('description'),
        'url' => home_url(),
        'logo' => get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : '',
        'image' => get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : '',
        'telephone' => get_theme_mod('gp_phone', ''),
        'email' => get_theme_mod('gp_email', ''),
        'address' => array(
            '@type' => 'PostalAddress',
            'streetAddress' => get_theme_mod('gp_address', ''),
            'addressLocality' => 'Medellín',
            'addressRegion' => 'Antioquia',
            'addressCountry' => 'CO'
        ),
        'sameAs' => array(
            get_theme_mod('gp_facebook', ''),
            get_theme_mod('gp_instagram', ''),
            get_theme_mod('gp_twitter', '')
        ),
        'priceRange' => '$$$$',
        'paymentAccepted' => 'PSE, Cash, Credit Card, Debit Card',
        'openingHours' => 'Mo-Fr 09:00-18:00, Sa 10:00-16:00'
    );
    
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
}

// ============================================
// META TAGS OPEN GRAPH (FACEBOOK/WHATSAPP)
// ============================================

add_action('wp_head', 'gp_open_graph_tags', 5);

function gp_open_graph_tags() {
    if (is_product()) {
        global $product;
        ?>
        <meta property="og:type" content="product">
        <meta property="og:title" content="<?php echo esc_attr($product->get_name()); ?>">
        <meta property="og:description" content="<?php echo esc_attr(wp_strip_all_tags($product->get_short_description())); ?>">
        <meta property="og:url" content="<?php echo get_permalink(); ?>">
        <meta property="og:image" content="<?php echo wp_get_attachment_url($product->get_image_id()); ?>">
        <meta property="og:image:width" content="1200">
        <meta property="og:image:height" content="630">
        <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
        <meta property="product:price:amount" content="<?php echo $product->get_price(); ?>">
        <meta property="product:price:currency" content="COP">
        <meta property="product:availability" content="<?php echo $product->is_in_stock() ? 'in stock' : 'out of stock'; ?>">
        <?php
    } else {
        ?>
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo is_front_page() ? get_bloginfo('name') : wp_get_document_title(); ?>">
        <meta property="og:description" content="<?php bloginfo('description'); ?>">
        <meta property="og:url" content="<?php echo get_permalink(); ?>">
        <meta property="og:image" content="<?php echo get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : ''; ?>">
        <meta property="og:site_name" content="<?php bloginfo('name'); ?>">
        <?php
    }
}

// ============================================
// META TAGS TWITTER CARDS
// ============================================

add_action('wp_head', 'gp_twitter_cards', 5);

function gp_twitter_cards() {
    if (is_product()) {
        global $product;
        ?>
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo esc_attr($product->get_name()); ?>">
        <meta name="twitter:description" content="<?php echo esc_attr(wp_strip_all_tags($product->get_short_description())); ?>">
        <meta name="twitter:image" content="<?php echo wp_get_attachment_url($product->get_image_id()); ?>">
        <meta name="twitter:label1" content="Precio">
        <meta name="twitter:data1" content="<?php echo $product->get_price_html(); ?>">
        <meta name="twitter:label2" content="Disponibilidad">
        <meta name="twitter:data2" content="<?php echo $product->is_in_stock() ? 'En Stock' : 'Agotado'; ?>">
        <?php
    } else {
        ?>
        <meta name="twitter:card" content="summary">
        <meta name="twitter:title" content="<?php echo is_front_page() ? get_bloginfo('name') : wp_get_document_title(); ?>">
        <meta name="twitter:description" content="<?php bloginfo('description'); ?>">
        <meta name="twitter:image" content="<?php echo get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : ''; ?>">
        <?php
    }
}

// ============================================
// SITEMAP XML AUTOMÁTICO
// ============================================

add_action('init', 'gp_create_sitemap');

function gp_create_sitemap() {
    add_rewrite_rule('^sitemap\.xml$', 'index.php?gp_sitemap=1', 'top');
}

add_filter('query_vars', 'gp_sitemap_query_vars');

function gp_sitemap_query_vars($vars) {
    $vars[] = 'gp_sitemap';
    return $vars;
}

add_action('template_redirect', 'gp_sitemap_output');

function gp_sitemap_output() {
    if (!get_query_var('gp_sitemap')) {
        return;
    }
    
    header('Content-Type: application/xml; charset=utf-8');
    
    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
    
    // Página de inicio
    echo '<url>';
    echo '<loc>' . home_url() . '</loc>';
    echo '<changefreq>daily</changefreq>';
    echo '<priority>1.0</priority>';
    echo '</url>';
    
    // Productos
    $products = wc_get_products(array('limit' => -1, 'status' => 'publish'));
    foreach ($products as $product) {
        echo '<url>';
        echo '<loc>' . get_permalink($product->get_id()) . '</loc>';
        echo '<lastmod>' . date('c', strtotime($product->get_date_modified())) . '</lastmod>';
        echo '<changefreq>weekly</changefreq>';
        echo '<priority>0.8</priority>';
        echo '</url>';
    }
    
    // Categorías
    $categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    foreach ($categories as $category) {
        echo '<url>';
        echo '<loc>' . get_term_link($category) . '</loc>';
        echo '<changefreq>weekly</changefreq>';
        echo '<priority>0.7</priority>';
        echo '</url>';
    }
    
    // Páginas
    $pages = get_pages();
    foreach ($pages as $page) {
        echo '<url>';
        echo '<loc>' . get_permalink($page->ID) . '</loc>';
        echo '<lastmod>' . date('c', strtotime($page->post_modified)) . '</lastmod>';
        echo '<changefreq>monthly</changefreq>';
        echo '<priority>0.6</priority>';
        echo '</url>';
    }
    
    echo '</urlset>';
    exit;
}

// ============================================
// ROBOTS.TXT OPTIMIZADO
// ============================================

add_filter('robots_txt', 'gp_custom_robots_txt', 10, 2);

function gp_custom_robots_txt($output, $public) {
    if ($public) {
        $output = "User-agent: *\n";
        $output .= "Disallow: /wp-admin/\n";
        $output .= "Disallow: /wp-includes/\n";
        $output .= "Disallow: /cart/\n";
        $output .= "Disallow: /checkout/\n";
        $output .= "Disallow: /my-account/\n";
        $output .= "Allow: /wp-content/uploads/\n";
        $output .= "\n";
        $output .= "Sitemap: " . home_url('sitemap.xml') . "\n";
    }
    
    return $output;
}

// ============================================
// META DESCRIPTION AUTOMÁTICA
// ============================================

add_action('wp_head', 'gp_meta_description', 1);

function gp_meta_description() {
    $description = '';
    
    if (is_product()) {
        global $product;
        $description = wp_strip_all_tags($product->get_short_description());
    } elseif (is_product_category()) {
        $term = get_queried_object();
        $description = $term->description ?: 'Explora nuestra colección de ' . $term->name . ' en ' . get_bloginfo('name');
    } elseif (is_front_page()) {
        $description = get_bloginfo('description');
    } elseif (is_singular()) {
        $description = wp_strip_all_tags(get_the_excerpt());
    }
    
    if ($description) {
        $description = wp_trim_words($description, 30);
        echo '<meta name="description" content="' . esc_attr($description) . '">';
    }
}

// ============================================
// CANONICAL URL
// ============================================

add_action('wp_head', 'gp_canonical_url', 1);

function gp_canonical_url() {
    if (is_singular()) {
        echo '<link rel="canonical" href="' . get_permalink() . '">';
    } elseif (is_archive()) {
        echo '<link rel="canonical" href="' . get_term_link(get_queried_object()) . '">';
    } elseif (is_front_page()) {
        echo '<link rel="canonical" href="' . home_url() . '">';
    }
}

// ============================================
// GOOGLE ANALYTICS & TAG MANAGER
// ============================================

add_action('customize_register', 'gp_seo_customizer');

function gp_seo_customizer($wp_customize) {
    // Sección SEO
    $wp_customize->add_section('gp_seo_section', array(
        'title' => '🎯 SEO y Analytics',
        'priority' => 25,
    ));
    
    // Google Analytics ID
    $wp_customize->add_setting('gp_google_analytics', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_google_analytics', array(
        'label' => 'Google Analytics ID',
        'section' => 'gp_seo_section',
        'type' => 'text',
        'description' => 'Ejemplo: G-XXXXXXXXXX o UA-XXXXXXXXX-X',
    ));
    
    // Google Tag Manager ID
    $wp_customize->add_setting('gp_google_tag_manager', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_google_tag_manager', array(
        'label' => 'Google Tag Manager ID',
        'section' => 'gp_seo_section',
        'type' => 'text',
        'description' => 'Ejemplo: GTM-XXXXXXX',
    ));
    
    // Facebook Pixel ID
    $wp_customize->add_setting('gp_facebook_pixel', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_facebook_pixel', array(
        'label' => 'Facebook Pixel ID',
        'section' => 'gp_seo_section',
        'type' => 'text',
        'description' => 'Ejemplo: 1234567890123456',
    ));
    
    // Google Search Console
    $wp_customize->add_setting('gp_google_verification', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_google_verification', array(
        'label' => 'Google Search Console Verification',
        'section' => 'gp_seo_section',
        'type' => 'text',
        'description' => 'Código de verificación de Google Search Console',
    ));
}

// Insertar Google Analytics
add_action('wp_head', 'gp_google_analytics_code', 1);

function gp_google_analytics_code() {
    $ga_id = get_theme_mod('gp_google_analytics');
    
    if (!$ga_id) {
        return;
    }
    
    // Google Analytics 4
    if (strpos($ga_id, 'G-') === 0) {
        ?>
        <!-- Google Analytics 4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $ga_id; ?>"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '<?php echo $ga_id; ?>');
        </script>
        <?php
    }
    // Universal Analytics
    else {
        ?>
        <!-- Google Analytics Universal -->
        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        ga('create', '<?php echo $ga_id; ?>', 'auto');
        ga('send', 'pageview');
        </script>
        <?php
    }
}

// Insertar Google Tag Manager
add_action('wp_head', 'gp_google_tag_manager_head', 1);

function gp_google_tag_manager_head() {
    $gtm_id = get_theme_mod('gp_google_tag_manager');
    
    if (!$gtm_id) {
        return;
    }
    ?>
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','<?php echo $gtm_id; ?>');</script>
    <!-- End Google Tag Manager -->
    <?php
}

add_action('wp_body_open', 'gp_google_tag_manager_body');

function gp_google_tag_manager_body() {
    $gtm_id = get_theme_mod('gp_google_tag_manager');
    
    if (!$gtm_id) {
        return;
    }
    ?>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo $gtm_id; ?>"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <?php
}

// Insertar Facebook Pixel
add_action('wp_head', 'gp_facebook_pixel_code', 1);

function gp_facebook_pixel_code() {
    $pixel_id = get_theme_mod('gp_facebook_pixel');
    
    if (!$pixel_id) {
        return;
    }
    ?>
    <!-- Facebook Pixel Code -->
    <script>
    !function(f,b,e,v,n,t,s)
    {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '<?php echo $pixel_id; ?>');
    fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
    src="https://www.facebook.com/tr?id=<?php echo $pixel_id; ?>&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->
    <?php
}

// Google Search Console Verification
add_action('wp_head', 'gp_google_verification_code', 1);

function gp_google_verification_code() {
    $verification = get_theme_mod('gp_google_verification');
    
    if ($verification) {
        echo '<meta name="google-site-verification" content="' . esc_attr($verification) . '">';
    }
}

// ============================================
// TRACKING DE CONVERSIONES (ADD TO CART, PURCHASE)
// ============================================

add_action('woocommerce_add_to_cart', 'gp_track_add_to_cart', 10, 6);

function gp_track_add_to_cart($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
    $pixel_id = get_theme_mod('gp_facebook_pixel');
    
    if (!$pixel_id) {
        return;
    }
    
    $product = wc_get_product($product_id);
    ?>
    <script>
    fbq('track', 'AddToCart', {
        content_name: '<?php echo esc_js($product->get_name()); ?>',
        content_ids: ['<?php echo $product_id; ?>'],
        content_type: 'product',
        value: <?php echo $product->get_price(); ?>,
        currency: 'COP'
    });
    
    gtag('event', 'add_to_cart', {
        currency: 'COP',
        value: <?php echo $product->get_price(); ?>,
        items: [{
            item_id: '<?php echo $product_id; ?>',
            item_name: '<?php echo esc_js($product->get_name()); ?>',
            price: <?php echo $product->get_price(); ?>,
            quantity: <?php echo $quantity; ?>
        }]
    });
    </script>
    <?php
}

// ============================================
// ALT TEXT AUTOMÁTICO PARA IMÁGENES
// ============================================

add_filter('wp_get_attachment_image_attributes', 'gp_auto_image_alt', 10, 2);

function gp_auto_image_alt($attr, $attachment) {
    if (empty($attr['alt'])) {
        $attr['alt'] = get_the_title($attachment->ID);
    }
    return $attr;
}
