<?php
/**
 * Golden Phoenix V71 - GIFT FINDER
 * Buscador de regalos por ocasión, presupuesto y persona
 */

if (!defined('ABSPATH')) exit;

// Crear página Gift Finder
add_action('after_switch_theme', 'gp_create_gift_finder_page');

function gp_create_gift_finder_page() {
    if (get_option('gp_gift_finder_page_created')) {
        return;
    }
    
    $page_id = wp_insert_post(array(
        'post_title' => 'Buscador de Regalos',
        'post_name' => 'gift-finder',
        'post_content' => '[gift_finder_form]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    
    update_option('gp_gift_finder_page_created', true);
    update_option('gp_gift_finder_page_id', $page_id);
}

// Shortcode formulario
add_shortcode('gift_finder_form', 'gp_gift_finder_form');

function gp_gift_finder_form() {
    ob_start();
    ?>
    
    <div class="gp-gift-finder">
        <h2 style="text-align: center; font-family: 'Playfair Display', serif; margin-bottom: 40px;">
            🎁 Encuentra el Regalo Perfecto
        </h2>
        
        <form id="gp-gift-form" style="max-width: 800px; margin: 0 auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                    ¿Para quién es el regalo?
                </label>
                <select name="recipient" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="mujer">Mujer</option>
                    <option value="hombre">Hombre</option>
                    <option value="pareja">Pareja</option>
                    <option value="mama">Mamá</option>
                    <option value="papa">Papá</option>
                    <option value="amiga">Amiga</option>
                    <option value="amigo">Amigo</option>
                </select>
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                    ¿Cuál es la ocasión?
                </label>
                <select name="occasion" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="cumpleanos">Cumpleaños</option>
                    <option value="aniversario">Aniversario</option>
                    <option value="compromiso">Compromiso</option>
                    <option value="boda">Boda</option>
                    <option value="navidad">Navidad</option>
                    <option value="dia-madre">Día de la Madre</option>
                    <option value="dia-padre">Día del Padre</option>
                    <option value="san-valentin">San Valentín</option>
                    <option value="graduacion">Graduación</option>
                    <option value="otro">Otro</option>
                </select>
            </div>
            
            <div style="margin-bottom: 25px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                    ¿Cuál es tu presupuesto?
                </label>
                <select name="budget" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">Seleccionar...</option>
                    <option value="0-100000">Hasta $100,000</option>
                    <option value="100000-300000">$100,000 - $300,000</option>
                    <option value="300000-500000">$300,000 - $500,000</option>
                    <option value="500000-1000000">$500,000 - $1,000,000</option>
                    <option value="1000000-99999999">Más de $1,000,000</option>
                </select>
            </div>
            
            <button type="submit" style="width: 100%; padding: 15px; background: #D4AF37; color: white; border: none; border-radius: 6px; font-weight: 600; font-size: 16px; cursor: pointer;">
                🔍 Buscar Regalo Perfecto
            </button>
        </form>
        
        <div id="gp-gift-results" style="margin-top: 40px;"></div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#gp-gift-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serialize();
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: formData + '&action=gp_find_gifts',
                success: function(response) {
                    $('#gp-gift-results').html(response);
                    $('html, body').animate({
                        scrollTop: $('#gp-gift-results').offset().top - 100
                    }, 500);
                }
            });
        });
    });
    </script>
    
    <?php
    return ob_get_clean();
}

// AJAX buscar regalos
add_action('wp_ajax_gp_find_gifts', 'gp_ajax_find_gifts');
add_action('wp_ajax_nopriv_gp_find_gifts', 'gp_ajax_find_gifts');

function gp_ajax_find_gifts() {
    $recipient = sanitize_text_field($_POST['recipient']);
    $occasion = sanitize_text_field($_POST['occasion']);
    $budget = sanitize_text_field($_POST['budget']);
    
    // Parsear presupuesto
    list($min, $max) = explode('-', $budget);
    
    // Query productos
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 12,
        'meta_query' => array(
            array(
                'key' => '_price',
                'value' => array($min, $max),
                'type' => 'NUMERIC',
                'compare' => 'BETWEEN'
            )
        )
    );
    
    $products = new WP_Query($args);
    
    if ($products->have_posts()) {
        echo '<h3 style="text-align: center; margin-bottom: 30px;">✨ Encontramos estos regalos perfectos para ti:</h3>';
        echo '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 30px;">';
        
        while ($products->have_posts()) {
            $products->the_post();
            wc_get_template_part('content', 'product');
        }
        
        echo '</div>';
    } else {
        echo '<p style="text-align: center;">No encontramos productos en este rango. Intenta con otro presupuesto.</p>';
    }
    
    wp_reset_postdata();
    wp_die();
}
