<?php
/**
 * GOLDEN PHOENIX - RESET & SETUP WIZARD
 * Soluciona problemas de activación y configura el tema correctamente
 */

if (!defined('ABSPATH')) exit;

class GP_Theme_Setup_Wizard {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_setup_page'));
        add_action('admin_init', array($this, 'handle_setup_actions'));
        add_action('wp_ajax_gp_reset_page', array($this, 'ajax_reset_page'));
    }
    
    public function add_setup_page() {
        add_menu_page(
            'Asistente Golden Phoenix',
            '🎨 Configurar Tema',
            'manage_options',
            'gp-setup-wizard',
            array($this, 'render_setup_page'),
            'dashicons-admin-appearance',
            3
        );
    }
    
    public function render_setup_page() {
        ?>
        <div class="wrap" style="max-width: 1200px; margin: 40px auto;">
            <h1 style="font-size: 32px; margin-bottom: 10px;">🎨 Asistente de Configuración - Golden Phoenix</h1>
            <p style="font-size: 16px; color: #666; margin-bottom: 40px;">Soluciona el problema de activación en 3 pasos</p>
            
            <!-- DIAGNÓSTICO -->
            <div style="background: #fff; padding: 30px; margin-bottom: 20px; border-left: 4px solid #2196F3; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">📊 Diagnóstico del Problema</h2>
                
                <?php
                $home_id = get_option('page_on_front');
                $shop_id = get_option('woocommerce_shop_page_id');
                
                if ($home_id) {
                    $home = get_post($home_id);
                    echo '<div style="background: #fff3cd; padding: 15px; border-radius: 4px; margin: 15px 0;">';
                    echo '<p style="margin: 0;"><strong>🏠 Página de Inicio:</strong> ' . get_the_title($home_id) . '</p>';
                    echo '<p style="margin: 5px 0 0;"><strong>Plantilla actual:</strong> ' . get_post_meta($home_id, '_wp_page_template', true) . '</p>';
                    echo '<p style="margin: 5px 0 0;"><strong>Contenido guardado:</strong> ' . (strlen($home->post_content) > 100 ? 'SÍ (Gutenberg activo)' : 'No') . '</p>';
                    echo '</div>';
                }
                
                if ($shop_id) {
                    $shop = get_post($shop_id);
                    echo '<div style="background: #fff3cd; padding: 15px; border-radius: 4px; margin: 15px 0;">';
                    echo '<p style="margin: 0;"><strong>🛒 Página Tienda:</strong> ' . get_the_title($shop_id) . '</p>';
                    echo '<p style="margin: 5px 0 0;"><strong>Plantilla actual:</strong> ' . get_post_meta($shop_id, '_wp_page_template', true) . '</p>';
                    echo '</div>';
                }
                ?>
                
                <div style="background: #f0f0f1; padding: 15px; border-radius: 4px; margin-top: 20px;">
                    <h3 style="margin-top: 0;">⚠️ El Problema:</h3>
                    <p>Cuando WordPress muestra la "Vista Previa", usa las plantillas del tema (page-home.php, etc). Pero cuando activas el tema, WordPress carga el <strong>contenido guardado en la base de datos</strong> (bloques de Gutenberg del tema anterior).</p>
                    
                    <h3>✅ La Solución:</h3>
                    <ol>
                        <li><strong>Limpiar contenido Gutenberg</strong> de las páginas</li>
                        <li><strong>Asignar plantillas correctas</strong> del tema</li>
                        <li><strong>Configurar ajustes</strong> de WordPress</li>
                    </ol>
                </div>
            </div>
            
            <!-- PASO 1 -->
            <div style="background: #fff; padding: 30px; margin-bottom: 20px; border-left: 4px solid #4CAF50; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">1️⃣ Limpiar Páginas</h2>
                <p>Elimina el contenido de bloques Gutenberg y prepara las páginas para usar las plantillas del tema.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('gp_reset_pages'); ?>
                    <input type="hidden" name="gp_action" value="reset_pages">
                    
                    <div style="margin: 20px 0;">
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="reset_home" checked>
                            <strong>Limpiar página de inicio</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="reset_shop" checked>
                            <strong>Limpiar página de tienda</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="reset_cart" checked>
                            <strong>Limpiar página de carrito</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="reset_checkout" checked>
                            <strong>Limpiar página de checkout</strong>
                        </label>
                    </div>
                    
                    <button type="submit" class="button button-primary button-hero">
                        🧹 Limpiar Páginas Seleccionadas
                    </button>
                </form>
            </div>
            
            <!-- PASO 2 -->
            <div style="background: #fff; padding: 30px; margin-bottom: 20px; border-left: 4px solid #FF9800; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">2️⃣ Asignar Plantillas</h2>
                <p>Asigna las plantillas correctas de Golden Phoenix a cada página.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('gp_assign_templates'); ?>
                    <input type="hidden" name="gp_action" value="assign_templates">
                    
                    <button type="submit" class="button button-primary button-hero">
                        📄 Asignar Plantillas Automáticamente
                    </button>
                </form>
                
                <div style="margin-top: 20px; background: #f0f0f1; padding: 15px; border-radius: 4px;">
                    <p style="margin: 0;"><strong>Plantillas que se asignarán:</strong></p>
                    <ul>
                        <li>Inicio → page-home.php</li>
                        <li>Tienda → woocommerce.php</li>
                        <li>Carrito → page-cart.php</li>
                        <li>Checkout → page.php</li>
                        <li>Colecciones → page-collections.php</li>
                    </ul>
                </div>
            </div>
            
            <!-- PASO 3 -->
            <div style="background: #fff; padding: 30px; margin-bottom: 20px; border-left: 4px solid #9C27B0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">3️⃣ Configurar WordPress</h2>
                <p>Configura los ajustes básicos de WordPress para el tema.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('gp_configure_wp'); ?>
                    <input type="hidden" name="gp_action" value="configure_wp">
                    
                    <div style="margin: 20px 0;">
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="set_permalinks" checked>
                            <strong>Configurar permalinks (/%postname%/)</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="set_timezone" checked>
                            <strong>Configurar zona horaria (America/Bogota)</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="disable_comments" checked>
                            <strong>Desactivar comentarios en páginas</strong>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="set_image_sizes" checked>
                            <strong>Configurar tamaños de imagen</strong>
                        </label>
                    </div>
                    
                    <button type="submit" class="button button-primary button-hero">
                        ⚙️ Configurar WordPress
                    </button>
                </form>
            </div>
            
            <!-- BONUS: CREAR PÁGINAS -->
            <div style="background: #fff; padding: 30px; margin-bottom: 20px; border-left: 4px solid #E91E63; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">🎁 BONUS: Crear Páginas Necesarias</h2>
                <p>Crea automáticamente todas las páginas que necesita Golden Phoenix.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('gp_create_pages'); ?>
                    <input type="hidden" name="gp_action" value="create_pages">
                    
                    <button type="submit" class="button button-primary button-hero">
                        ➕ Crear Todas las Páginas
                    </button>
                </form>
                
                <div style="margin-top: 20px; background: #f0f0f1; padding: 15px; border-radius: 4px;">
                    <p style="margin: 0;"><strong>Páginas que se crearán (si no existen):</strong></p>
                    <ul style="columns: 2;">
                        <li>Inicio</li>
                        <li>Tienda</li>
                        <li>Carrito</li>
                        <li>Finalizar Compra</li>
                        <li>Mi Cuenta</li>
                        <li>Colecciones</li>
                        <li>Sobre Nosotros</li>
                        <li>Contacto</li>
                        <li>Política de Privacidad</li>
                        <li>Términos y Condiciones</li>
                    </ul>
                </div>
            </div>
            
            <!-- ACCIÓN RÁPIDA -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; border-radius: 8px; text-align: center; color: white; margin-bottom: 20px;">
                <h2 style="margin-top: 0; color: white; font-size: 28px;">⚡ Acción Rápida</h2>
                <p style="font-size: 18px; margin: 10px 0 30px;">Haz TODO en un solo clic</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('gp_do_everything'); ?>
                    <input type="hidden" name="gp_action" value="do_everything">
                    
                    <button type="submit" style="background: white; color: #667eea; border: none; padding: 20px 40px; font-size: 20px; font-weight: bold; border-radius: 50px; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.2);">
                        🚀 HACER TODO AUTOMÁTICAMENTE
                    </button>
                </form>
                
                <p style="margin: 20px 0 0; font-size: 14px; opacity: 0.9;">
                    Esto hará: Limpiar + Plantillas + Configurar + Crear páginas
                </p>
            </div>
            
            <!-- AYUDA -->
            <div style="background: #e3f2fd; padding: 20px; border-radius: 4px; border-left: 4px solid #2196F3;">
                <h3 style="margin-top: 0;">💡 ¿Todavía no se ve bien?</h3>
                <ol>
                    <li>Ve a <strong>Apariencia → Personalizar</strong></li>
                    <li>Ajusta colores, tipografías y diseño</li>
                    <li>Ve a <strong>Páginas → Editar Inicio</strong></li>
                    <li>Si ves bloques de Gutenberg, elimínalos manualmente</li>
                    <li>Guarda la página vacía</li>
                    <li>Refresca el frontend (Ctrl+F5)</li>
                </ol>
                
                <p style="margin: 20px 0 0; font-weight: 600;">
                    📧 ¿Necesitas ayuda? ventas@agenciaredlab.com
                </p>
            </div>
        </div>
        
        <style>
        .button-hero {
            padding: 15px 30px !important;
            font-size: 16px !important;
            height: auto !important;
        }
        </style>
        <?php
    }
    
    public function handle_setup_actions() {
        if (!isset($_POST['gp_action'])) return;
        if (!current_user_can('manage_options')) return;
        
        $action = $_POST['gp_action'];
        
        // RESET PAGES
        if ($action === 'reset_pages' && wp_verify_nonce($_POST['_wpnonce'], 'gp_reset_pages')) {
            $pages_to_reset = array();
            
            if (isset($_POST['reset_home'])) $pages_to_reset[] = get_option('page_on_front');
            if (isset($_POST['reset_shop'])) $pages_to_reset[] = get_option('woocommerce_shop_page_id');
            if (isset($_POST['reset_cart'])) $pages_to_reset[] = get_option('woocommerce_cart_page_id');
            if (isset($_POST['reset_checkout'])) $pages_to_reset[] = get_option('woocommerce_checkout_page_id');
            
            foreach ($pages_to_reset as $page_id) {
                if ($page_id) {
                    wp_update_post(array(
                        'ID' => $page_id,
                        'post_content' => '' // Vaciar contenido
                    ));
                    
                    // Limpiar meta de Gutenberg
                    delete_post_meta($page_id, '_wp_page_template');
                }
            }
            
            add_settings_error('gp_messages', 'gp_message', '✅ Páginas limpiadas correctamente', 'success');
            set_transient('gp_admin_notice', '✅ Páginas limpiadas correctamente', 30);
        }
        
        // ASSIGN TEMPLATES
        if ($action === 'assign_templates' && wp_verify_nonce($_POST['_wpnonce'], 'gp_assign_templates')) {
            $home_id = get_option('page_on_front');
            if ($home_id) {
                update_post_meta($home_id, '_wp_page_template', 'page-home.php');
            }
            
            $shop_id = get_option('woocommerce_shop_page_id');
            if ($shop_id) {
                update_post_meta($shop_id, '_wp_page_template', 'default');
            }
            
            $cart_id = get_option('woocommerce_cart_page_id');
            if ($cart_id) {
                update_post_meta($cart_id, '_wp_page_template', 'page-cart.php');
            }
            
            set_transient('gp_admin_notice', '✅ Plantillas asignadas correctamente', 30);
        }
        
        // CONFIGURE WP
        if ($action === 'configure_wp' && wp_verify_nonce($_POST['_wpnonce'], 'gp_configure_wp')) {
            if (isset($_POST['set_permalinks'])) {
                update_option('permalink_structure', '/%postname%/');
                flush_rewrite_rules();
            }
            
            if (isset($_POST['set_timezone'])) {
                update_option('timezone_string', 'America/Bogota');
            }
            
            if (isset($_POST['disable_comments'])) {
                update_option('default_comment_status', 'closed');
            }
            
            if (isset($_POST['set_image_sizes'])) {
                update_option('thumbnail_size_w', 300);
                update_option('thumbnail_size_h', 300);
                update_option('medium_size_w', 768);
                update_option('medium_size_h', 768);
                update_option('large_size_w', 1024);
                update_option('large_size_h', 1024);
            }
            
            set_transient('gp_admin_notice', '✅ WordPress configurado correctamente', 30);
        }
        
        // CREATE PAGES
        if ($action === 'create_pages' && wp_verify_nonce($_POST['_wpnonce'], 'gp_create_pages')) {
            $pages = array(
                'Inicio' => 'page-home.php',
                'Colecciones' => 'page-collections.php',
                'Sobre Nosotros' => 'page.php',
                'Contacto' => 'page.php',
                'Política de Privacidad' => 'page.php',
                'Términos y Condiciones' => 'page.php'
            );
            
            foreach ($pages as $title => $template) {
                $existing = get_page_by_title($title);
                if (!$existing) {
                    $page_id = wp_insert_post(array(
                        'post_title' => $title,
                        'post_content' => '',
                        'post_status' => 'publish',
                        'post_type' => 'page'
                    ));
                    
                    if ($page_id) {
                        update_post_meta($page_id, '_wp_page_template', $template);
                    }
                }
            }
            
            // Set homepage
            $home = get_page_by_title('Inicio');
            if ($home) {
                update_option('page_on_front', $home->ID);
                update_option('show_on_front', 'page');
            }
            
            set_transient('gp_admin_notice', '✅ Páginas creadas correctamente', 30);
        }
        
        // DO EVERYTHING
        if ($action === 'do_everything' && wp_verify_nonce($_POST['_wpnonce'], 'gp_do_everything')) {
            // 1. Reset pages
            $all_pages = array(
                get_option('page_on_front'),
                get_option('woocommerce_shop_page_id'),
                get_option('woocommerce_cart_page_id'),
                get_option('woocommerce_checkout_page_id')
            );
            
            foreach ($all_pages as $page_id) {
                if ($page_id) {
                    wp_update_post(array(
                        'ID' => $page_id,
                        'post_content' => ''
                    ));
                }
            }
            
            // 2. Assign templates
            $home_id = get_option('page_on_front');
            if ($home_id) update_post_meta($home_id, '_wp_page_template', 'page-home.php');
            
            $cart_id = get_option('woocommerce_cart_page_id');
            if ($cart_id) update_post_meta($cart_id, '_wp_page_template', 'page-cart.php');
            
            // 3. Configure WP
            update_option('permalink_structure', '/%postname%/');
            update_option('timezone_string', 'America/Bogota');
            update_option('default_comment_status', 'closed');
            flush_rewrite_rules();
            
            // 4. Create missing pages
            $pages = array(
                'Colecciones' => 'page-collections.php',
                'Sobre Nosotros' => 'page.php',
                'Contacto' => 'page.php'
            );
            
            foreach ($pages as $title => $template) {
                $existing = get_page_by_title($title);
                if (!$existing) {
                    $page_id = wp_insert_post(array(
                        'post_title' => $title,
                        'post_content' => '',
                        'post_status' => 'publish',
                        'post_type' => 'page'
                    ));
                    
                    if ($page_id) {
                        update_post_meta($page_id, '_wp_page_template', $template);
                    }
                }
            }
            
            set_transient('gp_admin_notice', '✅ ¡TODO LISTO! Tema configurado completamente. Refresca el sitio (Ctrl+F5)', 30);
        }
    }
}

new GP_Theme_Setup_Wizard();

// Show admin notices
add_action('admin_notices', function() {
    if ($notice = get_transient('gp_admin_notice')) {
        echo '<div class="notice notice-success is-dismissible"><p>' . $notice . '</p></div>';
        delete_transient('gp_admin_notice');
    }
});
