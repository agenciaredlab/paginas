<?php
/**
 * Golden Phoenix V71 - WHATSAPP DIRECT ORDER
 * Permite ordenar productos por WhatsApp con carrito pre-llenado
 */

if (!defined('ABSPATH')) exit;

// ========================================
// CONFIGURACIÓN WHATSAPP
// ========================================

// Número de WhatsApp (configurable desde customizer)
function gp_get_whatsapp_number() {
    return get_theme_mod('gp_whatsapp_number', '573001234567'); // Default Colombia
}

// ========================================
// BOTÓN WHATSAPP EN PRODUCTO INDIVIDUAL
// ========================================

add_action('woocommerce_after_add_to_cart_button', 'gp_whatsapp_product_button');

function gp_whatsapp_product_button() {
    global $product;
    
    $whatsapp_number = gp_get_whatsapp_number();
    $product_name = $product->get_name();
    $product_url = get_permalink($product->get_id());
    $product_price = $product->get_price_html();
    
    // Mensaje pre-formateado
    $message = "Hola! Me interesa este producto:\n\n";
    $message .= "*{$product_name}*\n";
    $message .= "Precio: {$product_price}\n";
    $message .= "Link: {$product_url}";
    
    $whatsapp_link = "https://wa.me/{$whatsapp_number}?text=" . urlencode($message);
    ?>
    
    <a href="<?php echo esc_url($whatsapp_link); ?>" 
       class="button gp-whatsapp-button"
       target="_blank"
       style="
           background: #25D366;
           color: white;
           border: none;
           margin-top: 10px;
           width: 100%;
           display: flex;
           align-items: center;
           justify-content: center;
           gap: 10px;
           font-weight: 600;
       ">
        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
        Ordenar por WhatsApp
    </a>
    
    <?php
}

// ========================================
// BOTÓN WHATSAPP EN CARRITO
// ========================================

add_action('woocommerce_proceed_to_checkout', 'gp_whatsapp_cart_button', 5);

function gp_whatsapp_cart_button() {
    $whatsapp_number = gp_get_whatsapp_number();
    
    // Obtener items del carrito
    $cart_items = WC()->cart->get_cart();
    
    if (empty($cart_items)) {
        return;
    }
    
    // Construir mensaje con todos los productos
    $message = "Hola! Quiero hacer un pedido:\n\n";
    $message .= "*PRODUCTOS:*\n";
    
    $total = 0;
    foreach ($cart_items as $cart_item) {
        $product = $cart_item['data'];
        $quantity = $cart_item['quantity'];
        $name = $product->get_name();
        $price = $product->get_price();
        $subtotal = $price * $quantity;
        
        $message .= "• {$name}\n";
        $message .= "  Cantidad: {$quantity}\n";
        $message .= "  Precio: $" . number_format($price, 0, ',', '.') . "\n";
        $message .= "  Subtotal: $" . number_format($subtotal, 0, ',', '.') . "\n\n";
        
        $total += $subtotal;
    }
    
    $message .= "*TOTAL: $" . number_format($total, 0, ',', '.') . "*\n\n";
    $message .= "¿Pueden ayudarme con este pedido?";
    
    $whatsapp_link = "https://wa.me/{$whatsapp_number}?text=" . urlencode($message);
    ?>
    
    <a href="<?php echo esc_url($whatsapp_link); ?>" 
       class="checkout-button button alt gp-whatsapp-checkout"
       target="_blank"
       style="
           background: #25D366;
           display: flex;
           align-items: center;
           justify-content: center;
           gap: 10px;
           margin-bottom: 10px;
       ">
        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
        Completar Pedido por WhatsApp
    </a>
    
    <?php
}

// ========================================
// BOTÓN WHATSAPP FLOTANTE
// ========================================

add_action('wp_footer', 'gp_whatsapp_floating_button');

function gp_whatsapp_floating_button() {
    $whatsapp_number = gp_get_whatsapp_number();
    $whatsapp_enabled = get_theme_mod('gp_whatsapp_floating_enabled', true);
    
    if (!$whatsapp_enabled) {
        return;
    }
    
    $message = get_theme_mod('gp_whatsapp_message', 'Hola! Tengo una consulta sobre sus productos.');
    $whatsapp_link = "https://wa.me/{$whatsapp_number}?text=" . urlencode($message);
    ?>
    
    <a href="<?php echo esc_url($whatsapp_link); ?>" 
       class="gp-whatsapp-float"
       target="_blank"
       aria-label="Contactar por WhatsApp">
        <svg width="60" height="60" fill="white" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>
    
    <style>
    .gp-whatsapp-float {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: #25D366;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(37, 211, 102, 0.4);
        z-index: 9999;
        transition: all 0.3s ease;
        animation: pulse 2s infinite;
    }
    
    .gp-whatsapp-float:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px rgba(37, 211, 102, 0.6);
    }
    
    @keyframes pulse {
        0%, 100% {
            box-shadow: 0 4px 12px rgba(37, 211, 102, 0.4);
        }
        50% {
            box-shadow: 0 4px 20px rgba(37, 211, 102, 0.8);
        }
    }
    
    @media (max-width: 768px) {
        .gp-whatsapp-float {
            bottom: 15px;
            right: 15px;
            width: 55px;
            height: 55px;
        }
    }
    </style>
    
    <?php
}

// ========================================
// OPCIONES EN CUSTOMIZER
// ========================================

add_action('customize_register', 'gp_whatsapp_customizer');

function gp_whatsapp_customizer($wp_customize) {
    
    // Sección WhatsApp
    $wp_customize->add_section('gp_whatsapp_section', array(
        'title' => '💬 WhatsApp Direct Order',
        'priority' => 40,
        'description' => 'Configura el número de WhatsApp y botones'
    ));
    
    // Número WhatsApp
    $wp_customize->add_setting('gp_whatsapp_number', array(
        'default' => '573001234567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_whatsapp_number', array(
        'label' => 'Número WhatsApp (con código país)',
        'section' => 'gp_whatsapp_section',
        'type' => 'text',
        'description' => 'Ej: 573001234567 (sin + ni espacios)'
    ));
    
    // Habilitar botón flotante
    $wp_customize->add_setting('gp_whatsapp_floating_enabled', array(
        'default' => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    
    $wp_customize->add_control('gp_whatsapp_floating_enabled', array(
        'label' => 'Mostrar botón flotante',
        'section' => 'gp_whatsapp_section',
        'type' => 'checkbox',
    ));
    
    // Mensaje predeterminado
    $wp_customize->add_setting('gp_whatsapp_message', array(
        'default' => 'Hola! Tengo una consulta sobre sus productos.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('gp_whatsapp_message', array(
        'label' => 'Mensaje predeterminado',
        'section' => 'gp_whatsapp_section',
        'type' => 'textarea',
    ));
}

// ========================================
// SHORTCODE WHATSAPP
// ========================================

add_shortcode('whatsapp_button', 'gp_whatsapp_shortcode');

function gp_whatsapp_shortcode($atts) {
    $atts = shortcode_atts(array(
        'text' => 'Contactar por WhatsApp',
        'message' => 'Hola! Tengo una consulta.',
    ), $atts);
    
    $whatsapp_number = gp_get_whatsapp_number();
    $whatsapp_link = "https://wa.me/{$whatsapp_number}?text=" . urlencode($atts['message']);
    
    return '<a href="' . esc_url($whatsapp_link) . '" class="button gp-whatsapp-button" target="_blank">' . esc_html($atts['text']) . '</a>';
}
