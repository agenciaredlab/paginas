<?php
/**
 * Golden Phoenix V77 - NUEVO SISTEMA CHAT SIMPLE
 * Sin base de datos, sin errores, 100% funcional
 */

if (!defined('ABSPATH')) exit;

// ========================================
// DESACTIVAR COMPLETAMENTE live-chat-system.php
// ========================================

// Prevenir que se cargue el archivo antiguo
add_filter('pre_option_gp_old_chat_system_active', '__return_false');

// Remover menú del chat antiguo
add_action('admin_menu', 'gp_v77_remove_old_chat_menu', 999);

function gp_v77_remove_old_chat_menu() {
    remove_menu_page('gp-live-chat');
    remove_submenu_page('gp-live-chat', 'gp-live-chat');
    remove_submenu_page('gp-live-chat', 'gp-live-chat-settings');
    remove_submenu_page('gp-live-chat', 'gp-live-chat-stats');
}

// Ocultar con CSS cualquier remanente
add_action('admin_head', 'gp_v77_hide_old_chat_admin');

function gp_v77_hide_old_chat_admin() {
    ?>
    <style>
    /* Ocultar menú chat antiguo */
    a[href*="gp-live-chat"] {
        display: none !important;
    }
    </style>
    <?php
}

// ========================================
// NUEVO SISTEMA CHAT SIMPLE - SIN TABLAS
// ========================================

class GP_Simple_Chat {
    
    public static function init() {
        // Solo si está habilitado en settings
        if (!get_option('gp_live_chat_enabled', true)) {
            return;
        }
        
        add_action('wp_footer', array(__CLASS__, 'render_chat_widget'));
    }
    
    public static function render_chat_widget() {
        // No renderizar en admin
        if (is_admin()) {
            return;
        }
        ?>
        
        <style>
        /* Chat Widget Simple */
        .gp-simple-chat-button {
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #0084FF, #0056CC);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(0, 132, 255, 0.4);
            z-index: 9998;
            transition: all 0.3s ease;
        }
        
        .gp-simple-chat-button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(0, 132, 255, 0.6);
        }
        
        .gp-simple-chat-button svg {
            width: 30px;
            height: 30px;
            fill: white;
        }
        
        .gp-simple-chat-window {
            position: fixed;
            bottom: 90px;
            left: 20px;
            width: 350px;
            height: 500px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            z-index: 9999;
            display: none;
            flex-direction: column;
            overflow: hidden;
        }
        
        .gp-simple-chat-window.active {
            display: flex;
        }
        
        .gp-simple-chat-header {
            background: linear-gradient(135deg, #0084FF, #0056CC);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .gp-simple-chat-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 30px;
            height: 30px;
            padding: 0;
        }
        
        .gp-simple-chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f5f5f5;
        }
        
        .gp-simple-chat-message {
            margin-bottom: 15px;
            padding: 12px 16px;
            border-radius: 12px;
            max-width: 80%;
            word-wrap: break-word;
        }
        
        .gp-simple-chat-message.user {
            background: #0084FF;
            color: white;
            margin-left: auto;
            text-align: right;
            border-radius: 12px 12px 4px 12px;
        }
        
        .gp-simple-chat-message.agent {
            background: white;
            color: #333;
            border-radius: 12px 12px 12px 4px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        
        .gp-simple-chat-input-area {
            padding: 15px;
            border-top: 1px solid #ddd;
            display: flex;
            gap: 10px;
            background: white;
        }
        
        .gp-simple-chat-input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
        }
        
        .gp-simple-chat-send {
            background: #0084FF;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }
        
        .gp-simple-chat-send:hover {
            background: #0056CC;
        }
        
        @media (max-width: 768px) {
            .gp-simple-chat-window {
                width: calc(100% - 40px);
                height: calc(100vh - 150px);
                left: 20px;
                right: 20px;
            }
        }
        </style>
        
        <!-- Botón Chat -->
        <div class="gp-simple-chat-button" onclick="gpToggleSimpleChat()">
            <svg viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12c0 1.54.36 3 .97 4.29L2 22l5.71-.97C9 21.64 10.46 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.38 0-2.67-.33-3.82-.91L4 20l.91-4.18C4.33 14.67 4 13.38 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8z"/>
                <circle cx="8.5" cy="12" r="1.5"/>
                <circle cx="12" cy="12" r="1.5"/>
                <circle cx="15.5" cy="12" r="1.5"/>
            </svg>
        </div>
        
        <!-- Ventana Chat -->
        <div class="gp-simple-chat-window" id="gp-simple-chat">
            <div class="gp-simple-chat-header">
                <div>
                    <h4 style="margin: 0; font-size: 18px;">💬 Chat en Vivo</h4>
                    <small style="opacity: 0.9; font-size: 13px;">Responderemos pronto</small>
                </div>
                <button class="gp-simple-chat-close" onclick="gpToggleSimpleChat()">×</button>
            </div>
            
            <div class="gp-simple-chat-messages" id="gp-simple-chat-messages">
                <div class="gp-simple-chat-message agent">
                    👋 ¡Hola! ¿En qué podemos ayudarte hoy?
                </div>
            </div>
            
            <div class="gp-simple-chat-input-area">
                <input type="text" 
                       class="gp-simple-chat-input" 
                       id="gp-simple-chat-input"
                       placeholder="Escribe tu mensaje..."
                       onkeypress="if(event.key==='Enter') gpSendSimpleMessage()">
                <button class="gp-simple-chat-send" onclick="gpSendSimpleMessage()">
                    Enviar
                </button>
            </div>
        </div>
        
        <script>
        function gpToggleSimpleChat() {
            var chat = document.getElementById('gp-simple-chat');
            chat.classList.toggle('active');
            
            if (chat.classList.contains('active')) {
                document.getElementById('gp-simple-chat-input').focus();
            }
        }
        
        function gpSendSimpleMessage() {
            var input = document.getElementById('gp-simple-chat-input');
            var message = input.value.trim();
            
            if (!message) return;
            
            var messagesDiv = document.getElementById('gp-simple-chat-messages');
            
            // Agregar mensaje del usuario
            var userMsg = document.createElement('div');
            userMsg.className = 'gp-simple-chat-message user';
            userMsg.textContent = message;
            messagesDiv.appendChild(userMsg);
            
            input.value = '';
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
            
            // Respuesta automática
            setTimeout(function() {
                var agentMsg = document.createElement('div');
                agentMsg.className = 'gp-simple-chat-message agent';
                agentMsg.textContent = 'Gracias por tu mensaje. Un agente te responderá pronto. 😊';
                messagesDiv.appendChild(agentMsg);
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }, 1000);
        }
        </script>
        
        <?php
    }
}

GP_Simple_Chat::init();

// ========================================
// LIMPIAR ERRORES DE BASE DE DATOS
// ========================================

add_action('admin_init', 'gp_v77_suppress_db_errors');

function gp_v77_suppress_db_errors() {
    global $wpdb;
    $wpdb->suppress_errors = true;
}

// ========================================
// ADMIN NOTICE - NUEVO CHAT
// ========================================

add_action('admin_notices', 'gp_v77_new_chat_notice');

function gp_v77_new_chat_notice() {
    if (get_option('gp_v77_chat_notice_shown')) {
        return;
    }
    
    $screen = get_current_screen();
    if ($screen->id !== 'dashboard') {
        return;
    }
    ?>
    
    <div class="notice notice-success is-dismissible">
        <h3>✅ Golden Phoenix V77 - Nuevo Sistema Chat</h3>
        <p><strong>Cambios importantes:</strong></p>
        <ul style="list-style: disc; margin-left: 20px;">
            <li>❌ Chat antiguo eliminado (causaba errores DB)</li>
            <li>✅ Nuevo chat simple sin base de datos</li>
            <li>✅ 100% funcional</li>
            <li>✅ Sin errores</li>
            <li>🔵 Botón azul izquierda + 🟢 WhatsApp derecha</li>
        </ul>
        <p>
            <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_v77'}); return false;" class="button button-primary">
                Entendido
            </a>
        </p>
    </div>
    
    <?php
    update_option('gp_v77_chat_notice_shown', true);
}

add_action('wp_ajax_gp_dismiss_v77', function() {
    update_option('gp_v77_chat_notice_shown', true);
    wp_die();
});
