<?php
/**
 * Golden Phoenix Jewelry - Funciones Avanzadas
 * Integraciones: n8n, APIs, Chat, Membresías, Pasarelas de Pago
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// N8N WEBHOOK INTEGRATION
// ============================================

/**
 * Configuración de Webhooks n8n
 */
class GoldenPhoenix_N8N_Integration {
    
    private $webhook_url;
    
    public function __construct() {
        $this->webhook_url = get_option('gp_n8n_webhook_url', '');
        
        // Hooks para eventos de WooCommerce
        add_action('woocommerce_new_order', array($this, 'send_new_order_webhook'), 10, 1);
        add_action('woocommerce_order_status_changed', array($this, 'send_order_status_webhook'), 10, 3);
        add_action('woocommerce_payment_complete', array($this, 'send_payment_complete_webhook'), 10, 1);
        
        // Hooks para usuarios
        add_action('user_register', array($this, 'send_new_user_webhook'), 10, 1);
        add_action('wp_login', array($this, 'send_user_login_webhook'), 10, 2);
        
        // Hooks para productos
        add_action('save_post_product', array($this, 'send_product_update_webhook'), 10, 3);
        
        // Hook para formularios de contacto
        add_action('wpcf7_mail_sent', array($this, 'send_contact_form_webhook'));
        
        // Hook para newsletter
        add_action('gp_newsletter_subscribe', array($this, 'send_newsletter_webhook'), 10, 1);
    }
    
    /**
     * Enviar datos a n8n webhook
     */
    private function send_to_n8n($event_type, $data) {
        if (empty($this->webhook_url)) {
            return false;
        }
        
        $payload = array(
            'event' => $event_type,
            'timestamp' => current_time('mysql'),
            'site_url' => get_site_url(),
            'data' => $data
        );
        
        $response = wp_remote_post($this->webhook_url, array(
            'method' => 'POST',
            'timeout' => 10,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($payload)
        ));
        
        if (is_wp_error($response)) {
            error_log('n8n webhook error: ' . $response->get_error_message());
            return false;
        }
        
        return true;
    }
    
    /**
     * Nueva orden
     */
    public function send_new_order_webhook($order_id) {
        $order = wc_get_order($order_id);
        
        $data = array(
            'order_id' => $order_id,
            'order_number' => $order->get_order_number(),
            'total' => $order->get_total(),
            'currency' => $order->get_currency(),
            'status' => $order->get_status(),
            'customer' => array(
                'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'email' => $order->get_billing_email(),
                'phone' => $order->get_billing_phone(),
            ),
            'items' => array(),
        );
        
        foreach ($order->get_items() as $item) {
            $data['items'][] = array(
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'total' => $item->get_total(),
            );
        }
        
        $this->send_to_n8n('new_order', $data);
    }
    
    /**
     * Cambio de estado de orden
     */
    public function send_order_status_webhook($order_id, $old_status, $new_status) {
        $order = wc_get_order($order_id);
        
        $data = array(
            'order_id' => $order_id,
            'order_number' => $order->get_order_number(),
            'old_status' => $old_status,
            'new_status' => $new_status,
            'customer_email' => $order->get_billing_email(),
        );
        
        $this->send_to_n8n('order_status_changed', $data);
    }
    
    /**
     * Pago completado
     */
    public function send_payment_complete_webhook($order_id) {
        $order = wc_get_order($order_id);
        
        $data = array(
            'order_id' => $order_id,
            'total' => $order->get_total(),
            'payment_method' => $order->get_payment_method_title(),
            'customer_email' => $order->get_billing_email(),
        );
        
        $this->send_to_n8n('payment_complete', $data);
    }
    
    /**
     * Nuevo usuario
     */
    public function send_new_user_webhook($user_id) {
        $user = get_userdata($user_id);
        
        $data = array(
            'user_id' => $user_id,
            'username' => $user->user_login,
            'email' => $user->user_email,
            'display_name' => $user->display_name,
            'roles' => $user->roles,
        );
        
        $this->send_to_n8n('new_user', $data);
    }
    
    /**
     * Login de usuario
     */
    public function send_user_login_webhook($user_login, $user) {
        $data = array(
            'user_id' => $user->ID,
            'username' => $user_login,
            'email' => $user->user_email,
        );
        
        $this->send_to_n8n('user_login', $data);
    }
    
    /**
     * Actualización de producto
     */
    public function send_product_update_webhook($post_id, $post, $update) {
        if ($post->post_status !== 'publish') {
            return;
        }
        
        $product = wc_get_product($post_id);
        
        $data = array(
            'product_id' => $post_id,
            'product_name' => $product->get_name(),
            'price' => $product->get_price(),
            'stock_status' => $product->get_stock_status(),
            'is_update' => $update,
        );
        
        $this->send_to_n8n($update ? 'product_updated' : 'product_created', $data);
    }
    
    /**
     * Formulario de contacto
     */
    public function send_contact_form_webhook($contact_form) {
        $submission = WPCF7_Submission::get_instance();
        
        if ($submission) {
            $data = $submission->get_posted_data();
            $this->send_to_n8n('contact_form_submit', $data);
        }
    }
    
    /**
     * Newsletter subscribe
     */
    public function send_newsletter_webhook($email) {
        $data = array(
            'email' => $email,
            'source' => 'website_newsletter',
        );
        
        $this->send_to_n8n('newsletter_subscribe', $data);
    }
}

// Inicializar integración n8n
new GoldenPhoenix_N8N_Integration();

// ============================================
// REST API ENDPOINTS PERSONALIZADOS
// ============================================

/**
 * Registrar endpoints REST API personalizados
 */
add_action('rest_api_init', function() {
    
    // Endpoint: Productos destacados
    register_rest_route('golden-phoenix/v1', '/featured-products', array(
        'methods' => 'GET',
        'callback' => 'gp_get_featured_products',
        'permission_callback' => '__return_true'
    ));
    
    // Endpoint: Colecciones
    register_rest_route('golden-phoenix/v1', '/collections', array(
        'methods' => 'GET',
        'callback' => 'gp_get_collections',
        'permission_callback' => '__return_true'
    ));
    
    // Endpoint: Testimonios
    register_rest_route('golden-phoenix/v1', '/testimonials', array(
        'methods' => 'GET',
        'callback' => 'gp_get_testimonials',
        'permission_callback' => '__return_true'
    ));
    
    // Endpoint: Estadísticas de la tienda
    register_rest_route('golden-phoenix/v1', '/stats', array(
        'methods' => 'GET',
        'callback' => 'gp_get_shop_stats',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // Endpoint: Suscripción a newsletter
    register_rest_route('golden-phoenix/v1', '/newsletter', array(
        'methods' => 'POST',
        'callback' => 'gp_newsletter_subscribe_api',
        'permission_callback' => '__return_true'
    ));
    
    // Endpoint: Wishlist
    register_rest_route('golden-phoenix/v1', '/wishlist', array(
        'methods' => 'GET',
        'callback' => 'gp_get_wishlist',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    register_rest_route('golden-phoenix/v1', '/wishlist/add', array(
        'methods' => 'POST',
        'callback' => 'gp_add_to_wishlist',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    register_rest_route('golden-phoenix/v1', '/wishlist/remove', array(
        'methods' => 'POST',
        'callback' => 'gp_remove_from_wishlist',
        'permission_callback' => 'is_user_logged_in'
    ));
});

/**
 * Obtener productos destacados
 */
function gp_get_featured_products($request) {
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $request->get_param('limit') ?: 8,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_visibility',
                'field' => 'name',
                'terms' => 'featured',
            )
        )
    );
    
    $products = array();
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            
            $products[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'price' => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price' => $product->get_sale_price(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
                'link' => get_permalink(),
                'in_stock' => $product->is_in_stock(),
            );
        }
        wp_reset_postdata();
    }
    
    return new WP_REST_Response($products, 200);
}

/**
 * Obtener colecciones
 */
function gp_get_collections($request) {
    $args = array(
        'post_type' => 'collection',
        'posts_per_page' => $request->get_param('limit') ?: -1,
        'post_status' => 'publish'
    );
    
    $collections = array();
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $collections[] = array(
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'description' => get_the_excerpt(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
                'pieces_count' => get_post_meta(get_the_ID(), '_collection_pieces_count', true),
                'featured' => get_post_meta(get_the_ID(), '_collection_featured', true),
            );
        }
        wp_reset_postdata();
    }
    
    return new WP_REST_Response($collections, 200);
}

/**
 * Obtener testimonios
 */
function gp_get_testimonials($request) {
    $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => $request->get_param('limit') ?: -1,
        'post_status' => 'publish'
    );
    
    $testimonials = array();
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $testimonials[] = array(
                'id' => get_the_ID(),
                'content' => get_the_content(),
                'author' => get_the_title(),
                'author_title' => get_post_meta(get_the_ID(), '_testimonial_author_title', true),
                'rating' => get_post_meta(get_the_ID(), '_testimonial_rating', true),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'),
            );
        }
        wp_reset_postdata();
    }
    
    return new WP_REST_Response($testimonials, 200);
}

/**
 * Obtener estadísticas
 */
function gp_get_shop_stats() {
    $stats = array(
        'total_products' => wp_count_posts('product')->publish,
        'total_orders' => wp_count_posts('shop_order')->wc_processing + wp_count_posts('shop_order')->wc_completed,
        'total_customers' => count_users()['total_users'],
        'total_revenue' => gp_calculate_total_revenue(),
    );
    
    return new WP_REST_Response($stats, 200);
}

function gp_calculate_total_revenue() {
    global $wpdb;
    
    $result = $wpdb->get_var("
        SELECT SUM(meta_value) 
        FROM {$wpdb->postmeta} 
        WHERE meta_key = '_order_total'
    ");
    
    return floatval($result);
}

/**
 * Verificar permisos de administrador
 */
function gp_check_admin_permission() {
    return current_user_can('manage_options');
}

/**
 * API Newsletter subscribe
 */
function gp_newsletter_subscribe_api($request) {
    $email = sanitize_email($request->get_param('email'));
    
    if (!is_email($email)) {
        return new WP_Error('invalid_email', 'Email inválido', array('status' => 400));
    }
    
    global $wpdb;
    $table_name = $wpdb->prefix . 'newsletter_subscribers';
    
    $result = $wpdb->insert(
        $table_name,
        array(
            'email' => $email,
            'subscribe_date' => current_time('mysql'),
            'status' => 'active'
        )
    );
    
    if ($result) {
        // Trigger n8n webhook
        do_action('gp_newsletter_subscribe', $email);
        
        return new WP_REST_Response(array(
            'success' => true,
            'message' => '¡Gracias por suscribirte!'
        ), 200);
    }
    
    return new WP_Error('subscription_failed', 'Error al suscribirse', array('status' => 500));
}

/**
 * Wishlist API
 */
function gp_get_wishlist($request) {
    $user_id = get_current_user_id();
    $wishlist = get_user_meta($user_id, 'gp_wishlist', true);
    
    if (!$wishlist) {
        $wishlist = array();
    }
    
    $products = array();
    foreach ($wishlist as $product_id) {
        $product = wc_get_product($product_id);
        if ($product) {
            $products[] = array(
                'id' => $product_id,
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'image' => wp_get_attachment_url($product->get_image_id()),
                'link' => get_permalink($product_id),
            );
        }
    }
    
    return new WP_REST_Response($products, 200);
}

function gp_add_to_wishlist($request) {
    $user_id = get_current_user_id();
    $product_id = intval($request->get_param('product_id'));
    
    $wishlist = get_user_meta($user_id, 'gp_wishlist', true);
    if (!$wishlist) {
        $wishlist = array();
    }
    
    if (!in_array($product_id, $wishlist)) {
        $wishlist[] = $product_id;
        update_user_meta($user_id, 'gp_wishlist', $wishlist);
    }
    
    return new WP_REST_Response(array('success' => true), 200);
}

function gp_remove_from_wishlist($request) {
    $user_id = get_current_user_id();
    $product_id = intval($request->get_param('product_id'));
    
    $wishlist = get_user_meta($user_id, 'gp_wishlist', true);
    if (!$wishlist) {
        $wishlist = array();
    }
    
    $wishlist = array_diff($wishlist, array($product_id));
    update_user_meta($user_id, 'gp_wishlist', $wishlist);
    
    return new WP_REST_Response(array('success' => true), 200);
}

// ============================================
// SOPORTE PARA MÚLTIPLES PASARELAS DE PAGO
// ============================================

/**
 * Agregar soporte para pasarelas de pago adicionales
 */
add_filter('woocommerce_payment_gateways', 'gp_add_payment_gateways');

function gp_add_payment_gateways($gateways) {
    // Las pasarelas se agregan mediante plugins, pero configuramos el soporte
    
    // Asegurar compatibilidad con:
    // - Stripe
    // - PayPal
    // - MercadoPago
    // - Authorize.net
    // - Square
    // - PayU
    // - Conekta (México)
    // - Transferencia bancaria
    // - Pago contra entrega
    
    return $gateways;
}

/**
 * Personalizar opciones de pago
 */
add_filter('woocommerce_available_payment_gateways', 'gp_customize_payment_gateways');

function gp_customize_payment_gateways($gateways) {
    // Aquí puedes personalizar qué pasarelas mostrar según condiciones
    // Por ejemplo, solo mostrar ciertas pasarelas para pedidos grandes
    
    if (is_checkout() && WC()->cart) {
        $cart_total = WC()->cart->get_total('');
        
        // Ejemplo: Ocultar pago contra entrega para pedidos > $10,000
        if ($cart_total > 10000 && isset($gateways['cod'])) {
            unset($gateways['cod']);
        }
    }
    
    return $gateways;
}

// ============================================
// SISTEMA DE MEMBRESÍAS
// ============================================

/**
 * Crear niveles de membresía personalizados
 */
function gp_create_membership_levels() {
    // Compatibility con plugins de membresía como:
    // - WooCommerce Memberships
    // - Paid Memberships Pro
    // - MemberPress
    // - Restrict Content Pro
    
    // Niveles sugeridos:
    $membership_levels = array(
        'vip_gold' => array(
            'name' => 'VIP Gold',
            'price' => 99.00,
            'benefits' => array(
                '15% descuento en todos los productos',
                'Acceso anticipado a nuevas colecciones',
                'Envío gratis en todos los pedidos',
                'Consultoría de estilo personalizada',
                'Eventos exclusivos'
            )
        ),
        'vip_platinum' => array(
            'name' => 'VIP Platinum',
            'price' => 199.00,
            'benefits' => array(
                '25% descuento en todos los productos',
                'Diseño de joyas personalizado',
                'Atención prioritaria 24/7',
                'Todas las ventajas VIP Gold',
                'Limpieza y mantenimiento gratis'
            )
        ),
        'collector' => array(
            'name' => 'Collector',
            'price' => 499.00,
            'benefits' => array(
                '35% descuento en todos los productos',
                'Acceso a piezas únicas de colección',
                'Invitaciones a subastas privadas',
                'Todas las ventajas VIP Platinum',
                'Asesoría de inversión en joyas'
            )
        )
    );
    
    return $membership_levels;
}

// Guardar niveles de membresía
add_action('init', function() {
    update_option('gp_membership_levels', gp_create_membership_levels());
});

/**
 * Aplicar descuentos de membresía
 */
add_filter('woocommerce_product_get_price', 'gp_apply_membership_discount', 10, 2);
add_filter('woocommerce_product_variation_get_price', 'gp_apply_membership_discount', 10, 2);

function gp_apply_membership_discount($price, $product) {
    if (!is_user_logged_in()) {
        return $price;
    }
    
    $user_id = get_current_user_id();
    $membership = get_user_meta($user_id, 'gp_membership_level', true);
    
    $discounts = array(
        'vip_gold' => 0.15,      // 15%
        'vip_platinum' => 0.25,  // 25%
        'collector' => 0.35      // 35%
    );
    
    if (isset($discounts[$membership])) {
        $price = $price * (1 - $discounts[$membership]);
    }
    
    return $price;
}

/**
 * Mostrar badge de membresía
 */
add_action('woocommerce_before_account_navigation', 'gp_show_membership_badge');

function gp_show_membership_badge() {
    if (!is_user_logged_in()) {
        return;
    }
    
    $user_id = get_current_user_id();
    $membership = get_user_meta($user_id, 'gp_membership_level', true);
    
    if ($membership) {
        $levels = get_option('gp_membership_levels');
        if (isset($levels[$membership])) {
            echo '<div class="membership-badge ' . esc_attr($membership) . '">';
            echo '<h3>Miembro ' . esc_html($levels[$membership]['name']) . '</h3>';
            echo '</div>';
        }
    }
}

// ============================================
// CONFIGURACIÓN DE CHAT EN VIVO
// ============================================

/**
 * Integración con sistemas de chat
 * Compatible con:
 * - Tawk.to
 * - LiveChat
 * - Zendesk Chat
 * - Intercom
 * - Tidio
 * - WhatsApp Business
 */

add_action('wp_footer', 'gp_add_chat_widget');

function gp_add_chat_widget() {
    $chat_enabled = get_option('gp_chat_enabled', true);
    $chat_provider = get_option('gp_chat_provider', 'tawk');
    $chat_id = get_option('gp_chat_id', '');
    
    if (!$chat_enabled || empty($chat_id)) {
        return;
    }
    
    switch ($chat_provider) {
        case 'tawk':
            echo gp_get_tawk_script($chat_id);
            break;
        case 'livechat':
            echo gp_get_livechat_script($chat_id);
            break;
        case 'whatsapp':
            echo gp_get_whatsapp_button($chat_id);
            break;
        case 'tidio':
            echo gp_get_tidio_script($chat_id);
            break;
    }
}

function gp_get_tawk_script($property_id) {
    return "
    <script type='text/javascript'>
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement('script'),s0=document.getElementsByTagName('script')[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/{$property_id}';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    ";
}

function gp_get_whatsapp_button($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    $message = urlencode('Hola, tengo una consulta sobre sus joyas...');
    
    return "
    <a href='https://wa.me/{$phone}?text={$message}' class='whatsapp-float' target='_blank' aria-label='Contactar por WhatsApp'>
        <i class='fab fa-whatsapp'></i>
    </a>
    <style>
    .whatsapp-float {
        position: fixed;
        bottom: 100px;
        right: 20px;
        width: 60px;
        height: 60px;
        background: #25D366;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 30px;
        z-index: 9999;
        box-shadow: 0 4px 20px rgba(37, 211, 102, 0.5);
        transition: all 0.3s ease;
    }
    .whatsapp-float:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 30px rgba(37, 211, 102, 0.7);
    }
    </style>
    ";
}

function gp_get_livechat_script($license) {
    return "
    <script>
    window.__lc = window.__lc || {};
    window.__lc.license = {$license};
    ;(function(n,t,c){function i(n){return e._h?e._h.apply(null,n):e._q.push(n)}var e={_q:[],_h:null,_v:'2.0',on:function(){i(['on',c.call(arguments)])},once:function(){i(['once',c.call(arguments)])},off:function(){i(['off',c.call(arguments)])},get:function(){if(!e._h)throw new Error('[LiveChatWidget] You can\\'t use getters before load.');return i(['get',c.call(arguments)])},call:function(){i(['call',c.call(arguments)])},init:function(){var n=t.createElement('script');n.async=!0,n.type='text/javascript',n.src='https://cdn.livechatinc.com/tracking.js',t.head.appendChild(n)}};!n.__lc.asyncInit&&e.init(),n.LiveChatWidget=n.LiveChatWidget||e}(window,document,[].slice))
    </script>
    ";
}

function gp_get_tidio_script($tidio_key) {
    return "
    <script src='//code.tidio.co/{$tidio_key}.js' async></script>
    ";
}

// ============================================
// PÁGINA DE ADMINISTRACIÓN DE INTEGRACIONES
// ============================================

add_action('admin_menu', 'gp_add_integrations_page');

function gp_add_integrations_page() {
    add_menu_page(
        'Integraciones Golden Phoenix',
        'Integraciones',
        'manage_options',
        'gp-integrations',
        'gp_integrations_page',
        'dashicons-admin-generic',
        30
    );
}

function gp_integrations_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Guardar configuración
    if (isset($_POST['gp_save_integrations'])) {
        check_admin_referer('gp_integrations_nonce');
        
        update_option('gp_n8n_webhook_url', sanitize_text_field($_POST['n8n_webhook_url']));
        update_option('gp_chat_enabled', isset($_POST['chat_enabled']) ? 1 : 0);
        update_option('gp_chat_provider', sanitize_text_field($_POST['chat_provider']));
        update_option('gp_chat_id', sanitize_text_field($_POST['chat_id']));
        
        echo '<div class="notice notice-success"><p>Configuración guardada correctamente.</p></div>';
    }
    
    $n8n_url = get_option('gp_n8n_webhook_url', '');
    $chat_enabled = get_option('gp_chat_enabled', 1);
    $chat_provider = get_option('gp_chat_provider', 'tawk');
    $chat_id = get_option('gp_chat_id', '');
    
    ?>
    <div class="wrap">
        <h1>⚡ Integraciones Golden Phoenix Jewelry</h1>
        
        <form method="post" action="">
            <?php wp_nonce_field('gp_integrations_nonce'); ?>
            
            <h2>🔗 Integración n8n</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="n8n_webhook_url">URL del Webhook n8n</label></th>
                    <td>
                        <input type="url" id="n8n_webhook_url" name="n8n_webhook_url" value="<?php echo esc_attr($n8n_url); ?>" class="regular-text" placeholder="https://tu-instancia.n8n.cloud/webhook/...">
                        <p class="description">Eventos enviados: nuevas órdenes, cambios de estado, nuevos usuarios, productos actualizados, formularios de contacto, newsletter.</p>
                    </td>
                </tr>
            </table>
            
            <h2>💬 Chat en Vivo</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="chat_enabled">Habilitar Chat</label></th>
                    <td>
                        <input type="checkbox" id="chat_enabled" name="chat_enabled" value="1" <?php checked($chat_enabled, 1); ?>>
                        <label for="chat_enabled">Mostrar widget de chat en el sitio</label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="chat_provider">Proveedor de Chat</label></th>
                    <td>
                        <select id="chat_provider" name="chat_provider">
                            <option value="tawk" <?php selected($chat_provider, 'tawk'); ?>>Tawk.to</option>
                            <option value="livechat" <?php selected($chat_provider, 'livechat'); ?>>LiveChat</option>
                            <option value="whatsapp" <?php selected($chat_provider, 'whatsapp'); ?>>WhatsApp Business</option>
                            <option value="tidio" <?php selected($chat_provider, 'tidio'); ?>>Tidio</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="chat_id">ID/Teléfono del Chat</label></th>
                    <td>
                        <input type="text" id="chat_id" name="chat_id" value="<?php echo esc_attr($chat_id); ?>" class="regular-text">
                        <p class="description">Para Tawk.to: Property ID | Para WhatsApp: número con código de país (ej: 5215512345678) | Para LiveChat: License ID | Para Tidio: Public Key</p>
                    </td>
                </tr>
            </table>
            
            <h2>📊 APIs Disponibles</h2>
            <table class="form-table">
                <tr>
                    <td colspan="2">
                        <p><strong>Endpoints REST API disponibles:</strong></p>
                        <ul style="list-style: disc; margin-left: 20px;">
                            <li><code>/wp-json/golden-phoenix/v1/featured-products</code> - Productos destacados</li>
                            <li><code>/wp-json/golden-phoenix/v1/collections</code> - Colecciones</li>
                            <li><code>/wp-json/golden-phoenix/v1/testimonials</code> - Testimonios</li>
                            <li><code>/wp-json/golden-phoenix/v1/stats</code> - Estadísticas (requiere autenticación)</li>
                            <li><code>/wp-json/golden-phoenix/v1/newsletter</code> (POST) - Suscripción newsletter</li>
                            <li><code>/wp-json/golden-phoenix/v1/wishlist</code> - Lista de deseos del usuario</li>
                            <li><code>/wp-json/golden-phoenix/v1/wishlist/add</code> (POST) - Agregar a wishlist</li>
                            <li><code>/wp-json/golden-phoenix/v1/wishlist/remove</code> (POST) - Remover de wishlist</li>
                        </ul>
                        <p><a href="<?php echo rest_url('golden-phoenix/v1/'); ?>" target="_blank" class="button">Ver API</a></p>
                    </td>
                </tr>
            </table>
            
            <h2>💳 Pasarelas de Pago Soportadas</h2>
            <table class="form-table">
                <tr>
                    <td colspan="2">
                        <p>El tema es compatible con todas las pasarelas de pago de WooCommerce:</p>
                        <ul style="list-style: disc; margin-left: 20px;">
                            <li>✅ Stripe</li>
                            <li>✅ PayPal</li>
                            <li>✅ MercadoPago</li>
                            <li>✅ Authorize.net</li>
                            <li>✅ Square</li>
                            <li>✅ PayU</li>
                            <li>✅ Conekta (México)</li>
                            <li>✅ Transferencia bancaria</li>
                            <li>✅ Pago contra entrega</li>
                            <li>✅ Cualquier gateway compatible con WooCommerce</li>
                        </ul>
                        <p><a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout'); ?>" class="button">Configurar Pasarelas</a></p>
                    </td>
                </tr>
            </table>
            
            <h2>👥 Sistema de Membresías</h2>
            <table class="form-table">
                <tr>
                    <td colspan="2">
                        <p>Niveles de membresía preconfigurados:</p>
                        <ul style="list-style: disc; margin-left: 20px;">
                            <li><strong>VIP Gold</strong> - 15% descuento + beneficios</li>
                            <li><strong>VIP Platinum</strong> - 25% descuento + beneficios premium</li>
                            <li><strong>Collector</strong> - 35% descuento + acceso exclusivo</li>
                        </ul>
                        <p>Compatible con plugins: WooCommerce Memberships, Paid Memberships Pro, MemberPress</p>
                    </td>
                </tr>
            </table>
            
            <?php submit_button('Guardar Configuración', 'primary', 'gp_save_integrations'); ?>
        </form>
    </div>
    <?php
}
