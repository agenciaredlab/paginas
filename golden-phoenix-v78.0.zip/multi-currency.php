<?php
/**
 * Golden Phoenix V71 - MULTI-CURRENCY
 * Soporte para múltiples monedas con conversión automática
 */

if (!defined('ABSPATH')) exit;

// ========================================
// CONFIGURACIÓN MONEDAS
// ========================================

class GP_Multi_Currency {
    
    private static $currencies = array(
        'USD' => array(
            'name' => 'Dólar Estadounidense',
            'symbol' => '$',
            'rate' => 1, // Base
            'position' => 'left',
        ),
        'COP' => array(
            'name' => 'Peso Colombiano',
            'symbol' => '$',
            'rate' => 4000, // 1 USD = 4000 COP (editable)
            'position' => 'left',
            'thousands_sep' => '.',
            'decimal_sep' => ',',
            'decimals' => 0,
        ),
        'EUR' => array(
            'name' => 'Euro',
            'symbol' => '€',
            'rate' => 0.92, // 1 USD = 0.92 EUR
            'position' => 'right',
        ),
        'MXN' => array(
            'name' => 'Peso Mexicano',
            'symbol' => '$',
            'rate' => 17, // 1 USD = 17 MXN
            'position' => 'left',
        ),
        'BRL' => array(
            'name' => 'Real Brasileño',
            'symbol' => 'R$',
            'rate' => 5, // 1 USD = 5 BRL
            'position' => 'left',
        ),
    );
    
    public static function get_currencies() {
        // Permitir personalizar tasas desde opciones
        $saved_rates = get_option('gp_currency_rates', array());
        $currencies = self::$currencies;
        
        foreach ($saved_rates as $code => $rate) {
            if (isset($currencies[$code])) {
                $currencies[$code]['rate'] = floatval($rate);
            }
        }
        
        return $currencies;
    }
    
    public static function get_current_currency() {
        // 1. Cookie
        if (isset($_COOKIE['gp_currency'])) {
            return sanitize_text_field($_COOKIE['gp_currency']);
        }
        
        // 2. Sesión
        if (isset($_SESSION['gp_currency'])) {
            return sanitize_text_field($_SESSION['gp_currency']);
        }
        
        // 3. Default (COP para Colombia)
        return get_option('gp_default_currency', 'COP');
    }
    
    public static function set_currency($currency_code) {
        $currencies = self::get_currencies();
        
        if (!isset($currencies[$currency_code])) {
            return false;
        }
        
        // Guardar en cookie (30 días)
        setcookie('gp_currency', $currency_code, time() + (30 * DAY_IN_SECONDS), '/');
        
        // Guardar en sesión
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['gp_currency'] = $currency_code;
        
        return true;
    }
    
    public static function convert_price($price, $from = 'USD', $to = null) {
        if ($to === null) {
            $to = self::get_current_currency();
        }
        
        $currencies = self::get_currencies();
        
        if (!isset($currencies[$from]) || !isset($currencies[$to])) {
            return $price;
        }
        
        // Convertir a USD primero
        $usd_price = $price / $currencies[$from]['rate'];
        
        // Luego a moneda destino
        $converted = $usd_price * $currencies[$to]['rate'];
        
        return $converted;
    }
    
    public static function format_price($price, $currency = null) {
        if ($currency === null) {
            $currency = self::get_current_currency();
        }
        
        $currencies = self::get_currencies();
        
        if (!isset($currencies[$currency])) {
            return wc_price($price);
        }
        
        $curr = $currencies[$currency];
        $symbol = $curr['symbol'];
        $decimals = isset($curr['decimals']) ? $curr['decimals'] : 2;
        $dec_sep = isset($curr['decimal_sep']) ? $curr['decimal_sep'] : '.';
        $thousands_sep = isset($curr['thousands_sep']) ? $curr['thousands_sep'] : ',';
        
        $formatted = number_format($price, $decimals, $dec_sep, $thousands_sep);
        
        if ($curr['position'] === 'left') {
            return $symbol . $formatted;
        } else {
            return $formatted . ' ' . $symbol;
        }
    }
}

// ========================================
// FILTROS WOOCOMMERCE
// ========================================

// Modificar precio mostrado
add_filter('woocommerce_get_price_html', 'gp_multi_currency_price_html', 10, 2);

function gp_multi_currency_price_html($price_html, $product) {
    $price = $product->get_price();
    
    if (empty($price)) {
        return $price_html;
    }
    
    $converted = GP_Multi_Currency::convert_price($price);
    $formatted = GP_Multi_Currency::format_price($converted);
    
    return $formatted;
}

// Modificar precio en carrito
add_filter('woocommerce_cart_item_price', 'gp_multi_currency_cart_price', 10, 3);

function gp_multi_currency_cart_price($price_html, $cart_item, $cart_item_key) {
    $product = $cart_item['data'];
    $price = $product->get_price();
    
    $converted = GP_Multi_Currency::convert_price($price);
    $formatted = GP_Multi_Currency::format_price($converted);
    
    return $formatted;
}

// Modificar subtotal carrito
add_filter('woocommerce_cart_item_subtotal', 'gp_multi_currency_cart_subtotal', 10, 3);

function gp_multi_currency_cart_subtotal($subtotal, $cart_item, $cart_item_key) {
    $product = $cart_item['data'];
    $quantity = $cart_item['quantity'];
    $price = $product->get_price();
    
    $converted = GP_Multi_Currency::convert_price($price);
    $total = $converted * $quantity;
    $formatted = GP_Multi_Currency::format_price($total);
    
    return $formatted;
}

// ========================================
// SELECTOR DE MONEDA
// ========================================

add_action('wp_footer', 'gp_currency_selector');

function gp_currency_selector() {
    $currencies = GP_Multi_Currency::get_currencies();
    $current = GP_Multi_Currency::get_current_currency();
    ?>
    
    <div class="gp-currency-selector" style="
        position: fixed;
        top: 100px;
        right: 20px;
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 9998;
    ">
        <label style="display: block; margin-bottom: 8px; font-weight: 600; font-size: 12px;">
            💱 MONEDA:
        </label>
        <select id="gp-currency-select" style="
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        ">
            <?php foreach ($currencies as $code => $curr): ?>
                <option value="<?php echo esc_attr($code); ?>" <?php selected($current, $code); ?>>
                    <?php echo esc_html($curr['symbol'] . ' ' . $code . ' - ' . $curr['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#gp-currency-select').on('change', function() {
            var currency = $(this).val();
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'gp_change_currency',
                    currency: currency,
                    nonce: '<?php echo wp_create_nonce('gp_currency_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                }
            });
        });
    });
    </script>
    
    <?php
}

// AJAX para cambiar moneda
add_action('wp_ajax_gp_change_currency', 'gp_ajax_change_currency');
add_action('wp_ajax_nopriv_gp_change_currency', 'gp_ajax_change_currency');

function gp_ajax_change_currency() {
    check_ajax_referer('gp_currency_nonce', 'nonce');
    
    $currency = sanitize_text_field($_POST['currency']);
    
    if (GP_Multi_Currency::set_currency($currency)) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
}

// ========================================
// ADMIN: CONFIGURAR TASAS
// ========================================

add_action('admin_menu', 'gp_currency_admin_menu');

function gp_currency_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Multi-Currency',
        'Multi-Currency',
        'manage_woocommerce',
        'gp-multi-currency',
        'gp_currency_admin_page'
    );
}

function gp_currency_admin_page() {
    if (isset($_POST['gp_save_rates']) && check_admin_referer('gp_currency_rates')) {
        $rates = array();
        foreach ($_POST['rate'] as $code => $rate) {
            $rates[$code] = floatval($rate);
        }
        update_option('gp_currency_rates', $rates);
        echo '<div class="notice notice-success"><p>Tasas actualizadas</p></div>';
    }
    
    $currencies = GP_Multi_Currency::get_currencies();
    ?>
    
    <div class="wrap">
        <h1>Multi-Currency - Configuración</h1>
        
        <form method="post">
            <?php wp_nonce_field('gp_currency_rates'); ?>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Moneda</th>
                        <th>Símbolo</th>
                        <th>Tasa de Cambio (1 USD = X)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($currencies as $code => $curr): ?>
                    <tr>
                        <td><strong><?php echo esc_html($code . ' - ' . $curr['name']); ?></strong></td>
                        <td><?php echo esc_html($curr['symbol']); ?></td>
                        <td>
                            <input type="number" 
                                   name="rate[<?php echo esc_attr($code); ?>]" 
                                   value="<?php echo esc_attr($curr['rate']); ?>" 
                                   step="0.01"
                                   style="width: 150px;">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <p class="submit">
                <button type="submit" name="gp_save_rates" class="button button-primary">
                    Guardar Tasas
                </button>
            </p>
        </form>
        
        <hr>
        
        <h2>💡 Cómo obtener tasas actuales:</h2>
        <ul>
            <li>Google: "usd to cop" para tasa USD → COP</li>
            <li>API recomendada: <a href="https://exchangerate-api.com" target="_blank">exchangerate-api.com</a></li>
            <li>Actualizar manualmente o usar plugin de tasas automáticas</li>
        </ul>
    </div>
    
    <?php
}

// ========================================
// SHORTCODE SELECTOR
// ========================================

add_shortcode('currency_selector', 'gp_currency_selector_shortcode');

function gp_currency_selector_shortcode() {
    ob_start();
    gp_currency_selector();
    return ob_get_clean();
}
