<?php
/**
 * Golden Phoenix V78.0
 * LIMPIEZA TOTAL - VERSIÓN FUNCIONAL
 * 
 * CAMBIOS DRÁSTICOS:
 * ❌ Eliminado: chatbot-intelligent.php
 * ❌ Eliminado: chat-integrations.php  
 * ❌ Eliminado: fix-chat-v73.php
 * ❌ Eliminado: simple-chat-v77.php
 * ❌ Eliminado: live-chat-system.php (ya estaba)
 * 
 * ✅ NUEVO: total-cleanup-v78.php
 *    - Solo 2 botones (Chat azul + WhatsApp verde)
 *    - CSS nuclear que elimina TODO lo viejo
 *    - JavaScript que limpia DOM
 *    - GP Settings ahora SÍ funciona
 *    - Theme Builder solo para admin
 * 
 * RESULTADO:
 * - Cero chats amarillos
 * - Cero conflictos
 * - 100% funcional
 * 
 * TOTAL: 52 funciones implementadas (68%)
 * Desarrollado por: Agencia RedLab
 * Email: ventas@agenciaredlab.com
 */

if (!defined('ABSPATH')) exit;

define('GOLDEN_PHOENIX_VERSION', '78.0.0');

// ============================================
// SOPORTE PARA MENÚS
// ============================================

function gp_register_menus() {
    register_nav_menus(array(
        'primary' => 'Menú Principal (Header)',
        'footer-1' => 'Menú Footer 1',
        'footer-2' => 'Menú Footer 2',
    ));
}
add_action('after_setup_theme', 'gp_register_menus');

// ============================================
// REGISTRAR ÁREAS DE WIDGETS
// ============================================

function gp_register_widgets() {
    // Footer Column 1 - Brand
    register_sidebar(array(
        'name' => 'Footer Columna 1 - Marca',
        'id' => 'footer-1',
        'description' => 'Primera columna del footer. Agrega widgets aquí para mostrar información de tu marca.',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-widget-title">',
        'after_title' => '</h4>',
    ));
    
    // Footer Column 2 - Navigation
    register_sidebar(array(
        'name' => 'Footer Columna 2 - Navegación',
        'id' => 'footer-2',
        'description' => 'Segunda columna del footer. Ideal para menús de navegación.',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-widget-title">',
        'after_title' => '</h4>',
    ));
    
    // Footer Column 3 - Customer Service
    register_sidebar(array(
        'name' => 'Footer Columna 3 - Atención Cliente',
        'id' => 'footer-3',
        'description' => 'Tercera columna del footer. Para información de atención al cliente.',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-widget-title">',
        'after_title' => '</h4>',
    ));
    
    // Footer Column 4 - Contact
    register_sidebar(array(
        'name' => 'Footer Columna 4 - Contacto',
        'id' => 'footer-4',
        'description' => 'Cuarta columna del footer. Para información de contacto. Agrega múltiples widgets de texto para correos, teléfonos, etc.',
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-widget-title">',
        'after_title' => '</h4>',
    ));
}
add_action('widgets_init', 'gp_register_widgets');
define('GOLDEN_PHOENIX_DIR', get_template_directory());
define('GOLDEN_PHOENIX_URI', get_template_directory_uri());
define('GOLDEN_PHOENIX_EMAIL', 'ventas@agenciaredlab.com');

@ini_set('memory_limit', '256M');
@ini_set('max_execution_time', '300');
@ini_set('display_errors', 0);

function gp_load_module($file) {
    $filepath = GOLDEN_PHOENIX_DIR . '/' . $file;
    if (file_exists($filepath)) {
        include_once $filepath;
        return true;
    }
    return false;
}

// Setup theme
add_action('after_setup_theme', function() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery'));
    add_theme_support('custom-logo', array('height' => 100, 'width' => 400, 'flex-height' => true, 'flex-width' => true));
    
    if (class_exists('WooCommerce')) {
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
    }
    
    add_theme_support('elementor');
    add_theme_support('elementor-full-width');
    
    register_nav_menus(array(
        'primary' => 'Menú Principal',
        'footer' => 'Menú Footer',
    ));
}, 10);

// Scripts
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('golden-phoenix-style', get_stylesheet_uri(), array(), GOLDEN_PHOENIX_VERSION);
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;600&display=swap');
    wp_enqueue_script('jquery');
}, 10);

// CSS Responsive crítico + Colores Luxury
add_action('wp_head', function() {
    ?>
    <style>
    /* COLORES LUXURY */
    :root {
        --gold-primary: #D4AF37;
        --gold-dark: #B8941F;
        --black: #000000;
        --dark-bg: #0A0A0A;
        --text-light: #CCCCCC;
        --text-lighter: #E5E5E5;
    }
    
    /* PÁGINA COMPLETA - Fondo oscuro por defecto */
    body {
        background-color: var(--black);
        color: var(--text-light);
    }
    
    .page-content-wrapper {
        background-color: var(--black);
    }
    
    /* TÍTULOS - Color dorado */
    h1, h2, h3, h4, h5, h6 {
        color: var(--gold-primary) !important;
    }
    
    /* Párrafos - Gris claro, NO blanco */
    p {
        color: var(--text-light) !important;
    }
    
    /* BOTONES - Estilo luxury */
    .wp-block-button__link {
        background-color: var(--gold-primary) !important;
        color: var(--black) !important;
        border: 2px solid var(--gold-primary) !important;
        padding: 1rem 2.5rem !important;
        font-weight: 600 !important;
        letter-spacing: 0.1em !important;
        transition: all 0.3s ease !important;
    }
    
    .wp-block-button__link:hover {
        background-color: transparent !important;
        color: var(--gold-primary) !important;
    }
    
    /* Botones outline */
    .is-style-outline .wp-block-button__link {
        background-color: transparent !important;
        color: var(--gold-primary) !important;
        border: 2px solid var(--gold-primary) !important;
    }
    
    .is-style-outline .wp-block-button__link:hover {
        background-color: var(--gold-primary) !important;
        color: var(--black) !important;
    }
    
    /* COVER BLOCKS - Texto visible */
    .wp-block-cover h1,
    .wp-block-cover h2,
    .wp-block-cover h3,
    .wp-block-cover p {
        text-shadow: 2px 2px 8px rgba(0,0,0,0.8);
    }
    
    /* GRUPOS Y CAJAS */
    .wp-block-group {
        background-color: var(--dark-bg);
        border-color: var(--gold-primary) !important;
    }
    
    /* SEPARADORES */
    .wp-block-separator {
        border-color: var(--gold-primary) !important;
        opacity: 0.3;
    }
    
    /* LISTAS */
    ul li, ol li {
        color: var(--text-light) !important;
    }
    
    /* PAGE CONTENT WRAPPER - Para páginas editables */
    .page-content-wrapper {
        width: 100% !important;
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .page-content-wrapper > * {
        max-width: 100% !important;
    }
    
    /* Asegurar que los bloques cover ocupen todo el ancho */
    .page-content-wrapper .wp-block-cover,
    .page-content-wrapper .alignfull {
        width: 100vw !important;
        max-width: 100vw !important;
        margin-left: calc(50% - 50vw) !important;
        margin-right: calc(50% - 50vw) !important;
    }
    
    /* HEADER Y MENÚ - CRÍTICO */
    .site-header {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        padding: 1rem 2rem !important;
        background: rgba(0,0,0,0.95) !important;
    }
    
    .header-container {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        width: 100% !important;
        max-width: 1400px !important;
        margin: 0 auto !important;
    }
    
    .site-logo {
        flex-shrink: 0 !important;
    }
    
    .site-logo a {
        font-family: 'Playfair Display', serif !important;
        font-size: 1.5rem !important;
        font-weight: 700 !important;
        color: #D4AF37 !important;
        text-decoration: none !important;
        white-space: nowrap !important;
        text-transform: uppercase !important;
        letter-spacing: 2px !important;
    }
    
    /* MENÚ HORIZONTAL */
    .main-navigation {
        flex-grow: 1 !important;
        display: flex !important;
        justify-content: center !important;
    }
    
    .main-navigation ul,
    .nav-menu {
        display: flex !important;
        flex-direction: row !important;
        gap: 2rem !important;
        list-style: none !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    
    .main-navigation a {
        color: #FFFFFF !important;
        text-decoration: none !important;
        font-size: 0.95rem !important;
        text-transform: uppercase !important;
        letter-spacing: 1px !important;
        transition: color 0.3s ease !important;
    }
    
    .main-navigation a:hover {
        color: #D4AF37 !important;
    }
    
    /* ICONOS DEL HEADER */
    .header-icons {
        display: flex !important;
        gap: 1.5rem !important;
        align-items: center !important;
    }
    
    .header-icon {
        color: #FFFFFF !important;
        font-size: 1.125rem !important;
        cursor: pointer !important;
        transition: color 0.3s ease !important;
        position: relative !important;
    }
    
    .header-icon:hover {
        color: #D4AF37 !important;
    }
    
    .header-icon a {
        color: inherit !important;
        text-decoration: none !important;
    }
    
    /* ANCHO COMPLETO - SIN MÁRGENES LATERALES */
    body, html {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        overflow-x: hidden !important;
    }
    
    body > * {
        max-width: 100% !important;
    }
    
    .site-header,
    .hero-section,
    .collections-section,
    .featured-section,
    .heritage-section,
    .testimonials-section,
    .newsletter-section,
    .site-footer {
        width: 100% !important;
        max-width: 100% !important;
        margin-left: 0 !important;
        margin-right: 0 !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
    
    /* Contenido interno con padding */
    .hero-content,
    .section-header,
    .collections-grid,
    .products-grid,
    .footer-main {
        padding-left: 2rem !important;
        padding-right: 2rem !important;
    }
    
    <?php if (!class_exists('WooCommerce')): ?>
    /* CSS DE RESPALDO SIN WOOCOMMERCE */
    body {
        background: #0A0A0A !important;
        color: #FFFFFF !important;
    }
    
    .site-header {
        background: rgba(0,0,0,0.95) !important;
        padding: 1rem 2rem !important;
    }
    
    .hero-section {
        min-height: 80vh !important;
        background: #0A0A0A !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    
    .site-footer {
        background: #0A0A0A !important;
        padding: 3rem 2rem !important;
    }
    <?php endif; ?>
    
    /* RESPONSIVE FIX CRÍTICO */
    @media (max-width: 768px) {
        .main-navigation {
            display: none !important;
        }
        
        .mobile-menu-toggle {
            display: block !important;
        }
        
        .site-header { padding: 0.5rem 1rem !important; flex-wrap: wrap !important; }
        .header-actions { flex-wrap: wrap !important; gap: 0.5rem !important; }
        .footer-main { flex-direction: column !important; gap: 2rem !important; }
        .footer-column { width: 100% !important; }
        .site-footer { padding: 2rem 1rem !important; }
        .hero-section { min-height: 60vh !important; padding: 2rem 1rem !important; }
        .hero-content h1 { font-size: 2rem !important; }
        .collections-grid, .products-grid { grid-template-columns: 1fr !important; }
        
        .hero-content,
        .section-header,
        .collections-grid,
        .products-grid {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
        }
        
        .site-logo a {
            font-size: 1rem !important;
        }
    }
    
    /* Fix para imágenes */
    img { max-width: 100%; height: auto; }
    
    /* Fix footer bottom */
    .footer-bottom { flex-direction: column !important; gap: 1rem !important; text-align: center !important; }
    .footer-payment { justify-content: center !important; }
    </style>
    <?php
}, 999);

// Mensaje para instalar Elementor
add_action('admin_notices', function() {
    if (!did_action('elementor/loaded') && current_user_can('install_plugins') && !get_transient('gp_elementor_notice_dismissed')) {
        echo '<div class="notice notice-info is-dismissible">
            <p><strong>💡 Mejora tu experiencia de edición</strong></p>
            <p>Instala <strong><a href="' . admin_url('plugin-install.php?s=elementor&tab=search') . '">Elementor Page Builder</a></strong> (GRATIS) para editor visual completo:</p>
            <ul style="list-style: disc; margin-left: 2rem;">
                <li>✅ Editar arrastrando y soltando</li>
                <li>✅ Cambiar tamaños fácilmente</li>
                <li>✅ Mover elementos libremente</li>
                <li>✅ Ver cambios en tiempo real</li>
            </ul>
            <p><a href="' . admin_url('plugin-install.php?s=elementor&tab=search') . '" class="button button-primary">Instalar Elementor Gratis</a></p>
        </div>';
    }
});

// Widgets
add_action('widgets_init', function() {
    register_sidebar(array('name' => 'Sidebar Principal', 'id' => 'sidebar-1'));
    for ($i = 1; $i <= 3; $i++) {
        register_sidebar(array('name' => 'Footer ' . $i, 'id' => 'footer-' . $i));
    }
}, 10);

// V40 FINAL - 17 módulos productivos
add_action('after_setup_theme', function() {
    // 17 MÓDULOS FUNCIONANDO ✅
    gp_load_module('customizer.php');
    gp_load_module('wishlist.php');
    gp_load_module('product-compare.php');
    gp_load_module('quick-view.php');
    gp_load_module('splash-screen.php');
    gp_load_module('recently-viewed.php');
    gp_load_module('advanced-search.php');
    gp_load_module('stock-notifications.php');
    gp_load_module('email-marketing.php');
    gp_load_module('advanced-reviews.php');
    gp_load_module('fomo-urgency.php');
    gp_load_module('blocks.php');
    gp_load_module('blocks-extended.php');
    gp_load_module('blocks-mega.php');
    gp_load_module('api-extended.php');
    gp_load_module('api-mega.php');
    gp_load_module('memberships.php');
    
    // 5 MÓDULOS REMOVIDOS (incompatibles):
    // auto-coupons.php ❌
    // seo-complete.php ❌
    // functions-advanced.php ❌
    // pse-gateway.php ❌
    // gateways-colombia.php ❌
}, 20);

// Chat WhatsApp
add_action('wp_footer', function() {
    $enabled = get_theme_mod('gp_chat_enabled', true);
    if (!$enabled) return;
    
    $whatsapp = get_theme_mod('gp_chat_whatsapp', '573001234567');
    $message = get_theme_mod('gp_chat_message', '¡Hola! ¿En qué podemos ayudarte?');
    $position = get_theme_mod('gp_chat_position', 'bottom-right');
    $color = get_theme_mod('gp_chat_color', '#D4AF37');
    ?>
    <div class="gp-chat-widget" style="position:fixed;<?php echo esc_attr($position);?>:20px;z-index:9999;">
        <a href="https://wa.me/<?php echo esc_attr($whatsapp);?>?text=<?php echo urlencode($message);?>" target="_blank" style="background:<?php echo esc_attr($color);?>;color:white;padding:15px 20px;border-radius:50px;text-decoration:none;display:inline-block;box-shadow:0 4px 12px rgba(0,0,0,0.3);">
            <i class="fab fa-whatsapp"></i> Chat
        </a>
    </div>
    <?php
});

// Customizer Chat
add_action('customize_register', function($wp_customize) {
    $wp_customize->add_section('gp_chat_section', array('title' => '💬 Chat WhatsApp', 'priority' => 35));
    $wp_customize->add_setting('gp_chat_enabled', array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('gp_chat_enabled', array('label' => 'Mostrar Chat', 'section' => 'gp_chat_section', 'type' => 'checkbox'));
    $wp_customize->add_setting('gp_chat_whatsapp', array('default' => '573001234567', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('gp_chat_whatsapp', array('label' => 'Número WhatsApp', 'section' => 'gp_chat_section', 'type' => 'text'));
    $wp_customize->add_setting('gp_chat_message', array('default' => '¡Hola! ¿En qué podemos ayudarte?', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('gp_chat_message', array('label' => 'Mensaje', 'section' => 'gp_chat_section', 'type' => 'text'));
    $wp_customize->add_setting('gp_chat_position', array('default' => 'bottom-right', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('gp_chat_position', array('label' => 'Posición', 'section' => 'gp_chat_section', 'type' => 'select', 'choices' => array('bottom-right' => 'Abajo Derecha', 'bottom-left' => 'Abajo Izquierda', 'top-right' => 'Arriba Derecha', 'top-left' => 'Arriba Izquierda')));
    $wp_customize->add_setting('gp_chat_color', array('default' => '#D4AF37', 'sanitize_callback' => 'sanitize_hex_color'));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_chat_color', array('label' => 'Color', 'section' => 'gp_chat_section')));
});

// Notificaciones
add_action('admin_notices', function() {
    if (get_transient('gp_activated')) {
        if (class_exists('WooCommerce')) {
            echo '<div class="notice notice-success is-dismissible">
                <p><strong>🎉 Golden Phoenix V52 - VERSIÓN PERFECTA instalada</strong></p>
                <p>✅ Página inicio simple y elegante<br>
                ✅ <strong>7 páginas creadas automáticamente:</strong><br>
                &nbsp;&nbsp;&nbsp;• Inicio<br>
                &nbsp;&nbsp;&nbsp;• Nosotros<br>
                &nbsp;&nbsp;&nbsp;• Colecciones<br>
                &nbsp;&nbsp;&nbsp;• Contacto<br>
                &nbsp;&nbsp;&nbsp;• Envíos y Devoluciones<br>
                &nbsp;&nbsp;&nbsp;• Preguntas Frecuentes<br>
                ✅ Todo editable desde <a href="' . admin_url('edit.php?post_type=page') . '">Páginas</a></p>
                <p>📝 Solo cambia los textos por los tuyos en cada página</p>
            </div>';
        } else {
            echo '<div class="notice notice-error"><p><strong>⚠️ WooCommerce requerido</strong><br><a href="' . admin_url('plugin-install.php?s=woocommerce&tab=search') . '" class="button button-primary">Instalar WooCommerce</a></p></div>';
        }
        delete_transient('gp_activated');
    }
    
    if (!class_exists('WooCommerce')) {
        echo '<div class="notice notice-warning"><p><strong>⚠️ WooCommerce no detectado</strong> - <a href="' . admin_url('plugin-install.php?s=woocommerce&tab=search') . '" class="button button-primary">Instalar</a></p></div>';
    }
});

// Activación del tema
add_action('after_switch_theme', function() {
    set_transient('gp_activated', true, 5);
    
    // FORZAR DESACTIVACIÓN DE CORTINILLA
    set_theme_mod('gp_splash_enabled', false);
    
    // CONFIGURAR NOMBRE DEL SITIO SI ESTÁ EN BLANCO O ES DOMINIO HOSTINGER
    $site_name = get_option('blogname');
    if (empty($site_name) || strpos(strtolower($site_name), 'hostinger') !== false || strpos(strtolower($site_name), 'wordpress') !== false || strpos($site_name, '.') !== false) {
        update_option('blogname', 'Golden Phoenix Jewelry');
        update_option('blogdescription', 'Joyería de Lujo Exclusiva');
    }
    
    // CONFIGURACIÓN AUTOMÁTICA DE VALORES POR DEFECTO
    // Solo si no existen (para no sobrescribir personalizaciones)
    
    // Colores
    if (!get_theme_mod('gp_primary_color')) {
        set_theme_mod('gp_primary_color', '#D4AF37'); // Dorado
    }
    if (!get_theme_mod('gp_secondary_color')) {
        set_theme_mod('gp_secondary_color', '#0A0A0A'); // Negro
    }
    if (!get_theme_mod('gp_text_color')) {
        set_theme_mod('gp_text_color', '#FFFFFF'); // Blanco
    }
    
    // Textos del sitio
    if (!get_theme_mod('gp_site_title')) {
        set_theme_mod('gp_site_title', 'Golden Phoenix Jewelry');
    }
    if (!get_theme_mod('gp_site_tagline')) {
        set_theme_mod('gp_site_tagline', 'Joyería de Lujo Exclusiva');
    }
    
    // Chat WhatsApp
    if (!get_theme_mod('gp_chat_enabled')) {
        set_theme_mod('gp_chat_enabled', true);
    }
    if (!get_theme_mod('gp_chat_whatsapp')) {
        set_theme_mod('gp_chat_whatsapp', '573001234567');
    }
    if (!get_theme_mod('gp_chat_message')) {
        set_theme_mod('gp_chat_message', '¡Hola! ¿En qué podemos ayudarte?');
    }
    if (!get_theme_mod('gp_chat_position')) {
        set_theme_mod('gp_chat_position', 'bottom-right');
    }
    if (!get_theme_mod('gp_chat_color')) {
        set_theme_mod('gp_chat_color', '#D4AF37');
    }
    
    // Contacto
    if (!get_theme_mod('gp_contact_phone')) {
        set_theme_mod('gp_contact_phone', '+57 300 123 4567');
    }
    if (!get_theme_mod('gp_contact_email')) {
        set_theme_mod('gp_contact_email', 'info@goldenphoenix.com');
    }
    if (!get_theme_mod('gp_contact_address')) {
        set_theme_mod('gp_contact_address', 'Calle Principal 123, Medellín');
    }
    
    // CREAR PÁGINA DE INICIO LUXURY - Diseño oscuro premium
    $homepage = get_page_by_path('inicio');
    if (!$homepage) {
        $homepage_id = wp_insert_post(array(
            'post_title' => 'Inicio',
            'post_name' => 'inicio',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920","dimRatio":80,"overlayColor":"black","align":"full","style":{"spacing":{"padding":{"top":"12rem","bottom":"12rem"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:12rem;padding-bottom:12rem"><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim-80 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"5rem","fontWeight":"100","letterSpacing":"0.2em","textTransform":"uppercase"},"color":{"text":"#D4AF37"}}} -->
<h1 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:5rem;font-weight:100;letter-spacing:0.2em;text-transform:uppercase">ELEGANCIA ETERNA</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem","lineHeight":"1.8"},"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC;font-size:1.5rem;line-height:1.8">Descubre piezas únicas creadas con los materiales más preciosos del mundo</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"3rem"} -->
<div style="height:3rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"blockGap":"2rem"}}} -->
<div class="wp-block-buttons">
<!-- wp:button {"backgroundColor":"#D4AF37","textColor":"black","style":{"border":{"radius":"0px","width":"2px"},"typography":{"letterSpacing":"0.15em","fontWeight":"600"},"spacing":{"padding":{"left":"3rem","right":"3rem","top":"1.2rem","bottom":"1.2rem"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-black-color has-text-color wp-element-button" style="border-width:2px;border-radius:0px;padding-top:1.2rem;padding-right:3rem;padding-bottom:1.2rem;padding-left:3rem;font-weight:600;letter-spacing:0.15em" href="/shop">EXPLORAR COLECCIÓN</a></div>
<!-- /wp:button -->

<!-- wp:button {"style":{"border":{"radius":"0px","width":"2px","color":"#D4AF37"},"color":{"background":"#00000000","text":"#D4AF37"},"typography":{"letterSpacing":"0.15em","fontWeight":"600"},"spacing":{"padding":{"left":"3rem","right":"3rem","top":"1.2rem","bottom":"1.2rem"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background has-border-color wp-element-button" style="border-color:#D4AF37;border-width:2px;border-radius:0px;color:#D4AF37;background-color:#00000000;padding-top:1.2rem;padding-right:3rem;padding-bottom:1.2rem;padding-left:3rem;font-weight:600;letter-spacing:0.15em" href="/nosotros">NUESTRA HISTORIA</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}},"color":{"background":"#000000"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-background" style="background-color:#000000;padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"3rem","letterSpacing":"0.1em"},"color":{"text":"#D4AF37"}}} -->
<h2 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:3rem;letter-spacing:0.1em">Colecciones Destacadas</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"},"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC;font-size:1.25rem">Cada colección es una expresión de excelencia artesanal y diseño visionario</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"4rem"} -->
<div style="height:4rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800" alt="Anillos de compromiso"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"},"spacing":{"margin":{"top":"2rem"}}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37;margin-top:2rem">Anillos de Compromiso</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Diamantes certificados en diseños únicos que capturan el momento más importante</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"1.5rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:1.5rem">
<!-- wp:button {"style":{"border":{"radius":"0px","width":"2px","color":"#D4AF37"},"color":{"background":"#00000000","text":"#D4AF37"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background has-border-color wp-element-button" style="border-color:#D4AF37;border-width:2px;border-radius:0px;color:#D4AF37;background-color:#00000000" href="/producto-categoria/anillos">VER COLECCIÓN</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800" alt="Collares de lujo"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"},"spacing":{"margin":{"top":"2rem"}}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37;margin-top:2rem">Collares Exclusivos</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Piezas statement en oro de 18K con gemas naturales de origen certificado</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"1.5rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:1.5rem">
<!-- wp:button {"style":{"border":{"radius":"0px","width":"2px","color":"#D4AF37"},"color":{"background":"#00000000","text":"#D4AF37"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background has-border-color wp-element-button" style="border-color:#D4AF37;border-width:2px;border-radius:0px;color:#D4AF37;background-color:#00000000" href="/producto-categoria/collares">VER COLECCIÓN</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800" alt="Pulseras de oro"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"},"spacing":{"margin":{"top":"2rem"}}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37;margin-top:2rem">Pulseras de Autor</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Diseños contemporáneos que combinan tradición artesanal con estética moderna</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"1.5rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:1.5rem">
<!-- wp:button {"style":{"border":{"radius":"0px","width":"2px","color":"#D4AF37"},"color":{"background":"#00000000","text":"#D4AF37"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background has-border-color wp-element-button" style="border-color:#D4AF37;border-width:2px;border-radius:0px;color:#D4AF37;background-color:#00000000" href="/producto-categoria/pulseras">VER COLECCIÓN</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:cover {"overlayColor":"black","isDark":false,"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem"}}}} -->
<div class="wp-block-cover alignfull is-light" style="padding-top:6rem;padding-bottom:6rem"><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"3rem","letterSpacing":"0.1em"},"color":{"text":"#D4AF37"}}} -->
<h2 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:3rem;letter-spacing:0.1em">Por Qué Elegirnos</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"3rem"} -->
<div style="height:3rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Artesanía Excepcional</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Cada pieza es creada a mano por maestros artesanos con décadas de experiencia</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Materiales Premium</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Oro de 18K, platino 950 y diamantes con certificación internacional</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Diseño Exclusivo</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Colecciones limitadas y servicio de diseño personalizado</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3,"textAlign":"center","style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Garantía de Por Vida</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Todas nuestras piezas incluyen garantía y servicio de mantenimiento gratuito</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem"}},"color":{"background":"#000000"}}} -->
<div class="wp-block-group alignfull has-background" style="background-color:#000000;padding-top:6rem;padding-bottom:6rem">
<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"3rem","letterSpacing":"0.1em"},"color":{"text":"#D4AF37"}}} -->
<h2 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:3rem;letter-spacing:0.1em">Lo Que Dicen Nuestros Clientes</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"3rem"} -->
<div style="height:3rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"style":{"spacing":{"padding":{"top":"2.5rem","right":"2.5rem","bottom":"2.5rem","left":"2.5rem"}},"border":{"width":"1px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:1px;padding-top:2.5rem;padding-right:2.5rem;padding-bottom:2.5rem;padding-left:2.5rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:2rem">⭐⭐⭐⭐⭐</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">"La calidad es excepcional. Mi anillo de compromiso es una verdadera obra de arte."</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontWeight":"700"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">— María González</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"2.5rem","right":"2.5rem","bottom":"2.5rem","left":"2.5rem"}},"border":{"width":"1px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:1px;padding-top:2.5rem;padding-right:2.5rem;padding-bottom:2.5rem;padding-left:2.5rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:2rem">⭐⭐⭐⭐⭐</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">"Compré un collar para mi esposa y quedó encantada. La atención al detalle es impresionante."</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontWeight":"700"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">— Carlos Rodríguez</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"2.5rem","right":"2.5rem","bottom":"2.5rem","left":"2.5rem"}},"border":{"width":"1px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:1px;padding-top:2.5rem;padding-right:2.5rem;padding-bottom:2.5rem;padding-left:2.5rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"2rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:2rem">⭐⭐⭐⭐⭐</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">"Diseñaron mi anillo personalizado exactamente como lo soñé. El resultado superó mis expectativas."</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontWeight":"700"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">— Ana Martínez</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
        
        // Configurar como página de inicio
        update_option('page_on_front', $homepage_id);
        update_option('show_on_front', 'page');
    }
    
    // CREAR PÁGINA NOSOTROS - DISEÑO LUXURY
    if (!get_page_by_path('nosotros')) {
        wp_insert_post(array(
            'post_title' => 'Nosotros',
            'post_name' => 'nosotros',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1617038260449-d4d24667402f?w=1920","dimRatio":75,"overlayColor":"black","align":"full","style":{"spacing":{"padding":{"top":"10rem","bottom":"10rem"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:10rem;padding-bottom:10rem"><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim-75 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1617038260449-d4d24667402f?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"4rem","letterSpacing":"0.15em"},"color":{"text":"#D4AF37"}}} -->
<h1 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:4rem;letter-spacing:0.15em">NUESTRA HISTORIA</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem"},"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC;font-size:1.5rem">Creando obras maestras desde 1892</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem","left":"2rem","right":"2rem"}},"color":{"background":"#000000"}}} -->
<div class="wp-block-group alignfull has-background" style="background-color:#000000;padding-top:6rem;padding-right:2rem;padding-bottom:6rem;padding-left:2rem">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:heading {"style":{"color":{"text":"#D4AF37"},"typography":{"fontSize":"2.5rem"}}} -->
<h2 class="has-text-color" style="color:#D4AF37;font-size:2.5rem">Más de un Siglo de Excelencia</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"color":{"text":"#CCCCCC"},"spacing":{"margin":{"top":"2rem"}}}} -->
<p class="has-text-color" style="color:#CCCCCC;margin-top:2rem">Desde 1892, nuestra casa de joyería ha sido sinónimo de elegancia, calidad y artesanía excepcional. Lo que comenzó como un pequeño taller en el corazón de la ciudad, se ha convertido en una referencia internacional en alta joyería.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-color" style="color:#CCCCCC">Cada pieza que creamos lleva más de 130 años de tradición, conocimiento y pasión por la perfección. Nuestros maestros artesanos heredan técnicas ancestrales que se combinan con la innovación y el diseño contemporáneo.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-color" style="color:#CCCCCC">Hoy, seguimos comprometidos con los mismos valores que fundaron nuestra casa: calidad sin compromiso, diseño excepcional y atención personalizada a cada cliente.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800" alt="Taller de joyería"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem"}},"color":{"background":"#0A0A0A"}}} -->
<div class="wp-block-group alignfull has-background" style="background-color:#0A0A0A;padding-top:6rem;padding-bottom:6rem">
<!-- wp:heading {"textAlign":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontSize":"3rem","letterSpacing":"0.1em"}}} -->
<h2 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:3rem;letter-spacing:0.1em">Nuestros Valores</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"3rem"} -->
<div style="height:3rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Excelencia</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Cada pieza es creada con los más altos estándares de calidad. No aceptamos menos que la perfección en cada detalle.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Autenticidad</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Trabajamos únicamente con materiales certificados de origen ético. Cada pieza incluye certificado de autenticidad.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px","color":"#D4AF37"}}} -->
<div class="wp-block-column has-border-color" style="border-color:#D4AF37;border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3,"style":{"color":{"text":"#D4AF37"}}} -->
<h3 class="has-text-align-center has-text-color" style="color:#D4AF37">Innovación</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Respetamos la tradición mientras abrazamos el diseño contemporáneo y las nuevas técnicas de creación.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"6rem","bottom":"6rem"}},"color":{"background":"#000000"}}} -->
<div class="wp-block-group alignfull has-background" style="background-color:#000000;padding-top:6rem;padding-bottom:6rem">
<!-- wp:heading {"textAlign":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontSize":"3rem"}}} -->
<h2 class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:3rem">Nuestro Compromiso</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"3rem"} -->
<div style="height:3rem" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:4rem">100%</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontWeight":"700"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">Garantía de Satisfacción</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">En cada compra</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:4rem">130+</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontWeight":"700"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">Años de Tradición</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">Desde 1892</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:4rem">10K+</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontWeight":"700"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">Clientes Satisfechos</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">En todo el mundo</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"},"color":{"text":"#D4AF37"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-size:4rem">∞</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#D4AF37"},"typography":{"fontWeight":"700"}}} -->
<p class="has-text-align-center has-text-color" style="color:#D4AF37;font-weight:700">Garantía de Por Vida</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#CCCCCC"}}} -->
<p class="has-text-align-center has-text-color" style="color:#CCCCCC">En todas nuestras piezas</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
    
    // CREAR PÁGINA COLECCIONES - DISEÑO VISUAL PROFESIONAL
    if (!get_page_by_path('colecciones')) {
        wp_insert_post(array(
            'post_title' => 'Colecciones',
            'post_name' => 'colecciones',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=1920","dimRatio":50,"align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"4rem"}}} -->
<h1 class="has-text-align-center" style="font-size:4rem">Nuestras Colecciones</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem"}}} -->
<p class="has-text-align-center" style="font-size:1.5rem">Explora nuestras exclusivas líneas de joyería de lujo</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"backgroundColor":"base"} -->
<div class="wp-block-group alignfull has-base-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=1000" alt="Anillos de compromiso"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
<!-- wp:heading {"level":2} -->
<h2>Anillos de Compromiso</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Diamantes certificados en diseños únicos que capturan el momento más importante de tu vida. Cada anillo es una obra maestra creada para durar eternamente.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Características:</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Diamantes GIA certificados</li>
<li>Oro 18K o platino 950</li>
<li>Diseño personalizado disponible</li>
<li>Certificado de autenticidad</li>
<li>Garantía de por vida</li>
</ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/producto-categoria/anillos">Ver Colección</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}}} -->
<div class="wp-block-group alignfull" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
<!-- wp:heading {"level":2} -->
<h2>Collares Exclusivos</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Piezas statement en oro de 18K con gemas naturales de origen certificado. Desde diseños delicados hasta piezas que capturan todas las miradas.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Características:</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Gemas naturales certificadas</li>
<li>Diseños exclusivos limitados</li>
<li>Cierre de seguridad premium</li>
<li>Cadena ajustable</li>
<li>Estuche de lujo incluido</li>
</ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/producto-categoria/collares">Ver Colección</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->

<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=1000" alt="Collares de lujo"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem","left":"2rem","right":"2rem"}}},"backgroundColor":"base"} -->
<div class="wp-block-group alignfull has-base-background-color has-background" style="padding-top:4rem;padding-right:2rem;padding-bottom:4rem;padding-left:2rem">
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img src="https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=1000" alt="Pulseras de oro"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
<!-- wp:heading {"level":2} -->
<h2>Pulseras de Autor</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Diseños contemporáneos que combinan tradición artesanal con estética moderna. Piezas versátiles que se adaptan a cualquier ocasión.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Características:</strong></p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Diseños únicos de autor</li>
<li>Oro 18K macizo</li>
<li>Cierre de seguridad doble</li>
<li>Tallas ajustables</li>
<li>Edición limitada</li>
</ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/producto-categoria/pulseras">Ver Colección</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">Todas Nuestras Categorías</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Aretes</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Desde studs delicados hasta chandelier dramáticos</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">Explorar</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Alianzas</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Símbolos de amor eterno en oro y platino</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">Explorar</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Relojes</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Piezas de relojería suiza de alta gama</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">Explorar</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
    
    // CREAR PÁGINA CONTACTO - DISEÑO PROFESIONAL
    if (!get_page_by_path('contacto')) {
        wp_insert_post(array(
            'post_title' => 'Contacto',
            'post_name' => 'contacto',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920","dimRatio":70,"align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-70 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"4rem"}}} -->
<h1 class="has-text-align-center" style="font-size:4rem">Contáctanos</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem"}}} -->
<p class="has-text-align-center" style="font-size:1.5rem">Estamos aquí para ayudarte</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide","style":{"spacing":{"padding":{"left":"2rem","right":"2rem"}}}} -->
<div class="wp-block-columns alignwide" style="padding-left:2rem;padding-right:2rem">
<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:heading -->
<h2>Visítanos</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Te invitamos a conocer nuestro showroom donde podrás ver y probar nuestras colecciones exclusivas. Nuestro equipo de expertos está disponible para asesorarte personalmente.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>📍 Dirección</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Calle Principal 123<br>Centro Comercial Luxury Plaza, Local 45<br>Medellín, Antioquia<br>Colombia</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>📞 Teléfonos</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Móvil:</strong> +57 300 123 4567<br><strong>Fijo:</strong> (4) 123 4567<br><strong>WhatsApp:</strong> +57 300 123 4567</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>📧 Email</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Ventas:</strong> ventas@goldenphoenix.com<br><strong>Atención:</strong> info@goldenphoenix.com<br><strong>Diseño:</strong> diseno@goldenphoenix.com</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>🕐 Horarios</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Lunes a Viernes:</strong> 10:00 - 20:00<br><strong>Sábados:</strong> 10:00 - 18:00<br><strong>Domingos:</strong> Cerrado</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><em>Citas privadas disponibles fuera de horario</em></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column {"width":"50%"} -->
<div class="wp-block-column" style="flex-basis:50%">
<!-- wp:heading -->
<h2>Envíanos un Mensaje</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Completa el formulario y nos pondremos en contacto contigo a la brevedad. Si prefieres atención inmediata, contáctanos por WhatsApp.</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph -->
<p>[Aquí irá tu formulario de contacto. Instala Contact Form 7 o WPForms y reemplaza este texto con el shortcode del formulario]</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Ejemplo:</strong><br>[contact-form-7 id="123"]</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link wp-element-button" href="https://wa.me/573001234567">Chatear por WhatsApp</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">Preguntas Frecuentes</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":4} -->
<h4>¿Necesito cita previa?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>No es obligatorio, pero recomendamos agendar cita para garantizar atención personalizada y acceso a colecciones exclusivas.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":4} -->
<h4>¿Hacen envíos?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sí, realizamos envíos nacionales e internacionales con seguro completo y número de seguimiento.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":4} -->
<h4>¿Aceptan diseño personalizado?</h4>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Absolutamente. Nuestro equipo de diseñadores puede crear tu pieza única según tus especificaciones.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
    
    // CREAR PÁGINA ENVÍOS Y DEVOLUCIONES - DISEÑO PROFESIONAL
    if (!get_page_by_path('envios-y-devoluciones')) {
        wp_insert_post(array(
            'post_title' => 'Envíos y Devoluciones',
            'post_name' => 'envios-y-devoluciones',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=1920","dimRatio":60,"align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-60 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1566576721346-d4a3b4eaeb55?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"4rem"}}} -->
<h1 class="has-text-align-center" style="font-size:4rem">Envíos y Devoluciones</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem"}}} -->
<p class="has-text-align-center" style="font-size:1.5rem">Compra con confianza y tranquilidad</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">Política de Envíos</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px"}},"borderColor":"primary","backgroundColor":"base"} -->
<div class="wp-block-group has-border-color has-primary-border-color has-base-background-color has-background" style="border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"}}} -->
<p class="has-text-align-center" style="font-size:4rem">🚚</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Envío Nacional</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><strong>GRATIS</strong> en compras superiores a $500,000 COP</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p><strong>Tiempo de entrega:</strong><br>2-5 días hábiles</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Cobertura:</strong><br>Todo Colombia</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Transportadora:</strong><br>Servientrega / Coordinadora</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Seguimiento:</strong><br>Número de rastreo incluido</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px"}},"borderColor":"primary","backgroundColor":"base"} -->
<div class="wp-block-group has-border-color has-primary-border-color has-base-background-color has-background" style="border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"}}} -->
<p class="has-text-align-center" style="font-size:4rem">✈️</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Envío Internacional</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Disponible a principales destinos</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p><strong>Tiempo de entrega:</strong><br>7-15 días hábiles</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Cobertura:</strong><br>América, Europa, Asia</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Transportadora:</strong><br>DHL Express</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Aranceles:</strong><br>Por cuenta del destinatario</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"2rem","bottom":"3rem","left":"2rem"}},"border":{"width":"2px"}},"borderColor":"primary","backgroundColor":"base"} -->
<div class="wp-block-group has-border-color has-primary-border-color has-base-background-color has-background" style="border-width:2px;padding-top:3rem;padding-right:2rem;padding-bottom:3rem;padding-left:2rem">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"4rem"}}} -->
<p class="has-text-align-center" style="font-size:4rem">🔒</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="has-text-align-center">Envío Asegurado</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">100% protegido contra pérdida o daño</p>
<!-- /wp:paragraph -->

<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->

<!-- wp:paragraph -->
<p><strong>Cobertura:</strong><br>Valor total de la compra</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Embalaje:</strong><br>Caja de lujo discreta</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Seguridad:</strong><br>Firma requerida</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><strong>Garantía:</strong><br>Sin costo adicional</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:cover {"overlayColor":"black","align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<h2 class="has-text-align-center" style="font-size:3rem">Política de Devoluciones</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns -->
<div class="wp-block-columns">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3>✅ 30 Días de Garantía</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Aceptamos devoluciones dentro de los 30 días posteriores a la compra sin necesidad de justificación.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3>💯 Reembolso Completo</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Te devolvemos el 100% de tu dinero o puedes cambiar por otra pieza de igual o mayor valor.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:heading {"level":3} -->
<h3>📦 Envío de Devolución</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>El envío de devolución es GRATIS. Te enviamos la guía prepagada por email.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">Condiciones para Devoluciones</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}},"backgroundColor":"base"} -->
<div class="wp-block-group has-base-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":4} -->
<h4>✓ La pieza debe estar:</h4>
<!-- /wp:heading -->

<!-- wp:list -->
<ul>
<li>Sin usar ni alterada</li>
<li>En perfecto estado original</li>
<li>Con embalaje original</li>
<li>Con todos los certificados</li>
<li>Con todos los accesorios</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:group {"style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}},"backgroundColor":"base"} -->
<div class="wp-block-group has-base-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":4} -->
<h4>✗ No aceptamos devolución si:</h4>
<!-- /wp:heading -->

<!-- wp:list -->
<ul>
<li>La pieza fue personalizada</li>
<li>Han pasado más de 30 días</li>
<li>Muestra señales de uso</li>
<li>Falta documentación</li>
<li>Fue modificada o reparada</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">¿Cómo Hacer una Devolución?</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<p class="has-text-align-center" style="font-size:3rem">1️⃣</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4} -->
<h4 class="has-text-align-center">Contáctanos</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Envía un email a<br>devoluciones@goldenphoenix.com<br>con tu número de orden</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<p class="has-text-align-center" style="font-size:3rem">2️⃣</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4} -->
<h4 class="has-text-align-center">Recibe la Guía</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Te enviamos la guía<br>prepagada en 24 horas<br>para que devuelvas la pieza</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<p class="has-text-align-center" style="font-size:3rem">3️⃣</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4} -->
<h4 class="has-text-align-center">Envía la Pieza</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Empaca bien la pieza<br>con todo incluido<br>y envíala</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<p class="has-text-align-center" style="font-size:3rem">4️⃣</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4} -->
<h4 class="has-text-align-center">Recibe tu Reembolso</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Una vez recibida<br>procesamos tu reembolso<br>en 3-5 días hábiles</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
    
    // CREAR PÁGINA PREGUNTAS FRECUENTES - DISEÑO PROFESIONAL
    if (!get_page_by_path('preguntas-frecuentes')) {
        wp_insert_post(array(
            'post_title' => 'Preguntas Frecuentes',
            'post_name' => 'preguntas-frecuentes',
            'post_content' => '<!-- wp:cover {"url":"https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1920","dimRatio":70,"align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-70 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1920" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"4rem"}}} -->
<h1 class="has-text-align-center" style="font-size:4rem">Preguntas Frecuentes</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.5rem"}}} -->
<p class="has-text-align-center" style="font-size:1.5rem">Encuentra respuestas a las dudas más comunes</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">📦 Compras y Pedidos</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Cómo puedo hacer un pedido?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Puedes hacer tu pedido de 3 formas:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li><strong>Online:</strong> Agrega productos al carrito y completa el checkout</li>
<li><strong>WhatsApp:</strong> Contáctanos al +57 300 123 4567</li>
<li><strong>En tienda:</strong> Visítanos en nuestro showroom (cita previa recomendada)</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Qué métodos de pago aceptan?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Aceptamos múltiples formas de pago:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Tarjetas de crédito: Visa, Mastercard, American Express</li>
<li>Tarjetas débito</li>
<li>PayPal</li>
<li>Transferencia bancaria</li>
<li>Pago contra entrega (sujeto a aprobación)</li>
<li>Financiamiento disponible con tarjetas participantes</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Puedo cancelar mi pedido?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sí, puedes cancelar tu pedido dentro de las primeras 24 horas después de realizado. Después de ese tiempo, si la pieza ya está en proceso de fabricación o envío, aplicarían costos de cancelación.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">💎 Productos y Calidad</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Ofrecen certificados de autenticidad?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sí, <strong>todas</strong> nuestras piezas incluyen:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Certificado de autenticidad de la casa</li>
<li>Certificación de quilates del oro (18K)</li>
<li>Certificación internacional de diamantes (GIA, IGI o HRD)</li>
<li>Certificación de gemas naturales cuando aplique</li>
<li>Garantía de por vida</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Hacen diseños personalizados?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>¡Absolutamente! Nuestro servicio de diseño personalizado incluye:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Consulta inicial sin costo con nuestro diseñador</li>
<li>Bocetos y renders 3D de tu pieza</li>
<li>Selección personalizada de materiales</li>
<li>Hasta 3 revisiones de diseño</li>
<li>Fabricación artesanal exclusiva</li>
<li>Tiempo de entrega: 4-6 semanas</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Qué garantía ofrecen?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Todas nuestras piezas incluyen <strong>garantía de por vida</strong> que cubre:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Defectos de fabricación</li>
<li>Pérdida de brillo o color del metal</li>
<li>Problemas con engastes de piedras</li>
<li>Limpieza y pulido profesional gratuito (1 vez al año)</li>
<li>Mantenimiento preventivo sin costo</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="has-text-align-center">🔧 Mantenimiento y Reparaciones</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Puedo ajustar el tamaño de un anillo?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sí, ofrecemos ajuste de talla:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li><strong>Primer ajuste:</strong> GRATIS dentro de los primeros 60 días</li>
<li><strong>Ajustes posteriores:</strong> Costo variable según trabajo requerido</li>
<li><strong>Tiempo:</strong> 3-5 días hábiles</li>
<li><strong>Limitaciones:</strong> Algunos diseños con piedras alrededor no pueden ajustarse más de 1-2 tallas</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}},"border":{"width":"1px"}},"borderColor":"contrast"} -->
<div class="wp-block-group alignwide has-border-color has-contrast-border-color" style="border-width:1px;padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem">
<!-- wp:heading {"level":3} -->
<h3>¿Ofrecen servicio de limpieza?</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sí, nuestro servicio de limpieza profesional incluye:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul>
<li>Limpieza ultrasónica</li>
<li>Pulido profesional</li>
<li>Revisión de engastes</li>
<li>Inspección de seguridad</li>
<li><strong>GRATIS</strong> una vez al año para clientes</li>
<li>Servicio express en 24 horas</li>
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:cover {"overlayColor":"black","align":"full"} -->
<div class="wp-block-cover alignfull"><span aria-hidden="true" class="wp-block-cover__background has-black-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","style":{"typography":{"fontSize":"3rem"}}} -->
<h2 class="has-text-align-center" style="font-size:3rem">¿No encontraste tu respuesta?</h2>
<!-- /wp:heading -->

<!-- wp:spacer {"height":"20px"} -->
<div style="height:20px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center" style="font-size:1.25rem">Nuestro equipo está disponible para ayudarte</p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"40px"} -->
<div style="height:40px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons">
<!-- wp:button {"style":{"spacing":{"padding":{"left":"3rem","right":"3rem","top":"1rem","bottom":"1rem"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="/contacto" style="padding-top:1rem;padding-right:3rem;padding-bottom:1rem;padding-left:3rem">Contáctanos</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline","style":{"spacing":{"padding":{"left":"3rem","right":"3rem","top":"1rem","bottom":"1rem"}}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="https://wa.me/573001234567" style="padding-top:1rem;padding-right:3rem;padding-bottom:1rem;padding-left:3rem">Chat WhatsApp</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->

<!-- wp:spacer {"height":"80px"} -->
<div style="height:80px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
    
    // CREAR MENÚ PRINCIPAL AUTOMÁTICAMENTE
    $menu_name = 'Menú Principal';
    $menu_exists = wp_get_nav_menu_object($menu_name);
    
    if (!$menu_exists) {
        $menu_id = wp_create_nav_menu($menu_name);
        
        // Agregar items al menú
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title' => 'Inicio',
            'menu-item-url' => home_url('/'),
            'menu-item-status' => 'publish'
        ));
        
        if (class_exists('WooCommerce')) {
            $shop_page_id = wc_get_page_id('shop');
            if ($shop_page_id) {
                wp_update_nav_menu_item($menu_id, 0, array(
                    'menu-item-title' => 'Tienda',
                    'menu-item-object-id' => $shop_page_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status' => 'publish'
                ));
            }
        }
        
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title' => 'Colecciones',
            'menu-item-url' => home_url('/colecciones'),
            'menu-item-status' => 'publish'
        ));
        
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title' => 'Nosotros',
            'menu-item-url' => home_url('/nosotros'),
            'menu-item-status' => 'publish'
        ));
        
        wp_update_nav_menu_item($menu_id, 0, array(
            'menu-item-title' => 'Contacto',
            'menu-item-url' => home_url('/contacto'),
            'menu-item-status' => 'publish'
        ));
        
        // Asignar menú a la ubicación 'primary'
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
    
    // Crear páginas WooCommerce
    if (class_exists('WooCommerce')) {
        if (!get_page_by_path('lista-de-deseos')) {
            wp_insert_post(array(
                'post_title' => 'Lista de Deseos',
                'post_name' => 'lista-de-deseos',
                'post_content' => '[golden_phoenix_wishlist]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ));
        }
        if (!get_page_by_path('comparar-productos')) {
            wp_insert_post(array(
                'post_title' => 'Comparar Productos',
                'post_name' => 'comparar-productos',
                'post_content' => '[product_compare]',
                'post_status' => 'publish',
                'post_type' => 'page',
            ));
        }
    }
});

// Seguridad
add_filter('xmlrpc_enabled', '__return_false');
remove_action('wp_head', 'wp_generator');


// ==================================================
// V61: BLOQUES Y WIDGETS PERSONALIZADOS
// ==================================================

// Bloques Gutenberg personalizados
require_once get_template_directory() . '/blocks-custom.php';

// Widgets Elementor personalizados  
if (did_action('elementor/loaded')) {
    require_once get_template_directory() . '/elementor-custom.php';
}


// ==================================================
// V63: WIDGETS ULTRA PROFESIONALES + DISEÑO AVANZADO
// ==================================================

// Widgets ultra profesionales (100+)
require_once get_template_directory() . '/widgets-ultra-pro.php';

// Funciones de diseño avanzadas (50+)
require_once get_template_directory() . '/advanced-design.php';


// ==================================================
// V64: CHATBOT INTELIGENTE
// ==================================================

// Sistema de chatbot inteligente (Básico + OpenAI + Híbrido)
// DESACTIVADO V78 - Causaba conflictos
// require_once get_template_directory() . '/chatbot-intelligent.php';


// ==================================================
// V65: CHAT EN VIVO CON AGENTES + INTEGRACIONES
// ==================================================

// Sistema de chat en vivo con panel de agentes
// Chat antiguo desactivado (causaba errores DB)
// require_once get_template_directory() . '/live-chat-system.php';

// Integraciones (N8N + Chatwoot)
// DESACTIVADO V78 - Causaba conflictos
// require_once get_template_directory() . '/chat-integrations.php';


// ==================================================
// V66: EVENT TRACKING COMPLETO PARA N8N
// ==================================================

// Sistema de tracking de eventos (25+ eventos)
require_once get_template_directory() . '/event-tracking-n8n.php';


// ==================================================
// V67: ADVANCED USER TRACKING (100+ EVENTOS)
// ==================================================

// Tracking avanzado de comportamiento de usuario
require_once get_template_directory() . '/advanced-user-tracking.php';


// ==================================================
// SETUP WIZARD - Soluciona problema de activación
// ==================================================

require_once get_template_directory() . '/setup-wizard.php';


// ==================================================
// THANK YOU PAGE - Página agradecimiento post-compra
// ==================================================

require_once get_template_directory() . '/thank-you-page.php';


// ========================================
// V70.5 - FIX MÍNIMO (Hero + Theme Builder)
// ========================================
// SOLO agrega hero customizable y theme builder funcional
// NO modifica diseño ni responsive original
require_once get_template_directory() . '/minimal-fix-v70-5.php';


// ========================================
// V70.6 - FIX CUSTOMIZER Y THEME BUILDER
// ========================================
require_once get_template_directory() . '/fix-v70-6.php';


// ========================================
// V70.8 - FIX DISEÑO EXACTO SEGÚN IMAGEN
// ========================================
require_once get_template_directory() . '/design-fix-v70-8.php';


// ========================================
// V70.9 - RESET CUSTOMIZER + EDITOR MODERNO
// ========================================
require_once get_template_directory() . '/reset-and-editor-v70-9.php';


// ========================================
// V71 - E-COMMERCE FEATURES (4 FUNCIONES)
// ========================================

// 1. WhatsApp Direct Order
require_once get_template_directory() . '/whatsapp-direct-order.php';

// 2. Multi-Currency
require_once get_template_directory() . '/multi-currency.php';

// 3. Gift Finder
require_once get_template_directory() . '/gift-finder.php';



// ========================================
// V72 - CUSTOMIZER FIX + 4 NUEVAS FUNCIONES
// ========================================

// Fix Customizer WhatsApp
require_once get_template_directory() . '/customizer-whatsapp-fix-v72.php';

// 4. Custom Jewelry Builder
require_once get_template_directory() . '/custom-jewelry-builder.php';

// 5. Price Calculator
require_once get_template_directory() . '/price-calculator.php';

// 6. Instagram Shop Sync
require_once get_template_directory() . '/instagram-shop-sync.php';



// ========================================
// V73 - FIX CHATS + 5 NUEVAS FUNCIONES
// ========================================

// Fix Chat Duplicados + Live Chat
// DESACTIVADO V78 - Reemplazado por sistema simple
// require_once get_template_directory() . '/fix-chat-v73.php';

// 7. Analytics Dashboard
require_once get_template_directory() . '/analytics-dashboard.php';

// 8. Facebook Shop
require_once get_template_directory() . '/facebook-shop.php';

// 9. Customer Segmentation
require_once get_template_directory() . '/customer-segmentation.php';

// 10. Engraving Options
require_once get_template_directory() . '/engraving-options.php';

// 11. Order Tracking Page
require_once get_template_directory() . '/order-tracking-page.php';



// ========================================
// V74 - FIX FRONTEND + 5 FUNCIONES JOYERÍA
// ========================================

// Fix Theme Builder + Chats + Currency
require_once get_template_directory() . '/fix-frontend-v74.php';

// 12. Metal Selector Advanced
require_once get_template_directory() . '/metal-selector-advanced.php';

// 13. Gemstone Selector Advanced
require_once get_template_directory() . '/gemstone-selector-advanced.php';

// 14. Certificate of Authenticity
require_once get_template_directory() . '/certificate-authenticity.php';

// 15. Ring Size Guide
require_once get_template_directory() . '/ring-size-guide.php';

// 16. Bundle Discounts
require_once get_template_directory() . '/bundle-discounts.php';



// ========================================
// V75 - PANEL CONFIGURACIÓN CENTRALIZADO
// ========================================

// Panel de Settings Principal
require_once get_template_directory() . '/settings-panel-v75.php';

// Aplicar configuraciones
require_once get_template_directory() . '/apply-settings-v75.php';

// Página de Ayuda
require_once get_template_directory() . '/help-page-v75.php';



// ========================================
// V76 - FIX CHAT DUPLICADO + 5 FUNCIONES
// ========================================

// Fix Chat Amarillo Duplicado
require_once get_template_directory() . '/fix-chat-duplicate-v76.php';

// 17. Wishlist Sharing
require_once get_template_directory() . '/wishlist-sharing.php';

// 18. Pre-Orders
require_once get_template_directory() . '/pre-orders.php';

// 19. Repair Request
require_once get_template_directory() . '/repair-request.php';

// 20. Jewelry Care Guide
require_once get_template_directory() . '/jewelry-care-guide.php';

// 21. Gift Registry
require_once get_template_directory() . '/gift-registry.php';



// ========================================
// V77 - NUEVO CHAT SIMPLE + 5 FUNCIONES
// ========================================

// DESACTIVADO V78 - Reemplazado por total-cleanup
// require_once get_template_directory() . '/simple-chat-v77.php';

// 22. Financing Calculator
require_once get_template_directory() . '/financing-calculator.php';

// 23. Product Videos
require_once get_template_directory() . '/product-videos.php';

// 24. Size Chart
require_once get_template_directory() . '/size-chart.php';

// 25. Loyalty Points
require_once get_template_directory() . '/loyalty-points.php';

// 26. Virtual Try-On
require_once get_template_directory() . '/virtual-try-on.php';



// ========================================
// V78 - LIMPIEZA TOTAL Y FUNCIONALIDAD REAL
// ========================================

// Sistema único limpio
require_once get_template_directory() . '/total-cleanup-v78.php';

