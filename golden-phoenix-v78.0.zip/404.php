<?php
/**
 * 404 Error Template
 * Plantilla para página no encontrada
 */

get_header();
?>

<div class="error-404-wrapper" style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 40px 20px;">
    
    <div class="error-404-content" style="text-align: center; max-width: 800px;">
        
        <!-- NÚMERO 404 ANIMADO -->
        <div style="font-size: 180px; font-weight: 900; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 20px; line-height: 1;">
            404
        </div>
        
        <!-- EMOJI -->
        <div style="font-size: 80px; margin-bottom: 30px; animation: float 3s ease-in-out infinite;">
            😕
        </div>
        
        <!-- TÍTULO -->
        <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 20px;">
            ¡Página no encontrada!
        </h1>
        
        <!-- DESCRIPCIÓN -->
        <p style="font-size: 20px; color: #999; margin: 0 0 40px; line-height: 1.6;">
            Lo sentimos, la página que estás buscando no existe o fue movida. 
            Pero no te preocupes, podemos ayudarte a encontrar lo que necesitas.
        </p>
        
        <!-- FORMULARIO DE BÚSQUEDA -->
        <div style="max-width: 500px; margin: 0 auto 40px;">
            <form role="search" method="get" action="<?php echo home_url('/'); ?>" style="display: flex; gap: 10px;">
                <input type="search" name="s" placeholder="¿Qué estás buscando?" style="flex: 1; padding: 18px 30px; border: 2px solid rgba(201,169,97,0.3); border-radius: 50px; background: rgba(255,255,255,0.05); color: #fff; font-size: 16px; outline: none;">
                <button type="submit" style="background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 18px 35px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer; font-size: 16px; transition: all 0.3s;">
                    🔍 Buscar
                </button>
            </form>
        </div>
        
        <!-- ENLACES RÁPIDOS -->
        <div style="background: rgba(255,255,255,0.05); padding: 40px; border-radius: 20px; margin-bottom: 40px;">
            <h3 style="color: #c9a961; font-size: 24px; margin: 0 0 30px;">Enlaces útiles:</h3>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                
                <a href="<?php echo home_url('/'); ?>" style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                    <div style="font-size: 32px; margin-bottom: 10px;">🏠</div>
                    <div style="color: #fff; font-weight: 600; font-size: 16px;">Inicio</div>
                </a>
                
                <?php if (function_exists('WC')): ?>
                    <a href="<?php echo wc_get_page_permalink('shop'); ?>" style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                        <div style="font-size: 32px; margin-bottom: 10px;">🛍️</div>
                        <div style="color: #fff; font-weight: 600; font-size: 16px;">Tienda</div>
                    </a>
                <?php endif; ?>
                
                <?php
                $collections_page = get_page_by_title('Colecciones');
                if ($collections_page):
                ?>
                    <a href="<?php echo get_permalink($collections_page->ID); ?>" style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                        <div style="font-size: 32px; margin-bottom: 10px;">💎</div>
                        <div style="color: #fff; font-weight: 600; font-size: 16px;">Colecciones</div>
                    </a>
                <?php endif; ?>
                
                <?php
                $contact_page = get_page_by_title('Contacto');
                if ($contact_page):
                ?>
                    <a href="<?php echo get_permalink($contact_page->ID); ?>" style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                        <div style="font-size: 32px; margin-bottom: 10px;">📞</div>
                        <div style="color: #fff; font-weight: 600; font-size: 16px;">Contacto</div>
                    </a>
                <?php endif; ?>
                
            </div>
        </div>
        
        <!-- CATEGORÍAS POPULARES -->
        <?php if (function_exists('WC')): ?>
            <div style="margin-bottom: 40px;">
                <h3 style="color: #fff; font-size: 20px; margin: 0 0 20px;">Categorías Populares:</h3>
                <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 10px;">
                    <?php
                    $product_categories = get_terms('product_cat', array('hide_empty' => true, 'number' => 6));
                    if ($product_categories):
                        foreach ($product_categories as $category):
                            $category_link = get_term_link($category);
                    ?>
                        <a href="<?php echo esc_url($category_link); ?>" style="background: rgba(201,169,97,0.2); color: #c9a961; padding: 12px 24px; border-radius: 50px; text-decoration: none; font-weight: 600; transition: all 0.3s;">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- BOTÓN PRINCIPAL -->
        <div>
            <a href="<?php echo home_url('/'); ?>" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 20px 50px; border-radius: 50px; text-decoration: none; font-weight: 700; font-size: 18px; transition: all 0.3s; box-shadow: 0 10px 30px rgba(201,169,97,0.3);">
                🏠 Volver al Inicio
            </a>
        </div>
        
    </div>
    
</div>

<style>
@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
}
</style>

<?php get_footer(); ?>
