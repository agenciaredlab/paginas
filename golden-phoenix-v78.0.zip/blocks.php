<?php
/**
 * Golden Phoenix Jewelry - Bloques de Gutenberg
 * Bloques personalizados para edición visual fácil
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// REGISTRO DE BLOQUES GUTENBERG
// ============================================

/**
 * Registrar bloques personalizados
 */
function gp_register_blocks() {
    // Verificar que Gutenberg esté disponible
    if (!function_exists('register_block_type')) {
        return;
    }
    
    // Registrar script de bloques
    wp_register_script(
        'gp-blocks',
        GOLDEN_PHOENIX_URI . '/assets/js/blocks.js',
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n'),
        GOLDEN_PHOENIX_VERSION,
        true
    );
    
    // Registrar estilos de bloques
    wp_register_style(
        'gp-blocks-style',
        GOLDEN_PHOENIX_URI . '/assets/css/blocks.css',
        array(),
        GOLDEN_PHOENIX_VERSION
    );
    
    wp_register_style(
        'gp-blocks-editor',
        GOLDEN_PHOENIX_URI . '/assets/css/blocks-editor.css',
        array('wp-edit-blocks'),
        GOLDEN_PHOENIX_VERSION
    );
    
    // Bloque: Hero Section
    register_block_type('golden-phoenix/hero', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_hero_block',
        'attributes' => array(
            'title' => array(
                'type' => 'string',
                'default' => 'Elegancia Eterna'
            ),
            'subtitle' => array(
                'type' => 'string',
                'default' => 'Colección Exclusiva 2025'
            ),
            'description' => array(
                'type' => 'string',
                'default' => 'Descubre piezas únicas...'
            ),
            'backgroundImage' => array(
                'type' => 'string',
                'default' => ''
            ),
            'buttonText' => array(
                'type' => 'string',
                'default' => 'Explorar Colección'
            ),
            'buttonUrl' => array(
                'type' => 'string',
                'default' => '#collections'
            )
        )
    ));
    
    // Bloque: Productos Destacados
    register_block_type('golden-phoenix/featured-products', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_featured_products_block',
        'attributes' => array(
            'limit' => array(
                'type' => 'number',
                'default' => 8
            ),
            'columns' => array(
                'type' => 'number',
                'default' => 4
            ),
            'showQuickView' => array(
                'type' => 'boolean',
                'default' => true
            ),
            'showWishlist' => array(
                'type' => 'boolean',
                'default' => true
            )
        )
    ));
    
    // Bloque: Colecciones Grid
    register_block_type('golden-phoenix/collections-grid', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_collections_block',
        'attributes' => array(
            'limit' => array(
                'type' => 'number',
                'default' => 3
            ),
            'layout' => array(
                'type' => 'string',
                'default' => 'grid'
            )
        )
    ));
    
    // Bloque: Testimonios
    register_block_type('golden-phoenix/testimonials', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_testimonials_block',
        'attributes' => array(
            'limit' => array(
                'type' => 'number',
                'default' => 3
            ),
            'style' => array(
                'type' => 'string',
                'default' => 'slider'
            )
        )
    ));
    
    // Bloque: Estadísticas
    register_block_type('golden-phoenix/stats', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_stats_block',
        'attributes' => array(
            'stats' => array(
                'type' => 'array',
                'default' => array(
                    array('number' => '1892', 'label' => 'Fundación'),
                    array('number' => '50+', 'label' => 'Maestros Joyeros'),
                    array('number' => '200k+', 'label' => 'Piezas Creadas')
                )
            )
        )
    ));
    
    // Bloque: Botón Luxury
    register_block_type('golden-phoenix/button', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_button_block',
        'attributes' => array(
            'text' => array(
                'type' => 'string',
                'default' => 'Ver Más'
            ),
            'url' => array(
                'type' => 'string',
                'default' => '#'
            ),
            'style' => array(
                'type' => 'string',
                'default' => 'primary'
            ),
            'size' => array(
                'type' => 'string',
                'default' => 'medium'
            )
        )
    ));
    
    // Bloque: Newsletter
    register_block_type('golden-phoenix/newsletter', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_newsletter_block',
        'attributes' => array(
            'title' => array(
                'type' => 'string',
                'default' => 'Únete a Nuestro Círculo Exclusivo'
            ),
            'description' => array(
                'type' => 'string',
                'default' => 'Recibe acceso anticipado...'
            ),
            'placeholder' => array(
                'type' => 'string',
                'default' => 'Tu correo electrónico'
            )
        )
    ));
    
    // Bloque: Beneficios de Membresía
    register_block_type('golden-phoenix/membership-benefits', array(
        'editor_script' => 'gp-blocks',
        'style' => 'gp-blocks-style',
        'editor_style' => 'gp-blocks-editor',
        'render_callback' => 'gp_render_membership_benefits_block',
        'attributes' => array(
            'membershipLevel' => array(
                'type' => 'string',
                'default' => 'vip_gold'
            )
        )
    ));
}
add_action('init', 'gp_register_blocks');

// ============================================
// FUNCIONES DE RENDERIZADO DE BLOQUES
// ============================================

/**
 * Renderizar bloque Hero
 */
function gp_render_hero_block($attributes) {
    $title = esc_html($attributes['title']);
    $subtitle = esc_html($attributes['subtitle']);
    $description = esc_html($attributes['description']);
    $bg_image = esc_url($attributes['backgroundImage']);
    $button_text = esc_html($attributes['buttonText']);
    $button_url = esc_url($attributes['buttonUrl']);
    
    ob_start();
    ?>
    <section class="hero-section gp-block-hero">
        <?php if ($bg_image): ?>
            <img src="<?php echo $bg_image; ?>" alt="Hero Background" class="hero-background">
        <?php endif; ?>
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <p class="hero-subtitle"><?php echo $subtitle; ?></p>
            <h1 class="hero-title"><?php echo $title; ?></h1>
            <p class="hero-description"><?php echo $description; ?></p>
            <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 2rem;">
                <a href="<?php echo $button_url; ?>" class="btn-luxury"><?php echo $button_text; ?></a>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}

/**
 * Renderizar bloque Productos Destacados
 */
function gp_render_featured_products_block($attributes) {
    $limit = intval($attributes['limit']);
    $columns = intval($attributes['columns']);
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $limit,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_visibility',
                'field' => 'name',
                'terms' => 'featured',
            )
        )
    );
    
    $query = new WP_Query($args);
    
    ob_start();
    
    if ($query->have_posts()):
    ?>
    <section class="featured-products gp-block-products" style="--columns: <?php echo $columns; ?>">
        <div class="products-grid">
            <?php while ($query->have_posts()): $query->the_post();
                $product = wc_get_product(get_the_ID());
            ?>
            <div class="product-card" data-product-id="<?php echo get_the_ID(); ?>">
                <div class="product-image-wrapper">
                    <?php echo get_the_post_thumbnail(get_the_ID(), 'large', array('class' => 'product-image')); ?>
                    <?php if ($attributes['showWishlist']): ?>
                        <div class="product-wishlist">♡</div>
                    <?php endif; ?>
                </div>
                <div class="product-info">
                    <p class="product-category"><?php echo wc_get_product_category_list(get_the_ID()); ?></p>
                    <h3 class="product-name"><?php the_title(); ?></h3>
                    <p class="product-price"><?php echo $product->get_price_html(); ?></p>
                </div>
                <?php if ($attributes['showQuickView']): ?>
                    <div class="product-quick-view">Vista Rápida</div>
                <?php endif; ?>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php
    endif;
    
    return ob_get_clean();
}

/**
 * Renderizar bloque Colecciones
 */
function gp_render_collections_block($attributes) {
    $limit = intval($attributes['limit']);
    
    $args = array(
        'post_type' => 'collection',
        'posts_per_page' => $limit,
        'post_status' => 'publish'
    );
    
    $query = new WP_Query($args);
    
    ob_start();
    
    if ($query->have_posts()):
    ?>
    <section class="collections-section gp-block-collections">
        <div class="collections-grid">
            <?php while ($query->have_posts()): $query->the_post(); ?>
            <div class="collection-card">
                <?php echo get_the_post_thumbnail(get_the_ID(), 'large', array('class' => 'collection-image')); ?>
                <div class="collection-overlay">
                    <h3 class="collection-name"><?php the_title(); ?></h3>
                    <p class="collection-count"><?php echo get_post_meta(get_the_ID(), '_collection_pieces_count', true); ?> Piezas</p>
                </div>
                <span class="collection-cta">Ver Colección →</span>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php
    endif;
    
    return ob_get_clean();
}

/**
 * Renderizar bloque Testimonios
 */
function gp_render_testimonials_block($attributes) {
    $limit = intval($attributes['limit']);
    
    $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => $limit,
        'post_status' => 'publish'
    );
    
    $query = new WP_Query($args);
    
    ob_start();
    
    if ($query->have_posts()):
    ?>
    <section class="testimonials-section gp-block-testimonials">
        <div class="testimonials-slider">
            <?php while ($query->have_posts()): $query->the_post();
                $rating = get_post_meta(get_the_ID(), '_testimonial_rating', true);
                $author_title = get_post_meta(get_the_ID(), '_testimonial_author_title', true);
            ?>
            <div class="testimonial-card">
                <div class="testimonial-stars">
                    <?php for ($i = 0; $i < intval($rating); $i++): ?>★<?php endfor; ?>
                </div>
                <p class="testimonial-quote"><?php the_content(); ?></p>
                <div class="testimonial-author">
                    <?php echo get_the_post_thumbnail(get_the_ID(), 'thumbnail', array('class' => 'author-image')); ?>
                    <div class="author-info">
                        <h4><?php the_title(); ?></h4>
                        <p class="author-title"><?php echo esc_html($author_title); ?></p>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php
    endif;
    
    return ob_get_clean();
}

/**
 * Renderizar bloque Estadísticas
 */
function gp_render_stats_block($attributes) {
    $stats = $attributes['stats'];
    
    ob_start();
    ?>
    <section class="heritage-stats gp-block-stats">
        <?php foreach ($stats as $stat): ?>
        <div class="stat-item">
            <span class="stat-number"><?php echo esc_html($stat['number']); ?></span>
            <span class="stat-label"><?php echo esc_html($stat['label']); ?></span>
        </div>
        <?php endforeach; ?>
    </section>
    <?php
    return ob_get_clean();
}

/**
 * Renderizar bloque Botón
 */
function gp_render_button_block($attributes) {
    $text = esc_html($attributes['text']);
    $url = esc_url($attributes['url']);
    $style = esc_attr($attributes['style']);
    $size = esc_attr($attributes['size']);
    
    $classes = "btn-luxury btn-{$style} btn-{$size}";
    
    return sprintf(
        '<a href="%s" class="%s">%s</a>',
        $url,
        $classes,
        $text
    );
}

/**
 * Renderizar bloque Newsletter
 */
function gp_render_newsletter_block($attributes) {
    $title = esc_html($attributes['title']);
    $description = esc_html($attributes['description']);
    $placeholder = esc_attr($attributes['placeholder']);
    
    ob_start();
    ?>
    <section class="newsletter-section gp-block-newsletter">
        <div class="newsletter-container">
            <h2><?php echo $title; ?></h2>
            <p class="newsletter-text"><?php echo $description; ?></p>
            
            <form class="newsletter-form" method="post">
                <input type="email" name="email" class="newsletter-input" placeholder="<?php echo $placeholder; ?>" required>
                <button type="submit" class="newsletter-submit">Suscribirse</button>
            </form>
        </div>
    </section>
    <?php
    return ob_get_clean();
}

/**
 * Renderizar bloque Beneficios de Membresía
 */
function gp_render_membership_benefits_block($attributes) {
    $level = $attributes['membershipLevel'];
    $levels = get_option('gp_membership_levels');
    
    if (!isset($levels[$level])) {
        return '<p>Nivel de membresía no encontrado.</p>';
    }
    
    $membership = $levels[$level];
    
    ob_start();
    ?>
    <div class="membership-benefits-block">
        <h3><?php echo esc_html($membership['name']); ?></h3>
        <p class="membership-price">$<?php echo number_format($membership['price'], 2); ?> / mes</p>
        <ul class="benefits-list">
            <?php foreach ($membership['benefits'] as $benefit): ?>
                <li>✓ <?php echo esc_html($benefit); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}

// ============================================
// CATEGORÍA DE BLOQUES PERSONALIZADA
// ============================================

/**
 * Registrar categoría de bloques
 */
function gp_block_categories($categories) {
    return array_merge(
        $categories,
        array(
            array(
                'slug' => 'golden-phoenix',
                'title' => 'Golden Phoenix Jewelry',
                'icon' => 'awards'
            )
        )
    );
}
add_filter('block_categories_all', 'gp_block_categories', 10, 2);

// ============================================
// SOPORTE PARA EDITOR DE BLOQUES
// ============================================

/**
 * Agregar soporte completo para Gutenberg
 */
function gp_gutenberg_support() {
    // Soporte para alineación ancha y completa
    add_theme_support('align-wide');
    
    // Soporte para estilos de bloque
    add_theme_support('wp-block-styles');
    
    // Soporte para responsive embeds
    add_theme_support('responsive-embeds');
    
    // Soporte para paleta de colores personalizada
    add_theme_support('editor-color-palette', array(
        array(
            'name' => 'Dorado Principal',
            'slug' => 'gold-primary',
            'color' => '#D4AF37',
        ),
        array(
            'name' => 'Dorado Claro',
            'slug' => 'gold-light',
            'color' => '#F4E4C1',
        ),
        array(
            'name' => 'Negro Profundo',
            'slug' => 'black-deep',
            'color' => '#0A0A0A',
        ),
        array(
            'name' => 'Blanco Puro',
            'slug' => 'white-pure',
            'color' => '#FFFFFF',
        ),
        array(
            'name' => 'Blanco Crema',
            'slug' => 'white-cream',
            'color' => '#FAF9F6',
        ),
    ));
    
    // Soporte para tamaños de fuente personalizados
    add_theme_support('editor-font-sizes', array(
        array(
            'name' => 'Pequeño',
            'size' => 14,
            'slug' => 'small'
        ),
        array(
            'name' => 'Normal',
            'size' => 16,
            'slug' => 'normal'
        ),
        array(
            'name' => 'Mediano',
            'size' => 20,
            'slug' => 'medium'
        ),
        array(
            'name' => 'Grande',
            'size' => 28,
            'slug' => 'large'
        ),
        array(
            'name' => 'Enorme',
            'size' => 42,
            'slug' => 'huge'
        )
    ));
    
    // Deshabilitar tamaños y colores personalizados (opcional)
    add_theme_support('disable-custom-font-sizes');
    add_theme_support('disable-custom-colors');
}
add_action('after_setup_theme', 'gp_gutenberg_support');

/**
 * Estilos del editor para que coincidan con el frontend
 */
function gp_editor_styles() {
    add_editor_style('assets/css/editor-style.css');
}
add_action('after_setup_theme', 'gp_editor_styles');

/**
 * Enqueue scripts y estilos para el editor
 */
function gp_enqueue_block_editor_assets() {
    wp_enqueue_script(
        'gp-block-editor',
        GOLDEN_PHOENIX_URI . '/assets/js/block-editor.js',
        array('wp-blocks', 'wp-dom-ready', 'wp-edit-post'),
        GOLDEN_PHOENIX_VERSION,
        true
    );
}
add_action('enqueue_block_editor_assets', 'gp_enqueue_block_editor_assets');
