<?php
if (!defined('ABSPATH')) exit;

class GP_Elementor_Hero_Section extends \Elementor\Widget_Base {
    
    public function get_name() { return 'gp_hero'; }
    public function get_title() { return '🎭 Hero Section'; }
    public function get_icon() { return 'eicon-header'; }
    public function get_categories() { return ['golden-phoenix']; }
    
    protected function register_controls() {
        $this->start_controls_section('content', ['label' => 'Contenido']);
        $this->add_control('bg_image', ['label' => 'Imagen Fondo', 'type' => \Elementor\Controls_Manager::MEDIA]);
        $this->add_control('title', ['label' => 'Título', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'ELEGANCIA ETERNA']);
        $this->add_control('subtitle', ['label' => 'Subtítulo', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Descubre piezas únicas']);
        $this->end_controls_section();
        
        $this->start_controls_section('style', ['label' => 'Estilo', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('overlay_opacity', ['label' => 'Opacidad Overlay', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => ['px' => ['min' => 0, 'max' => 100]], 'default' => ['size' => 80]]);
        $this->add_control('title_color', ['label' => 'Color Título', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '#D4AF37']);
        $this->add_control('subtitle_color', ['label' => 'Color Subtítulo', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '#CCCCCC']);
        $this->add_responsive_control('height', ['label' => 'Altura', 'type' => \Elementor\Controls_Manager::SLIDER, 'range' => ['px' => ['min' => 300, 'max' => 1000]], 'default' => ['size' => 600], 'selectors' => ['{{WRAPPER}} .gp-hero' => 'min-height: {{SIZE}}{{UNIT}};']]);
        $this->end_controls_section();
    }
    
    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <div class="gp-hero" style="background-image: url(<?php echo esc_url($s['bg_image']['url']); ?>); background-size: cover; background-position: center; position: relative; display: flex; align-items: center; justify-content: center; text-align: center; padding: 60px 20px;">
            <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,<?php echo $s['overlay_opacity']['size'] / 100; ?>);"></div>
            <div style="position: relative; z-index: 2;">
                <h1 style="color: <?php echo $s['title_color']; ?>; font-size: 80px; margin: 0 0 20px; letter-spacing: 0.2em;"><?php echo esc_html($s['title']); ?></h1>
                <p style="color: <?php echo $s['subtitle_color']; ?>; font-size: 24px; margin: 0;"><?php echo esc_html($s['subtitle']); ?></p>
            </div>
        </div>
        <?php
    }
}
