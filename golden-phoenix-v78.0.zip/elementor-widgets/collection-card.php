<?php
if (!defined('ABSPATH')) exit;

class GP_Elementor_Collection_Card extends \Elementor\Widget_Base {
    
    public function get_name() { return 'gp_collection_card'; }
    public function get_title() { return '🖼️ Tarjeta Colección'; }
    public function get_icon() { return 'eicon-gallery-grid'; }
    public function get_categories() { return ['golden-phoenix']; }
    
    protected function register_controls() {
        // Contenido
        $this->start_controls_section('content', ['label' => 'Contenido']);
        $this->add_control('image', ['label' => 'Imagen', 'type' => \Elementor\Controls_Manager::MEDIA]);
        $this->add_control('title', ['label' => 'Título', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'Anillos']);
        $this->add_control('desc', ['label' => 'Descripción', 'type' => \Elementor\Controls_Manager::TEXTAREA, 'default' => 'Elegancia eterna']);
        $this->add_control('btn_text', ['label' => 'Texto Botón', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'VER COLECCIÓN']);
        $this->add_control('btn_link', ['label' => 'Enlace', 'type' => \Elementor\Controls_Manager::URL]);
        $this->end_controls_section();
        
        // Estilos
        $this->start_controls_section('style', ['label' => 'Estilo', 'tab' => \Elementor\Controls_Manager::TAB_STYLE]);
        $this->add_control('title_color', ['label' => 'Color Título', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '#D4AF37']);
        $this->add_control('desc_color', ['label' => 'Color Descripción', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => '#CCCCCC']);
        $this->add_control('bg_color', ['label' => 'Fondo', 'type' => \Elementor\Controls_Manager::COLOR, 'default' => 'transparent']);
        $this->add_responsive_control('padding', ['label' => 'Padding', 'type' => \Elementor\Controls_Manager::DIMENSIONS, 'selectors' => ['{{WRAPPER}} .gp-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};']]);
        $this->end_controls_section();
    }
    
    protected function render() {
        $s = $this->get_settings_for_display();
        ?>
        <div class="gp-card" style="background: <?php echo $s['bg_color']; ?>; text-align: center;">
            <?php if ($s['image']['url']): ?>
                <img src="<?php echo esc_url($s['image']['url']); ?>" style="width: 100%; height: auto;">
            <?php endif; ?>
            <h3 style="color: <?php echo $s['title_color']; ?>; margin: 20px 0 10px;"><?php echo esc_html($s['title']); ?></h3>
            <p style="color: <?php echo $s['desc_color']; ?>; margin: 0 0 20px;"><?php echo esc_html($s['desc']); ?></p>
            <a href="<?php echo esc_url($s['btn_link']['url']); ?>" style="display: inline-block; padding: 12px 35px; border: 1px solid <?php echo $s['title_color']; ?>; color: <?php echo $s['title_color']; ?>; text-decoration: none;">
                <?php echo esc_html($s['btn_text']); ?>
            </a>
        </div>
        <?php
    }
}
