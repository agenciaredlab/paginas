<?php
/**
 * WIDGET ELEMENTOR: BOTÓN LUXURY
 * Botón totalmente personalizable
 */

if (!defined('ABSPATH')) exit;

class GP_Elementor_Luxury_Button extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'gp_luxury_button';
    }
    
    public function get_title() {
        return '✨ Botón Luxury';
    }
    
    public function get_icon() {
        return 'eicon-button';
    }
    
    public function get_categories() {
        return ['golden-phoenix'];
    }
    
    protected function register_controls() {
        
        // SECCIÓN: CONTENIDO
        $this->start_controls_section(
            'content_section',
            [
                'label' => '📝 Contenido',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'button_text',
            [
                'label' => 'Texto del botón',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'VER COLECCIÓN',
                'dynamic' => ['active' => true],
            ]
        );
        
        $this->add_control(
            'button_link',
            [
                'label' => 'Enlace',
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => '/producto-categoria/anillos',
                'default' => [
                    'url' => '#',
                ],
                'dynamic' => ['active' => true],
            ]
        );
        
        $this->end_controls_section();
        
        // SECCIÓN: ESTILO
        $this->start_controls_section(
            'style_section',
            [
                'label' => '🎨 Estilo',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'text_color',
            [
                'label' => 'Color de texto',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#D4AF37',
            ]
        );
        
        $this->add_control(
            'background_color',
            [
                'label' => 'Color de fondo',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'transparent',
            ]
        );
        
        $this->add_control(
            'hover_text_color',
            [
                'label' => 'Color de texto (hover)',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#000000',
            ]
        );
        
        $this->add_control(
            'hover_background_color',
            [
                'label' => 'Color de fondo (hover)',
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#D4AF37',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'label' => 'Tipografía',
                'selector' => '{{WRAPPER}} .gp-luxury-btn',
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'label' => 'Borde',
                'selector' => '{{WRAPPER}} .gp-luxury-btn',
            ]
        );
        
        $this->add_control(
            'border_radius',
            [
                'label' => 'Redondez de esquinas',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .gp-luxury-btn' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'padding',
            [
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => 12,
                    'right' => 35,
                    'bottom' => 12,
                    'left' => 35,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .gp-luxury-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'align',
            [
                'label' => 'Alineación',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => 'Izquierda',
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => 'Centro',
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => 'Derecha',
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .gp-luxury-btn-wrapper' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'button_width',
            [
                'label' => 'Ancho del botón',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'auto' => 'Automático',
                    '100%' => 'Ancho completo (100%)',
                    '75%' => '75%',
                    '50%' => '50%',
                    '25%' => '25%',
                ],
                'default' => 'auto',
                'selectors' => [
                    '{{WRAPPER}} .gp-luxury-btn' => 'width: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $this->add_render_attribute('button', 'class', 'gp-luxury-btn');
        $this->add_render_attribute('button', 'href', $settings['button_link']['url']);
        
        if ($settings['button_link']['is_external']) {
            $this->add_render_attribute('button', 'target', '_blank');
        }
        
        if ($settings['button_link']['nofollow']) {
            $this->add_render_attribute('button', 'rel', 'nofollow');
        }
        
        $this->add_render_attribute('button', 'style', sprintf(
            'background-color: %s; color: %s; transition: all 0.3s ease; display: inline-block; text-decoration: none;',
            $settings['background_color'],
            $settings['text_color']
        ));
        
        $this->add_render_attribute('button', 'data-hover-bg', $settings['hover_background_color']);
        $this->add_render_attribute('button', 'data-hover-color', $settings['hover_text_color']);
        $this->add_render_attribute('button', 'data-normal-bg', $settings['background_color']);
        $this->add_render_attribute('button', 'data-normal-color', $settings['text_color']);
        
        ?>
        <div class="gp-luxury-btn-wrapper">
            <a <?php echo $this->get_render_attribute_string('button'); ?>>
                <?php echo esc_html($settings['button_text']); ?>
            </a>
        </div>
        
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var btn = document.querySelector('.elementor-element-<?php echo $this->get_id(); ?> .gp-luxury-btn');
            if (btn) {
                btn.addEventListener('mouseenter', function() {
                    this.style.backgroundColor = this.dataset.hoverBg;
                    this.style.color = this.dataset.hoverColor;
                });
                btn.addEventListener('mouseleave', function() {
                    this.style.backgroundColor = this.dataset.normalBg;
                    this.style.color = this.dataset.normalColor;
                });
            }
        });
        </script>
        <?php
    }
}
