<?php
/**
 * Golden Phoenix V73 - FIX CHATS DUPLICADOS
 * Elimina configuraciones duplicadas y arregla botones
 */

if (!defined('ABSPATH')) exit;

// ========================================
// ELIMINAR CONFIGURACIONES DUPLICADAS
// ========================================

add_action('customize_register', 'gp_v73_remove_duplicates', 999);

function gp_v73_remove_duplicates($wp_customize) {
    // Eliminar "Chat WhatsApp" duplicado del visual-builder
    if ($wp_customize->get_section('gp_chat_section')) {
        $wp_customize->remove_section('gp_chat_section');
    }
    
    if ($wp_customize->get_setting('gp_chat_whatsapp')) {
        $wp_customize->remove_setting('gp_chat_whatsapp');
    }
    
    if ($wp_customize->get_control('gp_chat_whatsapp')) {
        $wp_customize->remove_control('gp_chat_whatsapp');
    }
}

// ========================================
// FIX LIVE CHAT BUTTON
// ========================================

add_action('wp_footer', 'gp_v73_fix_live_chat_button', 99);

function gp_v73_fix_live_chat_button() {
    $live_chat_enabled = get_option('gp_live_chat_enabled', false);
    
    if (!$live_chat_enabled) {
        return;
    }
    ?>
    
    <style>
    /* Asegurar que botón live chat sea visible y funcional */
    .gp-live-chat-trigger {
        position: fixed;
        bottom: 90px; /* Arriba del WhatsApp */
        right: 20px;
        background: #0084FF;
        color: white;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0, 132, 255, 0.4);
        z-index: 9998;
        transition: all 0.3s ease;
    }
    
    .gp-live-chat-trigger:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px rgba(0, 132, 255, 0.6);
    }
    
    .gp-live-chat-widget {
        position: fixed;
        bottom: 160px;
        right: 20px;
        width: 350px;
        height: 500px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 8px 30px rgba(0,0,0,0.2);
        z-index: 9999;
        display: none;
        flex-direction: column;
    }
    
    .gp-live-chat-widget.active {
        display: flex;
    }
    
    .gp-chat-header {
        background: linear-gradient(135deg, #0084FF, #0056CC);
        color: white;
        padding: 20px;
        border-radius: 12px 12px 0 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .gp-chat-close {
        background: none;
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        padding: 0;
        width: 30px;
        height: 30px;
    }
    
    .gp-chat-messages {
        flex: 1;
        overflow-y: auto;
        padding: 20px;
        background: #f5f5f5;
    }
    
    .gp-chat-input-area {
        padding: 15px;
        border-top: 1px solid #ddd;
        display: flex;
        gap: 10px;
    }
    
    .gp-chat-input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 20px;
        outline: none;
    }
    
    .gp-chat-send {
        background: #0084FF;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 20px;
        cursor: pointer;
    }
    
    @media (max-width: 768px) {
        .gp-live-chat-widget {
            width: calc(100% - 40px);
            height: calc(100vh - 200px);
            right: 20px;
            bottom: 160px;
        }
    }
    </style>
    
    <!-- Botón flotante Chat en Vivo -->
    <div class="gp-live-chat-trigger" onclick="gpToggleChat()">
        <svg width="30" height="30" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12c0 1.54.36 3 .97 4.29L2 22l5.71-.97C9 21.64 10.46 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.38 0-2.67-.33-3.82-.91L4 20l.91-4.18C4.33 14.67 4 13.38 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8z"/>
            <circle cx="8.5" cy="12" r="1.5"/>
            <circle cx="12" cy="12" r="1.5"/>
            <circle cx="15.5" cy="12" r="1.5"/>
        </svg>
    </div>
    
    <!-- Widget de Chat -->
    <div class="gp-live-chat-widget" id="gp-chat-widget">
        <div class="gp-chat-header">
            <div>
                <h4 style="margin: 0;">💬 Chat en Vivo</h4>
                <small style="opacity: 0.9;">Estamos aquí para ayudarte</small>
            </div>
            <button class="gp-chat-close" onclick="gpToggleChat()">×</button>
        </div>
        
        <div class="gp-chat-messages" id="gp-chat-messages">
            <div style="text-align: center; padding: 40px 20px; color: #666;">
                <p>👋 ¡Hola! ¿En qué podemos ayudarte?</p>
            </div>
        </div>
        
        <div class="gp-chat-input-area">
            <input type="text" 
                   class="gp-chat-input" 
                   id="gp-chat-input"
                   placeholder="Escribe tu mensaje..."
                   onkeypress="if(event.key==='Enter') gpSendMessage()">
            <button class="gp-chat-send" onclick="gpSendMessage()">
                Enviar
            </button>
        </div>
    </div>
    
    <script>
    function gpToggleChat() {
        var widget = document.getElementById('gp-chat-widget');
        widget.classList.toggle('active');
        
        if (widget.classList.contains('active')) {
            document.getElementById('gp-chat-input').focus();
        }
    }
    
    function gpSendMessage() {
        var input = document.getElementById('gp-chat-input');
        var message = input.value.trim();
        
        if (!message) return;
        
        var messagesDiv = document.getElementById('gp-chat-messages');
        
        // Agregar mensaje del usuario
        messagesDiv.innerHTML += '<div style="text-align: right; margin-bottom: 10px;"><div style="display: inline-block; background: #0084FF; color: white; padding: 10px 15px; border-radius: 18px 18px 4px 18px; max-width: 70%;">' + message + '</div></div>';
        
        input.value = '';
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        
        // Simular respuesta (en producción conectar con sistema real)
        setTimeout(function() {
            messagesDiv.innerHTML += '<div style="text-align: left; margin-bottom: 10px;"><div style="display: inline-block; background: white; color: #333; padding: 10px 15px; border-radius: 18px 18px 18px 4px; max-width: 70%; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">Gracias por tu mensaje. Un agente te responderá pronto.</div></div>';
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }, 1000);
    }
    </script>
    
    <?php
}

// Activar chat en vivo por defecto
add_action('after_switch_theme', 'gp_v73_enable_live_chat');

function gp_v73_enable_live_chat() {
    if (get_option('gp_v73_chat_initialized')) {
        return;
    }
    
    update_option('gp_live_chat_enabled', true);
    update_option('gp_v73_chat_initialized', true);
}

// ========================================
// ADMIN: CONFIGURACIÓN SIMPLIFICADA
// ========================================

add_action('admin_menu', 'gp_v73_chat_admin_menu');

function gp_v73_chat_admin_menu() {
    add_submenu_page(
        'options-general.php',
        'Configuración Chat',
        'Chat en Vivo',
        'manage_options',
        'gp-chat-config',
        'gp_v73_chat_admin_page'
    );
}

function gp_v73_chat_admin_page() {
    if (isset($_POST['gp_save_chat'])) {
        check_admin_referer('gp_chat_settings');
        update_option('gp_live_chat_enabled', isset($_POST['live_chat_enabled']));
        echo '<div class="notice notice-success"><p>Configuración guardada</p></div>';
    }
    
    $enabled = get_option('gp_live_chat_enabled', true);
    ?>
    
    <div class="wrap">
        <h1>💬 Configuración de Chat</h1>
        
        <form method="post">
            <?php wp_nonce_field('gp_chat_settings'); ?>
            
            <table class="form-table">
                <tr>
                    <th>Chat en Vivo</th>
                    <td>
                        <label>
                            <input type="checkbox" name="live_chat_enabled" value="1" <?php checked($enabled); ?>>
                            Habilitar chat en vivo en el sitio
                        </label>
                        <p class="description">
                            Muestra un botón flotante de chat azul encima del botón de WhatsApp
                        </p>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" name="gp_save_chat" class="button button-primary">
                    Guardar Cambios
                </button>
            </p>
        </form>
        
        <hr>
        
        <h2>📊 Resumen de Botones Flotantes:</h2>
        <ul>
            <li><strong>WhatsApp (Verde):</strong> <?php echo get_theme_mod('gp_whatsapp_floating_enabled', true) ? '✅ Activo' : '❌ Desactivado'; ?></li>
            <li><strong>Chat en Vivo (Azul):</strong> <?php echo $enabled ? '✅ Activo' : '❌ Desactivado'; ?></li>
        </ul>
        
        <p><strong>Nota:</strong> El chat en vivo aparece arriba del WhatsApp para no sobreponerse.</p>
    </div>
    
    <?php
}
