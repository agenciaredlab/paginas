<?php
/**
 * Golden Phoenix Jewelry - REST API Extendida
 * 30+ Endpoints para Integraciones Completas
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// REGISTRO DE ENDPOINTS EXTENDIDOS
// ============================================

add_action('rest_api_init', function() {
    $namespace = 'golden-phoenix/v1';
    
    // ============================================
    // PRODUCTOS (8 endpoints)
    // ============================================
    
    // 1. Productos por categoría
    register_rest_route($namespace, '/products/category/(?P<slug>[a-zA-Z0-9-]+)', array(
        'methods' => 'GET',
        'callback' => 'gp_api_products_by_category',
        'permission_callback' => '__return_true'
    ));
    
    // 2. Producto individual con detalles completos
    register_rest_route($namespace, '/products/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'gp_api_single_product',
        'permission_callback' => '__return_true'
    ));
    
    // 3. Productos más vendidos
    register_rest_route($namespace, '/products/bestsellers', array(
        'methods' => 'GET',
        'callback' => 'gp_api_bestsellers',
        'permission_callback' => '__return_true'
    ));
    
    // 4. Productos en oferta
    register_rest_route($namespace, '/products/on-sale', array(
        'methods' => 'GET',
        'callback' => 'gp_api_on_sale_products',
        'permission_callback' => '__return_true'
    ));
    
    // 5. Productos relacionados
    register_rest_route($namespace, '/products/(?P<id>\d+)/related', array(
        'methods' => 'GET',
        'callback' => 'gp_api_related_products',
        'permission_callback' => '__return_true'
    ));
    
    // 6. Búsqueda avanzada de productos
    register_rest_route($namespace, '/products/search', array(
        'methods' => 'POST',
        'callback' => 'gp_api_search_products',
        'permission_callback' => '__return_true'
    ));
    
    // 7. Filtrar productos
    register_rest_route($namespace, '/products/filter', array(
        'methods' => 'POST',
        'callback' => 'gp_api_filter_products',
        'permission_callback' => '__return_true'
    ));
    
    // 8. Stock de producto
    register_rest_route($namespace, '/products/(?P<id>\d+)/stock', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_stock',
        'permission_callback' => '__return_true'
    ));
    
    // ============================================
    // CARRITO (6 endpoints)
    // ============================================
    
    // 9. Ver carrito
    register_rest_route($namespace, '/cart', array(
        'methods' => 'GET',
        'callback' => 'gp_api_get_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 10. Agregar al carrito
    register_rest_route($namespace, '/cart/add', array(
        'methods' => 'POST',
        'callback' => 'gp_api_add_to_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 11. Actualizar cantidad en carrito
    register_rest_route($namespace, '/cart/update', array(
        'methods' => 'POST',
        'callback' => 'gp_api_update_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 12. Remover del carrito
    register_rest_route($namespace, '/cart/remove', array(
        'methods' => 'POST',
        'callback' => 'gp_api_remove_from_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 13. Aplicar cupón
    register_rest_route($namespace, '/cart/apply-coupon', array(
        'methods' => 'POST',
        'callback' => 'gp_api_apply_coupon',
        'permission_callback' => '__return_true'
    ));
    
    // 14. Vaciar carrito
    register_rest_route($namespace, '/cart/clear', array(
        'methods' => 'POST',
        'callback' => 'gp_api_clear_cart',
        'permission_callback' => '__return_true'
    ));
    
    // ============================================
    // ÓRDENES (5 endpoints)
    // ============================================
    
    // 15. Crear orden
    register_rest_route($namespace, '/orders/create', array(
        'methods' => 'POST',
        'callback' => 'gp_api_create_order',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 16. Órdenes del usuario
    register_rest_route($namespace, '/orders/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_orders',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 17. Detalle de orden
    register_rest_route($namespace, '/orders/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'gp_api_order_details',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 18. Actualizar estado de orden
    register_rest_route($namespace, '/orders/(?P<id>\d+)/status', array(
        'methods' => 'POST',
        'callback' => 'gp_api_update_order_status',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 19. Tracking de envío
    register_rest_route($namespace, '/orders/(?P<id>\d+)/tracking', array(
        'methods' => 'GET',
        'callback' => 'gp_api_order_tracking',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // CLIENTES/USUARIOS (5 endpoints)
    // ============================================
    
    // 20. Perfil de usuario
    register_rest_route($namespace, '/customer/profile', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_profile',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 21. Actualizar perfil
    register_rest_route($namespace, '/customer/update', array(
        'methods' => 'POST',
        'callback' => 'gp_api_update_customer',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 22. Direcciones guardadas
    register_rest_route($namespace, '/customer/addresses', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_addresses',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 23. Agregar dirección
    register_rest_route($namespace, '/customer/addresses/add', array(
        'methods' => 'POST',
        'callback' => 'gp_api_add_address',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 24. Métodos de pago del cliente
    register_rest_route($namespace, '/customer/payment-methods', array(
        'methods' => 'GET',
        'callback' => 'gp_api_payment_methods',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // MEMBRESÍAS (4 endpoints)
    // ============================================
    
    // 25. Niveles de membresía
    register_rest_route($namespace, '/memberships/levels', array(
        'methods' => 'GET',
        'callback' => 'gp_api_membership_levels',
        'permission_callback' => '__return_true'
    ));
    
    // 26. Membresía del usuario
    register_rest_route($namespace, '/memberships/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_membership',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 27. Beneficios utilizados
    register_rest_route($namespace, '/memberships/benefits/used', array(
        'methods' => 'GET',
        'callback' => 'gp_api_benefits_used',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 28. Registrar uso de beneficio
    register_rest_route($namespace, '/memberships/benefits/log', array(
        'methods' => 'POST',
        'callback' => 'gp_api_log_benefit',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // RESEÑAS (3 endpoints)
    // ============================================
    
    // 29. Reseñas de producto
    register_rest_route($namespace, '/reviews/product/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_reviews',
        'permission_callback' => '__return_true'
    ));
    
    // 30. Crear reseña
    register_rest_route($namespace, '/reviews/create', array(
        'methods' => 'POST',
        'callback' => 'gp_api_create_review',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 31. Reseñas del usuario
    register_rest_route($namespace, '/reviews/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_reviews',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // CUPONES Y DESCUENTOS (3 endpoints)
    // ============================================
    
    // 32. Validar cupón
    register_rest_route($namespace, '/coupons/validate', array(
        'methods' => 'POST',
        'callback' => 'gp_api_validate_coupon',
        'permission_callback' => '__return_true'
    ));
    
    // 33. Cupones del usuario
    register_rest_route($namespace, '/coupons/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_coupons',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 34. Generar cupón personalizado
    register_rest_route($namespace, '/coupons/generate', array(
        'methods' => 'POST',
        'callback' => 'gp_api_generate_coupon',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // ============================================
    // ANALYTICS Y REPORTES (4 endpoints)
    // ============================================
    
    // 35. Ventas por periodo
    register_rest_route($namespace, '/analytics/sales', array(
        'methods' => 'GET',
        'callback' => 'gp_api_sales_analytics',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 36. Productos más vistos
    register_rest_route($namespace, '/analytics/most-viewed', array(
        'methods' => 'GET',
        'callback' => 'gp_api_most_viewed',
        'permission_callback' => '__return_true'
    ));
    
    // 37. Estadísticas de clientes
    register_rest_route($namespace, '/analytics/customers', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_analytics',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 38. Reporte de inventario
    register_rest_route($namespace, '/analytics/inventory', array(
        'methods' => 'GET',
        'callback' => 'gp_api_inventory_report',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // ============================================
    // CONFIGURACIÓN Y UTILIDADES (4 endpoints)
    // ============================================
    
    // 39. Configuración de la tienda
    register_rest_route($namespace, '/config/store', array(
        'methods' => 'GET',
        'callback' => 'gp_api_store_config',
        'permission_callback' => '__return_true'
    ));
    
    // 40. Categorías de productos
    register_rest_route($namespace, '/categories', array(
        'methods' => 'GET',
        'callback' => 'gp_api_categories',
        'permission_callback' => '__return_true'
    ));
    
    // 41. Banners y promociones
    register_rest_route($namespace, '/promotions/active', array(
        'methods' => 'GET',
        'callback' => 'gp_api_active_promotions',
        'permission_callback' => '__return_true'
    ));
    
    // 42. Notificaciones del usuario
    register_rest_route($namespace, '/notifications/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_notifications',
        'permission_callback' => 'is_user_logged_in'
    ));
});

// ============================================
// IMPLEMENTACIÓN DE ENDPOINTS - PRODUCTOS
// ============================================

function gp_api_products_by_category($request) {
    $slug = $request['slug'];
    $per_page = $request->get_param('per_page') ?: 20;
    $page = $request->get_param('page') ?: 1;
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $per_page,
        'paged' => $page,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => $slug
            )
        )
    );
    
    $query = new WP_Query($args);
    $products = array();
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            
            $products[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'slug' => get_post_field('post_name'),
                'price' => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price' => $product->get_sale_price(),
                'on_sale' => $product->is_on_sale(),
                'stock_status' => $product->get_stock_status(),
                'stock_quantity' => $product->get_stock_quantity(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'full'),
                'gallery' => array_map(function($id) {
                    return wp_get_attachment_url($id);
                }, $product->get_gallery_image_ids()),
                'short_description' => $product->get_short_description(),
                'description' => $product->get_description(),
                'categories' => wp_get_post_terms(get_the_ID(), 'product_cat', array('fields' => 'names')),
                'tags' => wp_get_post_terms(get_the_ID(), 'product_tag', array('fields' => 'names')),
                'rating' => $product->get_average_rating(),
                'review_count' => $product->get_review_count(),
                'permalink' => get_permalink()
            );
        }
        wp_reset_postdata();
    }
    
    return new WP_REST_Response(array(
        'products' => $products,
        'total' => $query->found_posts,
        'pages' => $query->max_num_pages,
        'current_page' => $page
    ), 200);
}

function gp_api_single_product($request) {
    $product_id = $request['id'];
    $product = wc_get_product($product_id);
    
    if (!$product) {
        return new WP_Error('product_not_found', 'Producto no encontrado', array('status' => 404));
    }
    
    $data = array(
        'id' => $product_id,
        'name' => $product->get_name(),
        'slug' => $product->get_slug(),
        'type' => $product->get_type(),
        'price' => $product->get_price(),
        'regular_price' => $product->get_regular_price(),
        'sale_price' => $product->get_sale_price(),
        'on_sale' => $product->is_on_sale(),
        'currency' => get_woocommerce_currency(),
        'stock_status' => $product->get_stock_status(),
        'stock_quantity' => $product->get_stock_quantity(),
        'manage_stock' => $product->get_manage_stock(),
        'images' => array(
            'featured' => get_the_post_thumbnail_url($product_id, 'full'),
            'gallery' => array_map(function($id) {
                return wp_get_attachment_url($id);
            }, $product->get_gallery_image_ids())
        ),
        'description' => $product->get_description(),
        'short_description' => $product->get_short_description(),
        'categories' => wp_get_post_terms($product_id, 'product_cat', array('fields' => 'all')),
        'tags' => wp_get_post_terms($product_id, 'product_tag', array('fields' => 'names')),
        'attributes' => $product->get_attributes(),
        'dimensions' => array(
            'length' => $product->get_length(),
            'width' => $product->get_width(),
            'height' => $product->get_height(),
            'weight' => $product->get_weight()
        ),
        'rating' => array(
            'average' => $product->get_average_rating(),
            'count' => $product->get_review_count()
        ),
        'permalink' => get_permalink($product_id),
        'date_created' => $product->get_date_created()->format('Y-m-d H:i:s'),
        'date_modified' => $product->get_date_modified()->format('Y-m-d H:i:s')
    );
    
    // Si es variable, agregar variaciones
    if ($product->is_type('variable')) {
        $variations = array();
        foreach ($product->get_children() as $variation_id) {
            $variation = wc_get_product($variation_id);
            $variations[] = array(
                'id' => $variation_id,
                'attributes' => $variation->get_attributes(),
                'price' => $variation->get_price(),
                'stock_status' => $variation->get_stock_status(),
                'stock_quantity' => $variation->get_stock_quantity()
            );
        }
        $data['variations'] = $variations;
    }
    
    return new WP_REST_Response($data, 200);
}

function gp_api_bestsellers($request) {
    $limit = $request->get_param('limit') ?: 10;
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $limit,
        'meta_key' => 'total_sales',
        'orderby' => 'meta_value_num',
        'order' => 'DESC'
    );
    
    $query = new WP_Query($args);
    $products = array();
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $product = wc_get_product(get_the_ID());
            
            $products[] = array(
                'id' => get_the_ID(),
                'name' => get_the_title(),
                'price' => $product->get_price_html(),
                'image' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
                'total_sales' => get_post_meta(get_the_ID(), 'total_sales', true),
                'permalink' => get_permalink()
            );
        }
        wp_reset_postdata();
    }
    
    return new WP_REST_Response($products, 200);
}

// ============================================
// IMPLEMENTACIÓN - CARRITO
// ============================================

function gp_api_get_cart($request) {
    $cart = WC()->cart;
    
    $items = array();
    foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
        $product = $cart_item['data'];
        
        $items[] = array(
            'key' => $cart_item_key,
            'product_id' => $cart_item['product_id'],
            'variation_id' => $cart_item['variation_id'],
            'quantity' => $cart_item['quantity'],
            'name' => $product->get_name(),
            'price' => $product->get_price(),
            'subtotal' => $cart_item['line_subtotal'],
            'total' => $cart_item['line_total'],
            'image' => wp_get_attachment_url($product->get_image_id())
        );
    }
    
    return new WP_REST_Response(array(
        'items' => $items,
        'totals' => array(
            'subtotal' => $cart->get_subtotal(),
            'discount' => $cart->get_discount_total(),
            'shipping' => $cart->get_shipping_total(),
            'tax' => $cart->get_tax_totals(),
            'total' => $cart->get_total('edit')
        ),
        'coupons' => $cart->get_applied_coupons(),
        'item_count' => $cart->get_cart_contents_count()
    ), 200);
}

function gp_api_add_to_cart($request) {
    $product_id = intval($request->get_param('product_id'));
    $quantity = intval($request->get_param('quantity')) ?: 1;
    $variation_id = intval($request->get_param('variation_id')) ?: 0;
    
    $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id);
    
    if ($cart_item_key) {
        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Producto agregado al carrito',
            'cart_item_key' => $cart_item_key,
            'cart_total' => WC()->cart->get_cart_contents_count()
        ), 200);
    }
    
    return new WP_Error('add_to_cart_failed', 'No se pudo agregar al carrito', array('status' => 400));
}

// ============================================
// IMPLEMENTACIÓN - ÓRDENES
// ============================================

function gp_api_user_orders($request) {
    $user_id = get_current_user_id();
    $page = $request->get_param('page') ?: 1;
    $per_page = $request->get_param('per_page') ?: 10;
    
    $orders = wc_get_orders(array(
        'customer_id' => $user_id,
        'limit' => $per_page,
        'page' => $page,
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    $result = array();
    foreach ($orders as $order) {
        $result[] = array(
            'id' => $order->get_id(),
            'order_number' => $order->get_order_number(),
            'status' => $order->get_status(),
            'total' => $order->get_total(),
            'currency' => $order->get_currency(),
            'date_created' => $order->get_date_created()->format('Y-m-d H:i:s'),
            'payment_method' => $order->get_payment_method_title(),
            'items_count' => $order->get_item_count(),
            'view_url' => $order->get_view_order_url()
        );
    }
    
    return new WP_REST_Response($result, 200);
}

// Agregar más implementaciones según sea necesario...

// ============================================
// FUNCIONES AUXILIARES
// ============================================

function gp_format_product_for_api($product) {
    return array(
        'id' => $product->get_id(),
        'name' => $product->get_name(),
        'price' => $product->get_price(),
        'image' => wp_get_attachment_url($product->get_image_id()),
        'stock' => $product->get_stock_status(),
        'permalink' => get_permalink($product->get_id())
    );
}
