<?php
/**
 * V74 - RING SIZE GUIDE
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', 'gp_ring_size_selector');

function gp_ring_size_selector() {
    global $product;
    
    if (!has_term('anillos', 'product_cat', $product->get_id())) {
        return;
    }
    ?>
    
    <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <h4 style="margin-top: 0;">💍 Talla del Anillo</h4>
        
        <select name="ring_size" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 15px;">
            <option value="">Selecciona tu talla...</option>
            <option value="5">5 (15.7mm)</option>
            <option value="6">6 (16.5mm)</option>
            <option value="7">7 (17.3mm)</option>
            <option value="8">8 (18.2mm)</option>
            <option value="9">9 (19.0mm)</option>
            <option value="10">10 (19.8mm)</option>
            <option value="11">11 (20.6mm)</option>
        </select>
        
        <button type="button" onclick="document.getElementById('size-guide-modal').style.display='block'" style="background: none; border: none; color: #D4AF37; text-decoration: underline; cursor: pointer;">
            📏 ¿Cómo medir mi talla?
        </button>
    </div>
    
    <div id="size-guide-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 99999; align-items: center; justify-content: center;">
        <div style="background: white; padding: 40px; border-radius: 12px; max-width: 500px; margin: 20px; position: relative;">
            <button onclick="document.getElementById('size-guide-modal').style.display='none'" style="position: absolute; top: 15px; right: 15px; background: none; border: none; font-size: 24px; cursor: pointer;">×</button>
            <h3 style="margin-top: 0;">📏 Guía de Tallas</h3>
            <p><strong>Método 1:</strong> Mide un anillo que te quede bien</p>
            <p><strong>Método 2:</strong> Mide tu dedo con un hilo</p>
            <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='200'%3E%3Ctext x='150' y='100' text-anchor='middle' font-size='20'%3EGuía Visual%3C/text%3E%3C/svg%3E" style="width: 100%; margin: 20px 0;">
        </div>
    </div>
    
    <?php
}
