<?php
/**
 * Golden Phoenix - FOMO y Urgencia
 * Sistema de escasez, urgencia y prueba social para aumentar conversiones
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// CONTADOR DE STOCK BAJO
// ============================================

add_action('woocommerce_single_product_summary', 'gp_low_stock_alert', 25);

function gp_low_stock_alert() {
    global $product;
    
    if (!$product->managing_stock()) {
        return;
    }
    
    $stock_quantity = $product->get_stock_quantity();
    $low_stock_threshold = 10;
    
    if ($stock_quantity > 0 && $stock_quantity <= $low_stock_threshold) {
        ?>
        <div class="low-stock-alert" style="background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); border-left: 4px solid #ff6b6b; padding: 15px 20px; border-radius: 8px; margin: 20px 0; animation: pulse 2s infinite;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 24px;">🔥</span>
                <div>
                    <div style="font-weight: 700; color: #dc3545; margin-bottom: 5px;">
                        ¡Solo quedan <?php echo $stock_quantity; ?> unidades!
                    </div>
                    <div style="font-size: 14px; color: #666;">
                        Este producto se está agotando rápidamente
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.02); }
        }
        </style>
        <?php
    }
}

// ============================================
// PERSONAS VIENDO AHORA
// ============================================

add_action('woocommerce_single_product_summary', 'gp_people_viewing_now', 26);

function gp_people_viewing_now() {
    global $product;
    
    // Generar número "realista" basado en ID del producto
    $base = $product->get_id() % 10;
    $viewers = rand($base + 3, $base + 12);
    
    ?>
    <div class="people-viewing" style="display: inline-flex; align-items: center; gap: 10px; background: #f0f8ff; padding: 12px 20px; border-radius: 25px; margin: 15px 0; border: 2px solid #D4AF37;">
        <span style="width: 10px; height: 10px; background: #28a745; border-radius: 50%; animation: blink 1.5s infinite;"></span>
        <span style="font-weight: 600; color: #0A0A0A;">
            <i class="fas fa-eye"></i> <?php echo $viewers; ?> personas viendo ahora
        </span>
    </div>
    
    <style>
    @keyframes blink {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.3; }
    }
    </style>
    <?php
}

// ============================================
// VENTAS RECIENTES (FAKE PROOF)
// ============================================

add_action('wp_footer', 'gp_recent_sales_popup');

function gp_recent_sales_popup() {
    // Solo en tienda y productos
    if (!is_shop() && !is_product() && !is_product_category()) {
        return;
    }
    
    // Obtener productos vendidos recientemente (o simular)
    $recent_orders = wc_get_orders(array(
        'limit' => 10,
        'status' => 'completed'
    ));
    
    if (empty($recent_orders)) {
        // Simular ventas si no hay órdenes reales
        $products = wc_get_products(array('limit' => 10, 'orderby' => 'rand'));
        $fake_sales = array();
        
        foreach ($products as $product) {
            $fake_sales[] = array(
                'product_name' => $product->get_name(),
                'product_image' => wp_get_attachment_url($product->get_image_id()),
                'time_ago' => rand(5, 60) . ' minutos'
            );
        }
        
        $sales_data = $fake_sales;
    } else {
        $sales_data = array();
        foreach ($recent_orders as $order) {
            foreach ($order->get_items() as $item) {
                $product = $item->get_product();
                if ($product) {
                    $sales_data[] = array(
                        'product_name' => $product->get_name(),
                        'product_image' => wp_get_attachment_url($product->get_image_id()),
                        'time_ago' => human_time_diff(strtotime($order->get_date_created()))
                    );
                }
            }
        }
    }
    
    if (empty($sales_data)) {
        return;
    }
    
    $random_sale = $sales_data[array_rand($sales_data)];
    ?>
    
    <div id="recent-sale-popup" style="position: fixed; bottom: 20px; left: 20px; background: white; padding: 15px; border-radius: 12px; box-shadow: 0 8px 30px rgba(0,0,0,0.2); z-index: 99999; max-width: 350px; display: none; animation: slideIn 0.5s;">
        
        <button onclick="this.closest('#recent-sale-popup').style.display='none'" style="position: absolute; top: 10px; right: 10px; background: none; border: none; cursor: pointer; font-size: 20px; color: #999;">×</button>
        
        <div style="display: flex; gap: 15px; align-items: center;">
            <img src="<?php echo $random_sale['product_image']; ?>" alt="" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px; border: 2px solid #D4AF37;">
            
            <div style="flex: 1;">
                <div style="font-size: 12px; color: #28a745; font-weight: 600; margin-bottom: 5px;">
                    ✓ COMPRA VERIFICADA
                </div>
                <div style="font-weight: 600; margin-bottom: 5px; color: #0A0A0A;">
                    <?php echo esc_html($random_sale['product_name']); ?>
                </div>
                <div style="font-size: 12px; color: #666;">
                    <i class="fas fa-clock"></i> Hace <?php echo $random_sale['time_ago']; ?>
                </div>
            </div>
        </div>
        
    </div>
    
    <style>
    @keyframes slideIn {
        from {
            transform: translateX(-100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @media (max-width: 768px) {
        #recent-sale-popup {
            left: 10px !important;
            right: 10px !important;
            max-width: none !important;
        }
    }
    </style>
    
    <script>
    // Mostrar popup después de 10 segundos
    setTimeout(function() {
        const popup = document.getElementById('recent-sale-popup');
        popup.style.display = 'block';
        
        // Ocultar después de 8 segundos
        setTimeout(function() {
            popup.style.display = 'none';
        }, 8000);
        
        // Mostrar siguiente cada 30 segundos
        setInterval(function() {
            popup.style.display = 'block';
            setTimeout(function() {
                popup.style.display = 'none';
            }, 8000);
        }, 30000);
    }, 10000);
    </script>
    <?php
}

// ============================================
// TEMPORIZADOR DE OFERTA (URGENCIA)
// ============================================

add_action('woocommerce_single_product_summary', 'gp_sale_countdown_timer', 15);

function gp_sale_countdown_timer() {
    global $product;
    
    if (!$product->is_on_sale()) {
        return;
    }
    
    // Si tiene fecha de finalización de oferta
    $sale_end = $product->get_date_on_sale_to();
    
    if (!$sale_end) {
        // Si no tiene fecha, crear una ficticia (24 horas)
        $end_time = time() + (24 * 60 * 60);
    } else {
        $end_time = $sale_end->getTimestamp();
    }
    
    ?>
    <div class="sale-countdown-timer" style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); color: white; padding: 20px; border-radius: 12px; margin: 20px 0; text-align: center;">
        
        <div style="font-size: 16px; font-weight: 600; margin-bottom: 15px; letter-spacing: 1px;">
            ⚡ OFERTA POR TIEMPO LIMITADO
        </div>
        
        <div class="countdown-display" style="display: flex; justify-content: center; gap: 15px; margin-bottom: 15px;">
            <div class="countdown-unit" style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; min-width: 70px;">
                <div class="hours" style="font-size: 32px; font-weight: 700;">00</div>
                <div style="font-size: 11px; opacity: 0.9; margin-top: 5px;">HORAS</div>
            </div>
            <div class="countdown-unit" style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; min-width: 70px;">
                <div class="minutes" style="font-size: 32px; font-weight: 700;">00</div>
                <div style="font-size: 11px; opacity: 0.9; margin-top: 5px;">MINUTOS</div>
            </div>
            <div class="countdown-unit" style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; min-width: 70px;">
                <div class="seconds" style="font-size: 32px; font-weight: 700;">00</div>
                <div style="font-size: 11px; opacity: 0.9; margin-top: 5px;">SEGUNDOS</div>
            </div>
        </div>
        
        <div style="font-size: 14px; opacity: 0.9;">
            ¡No te pierdas esta oportunidad única!
        </div>
        
    </div>
    
    <script>
    const saleEndTime = <?php echo $end_time; ?> * 1000;
    
    function updateSaleCountdown() {
        const now = new Date().getTime();
        const distance = saleEndTime - now;
        
        if (distance < 0) {
            document.querySelector('.sale-countdown-timer').innerHTML = 
                '<div style="padding: 20px; text-align: center; font-weight: 600;">Esta oferta ha terminado</div>';
            return;
        }
        
        const hours = Math.floor(distance / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.querySelector('.countdown-display .hours').textContent = String(hours).padStart(2, '0');
        document.querySelector('.countdown-display .minutes').textContent = String(minutes).padStart(2, '0');
        document.querySelector('.countdown-display .seconds').textContent = String(seconds).padStart(2, '0');
    }
    
    updateSaleCountdown();
    setInterval(updateSaleCountdown, 1000);
    </script>
    <?php
}

// ============================================
// BARRA DE PROGRESO ENVÍO GRATIS
// ============================================

add_action('woocommerce_before_cart', 'gp_free_shipping_progress');

function gp_free_shipping_progress() {
    $free_shipping_threshold = 500000; // $500,000 COP
    $cart_total = WC()->cart->get_cart_contents_total();
    $remaining = $free_shipping_threshold - $cart_total;
    $progress = min(($cart_total / $free_shipping_threshold) * 100, 100);
    
    ?>
    <div class="free-shipping-progress" style="background: linear-gradient(135deg, #f0f8ff 0%, #e3f2fd 100%); border: 2px solid #D4AF37; border-radius: 12px; padding: 25px; margin-bottom: 30px;">
        
        <?php if ($remaining > 0) : ?>
            <div style="text-align: center; margin-bottom: 20px;">
                <i class="fas fa-truck" style="font-size: 32px; color: #D4AF37; margin-bottom: 10px;"></i>
                <div style="font-size: 18px; font-weight: 600; color: #0A0A0A; margin-bottom: 5px;">
                    ¡Estás cerca del envío GRATIS!
                </div>
                <div style="font-size: 14px; color: #666;">
                    Agrega <strong style="color: #D4AF37;">$<?php echo number_format($remaining, 0, ',', '.'); ?></strong> más para envío gratis
                </div>
            </div>
        <?php else : ?>
            <div style="text-align: center; color: #28a745;">
                <i class="fas fa-check-circle" style="font-size: 32px; margin-bottom: 10px;"></i>
                <div style="font-size: 18px; font-weight: 600;">
                    ¡Felicidades! Tienes envío GRATIS
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Barra de progreso -->
        <div style="background: #e0e0e0; height: 12px; border-radius: 6px; overflow: hidden; position: relative;">
            <div style="background: linear-gradient(90deg, #D4AF37 0%, #FFD700 100%); height: 100%; width: <?php echo $progress; ?>%; transition: width 0.5s; border-radius: 6px;"></div>
        </div>
        
    </div>
    <?php
}

// ============================================
// MENSAJES DE ESCASEZ DINÁMICOS
// ============================================

add_action('woocommerce_after_add_to_cart_button', 'gp_scarcity_messages');

function gp_scarcity_messages() {
    global $product;
    
    $messages = array(
        '💎 Este producto es muy solicitado',
        '🔥 Vendimos 8 de estos en las últimas 24 horas',
        '⏰ El stock se actualiza cada hora',
        '📦 Última vez en stock hace 3 días',
        '✨ Producto exclusivo de edición limitada',
        '🎯 Alta demanda: 15+ personas lo han visto hoy',
        '⚡ Se vende rápido: quedan pocas unidades'
    );
    
    $random_message = $messages[array_rand($messages)];
    
    ?>
    <div class="scarcity-message" style="background: #fff3cd; border-left: 4px solid #D4AF37; padding: 15px; border-radius: 4px; margin-top: 20px;">
        <div style="display: flex; align-items: center; gap: 12px;">
            <span style="font-size: 20px;">⚠️</span>
            <span style="font-weight: 600; color: #0A0A0A;">
                <?php echo $random_message; ?>
            </span>
        </div>
    </div>
    <?php
}

// ============================================
// MINI POPUP DE ABANDONO (EXIT INTENT)
// ============================================

add_action('wp_footer', 'gp_exit_intent_popup');

function gp_exit_intent_popup() {
    // Solo en carrito con productos
    if (!is_cart() || WC()->cart->is_empty()) {
        return;
    }
    
    ?>
    <div id="exit-intent-popup" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 999999; align-items: center; justify-content: center; padding: 20px;">
        <div style="max-width: 500px; background: white; border-radius: 20px; padding: 40px; text-align: center; position: relative;">
            
            <button onclick="closeExitPopup()" style="position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: #f0f0f0; border: none; cursor: pointer; font-size: 24px;">×</button>
            
            <div style="font-size: 60px; margin-bottom: 20px;">😢</div>
            
            <h2 style="font-size: 32px; margin-bottom: 15px; font-family: 'Playfair Display', serif;">
                ¡Espera un momento!
            </h2>
            
            <p style="font-size: 18px; color: #666; margin-bottom: 30px;">
                Usa el código <strong style="color: #D4AF37;">QUEDATEYA</strong> para obtener 10% de descuento adicional
            </p>
            
            <button onclick="applyCoupon('QUEDATEYA'); closeExitPopup();" style="background: #D4AF37; color: white; border: none; padding: 18px 50px; border-radius: 50px; font-size: 18px; font-weight: 600; cursor: pointer; margin-bottom: 15px; transition: all 0.3s;"
                    onmouseover="this.style.background='#0A0A0A'"
                    onmouseout="this.style.background='#D4AF37'">
                Aplicar Cupón Ahora
            </button>
            
            <p style="font-size: 12px; color: #999; margin: 0;">
                Oferta válida solo por los próximos 10 minutos
            </p>
        </div>
    </div>
    
    <script>
    let exitIntentShown = false;
    
    document.addEventListener('mouseleave', function(e) {
        if (e.clientY < 10 && !exitIntentShown) {
            exitIntentShown = true;
            document.getElementById('exit-intent-popup').style.display = 'flex';
        }
    });
    
    function closeExitPopup() {
        document.getElementById('exit-intent-popup').style.display = 'none';
    }
    
    function applyCoupon(code) {
        const input = document.querySelector('input[name="coupon_code"]');
        if (input) {
            input.value = code;
            input.closest('form').querySelector('button[name="apply_coupon"]').click();
        }
    }
    </script>
    <?php
}
