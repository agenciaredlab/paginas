<?php
/**
 * Golden Phoenix - Cupones Automáticos y Ofertas Flash
 * Sistema de descuentos inteligentes y ofertas por tiempo limitado
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// POPUP DE CUPÓN BIENVENIDA
// ============================================

add_action('wp_footer', 'gp_welcome_coupon_popup');

function gp_welcome_coupon_popup() {
    // Solo mostrar si no han comprado antes
    if (is_user_logged_in() && wc_get_customer_order_count(get_current_user_id()) > 0) {
        return;
    }
    
    // Solo mostrar si no han cerrado el popup antes
    if (isset($_COOKIE['gp_welcome_popup_closed'])) {
        return;
    }
    
    ?>
    <div id="gp-welcome-popup" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 999999; align-items: center; justify-content: center; padding: 20px;">
        <div style="max-width: 600px; background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%); border-radius: 20px; padding: 50px; text-align: center; position: relative; color: white; box-shadow: 0 20px 60px rgba(212,175,55,0.3);">
            
            <!-- Cerrar -->
            <button onclick="closeWelcomePopup()" style="position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: rgba(255,255,255,0.1); border: none; color: white; cursor: pointer; font-size: 24px;">
                ×
            </button>
            
            <!-- Contenido -->
            <div style="font-size: 60px; margin-bottom: 20px;">🎁</div>
            
            <h2 style="font-size: 36px; font-family: 'Playfair Display', serif; margin-bottom: 15px; color: #D4AF37;">
                ¡Bienvenido a Golden Phoenix!
            </h2>
            
            <p style="font-size: 18px; margin-bottom: 30px; opacity: 0.9;">
                Obtén un descuento especial en tu primera compra
            </p>
            
            <!-- Cupón -->
            <div style="background: rgba(212,175,55,0.1); border: 2px dashed #D4AF37; border-radius: 12px; padding: 30px; margin-bottom: 30px;">
                <p style="font-size: 14px; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 2px; color: #D4AF37;">
                    Código de Descuento
                </p>
                <div style="font-size: 42px; font-weight: 700; letter-spacing: 3px; margin-bottom: 15px; color: #D4AF37; font-family: monospace;">
                    BIENVENIDO15
                </div>
                <p style="font-size: 16px; margin: 0;">
                    15% de descuento en tu primera compra
                </p>
            </div>
            
            <!-- Botón copiar -->
            <button onclick="copyCouponCode('BIENVENIDO15')" style="background: #D4AF37; color: #0A0A0A; border: none; padding: 18px 50px; border-radius: 50px; font-size: 18px; font-weight: 600; cursor: pointer; transition: all 0.3s; margin-bottom: 15px;"
                    onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 10px 30px rgba(212,175,55,0.4)';"
                    onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='none';">
                📋 Copiar Código
            </button>
            
            <p style="font-size: 12px; opacity: 0.7; margin: 0;">
                * Válido para compras superiores a $300,000
            </p>
        </div>
    </div>
    
    <script>
    // Mostrar popup después de 5 segundos
    setTimeout(function() {
        document.getElementById('gp-welcome-popup').style.display = 'flex';
    }, 5000);
    
    function closeWelcomePopup() {
        document.getElementById('gp-welcome-popup').style.display = 'none';
        // Guardar en cookie para no mostrar de nuevo
        document.cookie = 'gp_welcome_popup_closed=1; max-age=' + (86400 * 30) + '; path=/';
    }
    
    function copyCouponCode(code) {
        navigator.clipboard.writeText(code).then(function() {
            const btn = event.target;
            const originalText = btn.innerHTML;
            btn.innerHTML = '✓ ¡Copiado!';
            btn.style.background = '#28a745';
            
            setTimeout(function() {
                btn.innerHTML = originalText;
                btn.style.background = '#D4AF37';
            }, 2000);
        });
    }
    </script>
    <?php
}

// ============================================
// CREAR CUPÓN DE BIENVENIDA AUTOMÁTICO
// ============================================

add_action('init', 'gp_create_welcome_coupon');

function gp_create_welcome_coupon() {
    // Verificar si el cupón ya existe
    $coupon_code = 'BIENVENIDO15';
    $coupon_id = wc_get_coupon_id_by_code($coupon_code);
    
    if ($coupon_id) {
        return; // Ya existe
    }
    
    // Crear cupón
    $coupon = array(
        'post_title' => $coupon_code,
        'post_content' => '',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'shop_coupon'
    );
    
    $new_coupon_id = wp_insert_post($coupon);
    
    // Configurar cupón
    update_post_meta($new_coupon_id, 'discount_type', 'percent');
    update_post_meta($new_coupon_id, 'coupon_amount', '15');
    update_post_meta($new_coupon_id, 'individual_use', 'yes');
    update_post_meta($new_coupon_id, 'usage_limit', '1');
    update_post_meta($new_coupon_id, 'usage_limit_per_user', '1');
    update_post_meta($new_coupon_id, 'minimum_amount', '300000');
    update_post_meta($new_coupon_id, 'free_shipping', 'yes');
}

// ============================================
// BANNER OFERTAS FLASH
// ============================================

add_action('wp_head', 'gp_flash_sale_banner');

function gp_flash_sale_banner() {
    // Obtener productos en oferta
    $sale_products = wc_get_products(array(
        'limit' => 1,
        'on_sale' => true,
        'orderby' => 'date',
        'order' => 'DESC'
    ));
    
    if (empty($sale_products)) {
        return;
    }
    
    $product = $sale_products[0];
    $sale_price = $product->get_sale_price();
    $regular_price = $product->get_regular_price();
    $discount_percent = round((($regular_price - $sale_price) / $regular_price) * 100);
    
    ?>
    <div id="flash-sale-banner" style="background: linear-gradient(90deg, #dc3545 0%, #c82333 100%); color: white; padding: 15px 0; text-align: center; position: sticky; top: 0; z-index: 9998; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
        <div class="container" style="max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; padding: 0 20px; flex-wrap: wrap; gap: 15px;">
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <span style="background: white; color: #dc3545; padding: 8px 15px; border-radius: 20px; font-weight: 700; font-size: 14px;">
                    ⚡ OFERTA FLASH
                </span>
                <span style="font-size: 16px; font-weight: 600;">
                    <?php echo $discount_percent; ?>% OFF en <?php echo $product->get_name(); ?>
                </span>
            </div>
            
            <div style="display: flex; align-items: center; gap: 20px;">
                <div id="flash-sale-countdown" style="display: flex; gap: 10px; font-weight: 700;">
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 12px; border-radius: 4px;">
                        <span id="flash-hours">00</span>h
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 12px; border-radius: 4px;">
                        <span id="flash-minutes">00</span>m
                    </div>
                    <div style="background: rgba(255,255,255,0.2); padding: 8px 12px; border-radius: 4px;">
                        <span id="flash-seconds">00</span>s
                    </div>
                </div>
                
                <a href="<?php echo get_permalink($product->get_id()); ?>" style="background: white; color: #dc3545; padding: 10px 25px; border-radius: 25px; text-decoration: none; font-weight: 700; transition: transform 0.3s;"
                   onmouseover="this.style.transform='scale(1.05)'"
                   onmouseout="this.style.transform='scale(1)'">
                    Ver Oferta →
                </a>
            </div>
            
        </div>
    </div>
    
    <style>
    @media (max-width: 768px) {
        #flash-sale-banner .container {
            flex-direction: column;
            text-align: center;
        }
        
        #flash-sale-banner .container > div {
            width: 100%;
            justify-content: center;
        }
    }
    </style>
    
    <script>
    // Contador regresivo (24 horas desde ahora)
    const flashEndTime = new Date().getTime() + (24 * 60 * 60 * 1000);
    
    function updateFlashCountdown() {
        const now = new Date().getTime();
        const distance = flashEndTime - now;
        
        if (distance < 0) {
            document.getElementById('flash-sale-banner').style.display = 'none';
            return;
        }
        
        const hours = Math.floor(distance / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        document.getElementById('flash-hours').textContent = String(hours).padStart(2, '0');
        document.getElementById('flash-minutes').textContent = String(minutes).padStart(2, '0');
        document.getElementById('flash-seconds').textContent = String(seconds).padStart(2, '0');
    }
    
    updateFlashCountdown();
    setInterval(updateFlashCountdown, 1000);
    </script>
    <?php
}

// ============================================
// CUPÓN AUTOMÁTICO CARRITO ABANDONADO
// ============================================

add_action('woocommerce_cart_updated', 'gp_check_abandoned_cart');

function gp_check_abandoned_cart() {
    // Si el carrito tiene productos y el usuario está logueado
    if (!WC()->cart->is_empty() && is_user_logged_in()) {
        $cart_total = WC()->cart->get_cart_contents_total();
        
        // Si el total es mayor a $500,000 y no hay cupón aplicado
        if ($cart_total > 500000 && empty(WC()->cart->get_applied_coupons())) {
            // Mostrar notificación de cupón disponible
            wc_add_notice('💎 ¡Usa el cupón <strong>VIP10</strong> para obtener 10% adicional en compras superiores a $500,000!', 'notice');
        }
    }
}

// ============================================
// CREAR CUPÓN VIP AUTOMÁTICO
// ============================================

add_action('init', 'gp_create_vip_coupon');

function gp_create_vip_coupon() {
    $coupon_code = 'VIP10';
    $coupon_id = wc_get_coupon_id_by_code($coupon_code);
    
    if ($coupon_id) {
        return;
    }
    
    $coupon = array(
        'post_title' => $coupon_code,
        'post_content' => '',
        'post_status' => 'publish',
        'post_author' => 1,
        'post_type' => 'shop_coupon'
    );
    
    $new_coupon_id = wp_insert_post($coupon);
    
    update_post_meta($new_coupon_id, 'discount_type', 'percent');
    update_post_meta($new_coupon_id, 'coupon_amount', '10');
    update_post_meta($new_coupon_id, 'minimum_amount', '500000');
}

// ============================================
// MOSTRAR CUPONES DISPONIBLES EN CARRITO
// ============================================

add_action('woocommerce_before_cart_table', 'gp_show_available_coupons');

function gp_show_available_coupons() {
    $cart_total = WC()->cart->get_cart_contents_total();
    $available_coupons = array();
    
    // Cupón bienvenida
    if (is_user_logged_in() && wc_get_customer_order_count(get_current_user_id()) == 0) {
        $available_coupons[] = array(
            'code' => 'BIENVENIDO15',
            'description' => '15% de descuento en tu primera compra',
            'min' => 300000
        );
    }
    
    // Cupón VIP
    if ($cart_total >= 500000) {
        $available_coupons[] = array(
            'code' => 'VIP10',
            'description' => '10% de descuento en compras superiores a $500,000',
            'min' => 500000
        );
    }
    
    if (empty($available_coupons)) {
        return;
    }
    
    ?>
    <div style="background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%); border-left: 4px solid #D4AF37; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
        <h3 style="margin: 0 0 15px 0; color: #0A0A0A; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 24px;">🎁</span>
            Cupones Disponibles para Ti
        </h3>
        
        <div style="display: grid; gap: 15px;">
            <?php foreach ($available_coupons as $coupon) : ?>
                <div style="background: white; padding: 15px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <div style="font-size: 20px; font-weight: 700; color: #D4AF37; margin-bottom: 5px; font-family: monospace;">
                            <?php echo $coupon['code']; ?>
                        </div>
                        <div style="color: #666; font-size: 14px;">
                            <?php echo $coupon['description']; ?>
                        </div>
                    </div>
                    <button onclick="applyCoupon('<?php echo $coupon['code']; ?>')" style="background: #D4AF37; color: white; border: none; padding: 12px 30px; border-radius: 25px; cursor: pointer; font-weight: 600; transition: all 0.3s;"
                            onmouseover="this.style.background='#0A0A0A'"
                            onmouseout="this.style.background='#D4AF37'">
                        Aplicar Cupón
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    function applyCoupon(code) {
        const input = document.querySelector('input[name="coupon_code"]');
        if (input) {
            input.value = code;
            input.closest('form').querySelector('button[name="apply_coupon"]').click();
        }
    }
    </script>
    <?php
}
