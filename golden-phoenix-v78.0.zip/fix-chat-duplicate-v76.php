<?php
/**
 * Golden Phoenix V76 - ELIMINAR CHAT DUPLICADO
 * Solo deja el chat azul funcional, elimina el amarillo
 */

if (!defined('ABSPATH')) exit;

// ========================================
// DESACTIVAR COMPLETAMENTE live-chat-system.php
// ========================================

// Remover todas las acciones del sistema antiguo
add_action('init', 'gp_v76_disable_old_chat_system', 1);

function gp_v76_disable_old_chat_system() {
    // Remover clase completa si existe
    if (class_exists('GP_Live_Chat_System')) {
        remove_action('wp_footer', array('GP_Live_Chat_System', 'render_chat_widget'));
        remove_action('admin_menu', array('GP_Live_Chat_System', 'add_admin_menu'));
    }
    
    // Prevenir que se cargue
    add_filter('gp_old_chat_disabled', '__return_true');
}

// Ocultar chat amarillo con CSS si aún aparece
add_action('wp_head', 'gp_v76_hide_old_chat_css', 999);

function gp_v76_hide_old_chat_css() {
    ?>
    <style>
    /* Ocultar chat amarillo antiguo */
    .gp-chat-widget-old,
    .gp-chat-button-old,
    div[class*="live-chat"]:not(.gp-live-chat-trigger):not(.gp-live-chat-widget) {
        display: none !important;
    }
    
    /* Asegurar solo chat azul visible */
    .gp-live-chat-trigger {
        display: flex !important;
        position: fixed !important;
        bottom: 20px !important;
        left: 20px !important;
        background: #0084FF !important;
        width: 60px !important;
        height: 60px !important;
        z-index: 9998 !important;
    }
    
    /* WhatsApp siempre derecha */
    .gp-whatsapp-float {
        position: fixed !important;
        bottom: 20px !important;
        right: 20px !important;
        left: auto !important;
        z-index: 9998 !important;
    }
    </style>
    <?php
}

// ========================================
// ASEGURAR SOLO 2 BOTONES: AZUL + VERDE
// ========================================

add_action('wp_footer', 'gp_v76_verify_buttons', 9999);

function gp_v76_verify_buttons() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        // Contar botones flotantes
        var buttons = $('body > div[class*="chat"], body > div[class*="whatsapp"]').filter(function() {
            return $(this).css('position') === 'fixed';
        });
        
        // Si hay más de 2, eliminar extras
        if (buttons.length > 2) {
            buttons.slice(2).remove();
        }
        
        // Asegurar posiciones correctas
        $('.gp-live-chat-trigger').css({
            'bottom': '20px',
            'left': '20px',
            'right': 'auto',
            'background': '#0084FF'
        });
        
        $('.gp-whatsapp-float').css({
            'bottom': '20px',
            'right': '20px',
            'left': 'auto',
            'background': '#25D366'
        });
    });
    </script>
    <?php
}

// ========================================
// ADMIN NOTICE - CHAT LIMPIADO
// ========================================

add_action('admin_notices', 'gp_v76_chat_fixed_notice');

function gp_v76_chat_fixed_notice() {
    if (get_option('gp_v76_chat_notice_shown')) {
        return;
    }
    
    $screen = get_current_screen();
    if ($screen->id !== 'dashboard') {
        return;
    }
    ?>
    
    <div class="notice notice-success is-dismissible">
        <h3>✅ Golden Phoenix V76 - Chat Arreglado</h3>
        <p><strong>Cambios:</strong></p>
        <ul style="list-style: disc; margin-left: 20px;">
            <li>❌ Chat amarillo duplicado eliminado</li>
            <li>✅ Solo 2 botones: Chat azul (izquierda) + WhatsApp verde (derecha)</li>
            <li>✅ Sin sobreposición</li>
        </ul>
        <p>
            <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_v76'}); return false;" class="button button-primary">
                Entendido
            </a>
        </p>
    </div>
    
    <?php
    update_option('gp_v76_chat_notice_shown', true);
}

add_action('wp_ajax_gp_dismiss_v76', function() {
    update_option('gp_v76_chat_notice_shown', true);
    wp_die();
});
