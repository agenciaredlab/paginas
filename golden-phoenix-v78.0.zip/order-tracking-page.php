<?php
/**
 * V73 - ORDER TRACKING PAGE
 */
if (!defined('ABSPATH')) exit;

add_action('after_switch_theme', function() {
    if (get_option('gp_tracking_page_created')) return;
    wp_insert_post(array(
        'post_title' => 'Rastrear mi Pedido',
        'post_name' => 'rastrear-pedido',
        'post_content' => '[order_tracking]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    update_option('gp_tracking_page_created', true);
});

add_shortcode('order_tracking', function() {
    ob_start();
    ?>
    <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h2 style="text-align: center; margin-bottom: 30px;">📦 Rastrear mi Pedido</h2>
        <form id="gp-tracking-form" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <label style="display: block; margin-bottom: 10px; font-weight: 600;">Número de Pedido:</label>
            <input type="text" id="order-number" placeholder="Ej: 12345" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; margin-bottom: 20px;">
            <label style="display: block; margin-bottom: 10px; font-weight: 600;">Email de Facturación:</label>
            <input type="email" id="order-email" placeholder="tu@email.com" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; margin-bottom: 20px;">
            <button type="submit" style="width: 100%; padding: 15px; background: #D4AF37; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;">Buscar Pedido</button>
        </form>
        <div id="tracking-result" style="margin-top: 30px;"></div>
    </div>
    <script>
    document.getElementById('gp-tracking-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var orderNum = document.getElementById('order-number').value;
        var email = document.getElementById('order-email').value;
        document.getElementById('tracking-result').innerHTML = '<div style="background: #f0f0f0; padding: 20px; border-radius: 8px;"><h3>Estado del Pedido #' + orderNum + '</h3><p>✅ Pedido confirmado<br>📦 En preparación<br>🚚 Listo para envío</p></div>';
    });
    </script>
    <?php
    return ob_get_clean();
});
