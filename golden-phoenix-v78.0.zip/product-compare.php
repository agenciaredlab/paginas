<?php
/**
 * Golden Phoenix - Comparador de Productos
 * Compara hasta 4 productos lado a lado
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// SHORTCODE COMPARADOR
// ============================================

add_shortcode('product_compare', 'gp_product_compare_shortcode');

function gp_product_compare_shortcode() {
    $compare_list = gp_get_compare_list();
    
    ob_start();
    ?>
    <div class="gp-product-compare">
        
        <div class="compare-header" style="text-align: center; margin-bottom: 40px;">
            <h1 style="font-size: 48px; font-family: 'Playfair Display', serif;">
                ⚖️ Comparador de Productos
            </h1>
            <p style="color: #666;">Compara hasta 4 joyas lado a lado</p>
        </div>
        
        <?php if (empty($compare_list)) : ?>
        
        <div class="compare-empty" style="text-align: center; padding: 60px 20px; background: white; border-radius: 8px;">
            <div style="font-size: 60px; margin-bottom: 20px;">📊</div>
            <h2>No has agregado productos para comparar</h2>
            <p style="color: #666; margin: 20px 0;">
                Explora nuestros productos y haz click en "Comparar"
            </p>
            <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
               style="display: inline-block; background: #D4AF37; color: white; padding: 15px 40px; border-radius: 4px; text-decoration: none; font-weight: 600; margin-top: 20px;">
                Ver Productos
            </a>
        </div>
        
        <?php else : ?>
        
        <div class="compare-table-wrapper" style="overflow-x: auto;">
            <table class="compare-table" style="width: 100%; background: white; border-collapse: separate; border-spacing: 10px;">
                <thead>
                    <tr>
                        <th style="padding: 20px; text-align: left; background: #f9f9f9; border-radius: 4px; width: 200px;">
                            Característica
                        </th>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <th style="padding: 20px; background: #f9f9f9; border-radius: 4px; position: relative;">
                            <button onclick="removeFromCompare(<?php echo $product_id; ?>)" 
                                    style="position: absolute; top: 10px; right: 10px; width: 30px; height: 30px; border-radius: 50%; background: white; border: 1px solid #ddd; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-times"></i>
                            </button>
                            <img src="<?php echo wp_get_attachment_url($product->get_image_id()); ?>" 
                                 alt="<?php echo $product->get_name(); ?>"
                                 style="width: 150px; height: 150px; object-fit: cover; border-radius: 4px; margin-bottom: 15px;">
                            <h3 style="font-size: 16px; margin-bottom: 10px;">
                                <?php echo $product->get_name(); ?>
                            </h3>
                            <div style="color: #D4AF37; font-size: 20px; font-weight: 700; margin-bottom: 15px;">
                                <?php echo $product->get_price_html(); ?>
                            </div>
                        </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <!-- Precio -->
                    <tr>
                        <td style="padding: 15px; background: #f9f9f9; font-weight: 600;">Precio</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <td style="padding: 15px; text-align: center; background: #f9f9f9;">
                            <span style="color: #D4AF37; font-weight: 700;">
                                <?php echo $product->get_price_html(); ?>
                            </span>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    
                    <!-- Disponibilidad -->
                    <tr>
                        <td style="padding: 15px; background: white; font-weight: 600;">Disponibilidad</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <td style="padding: 15px; text-align: center; background: white;">
                            <?php if ($product->is_in_stock()) : ?>
                                <span style="color: #28a745;">✓ En Stock</span>
                            <?php else : ?>
                                <span style="color: #dc3545;">✗ Agotado</span>
                            <?php endif; ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    
                    <!-- Rating -->
                    <tr>
                        <td style="padding: 15px; background: #f9f9f9; font-weight: 600;">Calificación</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <td style="padding: 15px; text-align: center; background: #f9f9f9;">
                            <div style="color: #D4AF37;">
                                <?php 
                                $rating = $product->get_average_rating();
                                for ($i = 1; $i <= 5; $i++) {
                                    echo $i <= $rating ? '★' : '☆';
                                }
                                ?>
                            </div>
                            <small style="color: #666;">(<?php echo $product->get_review_count(); ?> reseñas)</small>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    
                    <!-- Categorías -->
                    <tr>
                        <td style="padding: 15px; background: white; font-weight: 600;">Categoría</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                            $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
                        ?>
                        <td style="padding: 15px; text-align: center; background: white;">
                            <?php echo implode(', ', $categories); ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    
                    <!-- Descripción corta -->
                    <tr>
                        <td style="padding: 15px; background: #f9f9f9; font-weight: 600;">Descripción</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <td style="padding: 15px; text-align: center; background: #f9f9f9; font-size: 14px; color: #666;">
                            <?php echo wp_trim_words($product->get_short_description(), 20); ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    
                    <!-- Atributos (si existen) -->
                    <?php
                    $all_attributes = array();
                    foreach ($compare_list as $product_id) {
                        $product = wc_get_product($product_id);
                        if ($product) {
                            foreach ($product->get_attributes() as $attribute) {
                                $all_attributes[$attribute->get_name()] = $attribute->get_name();
                            }
                        }
                    }
                    
                    foreach ($all_attributes as $attr_name) :
                    ?>
                    <tr>
                        <td style="padding: 15px; background: white; font-weight: 600;"><?php echo wc_attribute_label($attr_name); ?></td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                            $attributes = $product->get_attributes();
                        ?>
                        <td style="padding: 15px; text-align: center; background: white;">
                            <?php
                            if (isset($attributes[$attr_name])) {
                                echo $product->get_attribute($attr_name);
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Acciones -->
                    <tr>
                        <td style="padding: 15px; background: #f9f9f9; font-weight: 600;">Acción</td>
                        <?php foreach ($compare_list as $product_id) : 
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                        <td style="padding: 15px; text-align: center; background: #f9f9f9;">
                            <?php if ($product->is_in_stock()) : ?>
                                <a href="<?php echo $product->add_to_cart_url(); ?>" 
                                   style="display: block; background: #D4AF37; color: white; padding: 12px; border-radius: 4px; text-decoration: none; font-weight: 600; margin-bottom: 10px;">
                                    Agregar al Carrito
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo get_permalink($product_id); ?>" 
                               style="display: block; background: #0A0A0A; color: white; padding: 12px; border-radius: 4px; text-decoration: none; font-weight: 600;">
                                Ver Detalles
                            </a>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 30px; text-align: center;">
            <button onclick="clearCompare()" 
                    style="background: #dc3545; color: white; border: none; padding: 15px 40px; border-radius: 4px; cursor: pointer; font-weight: 600;">
                Limpiar Comparación
            </button>
        </div>
        
        <?php endif; ?>
        
    </div>
    
    <script>
    function removeFromCompare(productId) {
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=remove_from_compare&product_id=' + productId
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) location.reload();
        });
    }
    
    function clearCompare() {
        if (!confirm('¿Limpiar todos los productos de la comparación?')) return;
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=clear_compare'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) location.reload();
        });
    }
    </script>
    
    <style>
    @media (max-width: 768px) {
        .compare-table th,
        .compare-table td {
            font-size: 12px;
            padding: 10px !important;
        }
        
        .compare-table th img {
            width: 80px !important;
            height: 80px !important;
        }
    }
    </style>
    <?php
    
    return ob_get_clean();
}

// ============================================
// FUNCIONES DE COMPARACIÓN
// ============================================

function gp_get_compare_list() {
    $compare = isset($_COOKIE['gp_compare']) ? json_decode(stripslashes($_COOKIE['gp_compare']), true) : array();
    return is_array($compare) ? $compare : array();
}

function gp_save_compare_list($compare) {
    setcookie('gp_compare', json_encode($compare), time() + (86400 * 30), '/');
}

// Agregar a comparación
add_action('wp_ajax_add_to_compare', 'gp_add_to_compare');
add_action('wp_ajax_nopriv_add_to_compare', 'gp_add_to_compare');

function gp_add_to_compare() {
    $product_id = intval($_POST['product_id']);
    $compare = gp_get_compare_list();
    
    if (count($compare) >= 4) {
        wp_send_json_error(array('message' => 'Máximo 4 productos para comparar'));
    }
    
    if (!in_array($product_id, $compare)) {
        $compare[] = $product_id;
        gp_save_compare_list($compare);
    }
    
    wp_send_json_success(array(
        'count' => count($compare),
        'message' => 'Agregado a comparación'
    ));
}

// Eliminar de comparación
add_action('wp_ajax_remove_from_compare', 'gp_remove_from_compare');
add_action('wp_ajax_nopriv_remove_from_compare', 'gp_remove_from_compare');

function gp_remove_from_compare() {
    $product_id = intval($_POST['product_id']);
    $compare = gp_get_compare_list();
    
    $key = array_search($product_id, $compare);
    if ($key !== false) {
        unset($compare[$key]);
        $compare = array_values($compare);
        gp_save_compare_list($compare);
    }
    
    wp_send_json_success(array('count' => count($compare)));
}

// Limpiar comparación
add_action('wp_ajax_clear_compare', 'gp_clear_compare');
add_action('wp_ajax_nopriv_clear_compare', 'gp_clear_compare');

function gp_clear_compare() {
    gp_save_compare_list(array());
    wp_send_json_success(array('message' => 'Comparación limpiada'));
}

// ============================================
// BOTÓN COMPARAR EN PRODUCTOS
// ============================================

add_action('woocommerce_after_add_to_cart_button', 'gp_compare_button');

function gp_compare_button() {
    global $product;
    $product_id = $product->get_id();
    $compare = gp_get_compare_list();
    $in_compare = in_array($product_id, $compare);
    $count = count($compare);
    
    ?>
    <button type="button" 
            class="gp-compare-toggle" 
            data-product-id="<?php echo $product_id; ?>"
            style="width: 100%; margin-top: 10px; background: transparent; border: 2px solid <?php echo $in_compare ? '#28a745' : '#0A0A0A'; ?>; color: <?php echo $in_compare ? '#28a745' : '#0A0A0A'; ?>; padding: 12px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: all 0.3s;">
        <i class="fas fa-balance-scale"></i>
        <span><?php echo $in_compare ? 'En Comparación' : 'Comparar'; ?></span>
        <?php if ($count > 0 && !$in_compare) : ?>
            <small style="display: block; font-size: 11px; margin-top: 5px;">(<?php echo $count; ?>/4 productos)</small>
        <?php endif; ?>
    </button>
    
    <script>
    document.querySelector('.gp-compare-toggle').addEventListener('click', function() {
        const btn = this;
        const productId = btn.dataset.productId;
        const isInCompare = btn.querySelector('span').textContent.includes('En Comparación');
        
        const action = isInCompare ? 'remove_from_compare' : 'add_to_compare';
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=${action}&product_id=${productId}`
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.data.message);
            }
        });
    });
    </script>
    <?php
}

// Crear página de comparación
add_action('init', 'gp_create_compare_page');

function gp_create_compare_page() {
    $compare_page = get_page_by_path('comparar-productos');
    
    if (!$compare_page) {
        wp_insert_post(array(
            'post_title' => 'Comparar Productos',
            'post_name' => 'comparar-productos',
            'post_content' => '[product_compare]',
            'post_status' => 'publish',
            'post_type' => 'page',
            'comment_status' => 'closed'
        ));
    }
}
