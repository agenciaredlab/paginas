<?php
/**
 * Golden Phoenix V75 - PANEL CONFIGURACIÓN CENTRALIZADO
 * Todas las funciones configurables desde un solo lugar
 */

if (!defined('ABSPATH')) exit;

class GP_Settings_Panel {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
    }
    
    public static function add_menu() {
        add_menu_page(
            'Golden Phoenix Settings',
            'GP Settings',
            'manage_options',
            'golden-phoenix-settings',
            array(__CLASS__, 'settings_page'),
            'dashicons-admin-generic',
            30
        );
        
        // Submenu tabs
        add_submenu_page('golden-phoenix-settings', 'General', 'General', 'manage_options', 'golden-phoenix-settings');
        add_submenu_page('golden-phoenix-settings', 'E-commerce', 'E-commerce', 'manage_options', 'gp-ecommerce-settings', array(__CLASS__, 'ecommerce_page'));
        add_submenu_page('golden-phoenix-settings', 'Joyería', 'Joyería', 'manage_options', 'gp-jewelry-settings', array(__CLASS__, 'jewelry_page'));
        add_submenu_page('golden-phoenix-settings', 'Chats', 'Chats & WhatsApp', 'manage_options', 'gp-chat-settings', array(__CLASS__, 'chat_page'));
    }
    
    public static function register_settings() {
        // General
        register_setting('gp_general_settings', 'gp_theme_builder_enabled');
        register_setting('gp_general_settings', 'gp_analytics_enabled');
        
        // E-commerce
        register_setting('gp_ecommerce_settings', 'gp_whatsapp_enabled');
        register_setting('gp_ecommerce_settings', 'gp_whatsapp_number');
        register_setting('gp_ecommerce_settings', 'gp_whatsapp_message');
        register_setting('gp_ecommerce_settings', 'gp_multicurrency_enabled');
        register_setting('gp_ecommerce_settings', 'gp_gift_finder_enabled');
        register_setting('gp_ecommerce_settings', 'gp_bundle_discount_enabled');
        register_setting('gp_ecommerce_settings', 'gp_bundle_2_percent');
        register_setting('gp_ecommerce_settings', 'gp_bundle_3_percent');
        register_setting('gp_ecommerce_settings', 'gp_bundle_5_percent');
        
        // Joyería
        register_setting('gp_jewelry_settings', 'gp_metal_selector_enabled');
        register_setting('gp_jewelry_settings', 'gp_gemstone_selector_enabled');
        register_setting('gp_jewelry_settings', 'gp_certificate_enabled');
        register_setting('gp_jewelry_settings', 'gp_ring_size_enabled');
        register_setting('gp_jewelry_settings', 'gp_engraving_enabled');
        register_setting('gp_jewelry_settings', 'gp_engraving_price');
        register_setting('gp_jewelry_settings', 'gp_custom_builder_enabled');
        
        // Chats
        register_setting('gp_chat_settings', 'gp_live_chat_enabled');
        register_setting('gp_chat_settings', 'gp_whatsapp_floating_enabled');
        register_setting('gp_chat_settings', 'gp_whatsapp_position');
        register_setting('gp_chat_settings', 'gp_whatsapp_color');
    }
    
    public static function settings_page() {
        if (isset($_POST['gp_save_general'])) {
            check_admin_referer('gp_general_settings');
            update_option('gp_theme_builder_enabled', isset($_POST['theme_builder_enabled']));
            update_option('gp_analytics_enabled', isset($_POST['analytics_enabled']));
            echo '<div class="notice notice-success"><p>✅ Configuración guardada</p></div>';
        }
        ?>
        
        <div class="wrap">
            <h1>⚙️ Golden Phoenix Settings - General</h1>
            
            <form method="post">
                <?php wp_nonce_field('gp_general_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th>Theme Builder</th>
                        <td>
                            <label>
                                <input type="checkbox" name="theme_builder_enabled" value="1" <?php checked(get_option('gp_theme_builder_enabled', false)); ?>>
                                Habilitar Theme Builder en Personalizar
                            </label>
                            <p class="description">Solo visible para administradores</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Analytics Dashboard</th>
                        <td>
                            <label>
                                <input type="checkbox" name="analytics_enabled" value="1" <?php checked(get_option('gp_analytics_enabled', true)); ?>>
                                Mostrar Analytics en menú admin
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="gp_save_general" class="button button-primary">
                        💾 Guardar Cambios
                    </button>
                </p>
            </form>
        </div>
        
        <?php
    }
    
    public static function ecommerce_page() {
        if (isset($_POST['gp_save_ecommerce'])) {
            check_admin_referer('gp_ecommerce_settings');
            
            update_option('gp_whatsapp_enabled', isset($_POST['whatsapp_enabled']));
            update_option('gp_whatsapp_number', sanitize_text_field($_POST['whatsapp_number']));
            update_option('gp_whatsapp_message', sanitize_textarea_field($_POST['whatsapp_message']));
            update_option('gp_multicurrency_enabled', isset($_POST['multicurrency_enabled']));
            update_option('gp_gift_finder_enabled', isset($_POST['gift_finder_enabled']));
            update_option('gp_bundle_discount_enabled', isset($_POST['bundle_discount_enabled']));
            update_option('gp_bundle_2_percent', intval($_POST['bundle_2_percent']));
            update_option('gp_bundle_3_percent', intval($_POST['bundle_3_percent']));
            update_option('gp_bundle_5_percent', intval($_POST['bundle_5_percent']));
            
            echo '<div class="notice notice-success"><p>✅ Configuración e-commerce guardada</p></div>';
        }
        ?>
        
        <div class="wrap">
            <h1>🛍️ Golden Phoenix Settings - E-commerce</h1>
            
            <form method="post">
                <?php wp_nonce_field('gp_ecommerce_settings'); ?>
                
                <h2>WhatsApp Direct Order</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar WhatsApp</th>
                        <td>
                            <label>
                                <input type="checkbox" name="whatsapp_enabled" value="1" <?php checked(get_option('gp_whatsapp_enabled', true)); ?>>
                                Habilitar botones WhatsApp
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Número WhatsApp</th>
                        <td>
                            <input type="text" name="whatsapp_number" value="<?php echo esc_attr(get_option('gp_whatsapp_number', '573001234567')); ?>" class="regular-text">
                            <p class="description">Sin + ni espacios. Ej: 573001234567</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Mensaje Predeterminado</th>
                        <td>
                            <textarea name="whatsapp_message" rows="3" class="large-text"><?php echo esc_textarea(get_option('gp_whatsapp_message', 'Hola! Tengo una consulta.')); ?></textarea>
                        </td>
                    </tr>
                </table>
                
                <hr>
                
                <h2>Multi-Currency</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar Multi-Currency</th>
                        <td>
                            <label>
                                <input type="checkbox" name="multicurrency_enabled" value="1" <?php checked(get_option('gp_multicurrency_enabled', true)); ?>>
                                Mostrar selector de moneda
                            </label>
                        </td>
                    </tr>
                </table>
                
                <hr>
                
                <h2>Gift Finder</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar Gift Finder</th>
                        <td>
                            <label>
                                <input type="checkbox" name="gift_finder_enabled" value="1" <?php checked(get_option('gp_gift_finder_enabled', true)); ?>>
                                Habilitar buscador de regalos
                            </label>
                        </td>
                    </tr>
                </table>
                
                <hr>
                
                <h2>Bundle Discounts</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar Descuentos</th>
                        <td>
                            <label>
                                <input type="checkbox" name="bundle_discount_enabled" value="1" <?php checked(get_option('gp_bundle_discount_enabled', true)); ?>>
                                Aplicar descuentos por cantidad
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>2 Productos</th>
                        <td>
                            <input type="number" name="bundle_2_percent" value="<?php echo esc_attr(get_option('gp_bundle_2_percent', 5)); ?>" min="0" max="100" style="width: 80px;"> %
                        </td>
                    </tr>
                    
                    <tr>
                        <th>3-4 Productos</th>
                        <td>
                            <input type="number" name="bundle_3_percent" value="<?php echo esc_attr(get_option('gp_bundle_3_percent', 10)); ?>" min="0" max="100" style="width: 80px;"> %
                        </td>
                    </tr>
                    
                    <tr>
                        <th>5+ Productos</th>
                        <td>
                            <input type="number" name="bundle_5_percent" value="<?php echo esc_attr(get_option('gp_bundle_5_percent', 15)); ?>" min="0" max="100" style="width: 80px;"> %
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="gp_save_ecommerce" class="button button-primary">
                        💾 Guardar Configuración E-commerce
                    </button>
                </p>
            </form>
        </div>
        
        <?php
    }
    
    public static function jewelry_page() {
        if (isset($_POST['gp_save_jewelry'])) {
            check_admin_referer('gp_jewelry_settings');
            
            update_option('gp_metal_selector_enabled', isset($_POST['metal_enabled']));
            update_option('gp_gemstone_selector_enabled', isset($_POST['gemstone_enabled']));
            update_option('gp_certificate_enabled', isset($_POST['certificate_enabled']));
            update_option('gp_ring_size_enabled', isset($_POST['ring_size_enabled']));
            update_option('gp_engraving_enabled', isset($_POST['engraving_enabled']));
            update_option('gp_engraving_price', intval($_POST['engraving_price']));
            update_option('gp_custom_builder_enabled', isset($_POST['custom_builder_enabled']));
            
            echo '<div class="notice notice-success"><p>✅ Configuración joyería guardada</p></div>';
        }
        ?>
        
        <div class="wrap">
            <h1>💎 Golden Phoenix Settings - Joyería</h1>
            
            <form method="post">
                <?php wp_nonce_field('gp_jewelry_settings'); ?>
                
                <table class="form-table">
                    <tr>
                        <th>Metal Selector</th>
                        <td>
                            <label>
                                <input type="checkbox" name="metal_enabled" value="1" <?php checked(get_option('gp_metal_selector_enabled', true)); ?>>
                                Habilitar selector de metales (Oro, Platino, Plata)
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Gemstone Selector</th>
                        <td>
                            <label>
                                <input type="checkbox" name="gemstone_enabled" value="1" <?php checked(get_option('gp_gemstone_selector_enabled', true)); ?>>
                                Habilitar selector de piedras preciosas
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Certificado Autenticidad</th>
                        <td>
                            <label>
                                <input type="checkbox" name="certificate_enabled" value="1" <?php checked(get_option('gp_certificate_enabled', true)); ?>>
                                Auto-generar certificados al completar pedido
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Ring Size Guide</th>
                        <td>
                            <label>
                                <input type="checkbox" name="ring_size_enabled" value="1" <?php checked(get_option('gp_ring_size_enabled', true)); ?>>
                                Mostrar guía de tallas en anillos
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Grabado Personalizado</th>
                        <td>
                            <label>
                                <input type="checkbox" name="engraving_enabled" value="1" <?php checked(get_option('gp_engraving_enabled', true)); ?>>
                                Permitir grabado personalizado
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Precio Grabado</th>
                        <td>
                            $<input type="number" name="engraving_price" value="<?php echo esc_attr(get_option('gp_engraving_price', 50000)); ?>" style="width: 150px;">
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Custom Jewelry Builder</th>
                        <td>
                            <label>
                                <input type="checkbox" name="custom_builder_enabled" value="1" <?php checked(get_option('gp_custom_builder_enabled', true)); ?>>
                                Habilitar constructor de joyas personalizado
                            </label>
                            <p class="description">Página: /custom-jewelry-builder</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="gp_save_jewelry" class="button button-primary">
                        💾 Guardar Configuración Joyería
                    </button>
                </p>
            </form>
        </div>
        
        <?php
    }
    
    public static function chat_page() {
        if (isset($_POST['gp_save_chat'])) {
            check_admin_referer('gp_chat_settings');
            
            update_option('gp_live_chat_enabled', isset($_POST['live_chat_enabled']));
            update_option('gp_whatsapp_floating_enabled', isset($_POST['whatsapp_float_enabled']));
            update_option('gp_whatsapp_position', sanitize_text_field($_POST['whatsapp_position']));
            update_option('gp_whatsapp_color', sanitize_hex_color($_POST['whatsapp_color']));
            
            echo '<div class="notice notice-success"><p>✅ Configuración chats guardada</p></div>';
        }
        ?>
        
        <div class="wrap">
            <h1>💬 Golden Phoenix Settings - Chats</h1>
            
            <form method="post">
                <?php wp_nonce_field('gp_chat_settings'); ?>
                
                <h2>Chat en Vivo</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar Chat en Vivo</th>
                        <td>
                            <label>
                                <input type="checkbox" name="live_chat_enabled" value="1" <?php checked(get_option('gp_live_chat_enabled', true)); ?>>
                                Mostrar botón de chat en vivo (azul)
                            </label>
                        </td>
                    </tr>
                </table>
                
                <hr>
                
                <h2>WhatsApp Flotante</h2>
                <table class="form-table">
                    <tr>
                        <th>Activar Botón Flotante</th>
                        <td>
                            <label>
                                <input type="checkbox" name="whatsapp_float_enabled" value="1" <?php checked(get_option('gp_whatsapp_floating_enabled', true)); ?>>
                                Mostrar botón WhatsApp flotante (verde)
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Posición</th>
                        <td>
                            <select name="whatsapp_position">
                                <option value="bottom-right" <?php selected(get_option('gp_whatsapp_position', 'bottom-right'), 'bottom-right'); ?>>Abajo Derecha</option>
                                <option value="bottom-left" <?php selected(get_option('gp_whatsapp_position', 'bottom-right'), 'bottom-left'); ?>>Abajo Izquierda</option>
                                <option value="top-right" <?php selected(get_option('gp_whatsapp_position', 'bottom-right'), 'top-right'); ?>>Arriba Derecha</option>
                                <option value="top-left" <?php selected(get_option('gp_whatsapp_position', 'bottom-right'), 'top-left'); ?>>Arriba Izquierda</option>
                            </select>
                        </td>
                    </tr>
                    
                    <tr>
                        <th>Color</th>
                        <td>
                            <input type="color" name="whatsapp_color" value="<?php echo esc_attr(get_option('gp_whatsapp_color', '#25D366')); ?>">
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" name="gp_save_chat" class="button button-primary">
                        💾 Guardar Configuración Chats
                    </button>
                </p>
            </form>
            
            <hr>
            
            <div style="background: #f0f0f0; padding: 20px; border-radius: 8px; margin-top: 30px;">
                <h3>📍 Estado Actual:</h3>
                <ul>
                    <li><strong>Chat en Vivo:</strong> <?php echo get_option('gp_live_chat_enabled') ? '✅ Activo (izquierda)' : '❌ Desactivado'; ?></li>
                    <li><strong>WhatsApp Flotante:</strong> <?php echo get_option('gp_whatsapp_floating_enabled') ? '✅ Activo (derecha)' : '❌ Desactivado'; ?></li>
                </ul>
            </div>
        </div>
        
        <?php
    }
}

GP_Settings_Panel::init();
