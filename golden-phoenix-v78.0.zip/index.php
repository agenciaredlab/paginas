<?php
/**
 * Template principal - Golden Phoenix V53
 * Si es página de inicio configurada, muestra solo el contenido de la página
 * Si no, muestra el contenido del tema
 */

get_header();

// Si es la página de inicio configurada, mostrar solo su contenido
if (is_front_page() && get_option('page_on_front')) {
    while (have_posts()) : the_post();
        ?>
        <div class="page-content-wrapper">
            <?php the_content(); ?>
        </div>
        <?php
    endwhile;
} else {
    // Contenido original del tema para otras páginas
    ?>

<!-- HERO SECTION -->
<section class="hero-section">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-jewelry.jpg" alt="Luxury Jewelry Collection" class="hero-background">
    <div class="hero-overlay"></div>
    
    <div class="hero-content">
        <p class="hero-subtitle">Colección Exclusiva 2025</p>
        <h1 class="hero-title">Elegancia Eterna</h1>
        <p class="hero-description">Descubre piezas únicas creadas con los materiales más preciosos del mundo. Cada joya cuenta una historia de lujo, artesanía y distinción.</p>
        <div style="display: flex; gap: 1rem; justify-content: center; margin-top: 2rem;">
            <a href="#collections" class="btn-luxury">Explorar Colección</a>
            <a href="#heritage" class="btn-luxury btn-outline">Nuestra Historia</a>
        </div>
    </div>
    
    <div class="scroll-indicator">
        <span class="scroll-text">Desliza</span>
        <div class="scroll-line"></div>
    </div>
</section>

<!-- COLECCIONES DESTACADAS -->
<section id="collections" class="collections-section">
    <div class="section-header">
        <p class="section-subtitle">Nuestras Colecciones</p>
        <h2 class="section-title">Creaciones Excepcionales</h2>
        <p class="section-description">Cada colección es una expresión de excelencia artesanal y diseño visionario, creada para quienes aprecian lo extraordinario.</p>
    </div>
    
    <div class="collections-grid">
        <?php
        // Colecciones de ejemplo
        $collections = array(
            array(
                'name' => 'Diamantes Eternos',
                'count' => '24 Piezas',
                'image' => 'collection-diamonds.jpg'
            ),
            array(
                'name' => 'Oro Rosa Signature',
                'count' => '18 Piezas',
                'image' => 'collection-rose-gold.jpg'
            ),
            array(
                'name' => 'Esmeraldas Imperiales',
                'count' => '12 Piezas',
                'image' => 'collection-emeralds.jpg'
            )
        );
        
        foreach ($collections as $collection): ?>
            <div class="collection-card">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $collection['image']; ?>" alt="<?php echo $collection['name']; ?>" class="collection-image">
                <div class="collection-overlay">
                    <h3 class="collection-name"><?php echo $collection['name']; ?></h3>
                    <p class="collection-count"><?php echo $collection['count']; ?></p>
                </div>
                <span class="collection-cta">Ver Colección →</span>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- PRODUCTOS DESTACADOS -->
<section class="featured-products">
    <div class="section-header">
        <p class="section-subtitle">Selección Exclusiva</p>
        <h2 class="section-title">Piezas Destacadas</h2>
        <p class="section-description">Las joyas más codiciadas de nuestra colección actual</p>
    </div>
    
    <div class="products-grid">
        <?php
        // Productos de ejemplo
        $products = array(
            array(
                'name' => 'Anillo Solitario Victoria',
                'category' => 'Anillos de Compromiso',
                'price' => '$15,900',
                'badge' => 'Nuevo',
                'image' => 'product-ring-1.jpg'
            ),
            array(
                'name' => 'Collar Eternity',
                'category' => 'Collares',
                'price' => '$24,500',
                'badge' => 'Exclusivo',
                'image' => 'product-necklace-1.jpg'
            ),
            array(
                'name' => 'Pulsera Imperial',
                'category' => 'Pulseras',
                'price' => '$18,700',
                'badge' => '',
                'image' => 'product-bracelet-1.jpg'
            ),
            array(
                'name' => 'Aretes Celestial',
                'category' => 'Aretes',
                'price' => '$12,300',
                'badge' => 'Bestseller',
                'image' => 'product-earrings-1.jpg'
            ),
            array(
                'name' => 'Broche Versailles',
                'category' => 'Broches',
                'price' => '$9,800',
                'badge' => '',
                'image' => 'product-brooch-1.jpg'
            ),
            array(
                'name' => 'Anillo Trinity',
                'category' => 'Anillos',
                'price' => '$7,500',
                'badge' => '',
                'image' => 'product-ring-2.jpg'
            )
        );
        
        foreach ($products as $index => $product): ?>
            <div class="product-card">
                <div class="product-image-wrapper">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="product-image">
                    <?php if (!empty($product['badge'])): ?>
                        <span class="product-badge"><?php echo $product['badge']; ?></span>
                    <?php endif; ?>
                    <div class="product-wishlist">♡</div>
                </div>
                <div class="product-info">
                    <p class="product-category"><?php echo $product['category']; ?></p>
                    <h3 class="product-name"><?php echo $product['name']; ?></h3>
                    <p class="product-price"><?php echo $product['price']; ?></p>
                </div>
                <div class="product-quick-view">Vista Rápida</div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <div style="text-align: center; margin-top: 4rem;">
        <a href="/shop" class="btn-luxury">Ver Toda la Colección</a>
    </div>
</section>

<!-- SECCIÓN PARALAJE -->
<section class="parallax-section">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/parallax-craftsman.jpg" alt="Artesanía de Lujo" class="parallax-bg" id="parallaxBg">
    <div class="hero-overlay"></div>
    <div class="parallax-content">
        <p class="section-subtitle" style="color: var(--gold-primary);">Artesanía Excepcional</p>
        <h2 style="color: var(--white-pure); font-size: clamp(2rem, 4vw, 3.5rem);">Cada Pieza es una Obra Maestra</h2>
        <p style="max-width: 600px; margin: 2rem auto; color: rgba(255, 255, 255, 0.8); font-size: 1.125rem;">Nuestros maestros joyeros dedican cientos de horas a perfeccionar cada detalle, utilizando técnicas centenarias combinadas con innovación moderna.</p>
    </div>
</section>

<!-- HERITAGE / ABOUT -->
<section id="heritage" class="heritage-section">
    <div class="heritage-pattern"></div>
    <div class="heritage-container">
        <div class="heritage-content">
            <p class="section-subtitle">Nuestra Herencia</p>
            <h2>Más de un Siglo de Excelencia</h2>
            <p class="heritage-text">
                Desde 1892, hemos sido sinónimo de lujo y artesanía excepcional. Cada joya que creamos es el resultado de generaciones de maestría, innovación constante y un compromiso inquebrantable con la perfección.
            </p>
            <p class="heritage-text">
                Nuestras piezas han adornado a la realeza, celebridades y coleccionistas distinguidos en todo el mundo. Cada creación lleva consigo nuestra firma de calidad y el peso de más de 130 años de tradición.
            </p>
            
            <div class="heritage-stats">
                <div class="stat-item">
                    <span class="stat-number">1892</span>
                    <span class="stat-label">Fundación</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">50+</span>
                    <span class="stat-label">Maestros Joyeros</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">200k+</span>
                    <span class="stat-label">Piezas Creadas</span>
                </div>
            </div>
        </div>
        
        <div class="heritage-image">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/heritage-workshop.jpg" alt="Nuestro Taller">
            <div class="heritage-frame"></div>
        </div>
    </div>
</section>

<!-- TESTIMONIOS -->
<section class="testimonials-section">
    <div class="section-header">
        <p class="section-subtitle">Testimonios</p>
        <h2 class="section-title">Lo Que Dicen Nuestros Clientes</h2>
    </div>
    
    <div class="testimonials-slider">
        <?php
        $testimonials = array(
            array(
                'quote' => 'La pieza más hermosa que he poseído. La artesanía es impecable y el servicio extraordinario. Una inversión que atesoraré por generaciones.',
                'author' => 'Isabella Martínez',
                'title' => 'Coleccionista de Arte',
                'image' => 'client-1.jpg',
                'stars' => 5
            ),
            array(
                'quote' => 'Incomparable. Cada detalle muestra el nivel de maestría que solo décadas de experiencia pueden lograr. Absolutamente exquisito.',
                'author' => 'Alejandro Vargas',
                'title' => 'Empresario',
                'image' => 'client-2.jpg',
                'stars' => 5
            )
        );
        
        foreach ($testimonials as $testimonial): ?>
            <div class="testimonial-card">
                <div class="testimonial-stars">
                    <?php for ($i = 0; $i < $testimonial['stars']; $i++): ?>★<?php endfor; ?>
                </div>
                <p class="testimonial-quote"><?php echo $testimonial['quote']; ?></p>
                <div class="testimonial-author">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $testimonial['image']; ?>" alt="<?php echo $testimonial['author']; ?>" class="author-image">
                    <div class="author-info">
                        <h4><?php echo $testimonial['author']; ?></h4>
                        <p class="author-title"><?php echo $testimonial['title']; ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- NEWSLETTER -->
<section class="newsletter-section">
    <div class="newsletter-container">
        <p class="section-subtitle" style="color: var(--gold-primary);">Mantente Informado</p>
        <h2>Únete a Nuestro Círculo Exclusivo</h2>
        <p class="newsletter-text">Recibe acceso anticipado a nuevas colecciones, eventos privados y ofertas exclusivas para miembros.</p>
        
        <form class="newsletter-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="newsletter_subscribe">
            <input type="email" name="email" class="newsletter-input" placeholder="Tu correo electrónico" required>
            <button type="submit" class="newsletter-submit">Suscribirse</button>
        </form>
    </div>
</section>

<?php get_footer(); ?>

<script>
let lastScroll = 0;
const header = document.querySelector('.site-header');

window.addEventListener('scroll', function() {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
});

// Parallax effect
const parallaxBg = document.getElementById('parallaxBg');

if (parallaxBg) {
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallaxSection = parallaxBg.parentElement;
        const sectionTop = parallaxSection.offsetTop;
        const sectionHeight = parallaxSection.offsetHeight;
        
        if (scrolled > sectionTop - window.innerHeight && scrolled < sectionTop + sectionHeight) {
            const offset = (scrolled - sectionTop) * 0.5;
            parallaxBg.style.transform = `translateY(${offset}px)`;
        }
    });
}

// Smooth scroll para enlaces internos
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Animación de fade in cuando elementos entran al viewport
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in-up');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar elementos para animación
document.querySelectorAll('.collection-card, .product-card, .testimonial-card').forEach(el => {
    observer.observe(el);
});

// Wishlist toggle
document.querySelectorAll('.product-wishlist').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        this.innerHTML = this.innerHTML === '♡' ? '♥' : '♡';
        this.style.color = this.innerHTML === '♥' ? 'var(--gold-primary)' : '';
    });
});
</script>

<?php
} // Fin del else - contenido del tema
?>

<?php get_footer(); ?>
