<?php
/**
 * V74 - METAL SELECTOR ADVANCED
 * Selector avanzado de metales con precios y características
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', 'gp_metal_selector_widget');

function gp_metal_selector_widget() {
    global $product;
    
    if (get_post_meta($product->get_id(), '_has_metal_options', true) !== 'yes') {
        return;
    }
    
    $metals = array(
        'oro-18k' => array('name' => 'Oro 18K', 'price' => 500000, 'color' => '#FFD700', 'purity' => '75%'),
        'oro-14k' => array('name' => 'Oro 14K', 'price' => 350000, 'color' => '#DAA520', 'purity' => '58.5%'),
        'oro-blanco' => array('name' => 'Oro Blanco 18K', 'price' => 550000, 'color' => '#E5E4E2', 'purity' => '75%'),
        'platino' => array('name' => 'Platino 950', 'price' => 800000, 'color' => '#E5E4E2', 'purity' => '95%'),
        'plata-925' => array('name' => 'Plata 925', 'price' => 100000, 'color' => '#C0C0C0', 'purity' => '92.5%'),
    );
    ?>
    
    <div class="gp-metal-selector" style="background: #f9f9f9; padding: 25px; border-radius: 8px; margin-bottom: 20px;">
        <h4 style="margin-top: 0;">🏅 Selecciona el Metal</h4>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 15px;">
            <?php foreach ($metals as $key => $metal): ?>
            <label class="metal-option" style="cursor: pointer;">
                <input type="radio" name="selected_metal" value="<?php echo $key; ?>" data-price="<?php echo $metal['price']; ?>" style="display: none;">
                <div class="metal-card" style="background: white; padding: 15px; border-radius: 8px; border: 2px solid #ddd; text-align: center; transition: all 0.3s;">
                    <div style="width: 40px; height: 40px; background: <?php echo $metal['color']; ?>; border-radius: 50%; margin: 0 auto 10px; border: 2px solid #666;"></div>
                    <strong style="display: block; margin-bottom: 5px;"><?php echo $metal['name']; ?></strong>
                    <small style="color: #666; display: block; margin-bottom: 5px;">Pureza: <?php echo $metal['purity']; ?></small>
                    <span style="color: #D4AF37; font-weight: 600;">+$<?php echo number_format($metal['price'], 0, ',', '.'); ?></span>
                </div>
            </label>
            <?php endforeach; ?>
        </div>
        
        <div id="metal-selected-info" style="display: none; padding: 15px; background: white; border-radius: 6px; border-left: 4px solid #D4AF37;">
            <strong>Metal seleccionado:</strong> <span id="metal-name"></span><br>
            <strong>Precio adicional:</strong> <span id="metal-price"></span>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('.metal-option input').on('change', function() {
            $('.metal-card').css({'border-color': '#ddd', 'transform': 'scale(1)'});
            $(this).siblings('.metal-card').css({'border-color': '#D4AF37', 'transform': 'scale(1.05)'});
            
            var metalName = $(this).siblings('.metal-card').find('strong').text();
            var metalPrice = $(this).data('price');
            
            $('#metal-name').text(metalName);
            $('#metal-price').text('$' + metalPrice.toLocaleString('es-CO'));
            $('#metal-selected-info').show();
        });
    });
    </script>
    
    <?php
}

add_action('add_meta_boxes', function() {
    add_meta_box('gp_metal_options', 'Opciones de Metal', function($post) {
        $value = get_post_meta($post->ID, '_has_metal_options', true);
        echo '<label><input type="checkbox" name="_has_metal_options" value="yes" ' . checked($value, 'yes', false) . '> Habilitar selector de metal</label>';
    }, 'product', 'side');
});

add_action('save_post_product', function($post_id) {
    if (isset($_POST['_has_metal_options'])) {
        update_post_meta($post_id, '_has_metal_options', 'yes');
    } else {
        delete_post_meta($post_id, '_has_metal_options');
    }
});
