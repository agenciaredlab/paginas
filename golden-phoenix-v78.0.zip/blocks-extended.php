<?php
/**
 * Golden Phoenix Jewelry - Bloques Extendidos
 * 25+ Bloques Gutenberg Personalizados
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// BLOQUES ADICIONALES DE DISEÑO
// ============================================

/**
 * Bloque: Galería de Productos con Filtros
 */
register_block_type('golden-phoenix/product-gallery', array(
    'editor_script' => 'gp-blocks',
    'style' => 'gp-blocks-style',
    'render_callback' => 'gp_render_product_gallery_block',
    'attributes' => array(
        'categories' => array('type' => 'array', 'default' => array()),
        'showFilters' => array('type' => 'boolean', 'default' => true),
        'showSearch' => array('type' => 'boolean', 'default' => true),
        'showSorting' => array('type' => 'boolean', 'default' => true),
        'productsPerPage' => array('type' => 'number', 'default' => 12),
        'layout' => array('type' => 'string', 'default' => 'grid'),
    )
));

/**
 * Bloque: Comparador de Productos
 */
register_block_type('golden-phoenix/product-comparison', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_comparison_block',
    'attributes' => array(
        'maxProducts' => array('type' => 'number', 'default' => 4),
        'showSpecs' => array('type' => 'boolean', 'default' => true),
        'showPricing' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Calculadora de Precio
 */
register_block_type('golden-phoenix/price-calculator', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_calculator_block',
    'attributes' => array(
        'basePrice' => array('type' => 'number', 'default' => 0),
        'options' => array('type' => 'array', 'default' => array()),
    )
));

/**
 * Bloque: Timeline de Proceso
 */
register_block_type('golden-phoenix/timeline', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_timeline_block',
    'attributes' => array(
        'steps' => array('type' => 'array', 'default' => array()),
        'orientation' => array('type' => 'string', 'default' => 'vertical'),
    )
));

/**
 * Bloque: Contador Regresivo
 */
register_block_type('golden-phoenix/countdown', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_countdown_block',
    'attributes' => array(
        'endDate' => array('type' => 'string', 'default' => ''),
        'title' => array('type' => 'string', 'default' => 'Oferta Limitada'),
        'showDays' => array('type' => 'boolean', 'default' => true),
        'showHours' => array('type' => 'boolean', 'default' => true),
        'showMinutes' => array('type' => 'boolean', 'default' => true),
        'showSeconds' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Carrusel de Imágenes Luxury
 */
register_block_type('golden-phoenix/luxury-carousel', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_carousel_block',
    'attributes' => array(
        'images' => array('type' => 'array', 'default' => array()),
        'autoplay' => array('type' => 'boolean', 'default' => true),
        'interval' => array('type' => 'number', 'default' => 5000),
        'effect' => array('type' => 'string', 'default' => 'fade'),
    )
));

/**
 * Bloque: Mapa Interactivo de Tiendas
 */
register_block_type('golden-phoenix/store-locator', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_store_locator_block',
    'attributes' => array(
        'stores' => array('type' => 'array', 'default' => array()),
        'mapStyle' => array('type' => 'string', 'default' => 'luxury'),
        'defaultZoom' => array('type' => 'number', 'default' => 12),
    )
));

/**
 * Bloque: FAQs Acordeón
 */
register_block_type('golden-phoenix/faq-accordion', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_faq_block',
    'attributes' => array(
        'faqs' => array('type' => 'array', 'default' => array()),
        'openFirst' => array('type' => 'boolean', 'default' => true),
        'style' => array('type' => 'string', 'default' => 'luxury'),
    )
));

/**
 * Bloque: Tarjetas de Equipo
 */
register_block_type('golden-phoenix/team-cards', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_team_block',
    'attributes' => array(
        'members' => array('type' => 'array', 'default' => array()),
        'columns' => array('type' => 'number', 'default' => 3),
        'showSocial' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Tabla de Precios Comparativa
 */
register_block_type('golden-phoenix/pricing-table', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_pricing_table_block',
    'attributes' => array(
        'plans' => array('type' => 'array', 'default' => array()),
        'highlightPlan' => array('type' => 'number', 'default' => 1),
        'billingPeriod' => array('type' => 'string', 'default' => 'monthly'),
    )
));

/**
 * Bloque: Formulario de Contacto Personalizado
 */
register_block_type('golden-phoenix/contact-form', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_contact_form_block',
    'attributes' => array(
        'fields' => array('type' => 'array', 'default' => array()),
        'submitText' => array('type' => 'string', 'default' => 'Enviar Mensaje'),
        'successMessage' => array('type' => 'string', 'default' => '¡Mensaje enviado!'),
    )
));

/**
 * Bloque: Video Hero
 */
register_block_type('golden-phoenix/video-hero', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_video_hero_block',
    'attributes' => array(
        'videoUrl' => array('type' => 'string', 'default' => ''),
        'posterImage' => array('type' => 'string', 'default' => ''),
        'autoplay' => array('type' => 'boolean', 'default' => true),
        'loop' => array('type' => 'boolean', 'default' => true),
        'muted' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Instagram Feed
 */
register_block_type('golden-phoenix/instagram-feed', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_instagram_block',
    'attributes' => array(
        'username' => array('type' => 'string', 'default' => ''),
        'limit' => array('type' => 'number', 'default' => 6),
        'columns' => array('type' => 'number', 'default' => 3),
    )
));

/**
 * Bloque: Barra de Progreso
 */
register_block_type('golden-phoenix/progress-bar', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_progress_bar_block',
    'attributes' => array(
        'label' => array('type' => 'string', 'default' => ''),
        'percentage' => array('type' => 'number', 'default' => 50),
        'color' => array('type' => 'string', 'default' => 'gold'),
        'animated' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Iconos con Texto
 */
register_block_type('golden-phoenix/icon-box', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_icon_box_block',
    'attributes' => array(
        'icon' => array('type' => 'string', 'default' => 'star'),
        'title' => array('type' => 'string', 'default' => ''),
        'description' => array('type' => 'string', 'default' => ''),
        'linkUrl' => array('type' => 'string', 'default' => ''),
    )
));

/**
 * Bloque: Tabs / Pestañas
 */
register_block_type('golden-phoenix/tabs', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_tabs_block',
    'attributes' => array(
        'tabs' => array('type' => 'array', 'default' => array()),
        'style' => array('type' => 'string', 'default' => 'horizontal'),
    )
));

/**
 * Bloque: Antes/Después (Comparación de Imágenes)
 */
register_block_type('golden-phoenix/before-after', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_before_after_block',
    'attributes' => array(
        'beforeImage' => array('type' => 'string', 'default' => ''),
        'afterImage' => array('type' => 'string', 'default' => ''),
        'orientation' => array('type' => 'string', 'default' => 'horizontal'),
    )
));

/**
 * Bloque: Call to Action Avanzado
 */
register_block_type('golden-phoenix/advanced-cta', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_advanced_cta_block',
    'attributes' => array(
        'title' => array('type' => 'string', 'default' => ''),
        'description' => array('type' => 'string', 'default' => ''),
        'primaryButton' => array('type' => 'object', 'default' => array()),
        'secondaryButton' => array('type' => 'object', 'default' => array()),
        'backgroundType' => array('type' => 'string', 'default' => 'gradient'),
    )
));

/**
 * Bloque: Lista de Verificación
 */
register_block_type('golden-phoenix/checklist', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_checklist_block',
    'attributes' => array(
        'items' => array('type' => 'array', 'default' => array()),
        'iconType' => array('type' => 'string', 'default' => 'check'),
        'iconColor' => array('type' => 'string', 'default' => 'gold'),
    )
));

/**
 * Bloque: Popup/Modal
 */
register_block_type('golden-phoenix/popup-modal', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_popup_block',
    'attributes' => array(
        'content' => array('type' => 'string', 'default' => ''),
        'triggerType' => array('type' => 'string', 'default' => 'button'),
        'triggerText' => array('type' => 'string', 'default' => 'Abrir'),
        'autoShow' => array('type' => 'boolean', 'default' => false),
        'delay' => array('type' => 'number', 'default' => 3000),
    )
));

/**
 * Bloque: Tabla de Especificaciones
 */
register_block_type('golden-phoenix/specs-table', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_specs_table_block',
    'attributes' => array(
        'specs' => array('type' => 'array', 'default' => array()),
        'style' => array('type' => 'string', 'default' => 'striped'),
    )
));

/**
 * Bloque: Código de Descuento
 */
register_block_type('golden-phoenix/coupon-code', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_coupon_block',
    'attributes' => array(
        'code' => array('type' => 'string', 'default' => ''),
        'discount' => array('type' => 'string', 'default' => ''),
        'expiryDate' => array('type' => 'string', 'default' => ''),
        'description' => array('type' => 'string', 'default' => ''),
    )
));

/**
 * Bloque: Alertas/Avisos
 */
register_block_type('golden-phoenix/alert-notice', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_alert_block',
    'attributes' => array(
        'type' => array('type' => 'string', 'default' => 'info'),
        'title' => array('type' => 'string', 'default' => ''),
        'message' => array('type' => 'string', 'default' => ''),
        'dismissible' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Reseñas de Productos
 */
register_block_type('golden-phoenix/product-reviews', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_reviews_block',
    'attributes' => array(
        'productId' => array('type' => 'number', 'default' => 0),
        'limit' => array('type' => 'number', 'default' => 5),
        'showRating' => array('type' => 'boolean', 'default' => true),
        'showVerified' => array('type' => 'boolean', 'default' => true),
    )
));

/**
 * Bloque: Chat Widget Personalizable
 */
register_block_type('golden-phoenix/chat-widget', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_chat_widget_block',
    'attributes' => array(
        'position' => array('type' => 'string', 'default' => 'bottom-right'),
        'greeting' => array('type' => 'string', 'default' => '¿Necesitas ayuda?'),
        'buttonColor' => array('type' => 'string', 'default' => 'gold'),
    )
));

/**
 * Bloque: Garantía/Trust Badges
 */
register_block_type('golden-phoenix/trust-badges', array(
    'editor_script' => 'gp-blocks',
    'render_callback' => 'gp_render_trust_badges_block',
    'attributes' => array(
        'badges' => array('type' => 'array', 'default' => array()),
        'layout' => array('type' => 'string', 'default' => 'horizontal'),
    )
));

// ============================================
// FUNCIONES DE RENDERIZADO (EJEMPLOS)
// ============================================

function gp_render_product_gallery_block($attributes) {
    ob_start();
    $categories = $attributes['categories'];
    $show_filters = $attributes['showFilters'];
    $products_per_page = $attributes['productsPerPage'];
    
    ?>
    <div class="gp-product-gallery" data-categories="<?php echo esc_attr(json_encode($categories)); ?>">
        <?php if ($show_filters): ?>
        <div class="gp-gallery-filters">
            <div class="filter-search">
                <input type="text" placeholder="Buscar productos..." class="gp-search-input">
            </div>
            <div class="filter-categories">
                <button class="filter-btn active" data-category="all">Todos</button>
                <?php
                $product_categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => true));
                foreach ($product_categories as $category):
                ?>
                    <button class="filter-btn" data-category="<?php echo $category->slug; ?>">
                        <?php echo $category->name; ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <div class="filter-sort">
                <select class="gp-sort-select">
                    <option value="date">Más Recientes</option>
                    <option value="price-asc">Precio: Menor a Mayor</option>
                    <option value="price-desc">Precio: Mayor a Menor</option>
                    <option value="popularity">Más Populares</option>
                </select>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="gp-gallery-grid" id="gp-products-container">
            <!-- Productos cargados dinámicamente -->
        </div>
        
        <div class="gp-gallery-pagination">
            <!-- Paginación -->
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        // Inicializar galería con AJAX
        gpInitProductGallery();
    });
    </script>
    <?php
    return ob_get_clean();
}

function gp_render_countdown_block($attributes) {
    $end_date = $attributes['endDate'];
    $title = $attributes['title'];
    
    ob_start();
    ?>
    <div class="gp-countdown-block" data-end="<?php echo esc_attr($end_date); ?>">
        <h3 class="countdown-title"><?php echo esc_html($title); ?></h3>
        <div class="countdown-timer">
            <?php if ($attributes['showDays']): ?>
                <div class="time-unit">
                    <span class="time-value" id="countdown-days">00</span>
                    <span class="time-label">Días</span>
                </div>
            <?php endif; ?>
            <?php if ($attributes['showHours']): ?>
                <div class="time-unit">
                    <span class="time-value" id="countdown-hours">00</span>
                    <span class="time-label">Horas</span>
                </div>
            <?php endif; ?>
            <?php if ($attributes['showMinutes']): ?>
                <div class="time-unit">
                    <span class="time-value" id="countdown-minutes">00</span>
                    <span class="time-label">Minutos</span>
                </div>
            <?php endif; ?>
            <?php if ($attributes['showSeconds']): ?>
                <div class="time-unit">
                    <span class="time-value" id="countdown-seconds">00</span>
                    <span class="time-label">Segundos</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    (function() {
        const endDate = new Date('<?php echo $end_date; ?>').getTime();
        
        function updateCountdown() {
            const now = new Date().getTime();
            const distance = endDate - now;
            
            if (distance < 0) {
                document.querySelector('.gp-countdown-block').innerHTML = '<h3>¡Oferta Expirada!</h3>';
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            document.getElementById('countdown-days').textContent = String(days).padStart(2, '0');
            document.getElementById('countdown-hours').textContent = String(hours).padStart(2, '0');
            document.getElementById('countdown-minutes').textContent = String(minutes).padStart(2, '0');
            document.getElementById('countdown-seconds').textContent = String(seconds).padStart(2, '0');
        }
        
        updateCountdown();
        setInterval(updateCountdown, 1000);
    })();
    </script>
    <?php
    return ob_get_clean();
}

function gp_render_faq_block($attributes) {
    $faqs = $attributes['faqs'];
    $open_first = $attributes['openFirst'];
    
    ob_start();
    ?>
    <div class="gp-faq-accordion">
        <?php foreach ($faqs as $index => $faq): ?>
        <div class="faq-item <?php echo ($open_first && $index === 0) ? 'active' : ''; ?>">
            <div class="faq-question" onclick="gpToggleFaq(this)">
                <h4><?php echo esc_html($faq['question']); ?></h4>
                <span class="faq-icon">+</span>
            </div>
            <div class="faq-answer" style="<?php echo ($open_first && $index === 0) ? '' : 'display:none;'; ?>">
                <p><?php echo esc_html($faq['answer']); ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <script>
    function gpToggleFaq(element) {
        const item = element.closest('.faq-item');
        const answer = item.querySelector('.faq-answer');
        const icon = item.querySelector('.faq-icon');
        
        // Cerrar otros
        document.querySelectorAll('.faq-item').forEach(i => {
            if (i !== item) {
                i.classList.remove('active');
                i.querySelector('.faq-answer').style.display = 'none';
                i.querySelector('.faq-icon').textContent = '+';
            }
        });
        
        // Toggle actual
        item.classList.toggle('active');
        if (answer.style.display === 'none') {
            answer.style.display = 'block';
            icon.textContent = '−';
        } else {
            answer.style.display = 'none';
            icon.textContent = '+';
        }
    }
    </script>
    <?php
    return ob_get_clean();
}

function gp_render_alert_block($attributes) {
    $type = $attributes['type'];
    $title = $attributes['title'];
    $message = $attributes['message'];
    $dismissible = $attributes['dismissible'];
    
    $icons = array(
        'info' => 'ℹ️',
        'success' => '✓',
        'warning' => '⚠️',
        'error' => '✕'
    );
    
    ob_start();
    ?>
    <div class="gp-alert gp-alert-<?php echo esc_attr($type); ?>" role="alert">
        <div class="alert-icon"><?php echo $icons[$type]; ?></div>
        <div class="alert-content">
            <?php if ($title): ?>
                <h4 class="alert-title"><?php echo esc_html($title); ?></h4>
            <?php endif; ?>
            <p class="alert-message"><?php echo esc_html($message); ?></p>
        </div>
        <?php if ($dismissible): ?>
            <button class="alert-close" onclick="this.parentElement.remove()">×</button>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// Agregar más funciones de renderizado según sea necesario...
