<?php
/**
 * V77 - LOYALTY POINTS
 * Sistema puntos de lealtad
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_order_status_completed', 'gp_award_loyalty_points');

function gp_award_loyalty_points($order_id) {
    $order = wc_get_order($order_id);
    $user_id = $order->get_user_id();
    
    if (!$user_id) return;
    
    $total = $order->get_total();
    $points = floor($total / 1000); // 1 punto por cada $1,000
    
    $current_points = get_user_meta($user_id, 'gp_loyalty_points', true) ?: 0;
    $new_points = $current_points + $points;
    
    update_user_meta($user_id, 'gp_loyalty_points', $new_points);
    
    $order->add_order_note("🌟 Cliente ganó {$points} puntos de lealtad");
}

add_shortcode('loyalty_points_balance', function() {
    if (!is_user_logged_in()) {
        return '<p>Inicia sesión para ver tus puntos</p>';
    }
    
    $points = get_user_meta(get_current_user_id(), 'gp_loyalty_points', true) ?: 0;
    
    ob_start();
    ?>
    <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; border-radius: 12px; text-align: center;">
        <h2 style="margin: 0 0 10px 0; color: white;">🌟 Tus Puntos de Lealtad</h2>
        <div style="font-size: 48px; font-weight: 700; margin: 20px 0;"><?php echo $points; ?></div>
        <p style="margin: 0; opacity: 0.9;">Puntos disponibles</p>
        
        <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 8px; margin-top: 20px;">
            <p style="margin: 0; font-size: 14px;">
                💡 Ganas 1 punto por cada $1,000 en compras<br>
                🎁 Canjea puntos por descuentos especiales
            </p>
        </div>
    </div>
    <?php
    return ob_get_clean();
});
