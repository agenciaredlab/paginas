<?php
/**
 * V77 - SIZE CHART
 * Tabla tallas universal
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', function() {
    global $product;
    
    if (!has_term('anillos', 'product_cat', $product->get_id())) {
        return;
    }
    ?>
    
    <button type="button" onclick="document.getElementById('gp-size-chart-modal').style.display='flex'" style="background: none; border: 1px solid #D4AF37; color: #D4AF37; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin-bottom: 15px; width: 100%;">
        📐 Ver Tabla de Tallas
    </button>
    
    <div id="gp-size-chart-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 99999; align-items: center; justify-content: center; padding: 20px;">
        <div style="background: white; padding: 40px; border-radius: 12px; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto; position: relative;">
            <button onclick="document.getElementById('gp-size-chart-modal').style.display='none'" style="position: absolute; top: 15px; right: 15px; background: none; border: none; font-size: 30px; cursor: pointer; color: #999;">×</button>
            
            <h2 style="margin-top: 0;">📏 Guía de Tallas - Anillos</h2>
            
            <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                <thead>
                    <tr style="background: #f5f5f5;">
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Talla</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Diámetro (mm)</th>
                        <th style="padding: 12px; border: 1px solid #ddd; text-align: left;">Circunferencia (mm)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">5</td><td style="padding: 10px; border: 1px solid #ddd;">15.7</td><td style="padding: 10px; border: 1px solid #ddd;">49.3</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">6</td><td style="padding: 10px; border: 1px solid #ddd;">16.5</td><td style="padding: 10px; border: 1px solid #ddd;">51.9</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">7</td><td style="padding: 10px; border: 1px solid #ddd;">17.3</td><td style="padding: 10px; border: 1px solid #ddd;">54.4</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">8</td><td style="padding: 10px; border: 1px solid #ddd;">18.2</td><td style="padding: 10px; border: 1px solid #ddd;">57.0</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">9</td><td style="padding: 10px; border: 1px solid #ddd;">19.0</td><td style="padding: 10px; border: 1px solid #ddd;">59.5</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">10</td><td style="padding: 10px; border: 1px solid #ddd;">19.8</td><td style="padding: 10px; border: 1px solid #ddd;">62.1</td></tr>
                    <tr><td style="padding: 10px; border: 1px solid #ddd;">11</td><td style="padding: 10px; border: 1px solid #ddd;">20.6</td><td style="padding: 10px; border: 1px solid #ddd;">64.6</td></tr>
                </tbody>
            </table>
            
            <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-top: 20px;">
                <h4>💡 Cómo medir tu talla:</h4>
                <ol style="line-height: 1.8;">
                    <li>Toma un anillo que te quede bien</li>
                    <li>Mide el diámetro interior con regla</li>
                    <li>Compara con la tabla</li>
                </ol>
            </div>
        </div>
    </div>
    
    <?php
});
