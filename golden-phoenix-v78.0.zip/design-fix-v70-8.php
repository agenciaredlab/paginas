<?php
/**
 * Golden Phoenix V70.8 - FIX DISEÑO EXACTO
 * Hace que el diseño coincida EXACTAMENTE con la imagen de referencia
 */

if (!defined('ABSPATH')) exit;

// Agregar CSS para diseño correcto
add_action('wp_head', 'gp_v70_8_design_fix', 10001);

function gp_v70_8_design_fix() {
    ?>
    <style id="gp-v70-8-design-fix">
    /* V70.8 - DISEÑO CORRECTO SEGÚN IMAGEN */
    
    /* RESET de estilos problemáticos */
    body {
        background-color: #FAF9F6 !important;
    }
    
    /* TESTIMONIALS SECTION - Exacto a imagen */
    .testimonials-section {
        background: #FAF9F6;
        padding: 80px 20px;
    }
    
    .testimonials-section .section-subtitle {
        text-align: center;
        font-size: 12px;
        letter-spacing: 3px;
        color: #D4AF37;
        font-weight: 600;
        margin-bottom: 15px;
        text-transform: uppercase;
    }
    
    .testimonials-section .section-title {
        text-align: center;
        font-family: 'Playfair Display', serif;
        font-size: 48px;
        color: #0A0A0A;
        font-weight: 400;
        margin-bottom: 60px;
        line-height: 1.3;
    }
    
    .testimonials-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .testimonial-card {
        background: #FFFFFF;
        padding: 40px 35px;
        border-radius: 8px;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.06);
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .testimonial-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
    }
    
    .testimonial-stars {
        display: flex;
        justify-content: center;
        gap: 4px;
        margin-bottom: 25px;
    }
    
    .testimonial-stars .star {
        color: #D4AF37;
        font-size: 20px;
    }
    
    .testimonial-text {
        font-family: 'Montserrat', sans-serif;
        font-size: 16px;
        line-height: 1.8;
        color: #555555;
        font-style: italic;
        margin-bottom: 30px;
    }
    
    .testimonial-author {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
    }
    
    .testimonial-avatar {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        border: 2px solid #D4AF37;
        object-fit: cover;
    }
    
    .testimonial-info {
        text-align: left;
    }
    
    .testimonial-name {
        font-family: 'Playfair Display', serif;
        font-size: 18px;
        font-weight: 700;
        color: #0A0A0A;
        margin: 0;
    }
    
    .testimonial-role {
        font-size: 14px;
        color: #D4AF37;
        margin: 0;
    }
    
    /* FEATURES SECTION - 4 columnas */
    .features-section {
        background: #0A0A0A;
        padding: 60px 20px;
    }
    
    .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 40px;
        max-width: 1400px;
        margin: 0 auto;
    }
    
    .feature-item {
        text-align: center;
        color: white;
    }
    
    .feature-title {
        font-family: 'Playfair Display', serif;
        font-size: 20px;
        color: #D4AF37;
        margin-bottom: 10px;
        font-weight: 600;
    }
    
    .feature-description {
        font-size: 14px;
        line-height: 1.6;
        color: #CCCCCC;
    }
    
    /* HEADER - Asegurar diseño correcto */
    .site-header {
        background: #FFFFFF;
        border-bottom: 1px solid #f0f0f0;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .testimonials-section .section-title {
            font-size: 32px;
        }
        
        .testimonials-grid {
            grid-template-columns: 1fr;
        }
        
        .features-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
    <?php
}

// Agregar sección de testimonios a page-home.php via hook
add_action('gp_after_features', 'gp_v70_8_testimonials_section');

function gp_v70_8_testimonials_section() {
    ?>
    <section class="testimonials-section">
        <div class="container">
            <p class="section-subtitle">TESTIMONIOS</p>
            <h2 class="section-title">Lo Que Dicen Nuestros<br>Clientes</h2>
            
            <div class="testimonials-grid">
                <!-- Testimonial 1 -->
                <div class="testimonial-card">
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    
                    <p class="testimonial-text">
                        "La pieza más hermosa que he poseído. La artesanía es impecable y el servicio extraordinario. Una inversión que atesoraré por generaciones."
                    </p>
                    
                    <div class="testimonial-author">
                        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='50'%3E%3Ccircle cx='25' cy='25' r='24' fill='%23f0f0f0'/%3E%3Ctext x='25' y='32' text-anchor='middle' fill='%23D4AF37' font-family='Arial' font-size='20' font-weight='bold'%3EIM%3C/text%3E%3C/svg%3E" 
                             alt="Isabella Martínez" 
                             class="testimonial-avatar">
                        <div class="testimonial-info">
                            <p class="testimonial-name">Isabella Martínez</p>
                            <p class="testimonial-role">Coleccionista de Arte</p>
                        </div>
                    </div>
                </div>
                
                <!-- Testimonial 2 -->
                <div class="testimonial-card">
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    
                    <p class="testimonial-text">
                        "Compré un collar para mi esposa y quedó encantada. La atención al detalle es impresionante. Sin duda volveré por más piezas."
                    </p>
                    
                    <div class="testimonial-author">
                        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='50'%3E%3Ccircle cx='25' cy='25' r='24' fill='%23f0f0f0'/%3E%3Ctext x='25' y='32' text-anchor='middle' fill='%23D4AF37' font-family='Arial' font-size='20' font-weight='bold'%3ECR%3C/text%3E%3C/svg%3E" 
                             alt="Carlos Rodríguez" 
                             class="testimonial-avatar">
                        <div class="testimonial-info">
                            <p class="testimonial-name">Carlos Rodríguez</p>
                            <p class="testimonial-role">Empresario</p>
                        </div>
                    </div>
                </div>
                
                <!-- Testimonial 3 -->
                <div class="testimonial-card">
                    <div class="testimonial-stars">
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                        <span class="star">★</span>
                    </div>
                    
                    <p class="testimonial-text">
                        "Diseñaron mi anillo personalizado exactamente como lo soñé. El resultado superó mis expectativas. Servicio excepcional de principio a fin."
                    </p>
                    
                    <div class="testimonial-author">
                        <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='50'%3E%3Ccircle cx='25' cy='25' r='24' fill='%23f0f0f0'/%3E%3Ctext x='25' y='32' text-anchor='middle' fill='%23D4AF37' font-family='Arial' font-size='20' font-weight='bold'%3EAM%3C/text%3E%3C/svg%3E" 
                             alt="Ana Martínez" 
                             class="testimonial-avatar">
                        <div class="testimonial-info">
                            <p class="testimonial-name">Ana Martínez</p>
                            <p class="testimonial-role">Arquitecta</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
}
