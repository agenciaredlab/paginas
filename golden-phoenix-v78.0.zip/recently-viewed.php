<?php
/**
 * Golden Phoenix - Recently Viewed Products
 * Productos vistos recientemente por el usuario
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// REGISTRAR PRODUCTO VISTO
// ============================================

add_action('woocommerce_after_single_product', 'gp_track_product_view');

function gp_track_product_view() {
    if (!is_singular('product')) {
        return;
    }
    
    global $post;
    $product_id = $post->ID;
    
    // Obtener productos vistos
    $viewed = gp_get_recently_viewed();
    
    // Eliminar el producto si ya está en la lista
    $key = array_search($product_id, $viewed);
    if ($key !== false) {
        unset($viewed[$key]);
    }
    
    // Agregar al inicio de la lista
    array_unshift($viewed, $product_id);
    
    // Limitar a 12 productos
    $viewed = array_slice($viewed, 0, 12);
    
    // Guardar en cookie
    setcookie('gp_recently_viewed', json_encode($viewed), time() + (86400 * 30), '/');
}

// ============================================
// OBTENER PRODUCTOS VISTOS
// ============================================

function gp_get_recently_viewed() {
    $viewed = isset($_COOKIE['gp_recently_viewed']) ? json_decode(stripslashes($_COOKIE['gp_recently_viewed']), true) : array();
    return is_array($viewed) ? $viewed : array();
}

// ============================================
// WIDGET PRODUCTOS VISTOS
// ============================================

add_action('woocommerce_after_single_product_summary', 'gp_recently_viewed_section', 25);

function gp_recently_viewed_section() {
    $viewed = gp_get_recently_viewed();
    
    // Excluir el producto actual
    global $post;
    $current_id = $post->ID;
    $viewed = array_filter($viewed, function($id) use ($current_id) {
        return $id != $current_id;
    });
    
    if (empty($viewed)) {
        return;
    }
    
    ?>
    <div class="gp-recently-viewed" style="margin: 80px 0; padding: 60px 0; background: #f9f9f9;">
        <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
            
            <div style="text-align: center; margin-bottom: 50px;">
                <h2 style="font-size: 42px; font-family: 'Playfair Display', serif; margin-bottom: 15px;">
                    👁️ Vistos Recientemente
                </h2>
                <div style="width: 80px; height: 3px; background: #D4AF37; margin: 20px auto;"></div>
                <p style="color: #666; font-size: 16px;">Productos que has visto anteriormente</p>
            </div>
            
            <div class="recently-viewed-slider" style="position: relative;">
                <!-- Botón anterior -->
                <button onclick="slideRecent('prev')" 
                        style="position: absolute; left: -50px; top: 50%; transform: translateY(-50%); width: 50px; height: 50px; border-radius: 50%; background: white; border: 2px solid #D4AF37; cursor: pointer; z-index: 10; display: flex; align-items: center; justify-content: center; transition: all 0.3s;"
                        onmouseover="this.style.background='#D4AF37'; this.querySelector('i').style.color='white';"
                        onmouseout="this.style.background='white'; this.querySelector('i').style.color='#D4AF37';">
                    <i class="fas fa-chevron-left" style="color: #D4AF37; transition: color 0.3s;"></i>
                </button>
                
                <!-- Productos -->
                <div class="recently-viewed-track" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 30px; overflow: hidden;">
                    
                    <?php
                    $count = 0;
                    foreach ($viewed as $product_id) :
                        if ($count >= 8) break; // Máximo 8 productos
                        
                        $product = wc_get_product($product_id);
                        if (!$product) continue;
                        
                        $count++;
                    ?>
                    
                    <div class="recently-viewed-item" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 15px rgba(0,0,0,0.08); transition: transform 0.3s;"
                         onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 8px 25px rgba(0,0,0,0.15)';"
                         onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 15px rgba(0,0,0,0.08)';">
                        
                        <a href="<?php echo get_permalink($product_id); ?>">
                            <div style="height: 280px; overflow: hidden; background: #f9f9f9; position: relative;">
                                <?php echo $product->get_image('medium', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                                
                                <!-- Badge si está en oferta -->
                                <?php if ($product->is_on_sale()) : ?>
                                    <span style="position: absolute; top: 15px; right: 15px; background: #dc3545; color: white; padding: 5px 12px; border-radius: 3px; font-size: 12px; font-weight: 600;">
                                        OFERTA
                                    </span>
                                <?php endif; ?>
                            </div>
                        </a>
                        
                        <div style="padding: 20px;">
                            <h3 style="font-size: 16px; margin-bottom: 10px; height: 40px; overflow: hidden;">
                                <a href="<?php echo get_permalink($product_id); ?>" style="text-decoration: none; color: #0A0A0A; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
                                    <?php echo $product->get_name(); ?>
                                </a>
                            </h3>
                            
                            <div style="color: #D4AF37; font-size: 20px; font-weight: 700; margin-bottom: 15px;">
                                <?php echo $product->get_price_html(); ?>
                            </div>
                            
                            <?php if ($product->is_in_stock()) : ?>
                                <button onclick="quickAddToCart(<?php echo $product_id; ?>, this)" 
                                        style="width: 100%; background: #D4AF37; color: white; border: none; padding: 12px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: background 0.3s;"
                                        onmouseover="this.style.background='#0A0A0A'"
                                        onmouseout="this.style.background='#D4AF37'">
                                    <i class="fas fa-cart-plus"></i> Agregar
                                </button>
                            <?php else : ?>
                                <button disabled style="width: 100%; background: #ccc; color: #666; border: none; padding: 12px; border-radius: 4px; font-weight: 600;">
                                    Agotado
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php endforeach; ?>
                    
                </div>
                
                <!-- Botón siguiente -->
                <button onclick="slideRecent('next')" 
                        style="position: absolute; right: -50px; top: 50%; transform: translateY(-50%); width: 50px; height: 50px; border-radius: 50%; background: white; border: 2px solid #D4AF37; cursor: pointer; z-index: 10; display: flex; align-items: center; justify-content: center; transition: all 0.3s;"
                        onmouseover="this.style.background='#D4AF37'; this.querySelector('i').style.color='white';"
                        onmouseout="this.style.background='white'; this.querySelector('i').style.color='#D4AF37';">
                    <i class="fas fa-chevron-right" style="color: #D4AF37; transition: color 0.3s;"></i>
                </button>
            </div>
            
        </div>
    </div>
    
    <style>
    @media (max-width: 1024px) {
        .recently-viewed-track {
            grid-template-columns: repeat(3, 1fr) !important;
        }
        
        .recently-viewed-slider button {
            display: none !important;
        }
    }
    
    @media (max-width: 768px) {
        .recently-viewed-track {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 15px !important;
        }
    }
    
    @media (max-width: 480px) {
        .recently-viewed-track {
            grid-template-columns: 1fr !important;
        }
    }
    </style>
    
    <script>
    let currentSlide = 0;
    
    function slideRecent(direction) {
        const track = document.querySelector('.recently-viewed-track');
        const items = track.querySelectorAll('.recently-viewed-item');
        const totalItems = items.length;
        const itemsPerView = window.innerWidth > 1024 ? 4 : window.innerWidth > 768 ? 3 : 2;
        const maxSlide = Math.ceil(totalItems / itemsPerView) - 1;
        
        if (direction === 'next') {
            currentSlide = currentSlide >= maxSlide ? 0 : currentSlide + 1;
        } else {
            currentSlide = currentSlide <= 0 ? maxSlide : currentSlide - 1;
        }
        
        const offset = currentSlide * (100 / itemsPerView);
        track.style.transform = `translateX(-${offset}%)`;
        track.style.transition = 'transform 0.5s ease';
    }
    
    // Auto-slide cada 5 segundos
    setInterval(() => slideRecent('next'), 5000);
    
    // Agregar rápidamente al carrito
    function quickAddToCart(productId, button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Agregando...';
        button.disabled = true;
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=add_to_cart&product_id=${productId}&quantity=1`
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                button.innerHTML = '<i class="fas fa-check"></i> ¡Agregado!';
                button.style.background = '#28a745';
                
                // Actualizar contador del carrito
                const cartCount = document.querySelector('.cart-count');
                if (cartCount) {
                    cartCount.textContent = parseInt(cartCount.textContent) + 1;
                }
                
                setTimeout(() => {
                    button.innerHTML = originalText;
                    button.style.background = '#D4AF37';
                    button.disabled = false;
                }, 2000);
            }
        });
    }
    </script>
    <?php
}

// ============================================
// SHORTCODE PRODUCTOS VISTOS
// ============================================

add_shortcode('recently_viewed', 'gp_recently_viewed_shortcode');

function gp_recently_viewed_shortcode($atts) {
    $atts = shortcode_atts(array(
        'limit' => 8,
        'columns' => 4
    ), $atts);
    
    $viewed = gp_get_recently_viewed();
    
    if (empty($viewed)) {
        return '<p style="text-align: center; padding: 40px; color: #666;">No has visto ningún producto aún</p>';
    }
    
    ob_start();
    ?>
    <div class="gp-recently-viewed-shortcode">
        <div style="display: grid; grid-template-columns: repeat(<?php echo $atts['columns']; ?>, 1fr); gap: 30px;">
            <?php
            $count = 0;
            foreach ($viewed as $product_id) :
                if ($count >= $atts['limit']) break;
                
                $product = wc_get_product($product_id);
                if (!$product) continue;
                
                $count++;
                
                // Similar al código anterior
                wc_get_template_part('content', 'product');
            endforeach;
            ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ============================================
// LIMPIAR PRODUCTOS VISTOS
// ============================================

add_action('wp_ajax_clear_recently_viewed', 'gp_clear_recently_viewed');
add_action('wp_ajax_nopriv_clear_recently_viewed', 'gp_clear_recently_viewed');

function gp_clear_recently_viewed() {
    setcookie('gp_recently_viewed', '', time() - 3600, '/');
    wp_send_json_success(array('message' => 'Historial limpiado'));
}
