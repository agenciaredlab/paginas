<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <?php wp_head(); ?>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@300;400;500;600;700&family=Montserrat:wght@200;300;400;500;600;700&family=Cormorant+Garamond:wght@300;400;500;600;700&family=Bodoni+Moda:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome para iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="header-container">
        <!-- Logo -->
        <div class="site-logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <?php if (has_custom_logo()): ?>
                    <?php the_custom_logo(); ?>
                <?php else: ?>
                    <?php bloginfo('name'); ?>
                <?php endif; ?>
            </a>
        </div>
        
        <!-- Navegación Principal -->
        <nav class="main-navigation">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'nav-menu',
                'fallback_cb' => function() {
                    echo '<a href="' . esc_url(home_url('/')) . '">Inicio</a>';
                    echo '<a href="' . esc_url(home_url('/colecciones')) . '">Colecciones</a>';
                    // Solo mostrar Tienda si WooCommerce está activo
                    if (function_exists('wc_get_page_id')) {
                        echo '<a href="' . esc_url(get_permalink(wc_get_page_id('shop'))) . '">Tienda</a>';
                    }
                    echo '<a href="' . esc_url(home_url('/nosotros')) . '">Nosotros</a>';
                    echo '<a href="' . esc_url(home_url('/contacto')) . '">Contacto</a>';
                }
            ));
            ?>
        </nav>
        
        <!-- Iconos de Header -->
        <div class="header-icons">
            <!-- Búsqueda -->
            <div class="header-icon search-toggle" title="Buscar">
                <i class="fas fa-search"></i>
            </div>
            
            <!-- Usuario/Login -->
            <?php if (class_exists('WooCommerce') && get_option('woocommerce_myaccount_page_id')) : ?>
            <div class="header-icon user-icon" title="Mi Cuenta">
                <a href="<?php echo esc_url(get_permalink(get_option('woocommerce_myaccount_page_id'))); ?>">
                    <i class="fas fa-user"></i>
                </a>
            </div>
            <?php endif; ?>
            
            <!-- Wishlist -->
            <div class="header-icon wishlist-icon" title="Lista de Deseos">
                <a href="<?php echo esc_url(home_url('/wishlist')); ?>">
                    <i class="fas fa-heart"></i>
                    <span class="wishlist-count">0</span>
                </a>
            </div>
            
            <!-- Carrito -->
            <?php if (class_exists('WooCommerce')) : ?>
            <div class="header-icon cart-icon" title="Carrito">
                <a href="<?php echo wc_get_cart_url(); ?>">
                    <i class="fas fa-shopping-bag"></i>
                    <span class="cart-count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                </a>
            </div>
            <?php endif; ?>
            
            <!-- Menú móvil -->
            <div class="header-icon mobile-menu-toggle" title="Menú">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </div>
</header>

<!-- Barra de búsqueda overlay -->
<div class="search-overlay" id="searchOverlay">
    <div class="search-overlay-content">
        <button class="search-close" id="searchClose">
            <i class="fas fa-times"></i>
        </button>
        <form class="search-form-overlay" method="get" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="text" name="s" placeholder="Buscar joyas, colecciones..." class="search-input-overlay" autocomplete="off">
            <button type="submit" class="search-submit-overlay">
                <i class="fas fa-search"></i>
            </button>
        </form>
        <div class="search-suggestions">
            <p class="suggestions-title">Búsquedas Populares:</p>
            <div class="suggestions-tags">
                <a href="<?php echo esc_url(home_url('/shop/?s=anillos+diamantes')); ?>">Anillos de Diamantes</a>
                <a href="<?php echo esc_url(home_url('/shop/?s=collares+oro')); ?>">Collares de Oro</a>
                <a href="<?php echo esc_url(home_url('/shop/?s=aretes+perlas')); ?>">Aretes de Perlas</a>
                <a href="<?php echo esc_url(home_url('/shop/?s=compromiso')); ?>">Anillos de Compromiso</a>
            </div>
        </div>
    </div>
</div>

<!-- Menú Móvil -->
<div class="mobile-menu" id="mobileMenu">
    <div class="mobile-menu-header">
        <div class="mobile-logo"><?php bloginfo('name'); ?></div>
        <button class="mobile-menu-close" id="mobileMenuClose">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <nav class="mobile-navigation">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'container' => false,
            'menu_class' => 'mobile-nav-menu',
            'fallback_cb' => function() {
                echo '<ul class="mobile-nav-menu">';
                echo '<li><a href="' . esc_url(home_url('/')) . '">Inicio</a></li>';
                echo '<li><a href="' . esc_url(home_url('/collections')) . '">Colecciones</a></li>';
                echo '<li><a href="' . esc_url(home_url('/shop')) . '">Tienda</a></li>';
                echo '<li><a href="' . esc_url(home_url('/about')) . '">Nosotros</a></li>';
                echo '<li><a href="' . esc_url(home_url('/contact')) . '">Contacto</a></li>';
                echo '</ul>';
            }
        ));
        ?>
    </nav>
    
    <div class="mobile-menu-footer">
        <div class="mobile-social">
            <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#" aria-label="Pinterest"><i class="fab fa-pinterest-p"></i></a>
            <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        </div>
    </div>
</div>

<style>
/* Estilos adicionales para header */
.header-icon {
    position: relative;
}

.cart-count,
.wishlist-count {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--gold-primary);
    color: var(--black-deep);
    width: 18px;
    height: 18px;
    border-radius: 50%;
    font-size: 0.7rem;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
}

.wishlist-count {
    display: none;
}

.wishlist-count.has-items {
    display: flex;
}

/* Search Overlay */
.search-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(10, 10, 10, 0.98);
    z-index: 99999;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    visibility: hidden;
    transition: var(--transition-smooth);
}

.search-overlay.active {
    opacity: 1;
    visibility: visible;
}

.search-overlay-content {
    max-width: 800px;
    width: 90%;
    position: relative;
}

.search-close {
    position: absolute;
    top: -60px;
    right: 0;
    background: none;
    border: none;
    color: var(--gold-primary);
    font-size: 2rem;
    cursor: pointer;
    transition: var(--transition-fast);
}

.search-close:hover {
    transform: rotate(90deg);
}

.search-form-overlay {
    display: flex;
    gap: 1rem;
    margin-bottom: 3rem;
}

.search-input-overlay {
    flex: 1;
    padding: 1.5rem 2rem;
    background: rgba(255, 255, 255, 0.05);
    border: 2px solid rgba(212, 175, 55, 0.3);
    color: var(--white-pure);
    font-size: 1.5rem;
    font-family: var(--font-heading);
    transition: var(--transition-fast);
}

.search-input-overlay:focus {
    outline: none;
    border-color: var(--gold-primary);
    background: rgba(255, 255, 255, 0.1);
}

.search-input-overlay::placeholder {
    color: rgba(255, 255, 255, 0.4);
}

.search-submit-overlay {
    padding: 1.5rem 3rem;
    background: var(--gold-primary);
    border: none;
    color: var(--black-deep);
    font-size: 1.5rem;
    cursor: pointer;
    transition: var(--transition-fast);
}

.search-submit-overlay:hover {
    background: var(--gold-light);
}

.search-suggestions {
    text-align: center;
}

.suggestions-title {
    color: rgba(255, 255, 255, 0.6);
    font-size: 0.875rem;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    margin-bottom: 1.5rem;
}

.suggestions-tags {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
}

.suggestions-tags a {
    padding: 0.75rem 1.5rem;
    background: rgba(212, 175, 55, 0.1);
    border: 1px solid rgba(212, 175, 55, 0.3);
    color: var(--gold-primary);
    font-size: 0.875rem;
    transition: var(--transition-fast);
}

.suggestions-tags a:hover {
    background: rgba(212, 175, 55, 0.2);
    border-color: var(--gold-primary);
}

/* Mobile Menu */
.mobile-menu {
    position: fixed;
    top: 0;
    right: -100%;
    width: 100%;
    max-width: 400px;
    height: 100%;
    background: var(--black-deep);
    z-index: 99999;
    transition: var(--transition-smooth);
    display: flex;
    flex-direction: column;
}

.mobile-menu.active {
    right: 0;
}

.mobile-menu-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2rem;
    border-bottom: 1px solid rgba(212, 175, 55, 0.2);
}

.mobile-logo {
    font-family: var(--font-accent);
    font-size: 1.5rem;
    color: var(--gold-primary);
    letter-spacing: 0.15em;
}

.mobile-menu-close {
    background: none;
    border: none;
    color: var(--gold-primary);
    font-size: 1.5rem;
    cursor: pointer;
}

.mobile-navigation {
    flex: 1;
    overflow-y: auto;
    padding: 2rem;
}

.mobile-nav-menu {
    list-style: none;
}

.mobile-nav-menu li {
    margin-bottom: 1rem;
}

.mobile-nav-menu a {
    display: block;
    padding: 1rem 0;
    color: var(--white-pure);
    font-size: 1.125rem;
    letter-spacing: 0.1em;
    border-bottom: 1px solid rgba(212, 175, 55, 0.1);
    transition: var(--transition-fast);
}

.mobile-nav-menu a:hover {
    color: var(--gold-primary);
    padding-left: 1rem;
}

.mobile-menu-footer {
    padding: 2rem;
    border-top: 1px solid rgba(212, 175, 55, 0.2);
}

.mobile-social {
    display: flex;
    gap: 1.5rem;
    justify-content: center;
}

.mobile-social a {
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid rgba(212, 175, 55, 0.3);
    color: var(--gold-primary);
    transition: var(--transition-fast);
}

.mobile-social a:hover {
    background: var(--gold-primary);
    color: var(--black-deep);
}

.mobile-menu-toggle {
    display: none;
}

@media (max-width: 1024px) {
    .main-navigation {
        display: none;
    }
    
    .mobile-menu-toggle {
        display: block;
    }
}
</style>

<script>
// Search overlay
document.querySelector('.search-toggle').addEventListener('click', function() {
    document.getElementById('searchOverlay').classList.add('active');
    setTimeout(() => {
        document.querySelector('.search-input-overlay').focus();
    }, 300);
});

document.getElementById('searchClose').addEventListener('click', function() {
    document.getElementById('searchOverlay').classList.remove('active');
});

// Cerrar search con ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('searchOverlay').classList.remove('active');
        document.getElementById('mobileMenu').classList.remove('active');
    }
});

// Mobile menu
document.querySelector('.mobile-menu-toggle').addEventListener('click', function() {
    document.getElementById('mobileMenu').classList.add('active');
});

document.getElementById('mobileMenuClose').addEventListener('click', function() {
    document.getElementById('mobileMenu').classList.remove('active');
});

// Cerrar menú al hacer click fuera
document.getElementById('mobileMenu').addEventListener('click', function(e) {
    if (e.target === this) {
        this.classList.remove('active');
    }
});
</script>
