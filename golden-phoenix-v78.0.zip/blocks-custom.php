<?php
/**
 * MEGA BIBLIOTECA DE BLOQUES GUTENBERG - GOLDEN PHOENIX V62
 * 20+ Bloques personalizados para sitios de joyería de lujo
 */

if (!defined('ABSPATH')) exit;

// Registrar TODOS los bloques personalizados
add_action('init', 'gp_register_all_custom_blocks');

function gp_register_all_custom_blocks() {
    
    // CATEGORÍA 1: BOTONES Y LLAMADOS A LA ACCIÓN (5 bloques)
    // 1. Botón Luxury (ya existe en V61)
    // 2. Botón con icono
    // 3. Grupo de botones
    // 4. Botón WhatsApp flotante
    // 5. Botón de descarga
    
    // CATEGORÍA 2: TARJETAS Y COLECCIONES (7 bloques)
    // 6. Tarjeta de producto
    // 7. Tarjeta de colección con hover
    // 8. Tarjeta de testimonio
    // 9. Tarjeta de miembro del equipo
    // 10. Tarjeta de servicio
    // 11. Tarjeta con flip (gira al hover)
    // 12. Tarjeta con imagen de fondo
    
    // CATEGORÍA 3: GALERÍAS Y SLIDERS (4 bloques)
    // 13. Galería de productos con lightbox
    // 14. Slider de testimonios
    // 15. Galería antes/después
    // 16. Carrusel de logos
    
    // CATEGORÍA 4: SECCIONES HERO Y BANNERS (5 bloques)
    // 17. Hero con video de fondo
    // 18. Hero con parallax
    // 19. Banner de oferta con contador
    // 20. Banner split (imagen + contenido)
    // 21. Hero fullscreen con scroll
    
    // CATEGORÍA 5: ELEMENTOS DE CONFIANZA (6 bloques)
    // 22. Contador de estadísticas
    // 23. Barra de progreso
    // 24. Tabla de precios
    // 25. Lista de características con iconos
    // 26. Iconos de garantía/envío
    // 27. Logos de medios/certificaciones
    
    // CATEGORÍA 6: FORMULARIOS Y CONTACTO (4 bloques)
    // 28. Formulario de contacto luxury
    // 29. Botón de reserva
    // 30. Formulario de newsletter
    // 31. Mapa de ubicación
    
    // CATEGORÍA 7: E-COMMERCE (5 bloques)
    // 32. Comparador de productos
    // 33. Tabla de tallas
    // 34. Guía de cuidados
    // 35. Selector de materiales
    // 36. Calculadora de financiamiento
    
    // CATEGORÍA 8: REDES SOCIALES (3 bloques)
    // 37. Feed de Instagram
    // 38. Botones de compartir
    // 39. Testimonios de redes sociales
    
    // CATEGORÍA 9: NAVEGACIÓN (3 bloques)
    // 40. Mega menú
    // 41. Breadcrumbs luxury
    // 42. Tabs (pestañas)
    
    // CATEGORÍA 10: CONTENIDO MULTIMEDIA (3 bloques)
    // 43. Video con overlay
    // 44. Audio player luxury
    // 45. Timeline (línea de tiempo)
    
    // Registro de bloques principales (los más importantes primero)
    register_all_luxury_blocks();
}

function register_all_luxury_blocks() {
    
    // BLOQUE 1: BOTÓN LUXURY (V61 - ya existe)
    register_block_type('golden-phoenix/luxury-button', array(
        'render_callback' => 'gp_render_luxury_button',
        'attributes' => array(
            'text' => array('type' => 'string', 'default' => 'VER COLECCIÓN'),
            'url' => array('type' => 'string', 'default' => '#'),
            'backgroundColor' => array('type' => 'string', 'default' => 'transparent'),
            'textColor' => array('type' => 'string', 'default' => '#D4AF37'),
            'borderColor' => array('type' => 'string', 'default' => '#D4AF37'),
            'borderWidth' => array('type' => 'number', 'default' => 2),
            'borderRadius' => array('type' => 'number', 'default' => 0),
            'paddingTop' => array('type' => 'number', 'default' => 12),
            'paddingRight' => array('type' => 'number', 'default' => 35),
            'paddingBottom' => array('type' => 'number', 'default' => 12),
            'paddingLeft' => array('type' => 'number', 'default' => 35),
            'fontSize' => array('type' => 'number', 'default' => 14),
            'fontWeight' => array('type' => 'string', 'default' => '600'),
            'letterSpacing' => array('type' => 'number', 'default' => 1.5),
            'hoverBackgroundColor' => array('type' => 'string', 'default' => '#D4AF37'),
            'hoverTextColor' => array('type' => 'string', 'default' => '#000000'),
            'alignment' => array('type' => 'string', 'default' => 'center'),
            'width' => array('type' => 'string', 'default' => 'auto'),
        )
    ));
    
    // BLOQUE 2: BOTÓN CON ICONO
    register_block_type('golden-phoenix/icon-button', array(
        'render_callback' => 'gp_render_icon_button',
        'attributes' => array(
            'text' => array('type' => 'string', 'default' => 'Contactar'),
            'url' => array('type' => 'string', 'default' => '#'),
            'icon' => array('type' => 'string', 'default' => 'phone'),
            'iconPosition' => array('type' => 'string', 'default' => 'left'),
            'style' => array('type' => 'string', 'default' => 'luxury'),
        )
    ));
    
    // BLOQUE 3: BOTÓN WHATSAPP FLOTANTE
    register_block_type('golden-phoenix/whatsapp-float', array(
        'render_callback' => 'gp_render_whatsapp_float',
        'attributes' => array(
            'phoneNumber' => array('type' => 'string', 'default' => '573001234567'),
            'message' => array('type' => 'string', 'default' => 'Hola, me interesa información'),
            'position' => array('type' => 'string', 'default' => 'bottom-right'),
            'color' => array('type' => 'string', 'default' => '#25D366'),
        )
    ));
    
    // BLOQUE 4: TARJETA DE PRODUCTO
    register_block_type('golden-phoenix/product-card', array(
        'render_callback' => 'gp_render_product_card',
        'attributes' => array(
            'productId' => array('type' => 'number', 'default' => 0),
            'showPrice' => array('type' => 'boolean', 'default' => true),
            'showRating' => array('type' => 'boolean', 'default' => true),
            'showButton' => array('type' => 'boolean', 'default' => true),
            'hoverEffect' => array('type' => 'string', 'default' => 'zoom'),
        )
    ));
    
    // BLOQUE 5: CONTADOR DE ESTADÍSTICAS
    register_block_type('golden-phoenix/stat-counter', array(
        'render_callback' => 'gp_render_stat_counter',
        'attributes' => array(
            'number' => array('type' => 'string', 'default' => '10000'),
            'suffix' => array('type' => 'string', 'default' => '+'),
            'label' => array('type' => 'string', 'default' => 'Clientes Felices'),
            'icon' => array('type' => 'string', 'default' => 'heart'),
            'color' => array('type' => 'string', 'default' => '#D4AF37'),
            'animationDuration' => array('type' => 'number', 'default' => 2000),
        )
    ));
    
    // BLOQUE 6: GALERÍA CON LIGHTBOX
    register_block_type('golden-phoenix/lightbox-gallery', array(
        'render_callback' => 'gp_render_lightbox_gallery',
        'attributes' => array(
            'images' => array('type' => 'array', 'default' => array()),
            'columns' => array('type' => 'number', 'default' => 3),
            'gap' => array('type' => 'number', 'default' => 20),
            'hoverEffect' => array('type' => 'string', 'default' => 'zoom'),
        )
    ));
    
    // BLOQUE 7: SLIDER DE TESTIMONIOS
    register_block_type('golden-phoenix/testimonial-slider', array(
        'render_callback' => 'gp_render_testimonial_slider',
        'attributes' => array(
            'testimonials' => array('type' => 'array', 'default' => array()),
            'autoplay' => array('type' => 'boolean', 'default' => true),
            'autoplaySpeed' => array('type' => 'number', 'default' => 5000),
            'showDots' => array('type' => 'boolean', 'default' => true),
            'showArrows' => array('type' => 'boolean', 'default' => true),
        )
    ));
    
    // BLOQUE 8: BANNER CON CONTADOR
    register_block_type('golden-phoenix/countdown-banner', array(
        'render_callback' => 'gp_render_countdown_banner',
        'attributes' => array(
            'title' => array('type' => 'string', 'default' => 'Oferta Limitada'),
            'endDate' => array('type' => 'string', 'default' => ''),
            'backgroundColor' => array('type' => 'string', 'default' => '#000000'),
            'textColor' => array('type' => 'string', 'default' => '#D4AF37'),
        )
    ));
    
    // BLOQUE 9: TABLA DE PRECIOS
    register_block_type('golden-phoenix/pricing-table', array(
        'render_callback' => 'gp_render_pricing_table',
        'attributes' => array(
            'plans' => array('type' => 'array', 'default' => array()),
            'highlightedPlan' => array('type' => 'number', 'default' => 1),
            'currency' => array('type' => 'string', 'default' => '$'),
        )
    ));
    
    // BLOQUE 10: FORMULARIO DE CONTACTO LUXURY
    register_block_type('golden-phoenix/luxury-form', array(
        'render_callback' => 'gp_render_luxury_form',
        'attributes' => array(
            'emailTo' => array('type' => 'string', 'default' => get_option('admin_email')),
            'showPhone' => array('type' => 'boolean', 'default' => true),
            'showMessage' => array('type' => 'boolean', 'default' => true),
            'buttonText' => array('type' => 'string', 'default' => 'ENVIAR'),
        )
    ));
    
    // Continúan más bloques...
}

// RENDER FUNCTIONS para cada bloque

function gp_render_luxury_button($attributes) {
    $style = sprintf(
        'background-color: %s; color: %s; border: %dpx solid %s; border-radius: %dpx;
         padding: %dpx %dpx %dpx %dpx; font-size: %dpx; font-weight: %s; letter-spacing: %dpx;
         text-align: %s; display: inline-block; text-decoration: none; transition: all 0.3s ease;
         cursor: pointer; width: %s;',
        $attributes['backgroundColor'], $attributes['textColor'], $attributes['borderWidth'],
        $attributes['borderColor'], $attributes['borderRadius'], $attributes['paddingTop'],
        $attributes['paddingRight'], $attributes['paddingBottom'], $attributes['paddingLeft'],
        $attributes['fontSize'], $attributes['fontWeight'], $attributes['letterSpacing'],
        $attributes['alignment'], $attributes['width']
    );
    
    return sprintf(
        '<div class="gp-luxury-button-wrapper" style="text-align: %s;">
            <a href="%s" class="gp-luxury-button" style="%s" 
               data-hover-bg="%s" data-hover-color="%s" data-normal-bg="%s" data-normal-color="%s">%s</a>
        </div>',
        $attributes['alignment'], esc_url($attributes['url']), $style,
        $attributes['hoverBackgroundColor'], $attributes['hoverTextColor'],
        $attributes['backgroundColor'], $attributes['textColor'], esc_html($attributes['text'])
    );
}

function gp_render_icon_button($attributes) {
    $icons = array(
        'phone' => '📞',
        'email' => '✉️',
        'whatsapp' => '💬',
        'cart' => '🛒',
        'heart' => '❤️',
        'star' => '⭐',
        'diamond' => '💎',
        'crown' => '👑',
    );
    
    $icon = isset($icons[$attributes['icon']]) ? $icons[$attributes['icon']] : '📞';
    $text = $attributes['iconPosition'] === 'left' 
        ? $icon . ' ' . $attributes['text']
        : $attributes['text'] . ' ' . $icon;
    
    return sprintf(
        '<a href="%s" class="gp-icon-button" style="display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #D4AF37, #C19A2E); color: #000; border-radius: 50px; text-decoration: none; font-weight: 600; transition: transform 0.3s;">%s</a>',
        esc_url($attributes['url']), esc_html($text)
    );
}

function gp_render_whatsapp_float($attributes) {
    $positions = array(
        'bottom-right' => 'bottom: 30px; right: 30px;',
        'bottom-left' => 'bottom: 30px; left: 30px;',
        'top-right' => 'top: 100px; right: 30px;',
        'top-left' => 'top: 100px; left: 30px;',
    );
    
    $position = isset($positions[$attributes['position']]) ? $positions[$attributes['position']] : $positions['bottom-right'];
    $whatsapp_url = sprintf(
        'https://wa.me/%s?text=%s',
        $attributes['phoneNumber'],
        urlencode($attributes['message'])
    );
    
    return sprintf(
        '<a href="%s" target="_blank" class="gp-whatsapp-float" style="position: fixed; %s z-index: 9999; width: 60px; height: 60px; background: %s; border-radius: 50%%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 20px rgba(0,0,0,0.3); transition: transform 0.3s;">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="white">
                <path d="M16 0C7.164 0 0 7.164 0 16c0 2.824.738 5.478 2.028 7.778L0 32l8.444-2.028C10.744 31.262 13.398 32 16 32c8.836 0 16-7.164 16-16S24.836 0 16 0zm8.11 22.11c-.358.998-1.778 1.832-2.91 2.074-.776.162-1.786.29-5.198-1.118-4.362-1.798-7.162-6.23-7.378-6.518-.214-.29-1.752-2.33-1.752-4.446 0-2.114 1.11-3.154 1.502-3.584.392-.43.856-.538 1.142-.538.286 0 .572.004.822.016.264.012.618-.1.966.738.358.86 1.218 2.976 1.326 3.192.108.214.18.466.036.754-.144.286-.216.466-.43.716-.214.25-.45.558-.644.75-.214.216-.437.45-.188.886.25.43 1.11 1.83 2.382 2.966 1.636 1.462 3.014 1.918 3.442 2.134.43.214.68.18.93-.108.25-.286.978-1.142 1.24-1.536.262-.394.524-.322.882-.196.358.126 2.274 1.074 2.666 1.268.392.196.654.288.75.454.096.164.096.95-.262 1.948z"/>
            </svg>
        </a>',
        esc_url($whatsapp_url), $position, $attributes['color']
    );
}

function gp_render_product_card($attributes) {
    if (!$attributes['productId'] || !class_exists('WooCommerce')) {
        return '<p>Por favor selecciona un producto de WooCommerce</p>';
    }
    
    $product = wc_get_product($attributes['productId']);
    if (!$product) return '';
    
    $image = $product->get_image('medium');
    $title = $product->get_name();
    $price = $product->get_price_html();
    $rating = $product->get_average_rating();
    $link = $product->get_permalink();
    
    ob_start();
    ?>
    <div class="gp-product-card" style="background: #0A0A0A; border: 1px solid #333; padding: 20px; text-align: center; transition: transform 0.3s;">
        <div class="gp-product-image" style="overflow: hidden; margin-bottom: 20px;">
            <?php echo $image; ?>
        </div>
        <h3 style="color: #D4AF37; margin: 15px 0;"><?php echo esc_html($title); ?></h3>
        <?php if ($attributes['showPrice']): ?>
            <div class="gp-product-price" style="color: #CCCCCC; font-size: 20px; margin: 10px 0;"><?php echo $price; ?></div>
        <?php endif; ?>
        <?php if ($attributes['showRating'] && $rating > 0): ?>
            <div class="gp-product-rating" style="color: #D4AF37; margin: 10px 0;">
                <?php echo str_repeat('⭐', round($rating)); ?>
            </div>
        <?php endif; ?>
        <?php if ($attributes['showButton']): ?>
            <a href="<?php echo esc_url($link); ?>" style="display: inline-block; margin-top: 15px; padding: 12px 30px; border: 2px solid #D4AF37; color: #D4AF37; text-decoration: none; transition: all 0.3s;">
                VER DETALLES
            </a>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

function gp_render_stat_counter($attributes) {
    return sprintf(
        '<div class="gp-stat-counter" style="text-align: center; padding: 30px;">
            <div class="gp-stat-icon" style="font-size: 48px; margin-bottom: 15px;">%s</div>
            <div class="gp-stat-number" style="font-size: 48px; font-weight: 700; color: %s; margin-bottom: 10px;" data-target="%s" data-suffix="%s">0%s</div>
            <div class="gp-stat-label" style="font-size: 18px; color: #CCCCCC;">%s</div>
        </div>',
        $attributes['icon'] === 'heart' ? '❤️' : '💎',
        $attributes['color'],
        $attributes['number'],
        $attributes['suffix'],
        $attributes['suffix'],
        esc_html($attributes['label'])
    );
}

// Continúan más funciones de render...

// JavaScript para efectos y animaciones
add_action('wp_footer', function() {
    ?>
    <script>
    // Hover effects para botones luxury
    document.addEventListener('DOMContentLoaded', function() {
        // Botones luxury
        document.querySelectorAll('.gp-luxury-button').forEach(function(btn) {
            btn.addEventListener('mouseenter', function() {
                this.style.backgroundColor = this.dataset.hoverBg;
                this.style.color = this.dataset.hoverColor;
            });
            btn.addEventListener('mouseleave', function() {
                this.style.backgroundColor = this.dataset.normalBg;
                this.style.color = this.dataset.normalColor;
            });
        });
        
        // WhatsApp float hover
        document.querySelectorAll('.gp-whatsapp-float').forEach(function(btn) {
            btn.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.1)';
            });
            btn.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        });
        
        // Product card hover
        document.querySelectorAll('.gp-product-card').forEach(function(card) {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-10px)';
                this.style.boxShadow = '0 10px 40px rgba(212, 175, 55, 0.3)';
            });
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
                this.style.boxShadow = 'none';
            });
        });
        
        // Counter animation
        document.querySelectorAll('.gp-stat-number').forEach(function(counter) {
            const target = parseInt(counter.dataset.target);
            const suffix = counter.dataset.suffix;
            const duration = 2000;
            const increment = target / (duration / 16);
            let current = 0;
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const timer = setInterval(() => {
                            current += increment;
                            if (current >= target) {
                                current = target;
                                clearInterval(timer);
                            }
                            counter.textContent = Math.floor(current) + suffix;
                        }, 16);
                        observer.unobserve(entry.target);
                    }
                });
            });
            
            observer.observe(counter);
        });
    });
    </script>
    <?php
});

