<?php
/**
 * Golden Phoenix - Splash Screen / Cortina de Bienvenida
 * Pantalla de entrada elegante totalmente personalizable
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// OPCIONES EN CUSTOMIZER
// ============================================

add_action('customize_register', 'gp_splash_screen_customizer');

function gp_splash_screen_customizer($wp_customize) {
    // Sección Splash Screen
    $wp_customize->add_section('gp_splash_section', array(
        'title' => '🎭 Cortina de Bienvenida',
        'priority' => 20,
        'description' => 'Personaliza la pantalla de entrada de tu tienda'
    ));
    
    // Activar Splash Screen (DESACTIVADO POR DEFECTO)
    $wp_customize->add_setting('gp_splash_enabled', array(
        'default' => false, // CAMBIADO DE true A false
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    
    $wp_customize->add_control('gp_splash_enabled', array(
        'label' => 'Mostrar Cortina de Bienvenida',
        'section' => 'gp_splash_section',
        'type' => 'checkbox',
        'description' => 'Mostrar pantalla de bienvenida al entrar al sitio',
    ));
    
    // Logo Splash
    $wp_customize->add_setting('gp_splash_logo', array(
        'default' => '',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'gp_splash_logo', array(
        'label' => 'Logo de Bienvenida',
        'section' => 'gp_splash_section',
        'mime_type' => 'image',
        'description' => 'Logo que se muestra en la cortina (recomendado: PNG transparente)',
    )));
    
    // Título Principal
    $wp_customize->add_setting('gp_splash_title', array(
        'default' => 'Golden Phoenix',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_splash_title', array(
        'label' => 'Título Principal',
        'section' => 'gp_splash_section',
        'type' => 'text',
        'description' => 'Texto principal de la cortina',
    ));
    
    // Subtítulo
    $wp_customize->add_setting('gp_splash_subtitle', array(
        'default' => 'Joyería de Lujo',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_splash_subtitle', array(
        'label' => 'Subtítulo',
        'section' => 'gp_splash_section',
        'type' => 'text',
    ));
    
    // Texto Descriptivo
    $wp_customize->add_setting('gp_splash_description', array(
        'default' => 'Piezas únicas que brillan con tu esencia',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('gp_splash_description', array(
        'label' => 'Descripción',
        'section' => 'gp_splash_section',
        'type' => 'textarea',
        'description' => 'Texto descriptivo (opcional)',
    ));
    
    // Color de Fondo
    $wp_customize->add_setting('gp_splash_bg_color', array(
        'default' => '#0A0A0A',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_splash_bg_color', array(
        'label' => 'Color de Fondo',
        'section' => 'gp_splash_section',
    )));
    
    // Color del Texto
    $wp_customize->add_setting('gp_splash_text_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_splash_text_color', array(
        'label' => 'Color del Texto',
        'section' => 'gp_splash_section',
    )));
    
    // Imagen de Fondo
    $wp_customize->add_setting('gp_splash_bg_image', array(
        'default' => '',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'gp_splash_bg_image', array(
        'label' => 'Imagen de Fondo (Opcional)',
        'section' => 'gp_splash_section',
        'mime_type' => 'image',
        'description' => 'Imagen de fondo con overlay oscuro',
    )));
    
    // Duración
    $wp_customize->add_setting('gp_splash_duration', array(
        'default' => '3',
        'sanitize_callback' => 'absint',
    ));
    
    $wp_customize->add_control('gp_splash_duration', array(
        'label' => 'Duración (segundos)',
        'section' => 'gp_splash_section',
        'type' => 'number',
        'description' => 'Tiempo antes de que desaparezca automáticamente',
        'input_attrs' => array(
            'min' => 1,
            'max' => 10,
            'step' => 1,
        ),
    ));
    
    // Botón "Entrar"
    $wp_customize->add_setting('gp_splash_button_text', array(
        'default' => 'Entrar a la Tienda',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_splash_button_text', array(
        'label' => 'Texto del Botón',
        'section' => 'gp_splash_section',
        'type' => 'text',
    ));
    
    // Mostrar solo primera vez
    $wp_customize->add_setting('gp_splash_once', array(
        'default' => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    
    $wp_customize->add_control('gp_splash_once', array(
        'label' => 'Mostrar solo la primera vez',
        'section' => 'gp_splash_section',
        'type' => 'checkbox',
        'description' => 'Si está activado, solo se muestra una vez por sesión',
    ));
    
    // Animación
    $wp_customize->add_setting('gp_splash_animation', array(
        'default' => 'fade',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_splash_animation', array(
        'label' => 'Estilo de Animación',
        'section' => 'gp_splash_section',
        'type' => 'select',
        'choices' => array(
            'fade' => 'Fade (Desvanecimiento)',
            'zoom' => 'Zoom (Acercamiento)',
            'slide' => 'Slide (Deslizar)',
            'curtain' => 'Curtain (Cortina)',
        ),
    ));
}

// ============================================
// MOSTRAR SPLASH SCREEN
// ============================================

add_action('wp_footer', 'gp_splash_screen_output');

function gp_splash_screen_output() {
    // Solo en homepage
    if (!is_front_page()) {
        return;
    }
    
    // Verificar si está activado (DESACTIVADO POR DEFECTO)
    if (!get_theme_mod('gp_splash_enabled', false)) { // CAMBIADO DE true A false
        return;
    }
    
    // Obtener configuraciones
    $logo = get_theme_mod('gp_splash_logo');
    $logo_url = $logo ? wp_get_attachment_url($logo) : '';
    
    $title = get_theme_mod('gp_splash_title', 'Golden Phoenix');
    $subtitle = get_theme_mod('gp_splash_subtitle', 'Joyería de Lujo');
    $description = get_theme_mod('gp_splash_description', 'Piezas únicas que brillan con tu esencia');
    
    $bg_color = get_theme_mod('gp_splash_bg_color', '#0A0A0A');
    $text_color = get_theme_mod('gp_splash_text_color', '#D4AF37');
    
    $bg_image = get_theme_mod('gp_splash_bg_image');
    $bg_image_url = $bg_image ? wp_get_attachment_url($bg_image) : '';
    
    $duration = get_theme_mod('gp_splash_duration', 3);
    $button_text = get_theme_mod('gp_splash_button_text', 'Entrar a la Tienda');
    $show_once = get_theme_mod('gp_splash_once', true);
    $animation = get_theme_mod('gp_splash_animation', 'fade');
    
    ?>
    <div id="gp-splash-screen" class="splash-<?php echo $animation; ?>" style="
        position: fixed;
        inset: 0;
        background: <?php echo $bg_color; ?>;
        <?php if ($bg_image_url) : ?>
        background-image: url('<?php echo $bg_image_url; ?>');
        background-size: cover;
        background-position: center;
        <?php endif; ?>
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        opacity: 1;
        transition: opacity 1s ease, transform 1s ease;
    ">
        
        <?php if ($bg_image_url) : ?>
        <!-- Overlay oscuro sobre la imagen -->
        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.7);"></div>
        <?php endif; ?>
        
        <!-- Contenido -->
        <div class="splash-content" style="position: relative; z-index: 1; text-align: center; max-width: 600px; padding: 40px;">
            
            <!-- Logo -->
            <?php if ($logo_url) : ?>
            <div class="splash-logo" style="margin-bottom: 40px; animation: logoFloat 3s ease-in-out infinite;">
                <img src="<?php echo $logo_url; ?>" alt="<?php echo $title; ?>" style="max-width: 250px; height: auto; filter: drop-shadow(0 10px 30px rgba(212,175,55,0.3));">
            </div>
            <?php endif; ?>
            
            <!-- Título -->
            <h1 style="
                font-size: clamp(36px, 8vw, 72px);
                font-family: 'Playfair Display', serif;
                color: <?php echo $text_color; ?>;
                margin-bottom: 20px;
                font-weight: 700;
                letter-spacing: 3px;
                text-shadow: 0 5px 20px rgba(0,0,0,0.5);
                animation: titleFade 1.5s ease-out;
            ">
                <?php echo esc_html($title); ?>
            </h1>
            
            <!-- Subtítulo -->
            <div style="
                font-size: clamp(18px, 3vw, 28px);
                color: white;
                margin-bottom: 15px;
                font-weight: 300;
                letter-spacing: 8px;
                text-transform: uppercase;
                opacity: 0.9;
                animation: subtitleFade 2s ease-out 0.5s both;
            ">
                <?php echo esc_html($subtitle); ?>
            </div>
            
            <!-- Descripción -->
            <?php if ($description) : ?>
            <p style="
                font-size: 16px;
                color: rgba(255,255,255,0.8);
                margin-bottom: 40px;
                line-height: 1.6;
                animation: descFade 2s ease-out 1s both;
            ">
                <?php echo esc_html($description); ?>
            </p>
            <?php endif; ?>
            
            <!-- Separador decorativo -->
            <div style="
                width: 100px;
                height: 2px;
                background: linear-gradient(90deg, transparent, <?php echo $text_color; ?>, transparent);
                margin: 30px auto;
                animation: lineExpand 1.5s ease-out 1.5s both;
            "></div>
            
            <!-- Botón Entrar -->
            <button onclick="closeSplashScreen()" style="
                background: <?php echo $text_color; ?>;
                color: #0A0A0A;
                border: none;
                padding: 18px 60px;
                border-radius: 50px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                letter-spacing: 2px;
                text-transform: uppercase;
                transition: all 0.3s;
                box-shadow: 0 10px 30px rgba(212,175,55,0.3);
                animation: buttonFade 2s ease-out 2s both;
            "
            onmouseover="this.style.transform='scale(1.05)'; this.style.boxShadow='0 15px 40px rgba(212,175,55,0.5)';"
            onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='0 10px 30px rgba(212,175,55,0.3)';">
                <?php echo esc_html($button_text); ?>
            </button>
            
            <!-- Texto "Click para continuar" -->
            <div style="
                margin-top: 30px;
                font-size: 12px;
                color: rgba(255,255,255,0.5);
                letter-spacing: 2px;
                text-transform: uppercase;
                animation: clickFade 2s ease-out 2.5s both infinite;
            ">
                o haz click en cualquier lugar
            </div>
        </div>
        
        <!-- Loader circular -->
        <div class="splash-loader" style="
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 60px;
            border: 3px solid rgba(255,255,255,0.1);
            border-top-color: <?php echo $text_color; ?>;
            border-radius: 50%;
            animation: spin 1.5s linear infinite;
        "></div>
        
    </div>
    
    <style>
    @keyframes logoFloat {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-15px); }
    }
    
    @keyframes titleFade {
        0% { opacity: 0; transform: translateY(-30px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes subtitleFade {
        0% { opacity: 0; transform: translateY(-20px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes descFade {
        0% { opacity: 0; }
        100% { opacity: 0.8; }
    }
    
    @keyframes lineExpand {
        0% { width: 0; opacity: 0; }
        100% { width: 100px; opacity: 1; }
    }
    
    @keyframes buttonFade {
        0% { opacity: 0; transform: scale(0.8); }
        100% { opacity: 1; transform: scale(1); }
    }
    
    @keyframes clickFade {
        0%, 100% { opacity: 0.3; }
        50% { opacity: 0.7; }
    }
    
    @keyframes spin {
        0% { transform: translateX(-50%) rotate(0deg); }
        100% { transform: translateX(-50%) rotate(360deg); }
    }
    
    /* Animaciones de cierre */
    .splash-fade.closing { opacity: 0; }
    .splash-zoom.closing { opacity: 0; transform: scale(1.5); }
    .splash-slide.closing { opacity: 0; transform: translateY(-100%); }
    .splash-curtain.closing { opacity: 0; transform: scaleY(0); }
    
    @media (max-width: 768px) {
        .splash-content {
            padding: 20px !important;
        }
        
        .splash-logo img {
            max-width: 150px !important;
        }
    }
    </style>
    
    <script>
    // Configuración
    const splashDuration = <?php echo $duration * 1000; ?>;
    const showOnce = <?php echo $show_once ? 'true' : 'false'; ?>;
    
    // Verificar si ya se mostró
    if (showOnce && sessionStorage.getItem('splashShown')) {
        document.getElementById('gp-splash-screen').style.display = 'none';
    } else {
        // Auto cerrar después de X segundos
        setTimeout(closeSplashScreen, splashDuration);
        
        // Cerrar al hacer click
        document.getElementById('gp-splash-screen').addEventListener('click', function(e) {
            if (e.target === this) {
                closeSplashScreen();
            }
        });
        
        // Prevenir scroll mientras está abierto
        document.body.style.overflow = 'hidden';
    }
    
    function closeSplashScreen() {
        const splash = document.getElementById('gp-splash-screen');
        splash.classList.add('closing');
        
        setTimeout(function() {
            splash.style.display = 'none';
            document.body.style.overflow = '';
            
            // Marcar como mostrado
            if (showOnce) {
                sessionStorage.setItem('splashShown', 'true');
            }
        }, 1000);
    }
    
    // Cerrar con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeSplashScreen();
        }
    });
    </script>
    <?php
}
