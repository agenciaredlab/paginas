<?php
/**
 * Golden Phoenix V78 - LIMPIEZA TOTAL
 * Elimina TODO lo que no funciona y deja solo lo esencial
 */

if (!defined('ABSPATH')) exit;

// ========================================
// DESACTIVAR TODOS LOS SISTEMAS DE CHAT
// ========================================

// Prevenir carga de archivos antiguos
define('GP_DISABLE_OLD_CHATS', true);

add_action('init', 'gp_v78_disable_all_old_chats', 1);

function gp_v78_disable_all_old_chats() {
    // Remover TODOS los hooks de chats antiguos
    remove_all_actions('wp_footer', 10);
    
    // Prevenir clases antiguas
    if (class_exists('GP_Live_Chat_System')) {
        foreach (get_class_methods('GP_Live_Chat_System') as $method) {
            remove_all_actions($method);
            remove_all_filters($method);
        }
    }
}

// ========================================
// OCULTAR TODO LO VIEJO CON CSS FUERTE
// ========================================

add_action('wp_head', 'gp_v78_nuclear_css_cleanup', 9999);

function gp_v78_nuclear_css_cleanup() {
    ?>
    <style>
    /* ELIMINAR TODOS LOS CHATS VIEJOS */
    [class*="chat"]:not(.gp-v78-chat):not(.woocommerce-cart),
    [id*="chat"]:not(#gp-v78-chat):not(#gp-v78-button),
    .gp-chat-widget,
    .gp-live-chat-trigger:not(.gp-v78-chat),
    .gp-live-chat-widget,
    div[style*="background: rgba(255, 193, 7"],
    div[style*="background: #FFC107"],
    div[onclick*="Chat"],
    .messenger-button,
    #fb-customer-chat {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }
    
    /* THEME BUILDER - SOLO ADMIN */
    body:not(.logged-in) .gp-theme-builder,
    body:not(.logged-in) #theme-builder-panel {
        display: none !important;
    }
    
    /* SOLO ESTOS 2 BOTONES */
    .gp-v78-chat {
        position: fixed !important;
        bottom: 20px !important;
        left: 20px !important;
        width: 60px !important;
        height: 60px !important;
        background: #0084FF !important;
        border-radius: 50% !important;
        z-index: 99999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        box-shadow: 0 4px 12px rgba(0,132,255,0.4) !important;
    }
    
    .gp-v78-whatsapp {
        position: fixed !important;
        bottom: 20px !important;
        right: 20px !important;
        width: 60px !important;
        height: 60px !important;
        background: #25D366 !important;
        border-radius: 50% !important;
        z-index: 99999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        cursor: pointer !important;
        box-shadow: 0 4px 12px rgba(37,211,102,0.4) !important;
        text-decoration: none !important;
    }
    </style>
    <?php
}

// ========================================
// JAVASCRIPT CLEANUP
// ========================================

add_action('wp_footer', 'gp_v78_cleanup_js', 9999);

function gp_v78_cleanup_js() {
    ?>
    <script>
    jQuery(document).ready(function($) {
        // Remover todos los elementos de chat excepto los nuevos
        $('[class*="chat"]:not(.gp-v78-chat):not(.woocommerce-cart)').remove();
        $('[id*="chat"]:not(#gp-v78-chat):not(#gp-v78-button)').remove();
        
        // Remover botones flotantes viejos
        $('body > div').each(function() {
            var pos = $(this).css('position');
            if (pos === 'fixed' && !$(this).hasClass('gp-v78-chat') && !$(this).hasClass('gp-v78-whatsapp')) {
                var bg = $(this).css('background-color');
                if (bg && (bg.indexOf('255, 193, 7') > -1 || bg.indexOf('251, 140, 0') > -1)) {
                    $(this).remove();
                }
            }
        });
    });
    </script>
    <?php
}

// ========================================
// SOLO 2 BOTONES SIMPLES
// ========================================

add_action('wp_footer', 'gp_v78_render_only_buttons', 10000);

function gp_v78_render_only_buttons() {
    if (is_admin()) return;
    
    $whatsapp_num = get_option('gp_whatsapp_number', '573001234567');
    ?>
    
    <!-- CHAT SIMPLE -->
    <div class="gp-v78-chat" id="gp-v78-button" onclick="document.getElementById('gp-v78-chat').style.display='flex'">
        <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12c0 1.54.36 3 .97 4.29L2 22l5.71-.97C9 21.64 10.46 22 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2z"/>
            <circle cx="8" cy="12" r="1.5"/>
            <circle cx="12" cy="12" r="1.5"/>
            <circle cx="16" cy="12" r="1.5"/>
        </svg>
    </div>
    
    <!-- WHATSAPP -->
    <a href="https://wa.me/<?php echo $whatsapp_num; ?>?text=Hola!" target="_blank" class="gp-v78-whatsapp">
        <svg width="30" height="30" fill="white" viewBox="0 0 24 24">
            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.42a8.225 8.225 0 012.41 5.83c0 4.54-3.7 8.23-8.24 8.23-1.48 0-2.93-.39-4.19-1.15l-.3-.17-3.12.82.83-3.04-.2-.32a8.188 8.188 0 01-1.26-4.38c.01-4.54 3.7-8.24 8.25-8.24M8.53 7.33c-.16 0-.43.06-.66.31-.22.25-.87.85-.87 2.07 0 1.22.89 2.39 1 2.56.14.17 1.76 2.67 4.25 3.73.59.27 1.05.42 1.41.53.59.19 1.13.16 1.56.1.48-.07 1.46-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.07-.1-.23-.15-.48-.27-.25-.12-1.47-.72-1.69-.81-.23-.08-.37-.12-.56.12-.16.25-.64.81-.78.97-.15.17-.29.19-.53.07-.26-.13-1.06-.39-2-1.23-.74-.66-1.23-1.47-1.38-1.72-.12-.24-.01-.39.11-.5.11-.11.27-.29.37-.44.13-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.11-.56-1.35-.77-1.84-.2-.48-.4-.42-.56-.43-.14 0-.3-.01-.46-.01z"/>
        </svg>
    </a>
    
    <!-- VENTANA CHAT -->
    <div id="gp-v78-chat" style="display:none; position:fixed; bottom:90px; left:20px; width:350px; height:500px; background:white; border-radius:12px; box-shadow:0 8px 30px rgba(0,0,0,0.2); z-index:99999; flex-direction:column;">
        <div style="background:linear-gradient(135deg,#0084FF,#0056CC); color:white; padding:20px; border-radius:12px 12px 0 0; display:flex; justify-content:space-between; align-items:center;">
            <div>
                <h4 style="margin:0; font-size:18px;">💬 Chat</h4>
                <small style="opacity:0.9;">Estamos aquí</small>
            </div>
            <button onclick="document.getElementById('gp-v78-chat').style.display='none'" style="background:none; border:none; color:white; font-size:24px; cursor:pointer;">×</button>
        </div>
        <div id="gp-v78-messages" style="flex:1; padding:20px; overflow-y:auto; background:#f5f5f5;">
            <div style="background:white; padding:12px; border-radius:12px; margin-bottom:10px;">
                👋 ¡Hola! ¿Cómo podemos ayudarte?
            </div>
        </div>
        <div style="padding:15px; border-top:1px solid #ddd; display:flex; gap:10px;">
            <input type="text" id="gp-v78-input" placeholder="Escribe..." style="flex:1; padding:10px; border:1px solid #ddd; border-radius:20px;" onkeypress="if(event.key==='Enter')gpV78Send()">
            <button onclick="gpV78Send()" style="background:#0084FF; color:white; border:none; padding:10px 20px; border-radius:20px; cursor:pointer;">Enviar</button>
        </div>
    </div>
    
    <script>
    function gpV78Send() {
        var input = document.getElementById('gp-v78-input');
        var msg = input.value.trim();
        if (!msg) return;
        
        var div = document.getElementById('gp-v78-messages');
        div.innerHTML += '<div style="text-align:right; margin:10px 0;"><div style="display:inline-block; background:#0084FF; color:white; padding:10px 15px; border-radius:12px; max-width:70%;">' + msg + '</div></div>';
        input.value = '';
        div.scrollTop = div.scrollHeight;
        
        setTimeout(function() {
            div.innerHTML += '<div style="background:white; padding:12px; border-radius:12px; margin:10px 0;">Gracias por tu mensaje 😊</div>';
            div.scrollTop = div.scrollHeight;
        }, 1000);
    }
    </script>
    
    <?php
}

// ========================================
// HACER QUE GP SETTINGS FUNCIONE DE VERDAD
// ========================================

// Aplicar configuración WhatsApp
add_filter('gp_whatsapp_number', function($default) {
    return get_option('gp_whatsapp_number', $default);
}, 99);

// Aplicar configuración Bundle Discounts
remove_action('woocommerce_cart_calculate_fees', 'gp_apply_bundle_discount');

add_action('woocommerce_cart_calculate_fees', function($cart) {
    if (!get_option('gp_bundle_discount_enabled', true)) {
        return;
    }
    
    $count = $cart->get_cart_contents_count();
    $percent = 0;
    
    if ($count >= 5) {
        $percent = get_option('gp_bundle_5_percent', 15);
    } elseif ($count >= 3) {
        $percent = get_option('gp_bundle_3_percent', 10);
    } elseif ($count >= 2) {
        $percent = get_option('gp_bundle_2_percent', 5);
    }
    
    if ($percent > 0) {
        $discount = $cart->get_subtotal() * ($percent / 100);
        $cart->add_fee("Descuento {$count} piezas ({$percent}%)", -$discount);
    }
}, 99);

// ========================================
// ADMIN NOTICE - LIMPIEZA COMPLETA
// ========================================

add_action('admin_notices', 'gp_v78_cleanup_notice');

function gp_v78_cleanup_notice() {
    if (get_option('gp_v78_notice_shown')) return;
    
    $screen = get_current_screen();
    if ($screen->id !== 'dashboard') return;
    ?>
    
    <div class="notice notice-success is-dismissible">
        <h2>✅ Golden Phoenix V78 - Limpieza Total Completada</h2>
        <h3>Cambios realizados:</h3>
        <ul style="list-style: disc; margin-left: 20px; line-height: 2;">
            <li>❌ <strong>Eliminados:</strong> Todos los sistemas de chat antiguos</li>
            <li>❌ <strong>Eliminados:</strong> Integraciones chat antiguas</li>
            <li>❌ <strong>Eliminados:</strong> Chatbot antiguo</li>
            <li>✅ <strong>Nuevo:</strong> Solo 2 botones simples (Chat + WhatsApp)</li>
            <li>✅ <strong>Arreglado:</strong> GP Settings ahora SÍ afecta la página</li>
            <li>✅ <strong>Arreglado:</strong> Theme Builder solo para admin</li>
        </ul>
        <h3>Configuración:</h3>
        <p>
            <a href="<?php echo admin_url('admin.php?page=golden-phoenix-settings'); ?>" class="button button-primary">
                ⚙️ Ir a GP Settings
            </a>
            <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_v78'}); return false;" class="button">
                Cerrar
            </a>
        </p>
    </div>
    
    <?php
    update_option('gp_v78_notice_shown', true);
}

add_action('wp_ajax_gp_dismiss_v78', function() {
    update_option('gp_v78_notice_shown', true);
    wp_die();
});
