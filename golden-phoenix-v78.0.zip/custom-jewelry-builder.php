<?php
/**
 * Golden Phoenix V72 - CUSTOM JEWELRY BUILDER
 * Constructor de joyas personalizado paso a paso
 */

if (!defined('ABSPATH')) exit;

// Crear página Custom Jewelry Builder
add_action('after_switch_theme', 'gp_create_jewelry_builder_page');

function gp_create_jewelry_builder_page() {
    if (get_option('gp_jewelry_builder_created')) {
        return;
    }
    
    $page_id = wp_insert_post(array(
        'post_title' => 'Diseña tu Joya',
        'post_name' => 'custom-jewelry-builder',
        'post_content' => '[jewelry_builder]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    
    update_option('gp_jewelry_builder_created', true);
    update_option('gp_jewelry_builder_page_id', $page_id);
}

// Shortcode constructor
add_shortcode('jewelry_builder', 'gp_jewelry_builder_shortcode');

function gp_jewelry_builder_shortcode() {
    ob_start();
    ?>
    
    <div class="gp-jewelry-builder">
        <h1 style="text-align: center; font-family: 'Playfair Display', serif; margin-bottom: 50px;">
            💎 Diseña tu Joya Personalizada
        </h1>
        
        <div class="builder-container" style="max-width: 1200px; margin: 0 auto;">
            
            <!-- PASO 1: Tipo de joya -->
            <div class="builder-step active" id="step-1">
                <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 30px;">
                    Paso 1: Selecciona el tipo de joya
                </h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div class="jewelry-type-card" data-type="anillo" style="background: white; padding: 30px; text-align: center; border-radius: 12px; cursor: pointer; border: 2px solid #f0f0f0; transition: all 0.3s;">
                        <div style="font-size: 60px; margin-bottom: 15px;">💍</div>
                        <h4>Anillo</h4>
                    </div>
                    
                    <div class="jewelry-type-card" data-type="collar" style="background: white; padding: 30px; text-align: center; border-radius: 12px; cursor: pointer; border: 2px solid #f0f0f0; transition: all 0.3s;">
                        <div style="font-size: 60px; margin-bottom: 15px;">📿</div>
                        <h4>Collar</h4>
                    </div>
                    
                    <div class="jewelry-type-card" data-type="pulsera" style="background: white; padding: 30px; text-align: center; border-radius: 12px; cursor: pointer; border: 2px solid #f0f0f0; transition: all 0.3s;">
                        <div style="font-size: 60px; margin-bottom: 15px;">💫</div>
                        <h4>Pulsera</h4>
                    </div>
                    
                    <div class="jewelry-type-card" data-type="aretes" style="background: white; padding: 30px; text-align: center; border-radius: 12px; cursor: pointer; border: 2px solid #f0f0f0; transition: all 0.3s;">
                        <div style="font-size: 60px; margin-bottom: 15px;">✨</div>
                        <h4>Aretes</h4>
                    </div>
                </div>
            </div>
            
            <!-- PASO 2: Metal -->
            <div class="builder-step" id="step-2" style="display: none;">
                <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 30px;">
                    Paso 2: Selecciona el metal
                </h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div class="metal-card" data-metal="oro-18k" data-price="500000">
                        <div style="background: linear-gradient(135deg, #FFD700, #FFA500); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>Oro 18K</h4>
                            <p>+$500,000</p>
                        </div>
                    </div>
                    
                    <div class="metal-card" data-metal="oro-14k" data-price="350000">
                        <div style="background: linear-gradient(135deg, #DAA520, #B8860B); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>Oro 14K</h4>
                            <p>+$350,000</p>
                        </div>
                    </div>
                    
                    <div class="metal-card" data-metal="platino" data-price="800000">
                        <div style="background: linear-gradient(135deg, #E5E4E2, #BCC6CC); color: #333; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>Platino</h4>
                            <p>+$800,000</p>
                        </div>
                    </div>
                    
                    <div class="metal-card" data-metal="plata-925" data-price="100000">
                        <div style="background: linear-gradient(135deg, #C0C0C0, #A8A8A8); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>Plata 925</h4>
                            <p>+$100,000</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- PASO 3: Piedra -->
            <div class="builder-step" id="step-3" style="display: none;">
                <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 30px;">
                    Paso 3: Selecciona la piedra preciosa
                </h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div class="stone-card" data-stone="diamante" data-price="1000000">
                        <div style="background: linear-gradient(135deg, #b9f2ff, #696969); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>💎 Diamante</h4>
                            <p>+$1,000,000</p>
                        </div>
                    </div>
                    
                    <div class="stone-card" data-stone="esmeralda" data-price="700000">
                        <div style="background: linear-gradient(135deg, #50C878, #228B22); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>💚 Esmeralda</h4>
                            <p>+$700,000</p>
                        </div>
                    </div>
                    
                    <div class="stone-card" data-stone="rubi" data-price="800000">
                        <div style="background: linear-gradient(135deg, #E0115F, #8B0000); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>❤️ Rubí</h4>
                            <p>+$800,000</p>
                        </div>
                    </div>
                    
                    <div class="stone-card" data-stone="zafiro" data-price="650000">
                        <div style="background: linear-gradient(135deg, #0F52BA, #000080); color: white; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>💙 Zafiro</h4>
                            <p>+$650,000</p>
                        </div>
                    </div>
                    
                    <div class="stone-card" data-stone="ninguna" data-price="0">
                        <div style="background: #f0f0f0; color: #333; padding: 30px; border-radius: 12px; cursor: pointer;">
                            <h4>❌ Sin Piedra</h4>
                            <p>Sin costo adicional</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- PASO 4: Grabado -->
            <div class="builder-step" id="step-4" style="display: none;">
                <h3 style="font-family: 'Playfair Display', serif; margin-bottom: 30px;">
                    Paso 4: Personaliza con grabado (opcional)
                </h3>
                
                <div style="background: white; padding: 40px; border-radius: 12px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: 600;">
                        ¿Deseas agregar un grabado personalizado? (+$50,000)
                    </label>
                    
                    <select id="engraving-option" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px; margin-bottom: 20px;">
                        <option value="no">No, gracias</option>
                        <option value="yes">Sí, agregar grabado</option>
                    </select>
                    
                    <div id="engraving-input" style="display: none;">
                        <label style="display: block; margin-bottom: 10px;">
                            Texto del grabado (máximo 20 caracteres):
                        </label>
                        <input type="text" id="engraving-text" maxlength="20" 
                               placeholder="Ej: Para siempre" 
                               style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 6px;">
                    </div>
                </div>
            </div>
            
            <!-- RESUMEN Y PRECIO -->
            <div id="builder-summary" style="position: sticky; bottom: 0; background: white; padding: 20px; border-top: 2px solid #D4AF37; margin-top: 40px; border-radius: 12px 12px 0 0; box-shadow: 0 -4px 20px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                    <div>
                        <h4 style="margin: 0 0 10px 0;">Tu Diseño:</h4>
                        <p id="summary-text" style="margin: 0; color: #666;">Selecciona opciones para ver tu diseño</p>
                    </div>
                    
                    <div style="text-align: right;">
                        <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Precio Total:</div>
                        <div id="total-price" style="font-size: 32px; font-weight: 700; color: #D4AF37;">$0</div>
                    </div>
                </div>
                
                <div style="margin-top: 20px; display: flex; gap: 15px;">
                    <button id="btn-prev" style="padding: 15px 30px; background: #666; color: white; border: none; border-radius: 6px; cursor: pointer; display: none;">
                        ← Anterior
                    </button>
                    
                    <button id="btn-next" style="flex: 1; padding: 15px 30px; background: #D4AF37; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                        Siguiente →
                    </button>
                    
                    <button id="btn-add-cart" style="flex: 1; padding: 15px 30px; background: #D4AF37; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; display: none;">
                        ✓ Agregar al Carrito
                    </button>
                </div>
            </div>
            
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var currentStep = 1;
        var totalSteps = 4;
        var design = {
            type: '',
            metal: '',
            stone: '',
            engraving: false,
            engravingText: '',
            price: 0
        };
        
        // Seleccionar tipo
        $('.jewelry-type-card').on('click', function() {
            $('.jewelry-type-card').css('border-color', '#f0f0f0');
            $(this).css('border-color', '#D4AF37');
            design.type = $(this).data('type');
            updateSummary();
        });
        
        // Seleccionar metal
        $('.metal-card').on('click', function() {
            $('.metal-card div').css('transform', 'scale(1)');
            $(this).find('div').css('transform', 'scale(1.05)');
            design.metal = $(this).data('metal');
            design.price += parseInt($(this).data('price'));
            updateSummary();
        });
        
        // Seleccionar piedra
        $('.stone-card').on('click', function() {
            $('.stone-card div').css('transform', 'scale(1)');
            $(this).find('div').css('transform', 'scale(1.05)');
            design.stone = $(this).data('stone');
            design.price += parseInt($(this).data('price'));
            updateSummary();
        });
        
        // Grabado
        $('#engraving-option').on('change', function() {
            if ($(this).val() === 'yes') {
                $('#engraving-input').show();
                design.engraving = true;
                design.price += 50000;
            } else {
                $('#engraving-input').hide();
                design.engraving = false;
                design.price -= 50000;
            }
            updateSummary();
        });
        
        $('#engraving-text').on('input', function() {
            design.engravingText = $(this).val();
            updateSummary();
        });
        
        // Navegación
        $('#btn-next').on('click', function() {
            if (currentStep < totalSteps) {
                currentStep++;
                showStep(currentStep);
            }
        });
        
        $('#btn-prev').on('click', function() {
            if (currentStep > 1) {
                currentStep--;
                showStep(currentStep);
            }
        });
        
        function showStep(step) {
            $('.builder-step').hide();
            $('#step-' + step).show();
            
            if (step === 1) {
                $('#btn-prev').hide();
            } else {
                $('#btn-prev').show();
            }
            
            if (step === totalSteps) {
                $('#btn-next').hide();
                $('#btn-add-cart').show();
            } else {
                $('#btn-next').show();
                $('#btn-add-cart').hide();
            }
        }
        
        function updateSummary() {
            var summary = '';
            if (design.type) summary += design.type.charAt(0).toUpperCase() + design.type.slice(1);
            if (design.metal) summary += ' de ' + design.metal;
            if (design.stone && design.stone !== 'ninguna') summary += ' con ' + design.stone;
            if (design.engraving && design.engravingText) summary += ' (Grabado: "' + design.engravingText + '")';
            
            $('#summary-text').text(summary || 'Selecciona opciones para ver tu diseño');
            $('#total-price').text('$' + design.price.toLocaleString('es-CO'));
        }
        
        // Agregar al carrito
        $('#btn-add-cart').on('click', function() {
            alert('Funcionalidad de carrito: Este diseño personalizado se agregará como producto especial.');
            // Aquí se integraría con WooCommerce para crear producto personalizado
        });
    });
    </script>
    
    <style>
    .jewelry-type-card:hover,
    .metal-card:hover,
    .stone-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }
    </style>
    
    <?php
    return ob_get_clean();
}
