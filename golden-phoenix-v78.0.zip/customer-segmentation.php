<?php
/**
 * V73 - CUSTOMER SEGMENTATION
 */
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function() {
    add_submenu_page('woocommerce', 'Segmentación', 'Segmentación', 'manage_woocommerce', 'gp-segmentation', 'gp_segmentation_page');
});

function gp_segmentation_page() {
    $vip_customers = gp_get_vip_customers();
    $new_customers = gp_get_new_customers();
    $inactive = gp_get_inactive_customers();
    ?>
    <div class="wrap">
        <h1>👥 Segmentación de Clientes</h1>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 20px 0;">
            <div style="background: gold; color: #333; padding: 20px; border-radius: 8px;">
                <h2>🌟 VIP (<?php echo count($vip_customers); ?>)</h2>
                <p>Más de $1,000,000 en compras</p>
            </div>
            <div style="background: lightgreen; color: #333; padding: 20px; border-radius: 8px;">
                <h2>🆕 Nuevos (<?php echo count($new_customers); ?>)</h2>
                <p>Últimos 30 días</p>
            </div>
            <div style="background: lightcoral; color: white; padding: 20px; border-radius: 8px;">
                <h2>😴 Inactivos (<?php echo count($inactive); ?>)</h2>
                <p>Sin compras 90+ días</p>
            </div>
        </div>
    </div>
    <?php
}

function gp_get_vip_customers() {
    global $wpdb;
    return $wpdb->get_results("SELECT user_id, SUM(total) as total FROM {$wpdb->prefix}wc_customer_lookup WHERE total > 1000000 GROUP BY user_id");
}

function gp_get_new_customers() {
    return get_users(array('date_query' => array(array('after' => '30 days ago'))));
}

function gp_get_inactive_customers() {
    return array(); // Placeholder
}
