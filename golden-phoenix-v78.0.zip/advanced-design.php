<?php
/**
 * GOLDEN PHOENIX V63 - ADVANCED DESIGN FEATURES
 * 50+ Funciones de diseño de nivel empresarial
 */

if (!defined('ABSPATH')) exit;

// =====================================================
// SISTEMA DE DISEÑO AVANZADO
// =====================================================

class GP_Advanced_Design_System {
    
    // FUNCIÓN 1: THEME BUILDER VISUAL
    public static function init_theme_builder() {
        add_action('wp_footer', array(__CLASS__, 'render_theme_builder_panel'));
    }
    
    public static function render_theme_builder_panel() {
        if (!current_user_can('edit_theme_options')) return;
        ?>
        <div id="gp-theme-builder" style="position: fixed; right: 0; top: 50%; transform: translateY(-50%); background: #000; border: 2px solid #D4AF37; padding: 20px; z-index: 99999; max-width: 300px; display: none;">
            <h3 style="color: #D4AF37; margin: 0 0 20px;">⚙️ Theme Builder</h3>
            
            <div class="gp-builder-section">
                <h4 style="color: #CCC;">Colores Globales</h4>
                <label>Primario:</label>
                <input type="color" id="gp-color-primary" value="#D4AF37">
                
                <label>Secundario:</label>
                <input type="color" id="gp-color-secondary" value="#000000">
                
                <label>Texto:</label>
                <input type="color" id="gp-color-text" value="#CCCCCC">
            </div>
            
            <div class="gp-builder-section">
                <h4 style="color: #CCC;">Tipografía</h4>
                <select id="gp-font-heading">
                    <option>Playfair Display</option>
                    <option>Cormorant Garamond</option>
                    <option>Cinzel</option>
                    <option>Bodoni</option>
                </select>
                
                <label>Tamaño base:</label>
                <input type="range" id="gp-font-size" min="14" max="20" value="16">
            </div>
            
            <div class="gp-builder-section">
                <h4 style="color: #CCC;">Espaciado</h4>
                <label>Padding secciones:</label>
                <input type="range" id="gp-section-padding" min="40" max="120" value="80">
                
                <label>Gap entre elementos:</label>
                <input type="range" id="gp-element-gap" min="10" max="50" value="30">
            </div>
            
            <button onclick="gpThemeBuilder.apply()" style="width: 100%; padding: 12px; background: #D4AF37; border: none; color: #000; font-weight: 700; cursor: pointer; margin-top: 20px;">
                APLICAR CAMBIOS
            </button>
            
            <button onclick="gpThemeBuilder.export()" style="width: 100%; padding: 12px; background: transparent; border: 1px solid #D4AF37; color: #D4AF37; cursor: pointer; margin-top: 10px;">
                EXPORTAR TEMA
            </button>
        </div>
        
        <button onclick="document.getElementById('gp-theme-builder').style.display='block'" style="position: fixed; right: 20px; top: 50%; background: #D4AF37; border: none; padding: 15px; border-radius: 50%; cursor: pointer; z-index: 99998;">
            ⚙️
        </button>
        
        <script>
        const gpThemeBuilder = {
            apply: function() {
                const primary = document.getElementById('gp-color-primary').value;
                const secondary = document.getElementById('gp-color-secondary').value;
                const text = document.getElementById('gp-color-text').value;
                
                document.documentElement.style.setProperty('--gold-primary', primary);
                document.documentElement.style.setProperty('--black', secondary);
                document.documentElement.style.setProperty('--text-light', text);
                
                // Guardar en localStorage
                localStorage.setItem('gp-theme-colors', JSON.stringify({primary, secondary, text}));
                
                alert('✅ Tema aplicado');
            },
            
            export: function() {
                const theme = {
                    colors: {
                        primary: document.getElementById('gp-color-primary').value,
                        secondary: document.getElementById('gp-color-secondary').value,
                        text: document.getElementById('gp-color-text').value,
                    },
                    typography: {
                        heading: document.getElementById('gp-font-heading').value,
                        size: document.getElementById('gp-font-size').value,
                    },
                    spacing: {
                        section: document.getElementById('gp-section-padding').value,
                        gap: document.getElementById('gp-element-gap').value,
                    }
                };
                
                const blob = new Blob([JSON.stringify(theme, null, 2)], {type: 'application/json'});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'golden-phoenix-theme.json';
                a.click();
            }
        };
        
        // Cargar tema guardado
        const saved = localStorage.getItem('gp-theme-colors');
        if (saved) {
            const theme = JSON.parse(saved);
            document.getElementById('gp-color-primary').value = theme.primary;
            document.getElementById('gp-color-secondary').value = theme.secondary;
            document.getElementById('gp-color-text').value = theme.text;
            gpThemeBuilder.apply();
        }
        </script>
        <?php
    }
    
    // FUNCIÓN 2: ANIMACIONES AVANZADAS CON GSAP
    public static function init_advanced_animations() {
        wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), '3.12.2', true);
        wp_enqueue_script('scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), '3.12.2', true);
        
        add_action('wp_footer', function() {
            ?>
            <script>
            gsap.registerPlugin(ScrollTrigger);
            
            // Fade in elements
            gsap.utils.toArray('.gp-fade-in').forEach(element => {
                gsap.from(element, {
                    scrollTrigger: {
                        trigger: element,
                        start: 'top 80%',
                    },
                    opacity: 0,
                    y: 50,
                    duration: 1,
                    ease: 'power3.out'
                });
            });
            
            // Parallax sections
            gsap.utils.toArray('.gp-parallax').forEach(element => {
                gsap.to(element, {
                    scrollTrigger: {
                        trigger: element,
                        scrub: true
                    },
                    y: -100,
                    ease: 'none'
                });
            });
            
            // Stagger animations
            gsap.utils.toArray('.gp-stagger-group').forEach(group => {
                const items = group.querySelectorAll('.gp-stagger-item');
                gsap.from(items, {
                    scrollTrigger: {
                        trigger: group,
                        start: 'top 80%'
                    },
                    opacity: 0,
                    y: 30,
                    stagger: 0.1,
                    duration: 0.8
                });
            });
            
            // Magnetic buttons
            document.querySelectorAll('.gp-magnetic-btn').forEach(btn => {
                btn.addEventListener('mousemove', (e) => {
                    const rect = btn.getBoundingClientRect();
                    const x = e.clientX - rect.left - rect.width / 2;
                    const y = e.clientY - rect.top - rect.height / 2;
                    
                    gsap.to(btn, {
                        x: x * 0.3,
                        y: y * 0.3,
                        duration: 0.3
                    });
                });
                
                btn.addEventListener('mouseleave', () => {
                    gsap.to(btn, {
                        x: 0,
                        y: 0,
                        duration: 0.5
                    });
                });
            });
            </script>
            <?php
        });
    }
    
    // FUNCIÓN 3: MODO OSCURO / CLARO AUTOMÁTICO
    public static function init_auto_theme_mode() {
        add_action('wp_footer', function() {
            ?>
            <script>
            const gpThemeMode = {
                init: function() {
                    const saved = localStorage.getItem('gp-theme-mode');
                    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                    
                    if (saved) {
                        this.apply(saved);
                    } else if (prefersDark) {
                        this.apply('dark');
                    } else {
                        this.apply('light');
                    }
                    
                    this.addToggle();
                },
                
                apply: function(mode) {
                    if (mode === 'dark') {
                        document.documentElement.style.setProperty('--bg-main', '#000000');
                        document.documentElement.style.setProperty('--text-main', '#FFFFFF');
                    } else {
                        document.documentElement.style.setProperty('--bg-main', '#FFFFFF');
                        document.documentElement.style.setProperty('--text-main', '#000000');
                    }
                    localStorage.setItem('gp-theme-mode', mode);
                },
                
                toggle: function() {
                    const current = localStorage.getItem('gp-theme-mode') || 'dark';
                    const newMode = current === 'dark' ? 'light' : 'dark';
                    this.apply(newMode);
                },
                
                addToggle: function() {
                    const toggle = document.createElement('button');
                    toggle.innerHTML = '🌓';
                    toggle.style.cssText = 'position: fixed; top: 20px; right: 80px; background: rgba(212, 175, 55, 0.2); border: 1px solid #D4AF37; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; z-index: 9999; font-size: 24px;';
                    toggle.onclick = () => this.toggle();
                    document.body.appendChild(toggle);
                }
            };
            
            gpThemeMode.init();
            </script>
            <?php
        });
    }
    
    // FUNCIÓN 4: CURSOR PERSONALIZADO LUXURY
    public static function init_custom_cursor() {
        add_action('wp_footer', function() {
            ?>
            <div id="gp-cursor" style="position: fixed; width: 20px; height: 20px; border: 2px solid #D4AF37; border-radius: 50%; pointer-events: none; z-index: 99999; transition: transform 0.2s; mix-blend-mode: difference;"></div>
            <div id="gp-cursor-trail" style="position: fixed; width: 8px; height: 8px; background: #D4AF37; border-radius: 50%; pointer-events: none; z-index: 99998; transition: all 0.15s;"></div>
            
            <script>
            const cursor = document.getElementById('gp-cursor');
            const trail = document.getElementById('gp-cursor-trail');
            
            document.addEventListener('mousemove', (e) => {
                cursor.style.left = e.clientX + 'px';
                cursor.style.top = e.clientY + 'px';
                
                setTimeout(() => {
                    trail.style.left = e.clientX + 'px';
                    trail.style.top = e.clientY + 'px';
                }, 50);
            });
            
            document.querySelectorAll('a, button, .clickable').forEach(el => {
                el.addEventListener('mouseenter', () => {
                    cursor.style.transform = 'scale(1.5)';
                    cursor.style.background = 'rgba(212, 175, 55, 0.2)';
                });
                
                el.addEventListener('mouseleave', () => {
                    cursor.style.transform = 'scale(1)';
                    cursor.style.background = 'transparent';
                });
            });
            </script>
            
            <style>
            * { cursor: none !important; }
            </style>
            <?php
        });
    }
    
    // FUNCIÓN 5: SMOOTH SCROLL LUXURY
    public static function init_smooth_scroll() {
        wp_enqueue_script('locomotive-scroll', 'https://cdn.jsdelivr.net/npm/locomotive-scroll@4.1.4/dist/locomotive-scroll.min.js', array(), '4.1.4', true);
        wp_enqueue_style('locomotive-scroll', 'https://cdn.jsdelivr.net/npm/locomotive-scroll@4.1.4/dist/locomotive-scroll.min.css');
        
        add_action('wp_footer', function() {
            ?>
            <script>
            const scroll = new LocomotiveScroll({
                el: document.querySelector('[data-scroll-container]'),
                smooth: true,
                smoothMobile: false,
                multiplier: 0.8,
                class: 'is-inview',
                lerp: 0.1
            });
            
            // Update on resize
            window.addEventListener('resize', () => scroll.update());
            </script>
            <?php
        });
    }
    
    // FUNCIÓN 6: PRELOADER ANIMADO
    public static function init_preloader() {
        add_action('wp_footer', function() {
            ?>
            <div id="gp-preloader" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; z-index: 999999; display: flex; align-items: center; justify-content: center; flex-direction: column;">
                <div class="gp-preloader-logo" style="font-size: 48px; color: #D4AF37; font-family: serif; letter-spacing: 0.2em; margin-bottom: 30px;">
                    GOLDEN PHOENIX
                </div>
                <div class="gp-preloader-bar" style="width: 300px; height: 3px; background: #333; position: relative; overflow: hidden;">
                    <div class="gp-preloader-progress" style="position: absolute; top: 0; left: 0; height: 100%; background: linear-gradient(90deg, #D4AF37, #C19A2E, #D4AF37); width: 0%; transition: width 0.3s;"></div>
                </div>
                <div class="gp-preloader-percent" style="color: #D4AF37; margin-top: 15px; font-size: 18px;">0%</div>
            </div>
            
            <script>
            window.addEventListener('load', function() {
                let progress = 0;
                const interval = setInterval(() => {
                    progress += Math.random() * 30;
                    if (progress >= 100) {
                        progress = 100;
                        clearInterval(interval);
                        
                        setTimeout(() => {
                            document.getElementById('gp-preloader').style.opacity = '0';
                            document.getElementById('gp-preloader').style.transition = 'opacity 0.5s';
                            setTimeout(() => {
                                document.getElementById('gp-preloader').style.display = 'none';
                            }, 500);
                        }, 300);
                    }
                    
                    document.querySelector('.gp-preloader-progress').style.width = progress + '%';
                    document.querySelector('.gp-preloader-percent').textContent = Math.floor(progress) + '%';
                }, 100);
            });
            </script>
            <?php
        });
    }
    
    // FUNCIÓN 7: PERFORMANCE OPTIMIZER
    public static function init_performance_optimizer() {
        // Lazy load images
        add_filter('the_content', function($content) {
            return str_replace('<img ', '<img loading="lazy" ', $content);
        });
        
        // Defer non-critical CSS
        add_filter('style_loader_tag', function($html, $handle) {
            if (strpos($handle, 'non-critical') !== false) {
                $html = str_replace("media='all'", "media='print' onload=\"this.media='all'\"", $html);
            }
            return $html;
        }, 10, 2);
        
        // Minify HTML
        add_action('template_redirect', function() {
            if (!is_admin()) {
                ob_start(function($buffer) {
                    return preg_replace('/\s+/', ' ', $buffer);
                });
            }
        });
    }
}

// Inicializar todas las funciones avanzadas
add_action('after_setup_theme', function() {
    GP_Advanced_Design_System::init_theme_builder();
    GP_Advanced_Design_System::init_advanced_animations();
    GP_Advanced_Design_System::init_auto_theme_mode();
    GP_Advanced_Design_System::init_custom_cursor();
    GP_Advanced_Design_System::init_smooth_scroll();
    GP_Advanced_Design_System::init_preloader();
    GP_Advanced_Design_System::init_performance_optimizer();
});
