<?php
/**
 * Golden Phoenix - Personalizador Visual Completo
 * Edita colores, textos, logos y todo desde WordPress Customizer
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// REGISTRAR OPCIONES EN CUSTOMIZER
// ============================================

add_action('customize_register', 'gp_customize_register');

function gp_customize_register($wp_customize) {
    
    // ============================================
    // SECCIÓN 1: COLORES DEL TEMA
    // ============================================
    
    $wp_customize->add_section('gp_colors_section', array(
        'title' => '🎨 Colores del Tema',
        'priority' => 30,
        'description' => 'Personaliza todos los colores de tu joyería'
    ));
    
    // Color Primario (Dorado)
    $wp_customize->add_setting('gp_primary_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh'
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_primary_color', array(
        'label' => 'Color Primario (Dorado)',
        'section' => 'gp_colors_section',
        'settings' => 'gp_primary_color',
    )));
    
    // Color Secundario
    $wp_customize->add_setting('gp_secondary_color', array(
        'default' => '#0A0A0A',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_secondary_color', array(
        'label' => 'Color Secundario (Negro)',
        'section' => 'gp_colors_section',
        'settings' => 'gp_secondary_color',
    )));
    
    // Color de Fondo
    $wp_customize->add_setting('gp_background_color', array(
        'default' => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_background_color', array(
        'label' => 'Color de Fondo Principal',
        'section' => 'gp_colors_section',
        'settings' => 'gp_background_color',
    )));
    
    // Color del Header
    $wp_customize->add_setting('gp_header_bg_color', array(
        'default' => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_header_bg_color', array(
        'label' => 'Color de Fondo del Header',
        'section' => 'gp_colors_section',
        'settings' => 'gp_header_bg_color',
    )));
    
    // Color del Footer
    $wp_customize->add_setting('gp_footer_bg_color', array(
        'default' => '#0A0A0A',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_footer_bg_color', array(
        'label' => 'Color de Fondo del Footer',
        'section' => 'gp_colors_section',
        'settings' => 'gp_footer_bg_color',
    )));
    
    // Color de Botones
    $wp_customize->add_setting('gp_button_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_button_color', array(
        'label' => 'Color de Botones',
        'section' => 'gp_colors_section',
        'settings' => 'gp_button_color',
    )));
    
    // Color de Enlaces
    $wp_customize->add_setting('gp_link_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_link_color', array(
        'label' => 'Color de Enlaces',
        'section' => 'gp_colors_section',
        'settings' => 'gp_link_color',
    )));
    
    // ============================================
    // SECCIÓN 2: TEXTOS DEL SITIO
    // ============================================
    
    $wp_customize->add_section('gp_texts_section', array(
        'title' => '📝 Textos del Sitio',
        'priority' => 31,
        'description' => 'Edita todos los textos visibles'
    ));
    
    // Texto del Hero
    $wp_customize->add_setting('gp_hero_title', array(
        'default' => 'Joyas Excepcionales',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_hero_title', array(
        'label' => 'Título Principal (Hero)',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_hero_subtitle', array(
        'default' => 'Diseñadas para Perdurar',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_hero_subtitle', array(
        'label' => 'Subtítulo (Hero)',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_hero_description', array(
        'default' => 'Descubre nuestra colección exclusiva de joyería de alta gama',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('gp_hero_description', array(
        'label' => 'Descripción (Hero)',
        'section' => 'gp_texts_section',
        'type' => 'textarea',
    ));
    
    // Botón Principal
    $wp_customize->add_setting('gp_main_button_text', array(
        'default' => 'Explorar Colección',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_main_button_text', array(
        'label' => 'Texto Botón Principal',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    // Menú Textos
    $wp_customize->add_setting('gp_menu_home', array(
        'default' => 'Inicio',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_menu_home', array(
        'label' => 'Menú: Inicio',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_menu_collections', array(
        'default' => 'Colecciones',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_menu_collections', array(
        'label' => 'Menú: Colecciones',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_menu_shop', array(
        'default' => 'Tienda',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_menu_shop', array(
        'label' => 'Menú: Tienda',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_menu_about', array(
        'default' => 'Nosotros',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_menu_about', array(
        'label' => 'Menú: Nosotros',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_menu_contact', array(
        'default' => 'Contacto',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_menu_contact', array(
        'label' => 'Menú: Contacto',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    // Carrito
    $wp_customize->add_setting('gp_cart_text', array(
        'default' => 'Carrito',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_cart_text', array(
        'label' => 'Texto: Carrito',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_checkout_text', array(
        'default' => 'Finalizar Compra',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_checkout_text', array(
        'label' => 'Texto: Finalizar Compra',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    // Footer
    $wp_customize->add_setting('gp_footer_text', array(
        'default' => '© 2025 Golden Phoenix Jewelry. Todos los derechos reservados.',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_footer_text', array(
        'label' => 'Texto Copyright Footer',
        'section' => 'gp_texts_section',
        'type' => 'text',
    ));
    
    // ============================================
    // SECCIÓN 3: TIPOGRAFÍA
    // ============================================
    
    $wp_customize->add_section('gp_typography_section', array(
        'title' => '✍️ Tipografía',
        'priority' => 32,
    ));
    
    $wp_customize->add_setting('gp_font_headings', array(
        'default' => 'Playfair Display',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_font_headings', array(
        'label' => 'Fuente para Títulos',
        'section' => 'gp_typography_section',
        'type' => 'select',
        'choices' => array(
            'Playfair Display' => 'Playfair Display (Elegante)',
            'Bodoni Moda' => 'Bodoni Moda (Clásico)',
            'Cormorant Garamond' => 'Cormorant Garamond',
            'Cinzel' => 'Cinzel (Lujoso)',
            'Lora' => 'Lora',
        )
    ));
    
    $wp_customize->add_setting('gp_font_body', array(
        'default' => 'Montserrat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_font_body', array(
        'label' => 'Fuente para Texto',
        'section' => 'gp_typography_section',
        'type' => 'select',
        'choices' => array(
            'Montserrat' => 'Montserrat (Moderna)',
            'Open Sans' => 'Open Sans',
            'Lato' => 'Lato',
            'Roboto' => 'Roboto',
            'Raleway' => 'Raleway',
        )
    ));
    
    // ============================================
    // SECCIÓN 4: INFORMACIÓN DE CONTACTO
    // ============================================
    
    $wp_customize->add_section('gp_contact_section', array(
        'title' => '📞 Información de Contacto',
        'priority' => 33,
    ));
    
    $wp_customize->add_setting('gp_phone', array(
        'default' => '+57 300 123 4567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_phone', array(
        'label' => 'Teléfono',
        'section' => 'gp_contact_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_email', array(
        'default' => 'info@goldenphoenix.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    
    $wp_customize->add_control('gp_email', array(
        'label' => 'Email',
        'section' => 'gp_contact_section',
        'type' => 'email',
    ));
    
    $wp_customize->add_setting('gp_address', array(
        'default' => 'Calle 123 #45-67, Medellín, Colombia',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_address', array(
        'label' => 'Dirección',
        'section' => 'gp_contact_section',
        'type' => 'text',
    ));
    
    $wp_customize->add_setting('gp_hours', array(
        'default' => 'Lun - Sáb: 10:00 - 20:00',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_hours', array(
        'label' => 'Horario de Atención',
        'section' => 'gp_contact_section',
        'type' => 'text',
        'description' => 'Ejemplo: Lun - Sáb: 10:00 - 20:00',
    ));
    
    $wp_customize->add_setting('gp_whatsapp', array(
        'default' => '+573001234567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('gp_whatsapp', array(
        'label' => 'WhatsApp (con código país)',
        'section' => 'gp_contact_section',
        'type' => 'text',
    ));
    
    // Redes Sociales
    $wp_customize->add_setting('gp_facebook', array(
        'default' => 'https://facebook.com/goldenphoenix',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('gp_facebook', array(
        'label' => 'Facebook URL',
        'section' => 'gp_contact_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('gp_instagram', array(
        'default' => 'https://instagram.com/goldenphoenix',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('gp_instagram', array(
        'label' => 'Instagram URL',
        'section' => 'gp_contact_section',
        'type' => 'url',
    ));
    
    $wp_customize->add_setting('gp_twitter', array(
        'default' => 'https://twitter.com/goldenphoenix',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('gp_twitter', array(
        'label' => 'Twitter/X URL',
        'section' => 'gp_contact_section',
        'type' => 'url',
    ));
}

// ============================================
// APLICAR COLORES PERSONALIZADOS
// ============================================

// DESACTIVADO: Causaba que el fondo fuera negro en vez de crema
// add_action('wp_head', 'gp_customizer_css');

function gp_customizer_css() {
    $primary_color = get_theme_mod('gp_primary_color', '#D4AF37');
    $secondary_color = get_theme_mod('gp_secondary_color', '#0A0A0A');
    $background_color = get_theme_mod('gp_background_color', '#FFFFFF');
    $header_bg = get_theme_mod('gp_header_bg_color', '#FFFFFF');
    $footer_bg = get_theme_mod('gp_footer_bg_color', '#0A0A0A');
    $button_color = get_theme_mod('gp_button_color', '#D4AF37');
    $link_color = get_theme_mod('gp_link_color', '#D4AF37');
    
    $font_headings = get_theme_mod('gp_font_headings', 'Playfair Display');
    $font_body = get_theme_mod('gp_font_body', 'Montserrat');
    
    ?>
    <style type="text/css" id="gp-custom-colors">
        /* Colores Personalizados */
        :root {
            --gp-primary: <?php echo esc_attr($primary_color); ?>;
            --gp-secondary: <?php echo esc_attr($secondary_color); ?>;
            --gp-background: <?php echo esc_attr($background_color); ?>;
        }
        
        /* Fondo del sitio - APLICADO */
        body,
        body.home,
        body.page,
        .site-main,
        #page,
        #content {
            background-color: <?php echo esc_attr($background_color); ?> !important;
        }
        
        /* Header - APLICADO */
        .site-header,
        header.site-header {
            background-color: <?php echo esc_attr($header_bg); ?> !important;
        }
        
        /* Footer - APLICADO */
        .site-footer,
        footer.site-footer {
            background-color: <?php echo esc_attr($footer_bg); ?> !important;
        }
        
        /* Botones - APLICADO */
        .btn-primary,
        .button,
        .woocommerce button.button,
        .woocommerce a.button,
        .woocommerce .cart .button,
        .woocommerce .checkout-button,
        button[type="submit"],
        input[type="submit"],
        .add-to-cart,
        .elementor-button {
            background-color: <?php echo esc_attr($button_color); ?> !important;
            border-color: <?php echo esc_attr($button_color); ?> !important;
        }
        
        .btn-primary:hover,
        .button:hover,
        .woocommerce button.button:hover {
            background-color: <?php echo esc_attr($secondary_color); ?> !important;
            border-color: <?php echo esc_attr($secondary_color); ?> !important;
        }
        
        /* Enlaces - APLICADO */
        a {
            color: <?php echo esc_attr($link_color); ?>;
        }
        
        a:hover {
            color: <?php echo esc_attr($secondary_color); ?>;
        }
        
        /* Color primario en varios elementos */
        .luxury-gold,
        .price,
        .woocommerce-Price-amount,
        .amount,
        .woocommerce .woocommerce-Price-amount {
            color: <?php echo esc_attr($primary_color); ?> !important;
        }
        
        /* Títulos */
        h1, h2, h3, h4, h5, h6,
        .site-title,
        .entry-title {
            font-family: '<?php echo esc_attr($font_headings); ?>', serif !important;
            color: <?php echo esc_attr($secondary_color); ?>;
        }
        
        /* Texto del cuerpo */
        body,
        p,
        .entry-content {
            font-family: '<?php echo esc_attr($font_body); ?>', sans-serif !important;
        }
        
        /* Menú de navegación */
        .main-navigation a {
            color: <?php echo esc_attr($secondary_color); ?>;
        }
        
        .main-navigation a:hover {
            color: <?php echo esc_attr($primary_color); ?>;
        }
        
        /* Bordes y líneas decorativas */
        .decorative-line,
        hr {
            border-color: <?php echo esc_attr($primary_color); ?>;
        }
        
        /* Asegurar que el fondo se aplique en todas partes */
        .home-page,
        .collections-page,
        .custom-cart-page {
            background-color: <?php echo esc_attr($background_color); ?> !important;
        }
    </style>
    <?php
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

// Obtener texto personalizado
function gp_get_text($key, $default = '') {
    return get_theme_mod($key, $default);
}

// Obtener color personalizado
function gp_get_color($key, $default = '#D4AF37') {
    return get_theme_mod($key, $default);
}
