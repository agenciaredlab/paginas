<?php
/**
 * Golden Phoenix V74 - FIX THEME BUILDER + CHATS + CURRENCY
 * Arregla elementos que no deben verse en frontend público
 */

if (!defined('ABSPATH')) exit;

// ========================================
// OCULTAR THEME BUILDER EN FRONTEND
// ========================================

add_action('wp_head', 'gp_v74_hide_theme_builder_frontend', 1);

function gp_v74_hide_theme_builder_frontend() {
    // Solo mostrar Theme Builder si usuario está logueado Y es admin
    if (!current_user_can('edit_theme_options')) {
        ?>
        <style>
        /* Ocultar Theme Builder para usuarios no admin */
        .gp-theme-builder,
        #theme-builder-panel,
        .theme-builder-controls {
            display: none !important;
        }
        </style>
        <?php
    }
}

// Desactivar visual builder completamente en frontend
add_action('init', 'gp_v74_disable_visual_builder_frontend');

function gp_v74_disable_visual_builder_frontend() {
    // Si no es admin, remover todos los hooks del visual builder
    if (!current_user_can('edit_theme_options')) {
        remove_action('wp_footer', 'gp_visual_builder_interface');
        remove_action('wp_footer', 'gp_theme_builder_panel');
    }
}

// ========================================
// FIX CHAT EN VIVO - ELIMINAR DUPLICADO
// ========================================

add_action('init', 'gp_v74_remove_duplicate_chat', 999);

function gp_v74_remove_duplicate_chat() {
    // Remover el chat en vivo del sistema antiguo (live-chat-system.php)
    remove_action('wp_footer', array('GP_Live_Chat_System', 'render_chat_widget'));
    
    // Usar SOLO el chat de fix-chat-v73.php
}

// ========================================
// FIX MULTI-CURRENCY - SELECTOR DISCRETO
// ========================================

add_action('wp_head', 'gp_v74_hide_currency_selector_default', 999);

function gp_v74_hide_currency_selector_default() {
    ?>
    <style>
    /* Ocultar selector de moneda flotante por defecto */
    .gp-currency-selector {
        display: none !important;
    }
    </style>
    <?php
}

// Agregar selector discreto en header
add_action('wp_head', 'gp_v74_currency_selector_header', 1000);

function gp_v74_currency_selector_header() {
    $currencies = GP_Multi_Currency::get_currencies();
    $current = GP_Multi_Currency::get_current_currency();
    ?>
    
    <style>
    /* Selector de moneda en header - discreto */
    #gp-currency-header {
        position: fixed;
        top: 10px;
        right: 100px;
        background: white;
        padding: 8px 15px;
        border-radius: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        z-index: 9997;
        font-size: 14px;
    }
    
    #gp-currency-header select {
        border: none;
        background: transparent;
        font-weight: 600;
        color: #D4AF37;
        cursor: pointer;
        padding: 0;
        outline: none;
    }
    
    @media (max-width: 768px) {
        #gp-currency-header {
            top: 60px;
            right: 10px;
            font-size: 12px;
            padding: 6px 12px;
        }
    }
    </style>
    
    <div id="gp-currency-header">
        💱 <select id="gp-currency-select-header">
            <?php foreach ($currencies as $code => $curr): ?>
                <option value="<?php echo esc_attr($code); ?>" <?php selected($current, $code); ?>>
                    <?php echo esc_html($code); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#gp-currency-select-header').on('change', function() {
            var currency = $(this).val();
            
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'gp_change_currency',
                    currency: currency,
                    nonce: '<?php echo wp_create_nonce('gp_currency_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                }
            });
        });
    });
    </script>
    
    <?php
}

// ========================================
// FIX POSICIÓN BOTONES FLOTANTES
// ========================================

add_action('wp_head', 'gp_v74_fix_floating_buttons_position', 1001);

function gp_v74_fix_floating_buttons_position() {
    ?>
    <style>
    /* Asegurar posiciones correctas sin sobreposición */
    
    /* WhatsApp - Abajo derecha */
    .gp-whatsapp-float {
        position: fixed !important;
        bottom: 20px !important;
        right: 20px !important;
        width: 60px !important;
        height: 60px !important;
        z-index: 9998 !important;
    }
    
    /* Chat en Vivo - Abajo IZQUIERDA (para no chocar) */
    .gp-live-chat-trigger {
        position: fixed !important;
        bottom: 20px !important;
        left: 20px !important; /* IZQUIERDA en vez de derecha */
        width: 60px !important;
        height: 60px !important;
        z-index: 9998 !important;
    }
    
    /* Widget chat en vivo */
    .gp-live-chat-widget {
        position: fixed !important;
        bottom: 90px !important;
        left: 20px !important; /* IZQUIERDA también */
        right: auto !important;
    }
    
    @media (max-width: 768px) {
        .gp-whatsapp-float {
            bottom: 80px !important;
            right: 15px !important;
        }
        
        .gp-live-chat-trigger {
            bottom: 15px !important;
            left: 15px !important;
        }
    }
    </style>
    <?php
}

// ========================================
// LIMPIAR OUTPUTS ANTERIORES DUPLICADOS
// ========================================

add_action('wp_footer', 'gp_v74_remove_duplicate_outputs', 1);

function gp_v74_remove_duplicate_outputs() {
    // Remover múltiples salidas del mismo widget
    ob_start();
}

// ========================================
// ADMIN NOTICE - CAMBIOS V74
// ========================================

add_action('admin_notices', 'gp_v74_admin_notice');

function gp_v74_admin_notice() {
    if (get_option('gp_v74_notice_shown')) {
        return;
    }
    
    $screen = get_current_screen();
    if ($screen->id !== 'themes') {
        return;
    }
    ?>
    
    <div class="notice notice-success is-dismissible">
        <h3>✅ Golden Phoenix V74 - Fixes Importantes</h3>
        <ul style="list-style: disc; margin-left: 20px;">
            <li>✅ Theme Builder ahora SOLO visible para administradores</li>
            <li>✅ Chat en Vivo duplicado eliminado</li>
            <li>✅ Botones flotantes reposicionados (WhatsApp derecha, Chat izquierda)</li>
            <li>✅ Selector moneda discreto en header</li>
        </ul>
        <p>
            <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_v74'}); return false;" class="button button-primary">
                Entendido
            </a>
        </p>
    </div>
    
    <?php
    update_option('gp_v74_notice_shown', true);
}

add_action('wp_ajax_gp_dismiss_v74', function() {
    update_option('gp_v74_notice_shown', true);
    wp_die();
});

// ========================================
// CUSTOMIZER: THEME BUILDER SOLO EN PREVIEW
// ========================================

add_action('customize_controls_enqueue_scripts', 'gp_v74_customizer_theme_builder');

function gp_v74_customizer_theme_builder() {
    // Permitir Theme Builder solo en customizer preview
    ?>
    <script>
    jQuery(document).ready(function($) {
        // Enviar mensaje al preview que está en customizer
        wp.customize.preview.bind('active', function() {
            $('body').addClass('customizer-preview-active');
        });
    });
    </script>
    <?php
}
