<?php
/**
 * V76 - JEWELRY CARE GUIDE
 * Guía cuidado de joyas por material
 */
if (!defined('ABSPATH')) exit;

add_action('after_switch_theme', function() {
    if (get_option('gp_care_guide_created')) return;
    wp_insert_post(array(
        'post_title' => 'Guía de Cuidado de Joyas',
        'post_name' => 'cuidado-joyas',
        'post_content' => '[jewelry_care_guide]',
        'post_status' => 'publish',
        'post_type' => 'page',
    ));
    update_option('gp_care_guide_created', true);
});

add_shortcode('jewelry_care_guide', function() {
    ob_start();
    ?>
    <div style="max-width: 1200px; margin: 0 auto;">
        <h1 style="text-align: center; font-family: 'Playfair Display', serif;">💎 Guía de Cuidado de Joyas</h1>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 40px;">
            
            <!-- Oro -->
            <div style="background: linear-gradient(135deg, #FFD700, #FFA500); color: white; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">🥇 Oro</h2>
                <ul style="line-height: 2;">
                    <li>Limpiar con agua tibia y jabón suave</li>
                    <li>Secar con paño suave</li>
                    <li>Guardar separado de otras joyas</li>
                    <li>Evitar químicos y cloro</li>
                    <li>Pulir 1-2 veces al año</li>
                </ul>
            </div>
            
            <!-- Plata -->
            <div style="background: linear-gradient(135deg, #C0C0C0, #A8A8A8); color: white; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">⚪ Plata</h2>
                <ul style="line-height: 2;">
                    <li>Limpiar con producto específico</li>
                    <li>Prevenir oxidación</li>
                    <li>Guardar en bolsa hermética</li>
                    <li>Usar regularmente previene oscurecimiento</li>
                    <li>Pulir con paño especial</li>
                </ul>
            </div>
            
            <!-- Platino -->
            <div style="background: linear-gradient(135deg, #E5E4E2, #BCC6CC); color: #333; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">💍 Platino</h2>
                <ul style="line-height: 2;">
                    <li>Muy resistente</li>
                    <li>Limpiar con agua y jabón</li>
                    <li>Mantenimiento profesional anual</li>
                    <li>No se decolora</li>
                    <li>Ideal para uso diario</li>
                </ul>
            </div>
            
            <!-- Diamantes -->
            <div style="background: linear-gradient(135deg, #b9f2ff, #696969); color: white; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">💎 Diamantes</h2>
                <ul style="line-height: 2;">
                    <li>Limpiar con cepillo suave</li>
                    <li>Agua tibia + amoníaco diluido</li>
                    <li>Revisar monturas regularmente</li>
                    <li>Evitar golpes fuertes</li>
                    <li>Limpieza profesional anual</li>
                </ul>
            </div>
            
            <!-- Perlas -->
            <div style="background: linear-gradient(135deg, #FFF5EE, #FFE4E1); color: #333; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">🦪 Perlas</h2>
                <ul style="line-height: 2;">
                    <li>MUY delicadas</li>
                    <li>Limpiar solo con paño húmedo</li>
                    <li>NUNCA químicos ni ultrasonido</li>
                    <li>Guardar planas, no colgadas</li>
                    <li>Usar regularmente mantiene brillo</li>
                </ul>
            </div>
            
            <!-- Piedras Preciosas -->
            <div style="background: linear-gradient(135deg, #50C878, #228B22); color: white; padding: 30px; border-radius: 12px;">
                <h2 style="margin-top: 0;">💚 Piedras Preciosas</h2>
                <ul style="line-height: 2;">
                    <li>Cada piedra es diferente</li>
                    <li>Evitar calor extremo</li>
                    <li>Limpiar con agua tibia</li>
                    <li>Consultar guía específica</li>
                    <li>Revisión profesional anual</li>
                </ul>
            </div>
            
        </div>
        
        <div style="background: #f9f9f9; padding: 30px; border-radius: 12px; margin-top: 40px;">
            <h2>⚠️ Consejos Generales</h2>
            <ul style="line-height: 2; font-size: 16px;">
                <li>✅ Quitarse joyas antes de ducha, ejercicio, dormir</li>
                <li>✅ Aplicar perfume/cremas ANTES de ponerse joyas</li>
                <li>✅ Guardar en joyero con compartimentos separados</li>
                <li>✅ Revisión profesional 1 vez al año</li>
                <li>✅ Limpieza profunda profesional cada 6 meses</li>
                <li>❌ No usar productos abrasivos</li>
                <li>❌ Evitar piscinas con cloro</li>
                <li>❌ No golpear ni forzar</li>
            </ul>
        </div>
    </div>
    <?php
    return ob_get_clean();
});
