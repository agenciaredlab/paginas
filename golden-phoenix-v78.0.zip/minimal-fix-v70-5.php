<?php
/**
 * Golden Phoenix V70.5 - FIX MÍNIMO SIN SOBRESCRIBIR DISEÑO
 * Solo corrige hero image customizable y theme builder
 * NO toca responsive ni diseño existente
 */

if (!defined('ABSPATH')) exit;

// ========================================
// FIX 1: HERO IMAGE DESDE CUSTOMIZER
// ========================================

add_action('customize_register', 'gp_v70_5_hero_customizer');

function gp_v70_5_hero_customizer($wp_customize) {
    
    // Agregar sección Hero solo si no existe
    if (!$wp_customize->get_section('gp_hero_section')) {
        $wp_customize->add_section('gp_hero_section', array(
            'title' => '🌅 Hero / Banner',
            'priority' => 35,
            'description' => 'Personaliza la imagen del banner principal'
        ));
    }
    
    // Imagen de fondo Hero
    $wp_customize->add_setting('gp_hero_bg_image', array(
        'default' => 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920',
        'sanitize_callback' => 'esc_url_raw',
        'transport' => 'refresh',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'gp_hero_bg_image', array(
        'label' => 'Imagen de Fondo Hero',
        'section' => 'gp_hero_section',
        'settings' => 'gp_hero_bg_image',
    )));
}

// Aplicar imagen hero sin !important (no sobrescribe)
add_action('wp_head', 'gp_v70_5_hero_image_css', 100);

function gp_v70_5_hero_image_css() {
    $hero_image = get_theme_mod('gp_hero_bg_image', 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920');
    ?>
    <style id="gp-v70-5-hero-image">
    /* Hero image desde customizer - sin !important */
    .hero-section {
        background-image: linear-gradient(135deg, rgba(10,10,10,0.7), rgba(10,10,10,0.5)), url('<?php echo esc_url($hero_image); ?>');
        background-size: cover;
        background-position: center;
    }
    </style>
    <?php
}

// ========================================
// FIX 2: THEME BUILDER BOTONES
// ========================================

add_action('wp_footer', 'gp_v70_5_theme_builder_fix', 10001);

function gp_v70_5_theme_builder_fix() {
    if (!current_user_can('edit_theme_options')) return;
    ?>
    <script id="gp-v70-5-builder-fix">
    (function() {
        'use strict';
        
        // Esperar a que cargue DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initThemeBuilder);
        } else {
            initThemeBuilder();
        }
        
        function initThemeBuilder() {
            // Solo crear si no existe
            if (typeof window.gpThemeBuilder !== 'undefined') {
                return;
            }
            
            window.gpThemeBuilder = {
                apply: function() {
                    try {
                        const primary = document.getElementById('gp-color-primary');
                        const secondary = document.getElementById('gp-color-secondary');
                        const text = document.getElementById('gp-color-text');
                        
                        if (!primary || !secondary || !text) {
                            console.warn('Theme Builder: Elementos no encontrados');
                            return;
                        }
                        
                        // Aplicar a variables CSS root
                        document.documentElement.style.setProperty('--gold-primary', primary.value);
                        document.documentElement.style.setProperty('--black-deep', secondary.value);
                        document.documentElement.style.setProperty('--black-soft', text.value);
                        
                        // Guardar en localStorage
                        localStorage.setItem('gp-theme-colors', JSON.stringify({
                            primary: primary.value,
                            secondary: secondary.value,
                            text: text.value,
                            timestamp: Date.now()
                        }));
                        
                        alert('✅ Cambios aplicados correctamente');
                    } catch (error) {
                        console.error('Theme Builder apply error:', error);
                        alert('❌ Error al aplicar cambios');
                    }
                },
                
                export: function() {
                    try {
                        const theme = {
                            version: '70.5',
                            colors: {
                                primary: document.getElementById('gp-color-primary')?.value || '#D4AF37',
                                secondary: document.getElementById('gp-color-secondary')?.value || '#0A0A0A',
                                text: document.getElementById('gp-color-text')?.value || '#1A1A1A',
                            },
                            typography: {
                                heading: document.getElementById('gp-font-heading')?.value || 'Playfair Display',
                                size: document.getElementById('gp-font-size')?.value || '16',
                            },
                            spacing: {
                                sectionPadding: document.getElementById('gp-section-padding')?.value || '80',
                                elementGap: document.getElementById('gp-element-gap')?.value || '30',
                            },
                            exported: new Date().toISOString()
                        };
                        
                        const json = JSON.stringify(theme, null, 2);
                        const blob = new Blob([json], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'golden-phoenix-theme-' + Date.now() + '.json';
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        
                        alert('✅ Tema exportado correctamente');
                    } catch (error) {
                        console.error('Theme Builder export error:', error);
                        alert('❌ Error al exportar tema');
                    }
                }
            };
            
            // Restaurar colores guardados si existen
            try {
                const savedColors = localStorage.getItem('gp-theme-colors');
                if (savedColors) {
                    const colors = JSON.parse(savedColors);
                    if (colors.primary) {
                        document.documentElement.style.setProperty('--gold-primary', colors.primary);
                    }
                    if (colors.secondary) {
                        document.documentElement.style.setProperty('--black-deep', colors.secondary);
                    }
                    if (colors.text) {
                        document.documentElement.style.setProperty('--black-soft', colors.text);
                    }
                }
            } catch (error) {
                console.error('Error restaurando colores:', error);
            }
        }
    })();
    </script>
    <?php
}
