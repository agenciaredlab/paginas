<?php
/**
 * Template Name: WooCommerce Shop
 * Description: Plantilla principal para la tienda WooCommerce
 */

get_header();
?>

<div class="woocommerce-page-wrapper" style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); min-height: 100vh; padding: 40px 0;">
    
    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 0 20px;">
        
        <?php if (is_shop()): ?>
            <!-- HERO TIENDA -->
            <div class="shop-hero" style="background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); padding: 80px 40px; border-radius: 20px; margin-bottom: 40px; text-align: center; box-shadow: 0 10px 40px rgba(201, 169, 97, 0.3);">
                <h1 style="font-size: 56px; font-weight: 700; color: #1a1a1a; margin: 0 0 20px; text-transform: uppercase; letter-spacing: 3px;">
                    <?php woocommerce_page_title(); ?>
                </h1>
                <p style="font-size: 20px; color: #2d2d2d; max-width: 700px; margin: 0 auto;">
                    Descubre nuestra exclusiva colección de joyas de lujo
                </p>
            </div>
        <?php endif; ?>
        
        <!-- BREADCRUMBS -->
        <?php if (function_exists('woocommerce_breadcrumb')): ?>
            <div style="margin-bottom: 30px;">
                <?php woocommerce_breadcrumb(array(
                    'delimiter'   => ' <span style="color: #c9a961;">›</span> ',
                    'wrap_before' => '<nav class="woocommerce-breadcrumb" style="font-size: 14px; color: #999;">',
                    'wrap_after'  => '</nav>',
                    'before'      => '',
                    'after'       => '',
                    'home'        => 'Inicio',
                )); ?>
            </div>
        <?php endif; ?>
        
        <div class="shop-content-wrapper" style="display: grid; grid-template-columns: 280px 1fr; gap: 40px;">
            
            <!-- SIDEBAR FILTROS -->
            <aside class="shop-sidebar" style="background: rgba(255,255,255,0.05); padding: 30px; border-radius: 15px; height: fit-content; position: sticky; top: 20px;">
                
                <h3 style="color: #c9a961; font-size: 20px; font-weight: 600; margin: 0 0 25px; padding-bottom: 15px; border-bottom: 2px solid rgba(201,169,97,0.2);">
                    🔍 Filtros
                </h3>
                
                <?php if (is_active_sidebar('shop-sidebar')): ?>
                    <?php dynamic_sidebar('shop-sidebar'); ?>
                <?php else: ?>
                    
                    <!-- CATEGORÍAS -->
                    <div style="margin-bottom: 30px;">
                        <h4 style="color: #fff; font-size: 16px; margin: 0 0 15px;">Categorías</h4>
                        <?php
                        $product_categories = get_terms('product_cat', array('hide_empty' => true));
                        if ($product_categories):
                            echo '<ul style="list-style: none; padding: 0; margin: 0;">';
                            foreach ($product_categories as $category):
                                $category_link = get_term_link($category);
                                echo '<li style="margin-bottom: 10px;">';
                                echo '<a href="' . esc_url($category_link) . '" style="color: #ccc; text-decoration: none; display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; border-radius: 8px; transition: all 0.3s;">';
                                echo '<span>' . esc_html($category->name) . '</span>';
                                echo '<span style="background: rgba(201,169,97,0.2); color: #c9a961; padding: 2px 8px; border-radius: 12px; font-size: 12px;">' . $category->count . '</span>';
                                echo '</a>';
                                echo '</li>';
                            endforeach;
                            echo '</ul>';
                        endif;
                        ?>
                    </div>
                    
                    <!-- RANGO DE PRECIOS -->
                    <?php if (class_exists('WooCommerce')): ?>
                        <div style="margin-bottom: 30px;">
                            <h4 style="color: #fff; font-size: 16px; margin: 0 0 15px;">Precio</h4>
                            <?php the_widget('WC_Widget_Price_Filter'); ?>
                        </div>
                    <?php endif; ?>
                    
                <?php endif; ?>
                
            </aside>
            
            <!-- CONTENIDO PRINCIPAL -->
            <main class="shop-main-content">
                
                <?php if (have_posts()): ?>
                    
                    <!-- TOOLBAR -->
                    <div class="woocommerce-toolbar" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding: 20px; background: rgba(255,255,255,0.05); border-radius: 12px;">
                        
                        <div class="woocommerce-result-count" style="color: #ccc;">
                            <?php woocommerce_result_count(); ?>
                        </div>
                        
                        <div class="woocommerce-ordering">
                            <?php woocommerce_catalog_ordering(); ?>
                        </div>
                        
                    </div>
                    
                    <!-- GRID DE PRODUCTOS -->
                    <div class="products-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
                        
                        <?php while (have_posts()): the_post(); ?>
                            <?php wc_get_template_part('content', 'product'); ?>
                        <?php endwhile; ?>
                        
                    </div>
                    
                    <!-- PAGINACIÓN -->
                    <div style="margin-top: 60px;">
                        <?php woocommerce_pagination(); ?>
                    </div>
                    
                <?php else: ?>
                    
                    <!-- NO HAY PRODUCTOS -->
                    <div style="text-align: center; padding: 80px 20px; background: rgba(255,255,255,0.05); border-radius: 20px;">
                        <div style="font-size: 64px; margin-bottom: 20px;">🔍</div>
                        <h2 style="color: #fff; font-size: 28px; margin: 0 0 15px;">No se encontraron productos</h2>
                        <p style="color: #999; font-size: 16px; margin: 0 0 30px;">Intenta ajustar los filtros o busca algo diferente</p>
                        <a href="<?php echo home_url('/'); ?>" class="button" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 15px 40px; border-radius: 50px; text-decoration: none; font-weight: 600; transition: all 0.3s;">
                            Volver al Inicio
                        </a>
                    </div>
                    
                <?php endif; ?>
                
            </main>
            
        </div>
        
    </div>
    
</div>

<?php get_footer(); ?>
