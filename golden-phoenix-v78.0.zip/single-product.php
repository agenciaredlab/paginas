<?php
/**
 * Single Product Template
 * Plantilla para página individual de producto
 */

get_header();
?>

<?php while (have_posts()): the_post(); ?>

<div class="single-product-wrapper" style="background: #1a1a1a; min-height: 100vh; padding: 40px 0;">
    
    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 0 20px;">
        
        <!-- BREADCRUMBS -->
        <?php if (function_exists('woocommerce_breadcrumb')): ?>
            <div style="margin-bottom: 30px;">
                <?php woocommerce_breadcrumb(); ?>
            </div>
        <?php endif; ?>
        
        <!-- CONTENIDO DEL PRODUCTO -->
        <?php wc_get_template_part('content', 'single-product'); ?>
        
        <!-- PRODUCTOS RELACIONADOS -->
        <?php woocommerce_output_related_products(); ?>
        
    </div>
    
</div>

<?php endwhile; ?>

<?php get_footer(); ?>
