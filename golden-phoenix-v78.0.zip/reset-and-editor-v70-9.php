<?php
/**
 * Golden Phoenix V70.9 - RESET CUSTOMIZER + EDITOR MODERNO
 * Limpia BD del customizer y agrega soporte para editor de bloques WordPress
 */

if (!defined('ABSPATH')) exit;

// ========================================
// RESET CUSTOMIZER DATABASE (Solo primera vez)
// ========================================

add_action('after_switch_theme', 'gp_v70_9_reset_customizer');

function gp_v70_9_reset_customizer() {
    // Solo ejecutar si no se ha hecho antes
    if (get_option('gp_v70_9_customizer_reset')) {
        return;
    }
    
    // Lista de theme_mods problemáticos que sobrescriben diseño
    $mods_to_remove = array(
        'gp_primary_color',
        'gp_secondary_color',
        'gp_background_color',
        'gp_header_bg_color',
        'gp_footer_bg_color',
        'gp_button_color',
        'gp_link_color',
        'gp_font_headings',
        'gp_font_body',
    );
    
    foreach ($mods_to_remove as $mod) {
        remove_theme_mod($mod);
    }
    
    // Marcar como completado
    update_option('gp_v70_9_customizer_reset', true);
    
    // Log para debug
    error_log('Golden Phoenix V70.9: Customizer reset completado');
}

// ========================================
// SOPORTE EDITOR DE BLOQUES MODERNO (FSE)
// ========================================

// 1. Habilitar tema de bloques
add_theme_support('block-templates');
add_theme_support('block-template-parts');

// 2. Habilitar estilos de bloques
add_theme_support('wp-block-styles');
add_theme_support('responsive-embeds');
add_theme_support('align-wide');
add_theme_support('align-full');

// 3. Habilitar editor completo
add_theme_support('editor-styles');

// 4. Agregar estilos del editor
add_action('after_setup_theme', 'gp_v70_9_editor_setup');

function gp_v70_9_editor_setup() {
    // Cargar estilos en el editor
    add_editor_style('style-editor.css');
    
    // Paleta de colores para el editor
    add_theme_support('editor-color-palette', array(
        array(
            'name'  => 'Dorado Principal',
            'slug'  => 'gold-primary',
            'color' => '#D4AF37',
        ),
        array(
            'name'  => 'Negro Profundo',
            'slug'  => 'black-deep',
            'color' => '#0A0A0A',
        ),
        array(
            'name'  => 'Crema',
            'slug'  => 'cream',
            'color' => '#FAF9F6',
        ),
        array(
            'name'  => 'Blanco',
            'slug'  => 'white',
            'color' => '#FFFFFF',
        ),
        array(
            'name'  => 'Gris Oscuro',
            'slug'  => 'dark-gray',
            'color' => '#555555',
        ),
    ));
    
    // Tamaños de fuente personalizados
    add_theme_support('editor-font-sizes', array(
        array(
            'name' => 'Pequeño',
            'size' => 14,
            'slug' => 'small'
        ),
        array(
            'name' => 'Normal',
            'size' => 16,
            'slug' => 'normal'
        ),
        array(
            'name' => 'Mediano',
            'size' => 20,
            'slug' => 'medium'
        ),
        array(
            'name' => 'Grande',
            'size' => 28,
            'slug' => 'large'
        ),
        array(
            'name' => 'Enorme',
            'size' => 48,
            'slug' => 'huge'
        )
    ));
}

// 5. Deshabilitar colores y fuentes custom (opcional)
// add_theme_support('disable-custom-colors');
// add_theme_support('disable-custom-font-sizes');

// ========================================
// CREAR ESTILOS PARA EL EDITOR
// ========================================

add_action('admin_init', 'gp_v70_9_create_editor_styles');

function gp_v70_9_create_editor_styles() {
    $editor_css = get_template_directory() . '/style-editor.css';
    
    // Solo crear si no existe
    if (file_exists($editor_css)) {
        return;
    }
    
    $css_content = <<<CSS
/* Editor Styles para Golden Phoenix */

body {
    font-family: 'Montserrat', sans-serif;
    font-size: 16px;
    line-height: 1.7;
    color: #0A0A0A;
}

h1, h2, h3, h4, h5, h6 {
    font-family: 'Playfair Display', serif;
    font-weight: 400;
    color: #0A0A0A;
}

h1 {
    font-size: 48px;
    letter-spacing: 0.1em;
}

h2 {
    font-size: 36px;
}

h3 {
    font-size: 28px;
}

.has-gold-primary-color {
    color: #D4AF37;
}

.has-gold-primary-background-color {
    background-color: #D4AF37;
}

.has-black-deep-color {
    color: #0A0A0A;
}

.has-black-deep-background-color {
    background-color: #0A0A0A;
}

.has-cream-background-color {
    background-color: #FAF9F6;
}

/* Alineaciones */
.alignwide {
    max-width: 1400px;
}

.alignfull {
    max-width: 100%;
}
CSS;
    
    file_put_contents($editor_css, $css_content);
}

// ========================================
// ASEGURAR DISEÑO CORRECTO (Override forzado)
// ========================================

add_action('wp_head', 'gp_v70_9_force_design', 99999);

function gp_v70_9_force_design() {
    ?>
    <style id="gp-v70-9-force-design">
    /* V70.9 - FORZAR DISEÑO CORRECTO */
    
    /* IMPORTANTE: Sobrescribir cualquier cosa de BD */
    body,
    body.home,
    body.page,
    body.single,
    body.archive {
        background-color: #FAF9F6 !important;
    }
    
    /* Header siempre blanco */
    .site-header,
    header.site-header {
        background-color: #FFFFFF !important;
    }
    
    /* Footer siempre negro */
    .site-footer,
    footer.site-footer {
        background-color: #0A0A0A !important;
    }
    
    /* Testimonios siempre con fondo crema */
    .testimonials-section {
        background-color: #FAF9F6 !important;
    }
    
    .testimonial-card {
        background-color: #FFFFFF !important;
    }
    </style>
    <?php
}

// ========================================
// AGREGAR MENSAJE ADMIN
// ========================================

add_action('admin_notices', 'gp_v70_9_admin_notice');

function gp_v70_9_admin_notice() {
    // Solo mostrar una vez
    if (get_option('gp_v70_9_admin_notice_shown')) {
        return;
    }
    
    $screen = get_current_screen();
    if ($screen->id !== 'themes') {
        return;
    }
    
    ?>
    <div class="notice notice-success is-dismissible">
        <h3>✅ Golden Phoenix V70.9 Activado</h3>
        <p><strong>Cambios importantes:</strong></p>
        <ul style="list-style: disc; margin-left: 20px;">
            <li>✅ Customizer limpiado - El diseño ya NO debería cambiar</li>
            <li>✅ Editor de bloques moderno habilitado</li>
            <li>✅ Paleta de colores personalizada en el editor</li>
            <li>✅ Soporte completo para bloques de Gutenberg</li>
        </ul>
        <p>
            <strong>Nuevo:</strong> Ve a <a href="<?php echo admin_url('site-editor.php'); ?>">Editor del sitio</a> 
            para usar el editor de bloques moderno.
        </p>
        <p>
            <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_notice'}); return false;" class="button button-primary">Entendido</a>
        </p>
    </div>
    <?php
    
    update_option('gp_v70_9_admin_notice_shown', true);
}

// AJAX para cerrar notificación
add_action('wp_ajax_gp_dismiss_notice', function() {
    update_option('gp_v70_9_admin_notice_shown', true);
    wp_die();
});
