<?php
/**
 * Golden Phoenix V72 - PRICE CALCULATOR
 * Calculadora de precios para joyas personalizadas
 */

if (!defined('ABSPATH')) exit;

// Widget calculadora en productos
add_action('woocommerce_before_add_to_cart_button', 'gp_price_calculator_widget');

function gp_price_calculator_widget() {
    global $product;
    
    // Solo mostrar en ciertos productos
    $show_calculator = get_post_meta($product->get_id(), '_show_price_calculator', true);
    
    if ($show_calculator !== 'yes') {
        return;
    }
    ?>
    
    <div class="gp-price-calculator" style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <h4 style="margin-top: 0;">💰 Calculadora de Precio</h4>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Quilates:</label>
            <input type="range" id="calc-carats" min="0.25" max="5" step="0.25" value="1" 
                   style="width: 100%;">
            <span id="calc-carats-value">1.00 ct</span>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">Pureza:</label>
            <select id="calc-purity" style="width: 100%; padding: 8px;">
                <option value="1">14K</option>
                <option value="1.3">18K</option>
                <option value="2">Platino</option>
            </select>
        </div>
        
        <div style="border-top: 2px solid #ddd; padding-top: 15px; margin-top: 15px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <strong>Precio Estimado:</strong>
                <span id="calc-total" style="font-size: 24px; color: #D4AF37; font-weight: 700;">$0</span>
            </div>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var basePrice = <?php echo $product->get_price(); ?>;
        
        function updatePrice() {
            var carats = parseFloat($('#calc-carats').val());
            var purity = parseFloat($('#calc-purity').val());
            var total = basePrice * carats * purity;
            
            $('#calc-carats-value').text(carats.toFixed(2) + ' ct');
            $('#calc-total').text('$' + Math.round(total).toLocaleString('es-CO'));
        }
        
        $('#calc-carats, #calc-purity').on('change input', updatePrice);
        updatePrice();
    });
    </script>
    
    <?php
}

// Meta box para habilitar calculadora
add_action('add_meta_boxes', 'gp_price_calculator_meta_box');

function gp_price_calculator_meta_box() {
    add_meta_box(
        'gp_price_calculator',
        'Calculadora de Precio',
        'gp_price_calculator_meta_box_callback',
        'product',
        'side'
    );
}

function gp_price_calculator_meta_box_callback($post) {
    $value = get_post_meta($post->ID, '_show_price_calculator', true);
    ?>
    <label>
        <input type="checkbox" name="_show_price_calculator" value="yes" <?php checked($value, 'yes'); ?>>
        Mostrar calculadora de precio
    </label>
    <?php
}

add_action('save_post_product', 'gp_save_price_calculator_meta');

function gp_save_price_calculator_meta($post_id) {
    if (isset($_POST['_show_price_calculator'])) {
        update_post_meta($post_id, '_show_price_calculator', 'yes');
    } else {
        delete_post_meta($post_id, '_show_price_calculator');
    }
}
