<?php
/**
 * GOLDEN PHOENIX V67 - TRACKING ULTRA-COMPLETO
 * 100+ eventos por usuario para análisis profundo
 */

if (!defined('ABSPATH')) exit;

class GP_Advanced_User_Tracking {
    
    private $enabled = false;
    private $webhook_url = '';
    
    public function __construct() {
        $this->enabled = get_option('gp_n8n_tracking_enabled', false);
        $this->webhook_url = get_option('gp_n8n_webhook_url', '');
        
        if (!$this->enabled || empty($this->webhook_url)) return;
        
        add_action('wp_footer', array($this, 'inject_advanced_tracking'));
        
        // NUEVOS EVENTOS DE COMPORTAMIENTO
        add_action('wp', array($this, 'track_page_session'));
        add_filter('woocommerce_add_to_cart_validation', array($this, 'track_add_to_cart_attempt'), 10, 3);
        
        // AJAX HANDLERS
        add_action('wp_ajax_gp_track_advanced_event', array($this, 'handle_advanced_event'));
        add_action('wp_ajax_nopriv_gp_track_advanced_event', array($this, 'handle_advanced_event'));
    }
    
    public function inject_advanced_tracking() {
        ?>
        <script>
        // GOLDEN PHOENIX ADVANCED TRACKING V67
        const gpAdvancedTracker = {
            endpoint: '<?php echo admin_url('admin-ajax.php'); ?>',
            sessionData: {
                sessionId: '<?php echo session_id() ?: uniqid('gp_'); ?>',
                userId: '<?php echo get_current_user_id(); ?>',
                userEmail: '<?php echo wp_get_current_user()->user_email; ?>',
                startTime: Date.now(),
                pageViews: 0,
                interactions: 0,
                scrollDepth: 0,
                mouseMovements: 0,
                clickCount: 0,
                focusTime: 0,
                idleTime: 0
            },
            
            // Enviar evento
            track: function(eventName, eventData = {}) {
                fetch(this.endpoint, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams({
                        action: 'gp_track_advanced_event',
                        event: eventName,
                        data: JSON.stringify(eventData),
                        session: JSON.stringify(this.sessionData),
                        meta: JSON.stringify({
                            page_url: window.location.href,
                            page_title: document.title,
                            referrer: document.referrer,
                            timestamp: new Date().toISOString(),
                            user_agent: navigator.userAgent,
                            screen: {
                                width: window.screen.width,
                                height: window.screen.height,
                                orientation: window.screen.orientation?.type,
                                color_depth: window.screen.colorDepth
                            },
                            viewport: {
                                width: window.innerWidth,
                                height: window.innerHeight
                            },
                            device: {
                                mobile: /Mobile|Android|iPhone/i.test(navigator.userAgent),
                                tablet: /Tablet|iPad/i.test(navigator.userAgent),
                                desktop: !/Mobile|Android|iPhone|Tablet|iPad/i.test(navigator.userAgent),
                                os: this.getOS(),
                                browser: this.getBrowser()
                            },
                            connection: navigator.connection ? {
                                type: navigator.connection.effectiveType,
                                downlink: navigator.connection.downlink,
                                rtt: navigator.connection.rtt,
                                saveData: navigator.connection.saveData
                            } : null,
                            language: navigator.language,
                            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                            battery: null, // Se obtiene async
                            memory: navigator.deviceMemory,
                            cores: navigator.hardwareConcurrency
                        })
                    })
                }).catch(err => console.error('Tracking error:', err));
            },
            
            getOS: function() {
                const ua = navigator.userAgent;
                if (ua.includes('Win')) return 'Windows';
                if (ua.includes('Mac')) return 'MacOS';
                if (ua.includes('Linux')) return 'Linux';
                if (ua.includes('Android')) return 'Android';
                if (ua.includes('iOS')) return 'iOS';
                return 'Unknown';
            },
            
            getBrowser: function() {
                const ua = navigator.userAgent;
                if (ua.includes('Chrome')) return 'Chrome';
                if (ua.includes('Safari')) return 'Safari';
                if (ua.includes('Firefox')) return 'Firefox';
                if (ua.includes('Edge')) return 'Edge';
                return 'Unknown';
            },
            
            init: function() {
                // ========================================
                // EVENTOS DE ENGAGEMENT
                // ========================================
                
                // 1. RAGE CLICKS (clic frustrado múltiple)
                let clickTimes = [];
                document.addEventListener('click', (e) => {
                    const now = Date.now();
                    clickTimes.push(now);
                    clickTimes = clickTimes.filter(t => now - t < 1000);
                    
                    if (clickTimes.length >= 5) {
                        this.track('rage_click', {
                            element: e.target.tagName,
                            element_text: e.target.textContent?.substring(0, 50),
                            element_id: e.target.id,
                            click_count: clickTimes.length
                        });
                        clickTimes = [];
                    }
                });
                
                // 2. DEAD CLICKS (clic sin resultado)
                document.addEventListener('click', (e) => {
                    const element = e.target;
                    const initialHTML = document.body.innerHTML.length;
                    
                    setTimeout(() => {
                        const finalHTML = document.body.innerHTML.length;
                        if (Math.abs(finalHTML - initialHTML) < 10) {
                            this.track('dead_click', {
                                element: element.tagName,
                                element_text: element.textContent?.substring(0, 50)
                            });
                        }
                    }, 500);
                });
                
                // 3. MOUSE TRACKING (heatmap data)
                let mousePositions = [];
                document.addEventListener('mousemove', (e) => {
                    mousePositions.push({x: e.clientX, y: e.clientY, t: Date.now()});
                    
                    if (mousePositions.length >= 100) {
                        this.track('mouse_heatmap', {
                            positions: mousePositions.slice(-100)
                        });
                        mousePositions = [];
                    }
                });
                
                // 4. HOVER INTENT (interés en elemento)
                let hoverTimer;
                document.addEventListener('mouseover', (e) => {
                    const element = e.target.closest('a, button, .product, [data-product-id]');
                    if (element) {
                        hoverTimer = setTimeout(() => {
                            this.track('hover_intent', {
                                element_type: element.tagName,
                                element_text: element.textContent?.substring(0, 50),
                                element_id: element.id,
                                hover_duration: 2000
                            });
                        }, 2000);
                    }
                });
                
                document.addEventListener('mouseout', () => {
                    clearTimeout(hoverTimer);
                });
                
                // 5. COPY TEXT (interés en contenido)
                document.addEventListener('copy', (e) => {
                    const selectedText = window.getSelection().toString();
                    this.track('text_copy', {
                        text: selectedText.substring(0, 200),
                        length: selectedText.length
                    });
                });
                
                // 6. TEXT SELECTION (sin copiar)
                document.addEventListener('mouseup', () => {
                    const selectedText = window.getSelection().toString();
                    if (selectedText.length > 10) {
                        this.track('text_selection', {
                            text: selectedText.substring(0, 200),
                            length: selectedText.length
                        });
                    }
                });
                
                // 7. PRINT PAGE
                window.addEventListener('beforeprint', () => {
                    this.track('page_print', {
                        page_type: document.body.className
                    });
                });
                
                // 8. SCREENSHOT DETECTION (tecla PrintScreen)
                document.addEventListener('keyup', (e) => {
                    if (e.key === 'PrintScreen') {
                        this.track('screenshot_attempt', {});
                    }
                });
                
                // ========================================
                // EVENTOS DE NAVEGACIÓN
                // ========================================
                
                // 9. BACK BUTTON
                window.addEventListener('popstate', () => {
                    this.track('back_button', {
                        from: window.location.href
                    });
                });
                
                // 10. TAB VISIBILITY (usuario cambia de tab)
                document.addEventListener('visibilitychange', () => {
                    this.track('tab_visibility', {
                        state: document.hidden ? 'hidden' : 'visible'
                    });
                });
                
                // 11. WINDOW BLUR/FOCUS
                window.addEventListener('blur', () => {
                    this.track('window_blur', {});
                });
                
                window.addEventListener('focus', () => {
                    this.track('window_focus', {});
                });
                
                // 12. ORIENTATION CHANGE (mobile)
                window.addEventListener('orientationchange', () => {
                    this.track('orientation_change', {
                        orientation: screen.orientation?.type
                    });
                });
                
                // 13. ONLINE/OFFLINE
                window.addEventListener('online', () => {
                    this.track('connection_online', {});
                });
                
                window.addEventListener('offline', () => {
                    this.track('connection_offline', {});
                });
                
                // ========================================
                // EVENTOS DE FORMULARIOS AVANZADOS
                // ========================================
                
                // 14. FORM FIELD FOCUS TIME
                const formFieldTimes = {};
                document.addEventListener('focus', (e) => {
                    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                        formFieldTimes[e.target.name] = Date.now();
                    }
                }, true);
                
                document.addEventListener('blur', (e) => {
                    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                        const fieldName = e.target.name;
                        if (formFieldTimes[fieldName]) {
                            const duration = Date.now() - formFieldTimes[fieldName];
                            this.track('form_field_time', {
                                field_name: fieldName,
                                duration_ms: duration,
                                value_length: e.target.value.length
                            });
                        }
                    }
                }, true);
                
                // 15. FORM FIELD ERRORS
                document.addEventListener('invalid', (e) => {
                    this.track('form_field_error', {
                        field_name: e.target.name,
                        field_type: e.target.type,
                        validation_message: e.target.validationMessage
                    });
                }, true);
                
                // 16. FORM ABANDONMENT
                let formStarted = false;
                document.addEventListener('input', (e) => {
                    const form = e.target.closest('form');
                    if (form && !formStarted) {
                        formStarted = true;
                        
                        window.addEventListener('beforeunload', () => {
                            if (formStarted && !form.submitted) {
                                this.track('form_abandoned', {
                                    form_id: form.id,
                                    form_action: form.action
                                });
                            }
                        });
                    }
                });
                
                // 17. AUTOCOMPLETE USAGE
                document.addEventListener('change', (e) => {
                    if (e.target.value && e.target.autocomplete) {
                        this.track('autocomplete_used', {
                            field_name: e.target.name,
                            field_type: e.target.type
                        });
                    }
                });
                
                // ========================================
                // EVENTOS DE E-COMMERCE AVANZADOS
                // ========================================
                
                // 18. PRODUCT VIEW DURATION
                if (document.body.classList.contains('single-product')) {
                    const productId = document.querySelector('[data-product-id]')?.dataset.productId;
                    const startTime = Date.now();
                    
                    window.addEventListener('beforeunload', () => {
                        this.track('product_view_duration', {
                            product_id: productId,
                            duration_seconds: (Date.now() - startTime) / 1000
                        });
                    });
                }
                
                // 19. PRODUCT IMAGE ZOOM
                document.addEventListener('click', (e) => {
                    const zoomTrigger = e.target.closest('.woocommerce-product-gallery__trigger, [data-zoom]');
                    if (zoomTrigger) {
                        this.track('product_image_zoom', {
                            product_id: document.querySelector('[data-product-id]')?.dataset.productId
                        });
                    }
                });
                
                // 20. VARIATION SELECTION
                document.addEventListener('change', (e) => {
                    const variation = e.target.closest('.variations select');
                    if (variation) {
                        this.track('product_variation_select', {
                            attribute: variation.name,
                            value: variation.value
                        });
                    }
                });
                
                // 21. QUANTITY ADJUSTMENT
                let qtyChanges = 0;
                document.addEventListener('change', (e) => {
                    if (e.target.classList.contains('qty') || e.target.name === 'quantity') {
                        qtyChanges++;
                        this.track('quantity_adjusted', {
                            new_quantity: e.target.value,
                            adjustment_count: qtyChanges
                        });
                    }
                });
                
                // 22. PRICE VISIBILITY (scroll para ver precio)
                const priceElement = document.querySelector('.price, .woocommerce-Price-amount');
                if (priceElement) {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                this.track('price_viewed', {
                                    price: priceElement.textContent
                                });
                                observer.disconnect();
                            }
                        });
                    });
                    observer.observe(priceElement);
                }
                
                // 23. REVIEWS INTERACTION
                document.addEventListener('click', (e) => {
                    const reviewTab = e.target.closest('#tab-title-reviews, .reviews_tab');
                    if (reviewTab) {
                        this.track('reviews_tab_opened', {});
                    }
                    
                    const reviewSort = e.target.closest('.woocommerce-review-sort');
                    if (reviewSort) {
                        this.track('reviews_sorted', {
                            sort_by: reviewSort.value
                        });
                    }
                });
                
                // 24. RELATED PRODUCTS CLICK
                document.addEventListener('click', (e) => {
                    const relatedProduct = e.target.closest('.related.products .product, .upsells .product');
                    if (relatedProduct) {
                        this.track('related_product_click', {
                            product_id: relatedProduct.dataset.productId,
                            section: relatedProduct.closest('.related') ? 'related' : 'upsell'
                        });
                    }
                });
                
                // 25. SHIPPING CALCULATOR
                document.addEventListener('submit', (e) => {
                    const shippingForm = e.target.closest('.shipping-calculator-form');
                    if (shippingForm) {
                        this.track('shipping_calculated', {
                            country: shippingForm.querySelector('[name="calc_shipping_country"]')?.value
                        });
                    }
                });
                
                // ========================================
                // EVENTOS DE INTENCIÓN DE COMPRA
                // ========================================
                
                // 26. CHECKOUT HESITATION (tiempo en checkout sin avanzar)
                if (document.body.classList.contains('woocommerce-checkout')) {
                    setTimeout(() => {
                        this.track('checkout_hesitation', {
                            time_seconds: 30
                        });
                    }, 30000);
                }
                
                // 27. PAYMENT METHOD CHANGE
                document.addEventListener('change', (e) => {
                    const paymentMethod = e.target.closest('input[name="payment_method"]');
                    if (paymentMethod) {
                        this.track('payment_method_changed', {
                            method: paymentMethod.value
                        });
                    }
                });
                
                // 28. BILLING SAME AS SHIPPING
                document.addEventListener('change', (e) => {
                    const sameAddress = e.target.id === 'ship-to-different-address-checkbox';
                    if (sameAddress) {
                        this.track('billing_address_toggle', {
                            different_address: e.target.checked
                        });
                    }
                });
                
                // 29. TERMS ACCEPTANCE
                document.addEventListener('change', (e) => {
                    const termsCheckbox = e.target.id === 'terms';
                    if (termsCheckbox) {
                        this.track('terms_accepted', {
                            accepted: e.target.checked
                        });
                    }
                });
                
                // 30. CHECKOUT ERROR (failed validation)
                const checkoutForm = document.querySelector('form.checkout');
                if (checkoutForm) {
                    checkoutForm.addEventListener('checkout_error', () => {
                        this.track('checkout_error', {});
                    });
                }
                
                // ========================================
                // EVENTOS DE BÚSQUEDA AVANZADOS
                // ========================================
                
                // 31. SEARCH REFINEMENT (búsqueda sin resultados)
                const searchResults = document.querySelector('.search-results');
                if (searchResults && searchResults.querySelectorAll('.product').length === 0) {
                    this.track('search_no_results', {
                        query: new URLSearchParams(window.location.search).get('s')
                    });
                }
                
                // 32. SEARCH AUTOCOMPLETE SELECTION
                document.addEventListener('click', (e) => {
                    const autocompleteItem = e.target.closest('.autocomplete-suggestion, .search-suggestion');
                    if (autocompleteItem) {
                        this.track('search_autocomplete_selected', {
                            suggestion: autocompleteItem.textContent
                        });
                    }
                });
                
                // 33. FILTER COMBINATION
                const activeFilters = document.querySelectorAll('.woocommerce-widget-layered-nav .chosen');
                if (activeFilters.length > 1) {
                    this.track('multi_filter_applied', {
                        filter_count: activeFilters.length,
                        filters: Array.from(activeFilters).map(f => f.textContent)
                    });
                }
                
                // ========================================
                // EVENTOS DE DISPOSITIVO/PERFORMANCE
                // ========================================
                
                // 34. PAGE LOAD TIME
                window.addEventListener('load', () => {
                    const loadTime = performance.timing.loadEventEnd - performance.timing.navigationStart;
                    this.track('page_load_time', {
                        load_time_ms: loadTime,
                        dns_time: performance.timing.domainLookupEnd - performance.timing.domainLookupStart,
                        connect_time: performance.timing.connectEnd - performance.timing.connectStart,
                        ttfb: performance.timing.responseStart - performance.timing.navigationStart
                    });
                });
                
                // 35. SLOW CONNECTION DETECTED
                if (navigator.connection && navigator.connection.effectiveType === '2g') {
                    this.track('slow_connection_detected', {
                        type: navigator.connection.effectiveType,
                        downlink: navigator.connection.downlink
                    });
                }
                
                // 36. LOW BATTERY
                if (navigator.getBattery) {
                    navigator.getBattery().then(battery => {
                        if (battery.level < 0.2) {
                            this.track('low_battery', {
                                level: battery.level
                            });
                        }
                    });
                }
                
                // 37. MEMORY WARNING
                if (performance.memory && performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit > 0.9) {
                    this.track('high_memory_usage', {
                        usage_percent: (performance.memory.usedJSHeapSize / performance.memory.jsHeapSizeLimit) * 100
                    });
                }
                
                // ========================================
                // EVENTOS DE SOCIAL PROOF
                // ========================================
                
                // 38. TESTIMONIAL VIEW
                const testimonials = document.querySelectorAll('.testimonial, .review');
                testimonials.forEach((testimonial, index) => {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                this.track('testimonial_viewed', {
                                    testimonial_index: index,
                                    testimonial_text: testimonial.textContent.substring(0, 100)
                                });
                                observer.disconnect();
                            }
                        });
                    });
                    observer.observe(testimonial);
                });
                
                // 39. TRUST BADGE VIEW
                const trustBadges = document.querySelectorAll('.trust-badge, .guarantee, .secure-checkout');
                trustBadges.forEach(badge => {
                    const observer = new IntersectionObserver((entries) => {
                        entries.forEach(entry => {
                            if (entry.isIntersecting) {
                                this.track('trust_badge_viewed', {
                                    badge_type: badge.className
                                });
                                observer.disconnect();
                            }
                        });
                    });
                    observer.observe(badge);
                });
                
                // 40. FAQ INTERACTION
                document.addEventListener('click', (e) => {
                    const faqItem = e.target.closest('.faq-item, .accordion-item');
                    if (faqItem) {
                        this.track('faq_opened', {
                            question: faqItem.querySelector('.question, .accordion-title')?.textContent.substring(0, 100)
                        });
                    }
                });
                
                // ========================================
                // EVENTOS DE REENGAGEMENT
                // ========================================
                
                // 41. RETURN VISIT
                const lastVisit = localStorage.getItem('gp_last_visit');
                if (lastVisit) {
                    const daysSince = (Date.now() - parseInt(lastVisit)) / (1000 * 60 * 60 * 24);
                    this.track('return_visit', {
                        days_since_last_visit: Math.floor(daysSince),
                        is_frequent_visitor: daysSince < 7
                    });
                }
                localStorage.setItem('gp_last_visit', Date.now());
                
                // 42. SESSION DEPTH (páginas por sesión)
                let sessionPages = sessionStorage.getItem('gp_session_pages') || 0;
                sessionPages++;
                sessionStorage.setItem('gp_session_pages', sessionPages);
                
                if ([5, 10, 20, 50].includes(parseInt(sessionPages))) {
                    this.track('session_depth_milestone', {
                        pages_viewed: sessionPages
                    });
                }
                
                // 43. ENGAGED SESSION (15+ mins)
                setTimeout(() => {
                    this.track('engaged_session', {
                        duration_minutes: 15
                    });
                }, 15 * 60 * 1000);
                
                // ========================================
                // EVENTOS DE CONVERSIÓN
                // ========================================
                
                // 44. ADD TO CART INTENT (mouse sobre botón)
                const addToCartButtons = document.querySelectorAll('.add_to_cart_button');
                addToCartButtons.forEach(button => {
                    button.addEventListener('mouseenter', () => {
                        this.track('add_to_cart_intent', {
                            product_id: button.dataset.productId
                        });
                    });
                });
                
                // 45. CHECKOUT STARTED (primer campo llenado)
                let checkoutStarted = false;
                if (document.body.classList.contains('woocommerce-checkout')) {
                    document.addEventListener('input', (e) => {
                        if (!checkoutStarted && e.target.closest('.woocommerce-checkout')) {
                            checkoutStarted = true;
                            this.track('checkout_first_interaction', {});
                        }
                    });
                }
                
                // ========================================
                // EVENTOS PERSONALIZADOS POR PÁGINA
                // ========================================
                
                // 46. HOMEPAGE SPECIFIC
                if (document.body.classList.contains('home')) {
                    // Hero CTA visibility
                    const heroCTA = document.querySelector('.hero .cta, .hero button');
                    if (heroCTA) {
                        const observer = new IntersectionObserver((entries) => {
                            entries.forEach(entry => {
                                if (entry.isIntersecting) {
                                    this.track('hero_cta_viewed', {});
                                    observer.disconnect();
                                }
                            });
                        });
                        observer.observe(heroCTA);
                    }
                }
                
                // 47. CATEGORY PAGE SPECIFIC
                if (document.body.classList.contains('archive')) {
                    // Products in viewport
                    const products = document.querySelectorAll('.product');
                    this.track('category_products_loaded', {
                        product_count: products.length
                    });
                }
                
                // 48. BLOG POST SPECIFIC
                if (document.body.classList.contains('single-post')) {
                    // Reading progress
                    const article = document.querySelector('article');
                    if (article) {
                        window.addEventListener('scroll', () => {
                            const articleTop = article.offsetTop;
                            const articleHeight = article.offsetHeight;
                            const scrolled = window.scrollY - articleTop;
                            const progress = Math.min(100, Math.max(0, (scrolled / articleHeight) * 100));
                            
                            if ([25, 50, 75, 100].includes(Math.floor(progress))) {
                                this.track('article_read_progress', {
                                    progress_percent: Math.floor(progress)
                                });
                            }
                        });
                    }
                }
            }
        };
        
        // Inicializar
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => gpAdvancedTracker.init());
        } else {
            gpAdvancedTracker.init();
        }
        </script>
        <?php
    }
    
    public function handle_advanced_event() {
        $event = sanitize_text_field($_POST['event']);
        $data = json_decode(stripslashes($_POST['data']), true);
        $session = json_decode(stripslashes($_POST['session']), true);
        $meta = json_decode(stripslashes($_POST['meta']), true);
        
        $this->send_to_n8n($event, $data, $session, $meta);
        
        wp_send_json_success();
    }
    
    private function send_to_n8n($event, $data, $session, $meta) {
        if (empty($this->webhook_url)) return;
        
        $payload = array(
            'event' => $event,
            'data' => $data,
            'session' => $session,
            'meta' => $meta,
            'source' => 'golden_phoenix_advanced_tracking'
        );
        
        wp_remote_post($this->webhook_url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($payload),
            'timeout' => 5,
            'blocking' => false
        ));
    }
}

new GP_Advanced_User_Tracking();
