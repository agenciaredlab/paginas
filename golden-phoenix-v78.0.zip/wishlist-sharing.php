<?php
/**
 * V76 - WISHLIST SHARING
 * Compartir lista de deseos por link/email/WhatsApp
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_after_add_to_wishlist', 'gp_wishlist_share_buttons');

function gp_wishlist_share_buttons() {
    if (!is_user_logged_in()) return;
    
    $user_id = get_current_user_id();
    $share_url = home_url('/wishlist-shared/?user=' . $user_id);
    ?>
    
    <div class="gp-wishlist-share" style="margin: 30px 0; padding: 20px; background: #f9f9f9; border-radius: 8px;">
        <h4 style="margin-top: 0;">💝 Compartir mi Lista de Deseos</h4>
        <p style="color: #666;">Comparte tu lista para que otros sepan qué regalarte</p>
        
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button onclick="gpCopyWishlist('<?php echo $share_url; ?>')" class="button" style="background: #667eea; color: white;">
                📋 Copiar Link
            </button>
            
            <a href="https://wa.me/?text=Mira mi lista de deseos: <?php echo urlencode($share_url); ?>" target="_blank" class="button" style="background: #25D366; color: white;">
                💬 WhatsApp
            </a>
            
            <a href="mailto:?subject=Mi Lista de Deseos&body=Mira mi lista: <?php echo $share_url; ?>" class="button" style="background: #EA4335; color: white;">
                ✉️ Email
            </a>
            
            <button onclick="gpShareFacebook('<?php echo $share_url; ?>')" class="button" style="background: #1877F2; color: white;">
                📘 Facebook
            </button>
        </div>
        
        <input type="text" id="wishlist-url" value="<?php echo $share_url; ?>" readonly style="width: 100%; padding: 10px; margin-top: 15px; border: 1px solid #ddd; border-radius: 4px;">
    </div>
    
    <script>
    function gpCopyWishlist(url) {
        navigator.clipboard.writeText(url);
        alert('✅ Link copiado!');
    }
    
    function gpShareFacebook(url) {
        window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url), '_blank');
    }
    </script>
    
    <?php
}

add_action('init', function() {
    add_rewrite_rule('^wishlist-shared/?', 'index.php?wishlist_shared=1', 'top');
});

add_filter('query_vars', function($vars) {
    $vars[] = 'wishlist_shared';
    return $vars;
});

add_action('template_redirect', function() {
    if (get_query_var('wishlist_shared')) {
        $user_id = intval($_GET['user']);
        echo '<h1>Lista de Deseos Compartida</h1>';
        echo do_shortcode('[yith_wcwl_wishlist user_id="' . $user_id . '"]');
        exit;
    }
});
