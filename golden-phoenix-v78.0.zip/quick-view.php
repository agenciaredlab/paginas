<?php
/**
 * Golden Phoenix - Quick View (Vista Rápida)
 * Ver producto en modal sin salir de la página
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// BOTÓN QUICK VIEW EN PRODUCTOS
// ============================================

add_action('woocommerce_after_shop_loop_item', 'gp_quick_view_button', 15);

function gp_quick_view_button() {
    global $product;
    ?>
    <button class="gp-quick-view-btn" 
            data-product-id="<?php echo $product->get_id(); ?>"
            style="width: 100%; margin-top: 10px; background: white; border: 2px solid #0A0A0A; color: #0A0A0A; padding: 12px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: all 0.3s;"
            onmouseover="this.style.background='#0A0A0A'; this.style.color='white';"
            onmouseout="this.style.background='white'; this.style.color='#0A0A0A';">
        <i class="fas fa-eye"></i> Vista Rápida
    </button>
    <?php
}

// ============================================
// MODAL QUICK VIEW
// ============================================

add_action('wp_footer', 'gp_quick_view_modal');

function gp_quick_view_modal() {
    ?>
    <div id="gp-quick-view-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 999999; overflow-y: auto; padding: 20px;">
        <div style="max-width: 1000px; margin: 50px auto; background: white; border-radius: 12px; position: relative;">
            
            <!-- Botón cerrar -->
            <button id="close-quick-view" style="position: absolute; top: 20px; right: 20px; width: 40px; height: 40px; border-radius: 50%; background: #f0f0f0; border: none; cursor: pointer; font-size: 24px; z-index: 10; display: flex; align-items: center; justify-content: center;"
                    onmouseover="this.style.background='#dc3545'; this.style.color='white';"
                    onmouseout="this.style.background='#f0f0f0'; this.style.color='#000';">
                ×
            </button>
            
            <!-- Contenido del producto -->
            <div id="quick-view-content" style="padding: 40px;">
                <!-- Cargado dinámicamente -->
            </div>
            
            <!-- Loader -->
            <div id="quick-view-loader" style="text-align: center; padding: 80px;">
                <div style="display: inline-block; width: 60px; height: 60px; border: 6px solid #f3f3f3; border-top-color: #D4AF37; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                <p style="margin-top: 20px; color: #666;">Cargando producto...</p>
            </div>
        </div>
    </div>
    
    <style>
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .quick-view-gallery {
        display: grid;
        grid-template-columns: 100px 1fr;
        gap: 20px;
    }
    
    .quick-view-thumbs {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .quick-view-thumbs img {
        width: 100%;
        height: 100px;
        object-fit: cover;
        border-radius: 4px;
        cursor: pointer;
        border: 2px solid transparent;
        transition: border 0.3s;
    }
    
    .quick-view-thumbs img:hover,
    .quick-view-thumbs img.active {
        border-color: #D4AF37;
    }
    
    .quick-view-main-image {
        width: 100%;
        height: 500px;
        object-fit: cover;
        border-radius: 8px;
    }
    
    @media (max-width: 768px) {
        #gp-quick-view-modal > div {
            margin: 20px auto;
        }
        
        #quick-view-content {
            padding: 20px !important;
        }
        
        .quick-view-layout {
            grid-template-columns: 1fr !important;
        }
        
        .quick-view-gallery {
            grid-template-columns: 1fr !important;
        }
        
        .quick-view-thumbs {
            flex-direction: row !important;
            overflow-x: auto;
        }
        
        .quick-view-thumbs img {
            min-width: 80px;
            height: 80px;
        }
        
        .quick-view-main-image {
            height: 300px !important;
        }
    }
    </style>
    
    <script>
    // Event listeners para botones quick view
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.gp-quick-view-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.dataset.productId;
                openQuickView(productId);
            });
        });
        
        // Cerrar modal
        document.getElementById('close-quick-view').addEventListener('click', closeQuickView);
        
        // Cerrar al hacer click fuera
        document.getElementById('gp-quick-view-modal').addEventListener('click', function(e) {
            if (e.target === this) closeQuickView();
        });
    });
    
    function openQuickView(productId) {
        const modal = document.getElementById('gp-quick-view-modal');
        const content = document.getElementById('quick-view-content');
        const loader = document.getElementById('quick-view-loader');
        
        modal.style.display = 'block';
        content.style.display = 'none';
        loader.style.display = 'block';
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=quick_view_product&product_id=${productId}`
        })
        .then(r => r.json())
        .then(data => {
            loader.style.display = 'none';
            content.style.display = 'block';
            
            if (data.success) {
                content.innerHTML = data.data.html;
                
                // Reinicializar scripts de WooCommerce si existen
                if (typeof jQuery !== 'undefined') {
                    jQuery(document.body).trigger('init_variations');
                }
            } else {
                content.innerHTML = '<p style="text-align: center; padding: 40px;">Error al cargar el producto</p>';
            }
        });
    }
    
    function closeQuickView() {
        document.getElementById('gp-quick-view-modal').style.display = 'none';
    }
    
    // Cambiar imagen principal
    function changeQuickViewImage(src) {
        document.getElementById('quick-view-main-img').src = src;
        
        // Actualizar clase active en thumbnails
        document.querySelectorAll('.quick-view-thumbs img').forEach(img => {
            img.classList.remove('active');
            if (img.src === src) img.classList.add('active');
        });
    }
    </script>
    <?php
}

// ============================================
// AJAX QUICK VIEW
// ============================================

add_action('wp_ajax_quick_view_product', 'gp_ajax_quick_view');
add_action('wp_ajax_nopriv_quick_view_product', 'gp_ajax_quick_view');

function gp_ajax_quick_view() {
    $product_id = intval($_POST['product_id']);
    $product = wc_get_product($product_id);
    
    if (!$product) {
        wp_send_json_error();
    }
    
    ob_start();
    ?>
    <div class="quick-view-layout" style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
        
        <!-- Galería de imágenes -->
        <div class="quick-view-gallery">
            <div class="quick-view-thumbs">
                <?php
                $image_id = $product->get_image_id();
                $gallery_ids = $product->get_gallery_image_ids();
                
                // Imagen principal como thumbnail
                if ($image_id) {
                    echo '<img src="' . wp_get_attachment_url($image_id) . '" onclick="changeQuickViewImage(this.src)" class="active">';
                }
                
                // Galería como thumbnails
                foreach ($gallery_ids as $gallery_id) {
                    echo '<img src="' . wp_get_attachment_url($gallery_id) . '" onclick="changeQuickViewImage(this.src)">';
                }
                ?>
            </div>
            
            <div>
                <img id="quick-view-main-img" 
                     src="<?php echo wp_get_attachment_url($image_id); ?>" 
                     alt="<?php echo $product->get_name(); ?>"
                     class="quick-view-main-image">
            </div>
        </div>
        
        <!-- Información del producto -->
        <div class="quick-view-info">
            <!-- Categorías -->
            <div style="margin-bottom: 10px;">
                <?php
                $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
                foreach ($categories as $cat) {
                    echo '<span style="display: inline-block; background: #f0f0f0; padding: 5px 12px; border-radius: 3px; font-size: 12px; margin-right: 5px; color: #666;">' . $cat . '</span>';
                }
                ?>
            </div>
            
            <!-- Título -->
            <h2 style="font-size: 32px; font-family: 'Playfair Display', serif; margin-bottom: 15px; color: #0A0A0A;">
                <?php echo $product->get_name(); ?>
            </h2>
            
            <!-- Rating -->
            <div style="margin-bottom: 20px;">
                <?php
                $rating = $product->get_average_rating();
                $review_count = $product->get_review_count();
                ?>
                <div style="color: #D4AF37; font-size: 18px; display: inline-block;">
                    <?php for ($i = 1; $i <= 5; $i++) echo $i <= $rating ? '★' : '☆'; ?>
                </div>
                <span style="color: #666; margin-left: 10px;">(<?php echo $review_count; ?> reseñas)</span>
            </div>
            
            <!-- Precio -->
            <div style="margin-bottom: 25px;">
                <div style="font-size: 36px; font-weight: 700; color: #D4AF37;">
                    <?php echo $product->get_price_html(); ?>
                </div>
                <?php if ($product->is_on_sale()) : ?>
                    <span style="background: #dc3545; color: white; padding: 5px 12px; border-radius: 3px; font-size: 12px; font-weight: 600; margin-top: 10px; display: inline-block;">
                        ¡EN OFERTA!
                    </span>
                <?php endif; ?>
            </div>
            
            <!-- Descripción corta -->
            <div style="margin-bottom: 25px; color: #666; line-height: 1.8;">
                <?php echo $product->get_short_description(); ?>
            </div>
            
            <!-- Stock -->
            <div style="margin-bottom: 25px;">
                <?php if ($product->is_in_stock()) : ?>
                    <span style="color: #28a745; font-weight: 600;">
                        <i class="fas fa-check-circle"></i> En Stock
                    </span>
                    <?php if ($product->get_stock_quantity()) : ?>
                        <span style="color: #666; margin-left: 10px;">
                            (<?php echo $product->get_stock_quantity(); ?> disponibles)
                        </span>
                    <?php endif; ?>
                <?php else : ?>
                    <span style="color: #dc3545; font-weight: 600;">
                        <i class="fas fa-times-circle"></i> Agotado
                    </span>
                <?php endif; ?>
            </div>
            
            <!-- Atributos/Variaciones -->
            <?php if ($product->is_type('variable')) : ?>
                <div style="margin-bottom: 25px;">
                    <?php
                    $attributes = $product->get_variation_attributes();
                    foreach ($attributes as $attr_name => $options) :
                    ?>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">
                                <?php echo wc_attribute_label($attr_name); ?>
                            </label>
                            <select style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px;">
                                <option value="">Selecciona una opción</option>
                                <?php foreach ($options as $option) : ?>
                                    <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Cantidad -->
            <div style="margin-bottom: 25px;">
                <label style="display: block; font-weight: 600; margin-bottom: 10px; color: #0A0A0A;">
                    Cantidad
                </label>
                <input type="number" 
                       value="1" 
                       min="1" 
                       max="<?php echo $product->get_stock_quantity() ?: 999; ?>"
                       style="width: 120px; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; text-align: center;">
            </div>
            
            <!-- Botones de acción -->
            <div style="display: grid; gap: 15px;">
                <?php if ($product->is_in_stock()) : ?>
                    <a href="<?php echo $product->add_to_cart_url(); ?>" 
                       class="quick-view-add-cart"
                       style="display: block; text-align: center; background: #D4AF37; color: white; padding: 18px; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 18px; transition: background 0.3s;"
                       onmouseover="this.style.background='#0A0A0A'"
                       onmouseout="this.style.background='#D4AF37'">
                        <i class="fas fa-shopping-cart"></i> Agregar al Carrito
                    </a>
                <?php endif; ?>
                
                <a href="<?php echo get_permalink($product_id); ?>" 
                   style="display: block; text-align: center; background: transparent; color: #0A0A0A; padding: 15px; border: 2px solid #0A0A0A; border-radius: 4px; text-decoration: none; font-weight: 600; transition: all 0.3s;"
                   onmouseover="this.style.background='#0A0A0A'; this.style.color='white';"
                   onmouseout="this.style.background='transparent'; this.style.color='#0A0A0A';">
                    <i class="fas fa-external-link-alt"></i> Ver Detalles Completos
                </a>
            </div>
            
            <!-- Features adicionales -->
            <div style="margin-top: 30px; padding-top: 30px; border-top: 1px solid #eee;">
                <div style="display: grid; gap: 12px;">
                    <div style="display: flex; align-items: center; gap: 12px; color: #666;">
                        <i class="fas fa-shipping-fast" style="color: #D4AF37; font-size: 20px;"></i>
                        <span>Envío gratis en compras superiores a $500,000</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 12px; color: #666;">
                        <i class="fas fa-shield-alt" style="color: #D4AF37; font-size: 20px;"></i>
                        <span>Garantía de autenticidad certificada</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 12px; color: #666;">
                        <i class="fas fa-undo" style="color: #D4AF37; font-size: 20px;"></i>
                        <span>Devolución gratis dentro de 30 días</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    
    $html = ob_get_clean();
    
    wp_send_json_success(array('html' => $html));
}
