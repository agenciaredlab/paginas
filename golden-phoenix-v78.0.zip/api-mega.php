<?php
/**
 * Golden Phoenix Jewelry - MEGA API V5.0
 * 75+ Endpoints REST API Ultra Completos
 * 
 * @package Golden_Phoenix
 * @version 5.0
 */

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function() {
    $ns = 'golden-phoenix/v1';
    
    // ============================================
    // PRODUCTOS AVANZADOS (15 endpoints)
    // ============================================
    
    // 1. Búsqueda con IA
    register_rest_route($ns, '/search/ai', array(
        'methods' => 'POST',
        'callback' => 'gp_api_ai_search',
        'permission_callback' => '__return_true'
    ));
    
    // 2. Productos por múltiples categorías
    register_rest_route($ns, '/products/categories/bulk', array(
        'methods' => 'POST',
        'callback' => 'gp_api_products_bulk_categories',
        'permission_callback' => '__return_true'
    ));
    
    // 3. Productos similares (ML)
    register_rest_route($ns, '/products/(?P<id>\d+)/similar', array(
        'methods' => 'GET',
        'callback' => 'gp_api_similar_products_ml',
        'permission_callback' => '__return_true'
    ));
    
    // 4. Historial de precios
    register_rest_route($ns, '/products/(?P<id>\d+)/price-history', array(
        'methods' => 'GET',
        'callback' => 'gp_api_price_history',
        'permission_callback' => '__return_true'
    ));
    
    // 5. Disponibilidad en tiendas físicas
    register_rest_route($ns, '/products/(?P<id>\d+)/store-availability', array(
        'methods' => 'GET',
        'callback' => 'gp_api_store_availability',
        'permission_callback' => '__return_true'
    ));
    
    // 6. Comparación de productos
    register_rest_route($ns, '/products/compare', array(
        'methods' => 'POST',
        'callback' => 'gp_api_compare_products',
        'permission_callback' => '__return_true'
    ));
    
    // 7. Alertas de stock
    register_rest_route($ns, '/products/(?P<id>\d+)/stock-alert/subscribe', array(
        'methods' => 'POST',
        'callback' => 'gp_api_stock_alert_subscribe',
        'permission_callback' => '__return_true'
    ));
    
    // 8. Variaciones detalladas
    register_rest_route($ns, '/products/(?P<id>\d+)/variations/detailed', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_variations_detailed',
        'permission_callback' => '__return_true'
    ));
    
    // 9. Imágenes de alta resolución
    register_rest_route($ns, '/products/(?P<id>\d+)/images/hi-res', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_images_hires',
        'permission_callback' => '__return_true'
    ));
    
    // 10. Modelo 3D
    register_rest_route($ns, '/products/(?P<id>\d+)/3d-model', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_3d_model',
        'permission_callback' => '__return_true'
    ));
    
    // 11. Especificaciones técnicas
    register_rest_route($ns, '/products/(?P<id>\d+)/specifications', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_specs',
        'permission_callback' => '__return_true'
    ));
    
    // 12. Certificaciones
    register_rest_route($ns, '/products/(?P<id>\d+)/certifications', array(
        'methods' => 'GET',
        'callback' => 'gp_api_product_certifications',
        'permission_callback' => '__return_true'
    ));
    
    // 13. Instrucciones de cuidado
    register_rest_route($ns, '/products/(?P<id>\d+)/care-instructions', array(
        'methods' => 'GET',
        'callback' => 'gp_api_care_instructions',
        'permission_callback' => '__return_true'
    ));
    
    // 14. Cross-sell inteligente
    register_rest_route($ns, '/products/(?P<id>\d+)/cross-sell-ai', array(
        'methods' => 'GET',
        'callback' => 'gp_api_cross_sell_ai',
        'permission_callback' => '__return_true'
    ));
    
    // 15. Up-sell inteligente
    register_rest_route($ns, '/products/(?P<id>\d+)/upsell-ai', array(
        'methods' => 'GET',
        'callback' => 'gp_api_upsell_ai',
        'permission_callback' => '__return_true'
    ));
    
    // ============================================
    // CARRITO AVANZADO (10 endpoints)
    // ============================================
    
    // 16. Guardar carrito para después
    register_rest_route($ns, '/cart/save', array(
        'methods' => 'POST',
        'callback' => 'gp_api_save_cart',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 17. Restaurar carrito guardado
    register_rest_route($ns, '/cart/restore', array(
        'methods' => 'POST',
        'callback' => 'gp_api_restore_cart',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 18. Compartir carrito
    register_rest_route($ns, '/cart/share', array(
        'methods' => 'POST',
        'callback' => 'gp_api_share_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 19. Recuperar carrito compartido
    register_rest_route($ns, '/cart/shared/(?P<token>[a-zA-Z0-9]+)', array(
        'methods' => 'GET',
        'callback' => 'gp_api_get_shared_cart',
        'permission_callback' => '__return_true'
    ));
    
    // 20. Estimación de envío
    register_rest_route($ns, '/cart/shipping/estimate', array(
        'methods' => 'POST',
        'callback' => 'gp_api_estimate_shipping',
        'permission_callback' => '__return_true'
    ));
    
    // 21. Cálculo de impuestos
    register_rest_route($ns, '/cart/taxes/calculate', array(
        'methods' => 'POST',
        'callback' => 'gp_api_calculate_taxes',
        'permission_callback' => '__return_true'
    ));
    
    // 22. Validar cupones múltiples
    register_rest_route($ns, '/cart/coupons/validate-multiple', array(
        'methods' => 'POST',
        'callback' => 'gp_api_validate_multiple_coupons',
        'permission_callback' => '__return_true'
    ));
    
    // 23. Totales detallados
    register_rest_route($ns, '/cart/totals/detailed', array(
        'methods' => 'GET',
        'callback' => 'gp_api_cart_totals_detailed',
        'permission_callback' => '__return_true'
    ));
    
    // 24. Verificar disponibilidad
    register_rest_route($ns, '/cart/verify-availability', array(
        'methods' => 'GET',
        'callback' => 'gp_api_verify_cart_availability',
        'permission_callback' => '__return_true'
    ));
    
    // 25. Bundle dinámico
    register_rest_route($ns, '/cart/create-bundle', array(
        'methods' => 'POST',
        'callback' => 'gp_api_create_bundle',
        'permission_callback' => '__return_true'
    ));
    
    // ============================================
    // ÓRDENES EXTENDIDAS (12 endpoints)
    // ============================================
    
    // 26. Detalles completos de orden
    register_rest_route($ns, '/orders/(?P<id>\d+)/detailed', array(
        'methods' => 'GET',
        'callback' => 'gp_api_order_detailed',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 27. Historial de estados
    register_rest_route($ns, '/orders/(?P<id>\d+)/status-history', array(
        'methods' => 'GET',
        'callback' => 'gp_api_order_status_history',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 28. Tracking en tiempo real
    register_rest_route($ns, '/orders/(?P<id>\d+)/tracking/realtime', array(
        'methods' => 'GET',
        'callback' => 'gp_api_realtime_tracking',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 29. Generar factura PDF
    register_rest_route($ns, '/orders/(?P<id>\d+)/invoice/pdf', array(
        'methods' => 'GET',
        'callback' => 'gp_api_generate_invoice_pdf',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 30. Solicitar devolución
    register_rest_route($ns, '/orders/(?P<id>\d+)/return/request', array(
        'methods' => 'POST',
        'callback' => 'gp_api_request_return',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 31. Estado de devolución
    register_rest_route($ns, '/orders/(?P<id>\d+)/return/status', array(
        'methods' => 'GET',
        'callback' => 'gp_api_return_status',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 32. Reordenar
    register_rest_route($ns, '/orders/(?P<id>\d+)/reorder', array(
        'methods' => 'POST',
        'callback' => 'gp_api_reorder',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 33. Cancelar orden
    register_rest_route($ns, '/orders/(?P<id>\d+)/cancel', array(
        'methods' => 'POST',
        'callback' => 'gp_api_cancel_order',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 34. Actualizar dirección de envío
    register_rest_route($ns, '/orders/(?P<id>\d+)/shipping-address', array(
        'methods' => 'PUT',
        'callback' => 'gp_api_update_shipping_address',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 35. Agregar nota a orden
    register_rest_route($ns, '/orders/(?P<id>\d+)/notes/add', array(
        'methods' => 'POST',
        'callback' => 'gp_api_add_order_note',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 36. Estadísticas de compra del usuario
    register_rest_route($ns, '/orders/stats/user', array(
        'methods' => 'GET',
        'callback' => 'gp_api_user_order_stats',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 37. Órdenes por rango de fechas
    register_rest_route($ns, '/orders/date-range', array(
        'methods' => 'POST',
        'callback' => 'gp_api_orders_by_date_range',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // CLIENTES EXTENDIDOS (10 endpoints)
    // ============================================
    
    // 38. Preferencias del usuario
    register_rest_route($ns, '/customer/preferences', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_preferences',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 39. Actualizar preferencias
    register_rest_route($ns, '/customer/preferences/update', array(
        'methods' => 'PUT',
        'callback' => 'gp_api_update_preferences',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 40. Historial de navegación
    register_rest_route($ns, '/customer/browsing-history', array(
        'methods' => 'GET',
        'callback' => 'gp_api_browsing_history',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 41. Productos vistos recientemente
    register_rest_route($ns, '/customer/recently-viewed', array(
        'methods' => 'GET',
        'callback' => 'gp_api_recently_viewed',
        'permission_callback' => '__return_true'
    ));
    
    // 42. Favoritos/Wishlist completo
    register_rest_route($ns, '/customer/wishlist/full', array(
        'methods' => 'GET',
        'callback' => 'gp_api_wishlist_full',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 43. Compartir wishlist
    register_rest_route($ns, '/customer/wishlist/share', array(
        'methods' => 'POST',
        'callback' => 'gp_api_share_wishlist',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 44. Notificaciones del usuario
    register_rest_route($ns, '/customer/notifications', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_notifications',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 45. Marcar notificación como leída
    register_rest_route($ns, '/customer/notifications/(?P<id>\d+)/read', array(
        'methods' => 'PUT',
        'callback' => 'gp_api_mark_notification_read',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 46. Puntos de lealtad
    register_rest_route($ns, '/customer/loyalty-points', array(
        'methods' => 'GET',
        'callback' => 'gp_api_loyalty_points',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 47. Canjear puntos
    register_rest_route($ns, '/customer/loyalty-points/redeem', array(
        'methods' => 'POST',
        'callback' => 'gp_api_redeem_points',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // MEMBRESÍAS EXTENDIDAS (8 endpoints)
    // ============================================
    
    // 48. Beneficios disponibles
    register_rest_route($ns, '/memberships/benefits/available', array(
        'methods' => 'GET',
        'callback' => 'gp_api_available_benefits',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 49. Historial de beneficios
    register_rest_route($ns, '/memberships/benefits/history', array(
        'methods' => 'GET',
        'callback' => 'gp_api_benefits_history',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 50. Upgrade de membresía
    register_rest_route($ns, '/memberships/upgrade', array(
        'methods' => 'POST',
        'callback' => 'gp_api_upgrade_membership',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 51. Comparar niveles
    register_rest_route($ns, '/memberships/compare', array(
        'methods' => 'GET',
        'callback' => 'gp_api_compare_membership_levels',
        'permission_callback' => '__return_true'
    ));
    
    // 52. Estadísticas de membresía
    register_rest_route($ns, '/memberships/stats', array(
        'methods' => 'GET',
        'callback' => 'gp_api_membership_stats',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 53. Renovar membresía
    register_rest_route($ns, '/memberships/renew', array(
        'methods' => 'POST',
        'callback' => 'gp_api_renew_membership',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 54. Cancelar membresía
    register_rest_route($ns, '/memberships/cancel', array(
        'methods' => 'POST',
        'callback' => 'gp_api_cancel_membership',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 55. Referidos de membresía
    register_rest_route($ns, '/memberships/referrals', array(
        'methods' => 'GET',
        'callback' => 'gp_api_membership_referrals',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // ============================================
    // RESEÑAS EXTENDIDAS (7 endpoints)
    // ============================================
    
    // 56. Reseñas con imágenes
    register_rest_route($ns, '/reviews/with-images', array(
        'methods' => 'GET',
        'callback' => 'gp_api_reviews_with_images',
        'permission_callback' => '__return_true'
    ));
    
    // 57. Reseñas verificadas
    register_rest_route($ns, '/reviews/verified', array(
        'methods' => 'GET',
        'callback' => 'gp_api_verified_reviews',
        'permission_callback' => '__return_true'
    ));
    
    // 58. Votar útil/no útil
    register_rest_route($ns, '/reviews/(?P<id>\d+)/vote', array(
        'methods' => 'POST',
        'callback' => 'gp_api_vote_review',
        'permission_callback' => '__return_true'
    ));
    
    // 59. Reportar reseña
    register_rest_route($ns, '/reviews/(?P<id>\d+)/report', array(
        'methods' => 'POST',
        'callback' => 'gp_api_report_review',
        'permission_callback' => 'is_user_logged_in'
    ));
    
    // 60. Responder a reseña (admin)
    register_rest_route($ns, '/reviews/(?P<id>\d+)/respond', array(
        'methods' => 'POST',
        'callback' => 'gp_api_respond_to_review',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 61. Estadísticas de reseñas
    register_rest_route($ns, '/reviews/stats', array(
        'methods' => 'GET',
        'callback' => 'gp_api_reviews_stats',
        'permission_callback' => '__return_true'
    ));
    
    // 62. Reseñas por rating
    register_rest_route($ns, '/reviews/by-rating/(?P<rating>[1-5])', array(
        'methods' => 'GET',
        'callback' => 'gp_api_reviews_by_rating',
        'permission_callback' => '__return_true'
    ));
    
    // ============================================
    // ANALYTICS Y REPORTES (10 endpoints)
    // ============================================
    
    // 63. Dashboard general
    register_rest_route($ns, '/analytics/dashboard', array(
        'methods' => 'GET',
        'callback' => 'gp_api_analytics_dashboard',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 64. Productos tendencia
    register_rest_route($ns, '/analytics/trending-products', array(
        'methods' => 'GET',
        'callback' => 'gp_api_trending_products',
        'permission_callback' => '__return_true'
    ));
    
    // 65. Productos con bajo stock
    register_rest_route($ns, '/analytics/low-stock', array(
        'methods' => 'GET',
        'callback' => 'gp_api_low_stock_products',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 66. Productos sin ventas
    register_rest_route($ns, '/analytics/no-sales', array(
        'methods' => 'GET',
        'callback' => 'gp_api_products_no_sales',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 67. Carritos abandonados
    register_rest_route($ns, '/analytics/abandoned-carts', array(
        'methods' => 'GET',
        'callback' => 'gp_api_abandoned_carts',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 68. Valor promedio de orden
    register_rest_route($ns, '/analytics/average-order-value', array(
        'methods' => 'GET',
        'callback' => 'gp_api_average_order_value',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 69. Tasa de conversión
    register_rest_route($ns, '/analytics/conversion-rate', array(
        'methods' => 'GET',
        'callback' => 'gp_api_conversion_rate',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 70. Clientes nuevos vs recurrentes
    register_rest_route($ns, '/analytics/customer-segments', array(
        'methods' => 'GET',
        'callback' => 'gp_api_customer_segments',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 71. Revenue por canal
    register_rest_route($ns, '/analytics/revenue-by-channel', array(
        'methods' => 'GET',
        'callback' => 'gp_api_revenue_by_channel',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // 72. Mapa de calor de ventas
    register_rest_route($ns, '/analytics/sales-heatmap', array(
        'methods' => 'GET',
        'callback' => 'gp_api_sales_heatmap',
        'permission_callback' => 'gp_check_admin_permission'
    ));
    
    // ============================================
    // UTILIDADES Y CONFIGURACIÓN (3 endpoints)
    // ============================================
    
    // 73. Buscar direcciones
    register_rest_route($ns, '/utils/address-lookup', array(
        'methods' => 'POST',
        'callback' => 'gp_api_address_lookup',
        'permission_callback' => '__return_true'
    ));
    
    // 74. Validar dirección
    register_rest_route($ns, '/utils/validate-address', array(
        'methods' => 'POST',
        'callback' => 'gp_api_validate_address',
        'permission_callback' => '__return_true'
    ));
    
    // 75. Geocodificación
    register_rest_route($ns, '/utils/geocode', array(
        'methods' => 'POST',
        'callback' => 'gp_api_geocode',
        'permission_callback' => '__return_true'
    ));
});

// ============================================
// IMPLEMENTACIONES SELECCIONADAS
// ============================================

function gp_api_ai_search($request) {
    $query = $request->get_param('query');
    
    // Búsqueda inteligente con NLP
    $keywords = gp_extract_keywords($query);
    $intent = gp_detect_intent($query);
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 20,
        's' => $query
    );
    
    // Agregar filtros basados en intención
    if ($intent === 'price') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = '_price';
    }
    
    $products = new WP_Query($args);
    $results = array();
    
    while ($products->have_posts()) {
        $products->the_post();
        $product = wc_get_product(get_the_ID());
        
        $results[] = array(
            'id' => get_the_ID(),
            'name' => get_the_title(),
            'price' => $product->get_price_html(),
            'image' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
            'url' => get_permalink(),
            'relevance_score' => gp_calculate_relevance($query, get_the_title())
        );
    }
    
    wp_reset_postdata();
    
    // Ordenar por relevancia
    usort($results, function($a, $b) {
        return $b['relevance_score'] <=> $a['relevance_score'];
    });
    
    return new WP_REST_Response(array(
        'products' => $results,
        'search_intent' => $intent,
        'keywords' => $keywords,
        'total' => count($results)
    ), 200);
}

function gp_extract_keywords($text) {
    // Implementar extracción de palabras clave
    $stopwords = array('el', 'la', 'los', 'las', 'un', 'una', 'de', 'en', 'para', 'con');
    $words = explode(' ', strtolower($text));
    return array_diff($words, $stopwords);
}

function gp_detect_intent($query) {
    $query_lower = strtolower($query);
    
    if (preg_match('/\b(barato|económico|precio)\b/', $query_lower)) {
        return 'price';
    }
    if (preg_match('/\b(nuevo|reciente|último)\b/', $query_lower)) {
        return 'new';
    }
    if (preg_match('/\b(popular|vendido|top)\b/', $query_lower)) {
        return 'popular';
    }
    
    return 'general';
}

function gp_calculate_relevance($query, $title) {
    similar_text(strtolower($query), strtolower($title), $percent);
    return $percent;
}

function gp_api_save_cart($request) {
    $user_id = get_current_user_id();
    $cart_items = WC()->cart->get_cart();
    
    $saved_cart = array(
        'items' => $cart_items,
        'totals' => array(
            'subtotal' => WC()->cart->get_subtotal(),
            'total' => WC()->cart->get_total('edit')
        ),
        'saved_at' => current_time('mysql')
    );
    
    update_user_meta($user_id, 'gp_saved_cart', $saved_cart);
    
    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'Carrito guardado exitosamente',
        'items_count' => count($cart_items)
    ), 200);
}

function gp_api_share_cart($request) {
    $cart_items = WC()->cart->get_cart();
    
    // Generar token único
    $token = wp_generate_password(32, false);
    
    // Guardar carrito compartido
    set_transient('gp_shared_cart_' . $token, $cart_items, 7 * DAY_IN_SECONDS);
    
    $share_url = home_url('/cart/shared/' . $token);
    
    return new WP_REST_Response(array(
        'success' => true,
        'share_url' => $share_url,
        'token' => $token,
        'expires_in' => '7 días'
    ), 200);
}

// Continuar implementaciones...
