<?php
/**
 * V74 - BUNDLE DISCOUNTS
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_cart_calculate_fees', 'gp_apply_bundle_discount');

function gp_apply_bundle_discount($cart) {
    $item_count = $cart->get_cart_contents_count();
    $discount = 0;
    
    if ($item_count >= 2 && $item_count < 3) {
        $discount = $cart->get_subtotal() * 0.05; // 5%
        $cart->add_fee('Descuento 2 piezas (5%)', -$discount);
    } elseif ($item_count >= 3 && $item_count < 5) {
        $discount = $cart->get_subtotal() * 0.10; // 10%
        $cart->add_fee('Descuento 3+ piezas (10%)', -$discount);
    } elseif ($item_count >= 5) {
        $discount = $cart->get_subtotal() * 0.15; // 15%
        $cart->add_fee('Descuento 5+ piezas (15%)', -$discount);
    }
}

add_action('woocommerce_before_cart', function() {
    ?>
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; text-align: center;">
        <h3 style="margin: 0 0 10px 0;">🎁 Descuentos por Cantidad</h3>
        <p style="margin: 0;">2 piezas: 5% OFF | 3-4 piezas: 10% OFF | 5+ piezas: 15% OFF</p>
    </div>
    <?php
});
