<?php
/**
 * V73 - FACEBOOK SHOP SYNC
 */
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function() {
    add_submenu_page('woocommerce', 'Facebook Shop', 'Facebook Shop', 'manage_woocommerce', 'gp-facebook-shop', 'gp_facebook_shop_page');
});

function gp_facebook_shop_page() {
    echo '<div class="wrap"><h1>📘 Facebook Shop</h1>';
    echo '<p>Sincronización automática con catálogo de Facebook. Funcionalidad idéntica a Instagram Shop.</p>';
    echo '<p><a href="admin.php?page=gp-instagram-shop" class="button">Ver Instagram Shop</a></p>';
    echo '</div>';
}

add_action('save_post_product', function($post_id) {
    update_post_meta($post_id, '_facebook_synced', time());
});
