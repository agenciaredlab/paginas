<?php
/**
 * V77 - PRODUCT VIDEOS
 * Videos demostración productos
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_product_options_general_product_data', function() {
    woocommerce_wp_text_input(array(
        'id' => '_product_video_url',
        'label' => 'Video URL (YouTube/Vimeo)',
        'placeholder' => 'https://youtube.com/watch?v=...',
        'desc_tip' => true,
        'description' => 'URL del video de demostración'
    ));
});

add_action('woocommerce_process_product_meta', function($post_id) {
    update_post_meta($post_id, '_product_video_url', sanitize_text_field($_POST['_product_video_url']));
});

add_action('woocommerce_before_add_to_cart_form', function() {
    global $product;
    
    $video_url = get_post_meta($product->get_id(), '_product_video_url', true);
    if (!$video_url) return;
    
    // Convertir URL a embed
    if (strpos($video_url, 'youtube.com') !== false) {
        preg_match('/[?&]v=([^&]+)/', $video_url, $matches);
        $video_id = $matches[1] ?? '';
        $embed_url = 'https://www.youtube.com/embed/' . $video_id;
    } elseif (strpos($video_url, 'vimeo.com') !== false) {
        $video_id = substr($video_url, strrpos($video_url, '/') + 1);
        $embed_url = 'https://player.vimeo.com/video/' . $video_id;
    } else {
        return;
    }
    ?>
    
    <div style="margin: 30px 0;">
        <h3>🎥 Video Demostración</h3>
        <div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; border-radius: 12px;">
            <iframe src="<?php echo esc_url($embed_url); ?>" 
                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;" 
                    allowfullscreen>
            </iframe>
        </div>
    </div>
    
    <?php
});
