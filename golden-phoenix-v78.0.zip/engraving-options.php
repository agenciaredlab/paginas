<?php
/**
 * V73 - ENGRAVING OPTIONS (standalone)
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_before_add_to_cart_button', function() {
    global $product;
    $has_engraving = get_post_meta($product->get_id(), '_has_engraving', true);
    if ($has_engraving !== 'yes') return;
    ?>
    <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <h4>✍️ Grabado Personalizado (+$50,000)</h4>
        <label>
            <input type="checkbox" name="add_engraving" value="yes" onchange="document.getElementById('engraving-text-field').style.display=this.checked?'block':'none'">
            Agregar grabado personalizado
        </label>
        <div id="engraving-text-field" style="display:none; margin-top: 15px;">
            <input type="text" name="engraving_text" maxlength="20" placeholder="Texto del grabado (máx 20 caracteres)" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
        </div>
    </div>
    <?php
});

add_filter('woocommerce_add_cart_item_data', function($cart_item_data, $product_id) {
    if (isset($_POST['add_engraving']) && $_POST['add_engraving'] === 'yes') {
        $cart_item_data['engraving'] = sanitize_text_field($_POST['engraving_text']);
        $cart_item_data['engraving_price'] = 50000;
    }
    return $cart_item_data;
}, 10, 2);

add_filter('woocommerce_get_item_data', function($item_data, $cart_item) {
    if (isset($cart_item['engraving'])) {
        $item_data[] = array('name' => 'Grabado', 'value' => $cart_item['engraving']);
    }
    return $item_data;
}, 10, 2);

add_action('woocommerce_before_calculate_totals', function($cart) {
    foreach ($cart->get_cart() as $cart_item) {
        if (isset($cart_item['engraving_price'])) {
            $cart_item['data']->set_price($cart_item['data']->get_price() + $cart_item['engraving_price']);
        }
    }
});

add_action('add_meta_boxes', function() {
    add_meta_box('gp_engraving', 'Opciones Grabado', function($post) {
        $value = get_post_meta($post->ID, '_has_engraving', true);
        echo '<label><input type="checkbox" name="_has_engraving" value="yes" ' . checked($value, 'yes', false) . '> Permite grabado personalizado</label>';
    }, 'product', 'side');
});

add_action('save_post_product', function($post_id) {
    if (isset($_POST['_has_engraving'])) {
        update_post_meta($post_id, '_has_engraving', 'yes');
    } else {
        delete_post_meta($post_id, '_has_engraving');
    }
});
