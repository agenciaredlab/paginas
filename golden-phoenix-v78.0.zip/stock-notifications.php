<?php
/**
 * Golden Phoenix - Stock Notifications
 * Avisar cuando productos agotados vuelvan a estar disponibles
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// FORMULARIO EN PRODUCTOS AGOTADOS
// ============================================

add_action('woocommerce_single_product_summary', 'gp_stock_notification_form', 35);

function gp_stock_notification_form() {
    global $product;
    
    if ($product->is_in_stock()) {
        return;
    }
    
    ?>
    <div class="gp-stock-notification" style="margin: 30px 0; padding: 25px; background: #fff3cd; border-left: 4px solid #D4AF37; border-radius: 4px;">
        <h3 style="font-size: 18px; margin-bottom: 15px; color: #0A0A0A;">
            <i class="fas fa-bell"></i> ¿Te interesa esta joya?
        </h3>
        <p style="color: #666; margin-bottom: 20px;">
            Déjanos tu email y te avisaremos cuando vuelva a estar disponible
        </p>
        
        <form id="stock-notification-form" style="display: flex; gap: 10px; flex-wrap: wrap;">
            <input type="hidden" name="product_id" value="<?php echo $product->get_id(); ?>">
            <input type="hidden" name="action" value="subscribe_stock_notification">
            
            <input type="email" 
                   name="email" 
                   placeholder="tu@email.com" 
                   required
                   style="flex: 1; min-width: 200px; padding: 15px; border: 2px solid #D4AF37; border-radius: 4px; font-size: 16px;">
            
            <button type="submit" 
                    style="background: #D4AF37; color: white; border: none; padding: 15px 30px; border-radius: 4px; cursor: pointer; font-weight: 600; transition: background 0.3s;"
                    onmouseover="this.style.background='#0A0A0A'"
                    onmouseout="this.style.background='#D4AF37'">
                <i class="fas fa-bell"></i> Avisarme
            </button>
        </form>
        
        <div id="stock-notification-response" style="margin-top: 15px;"></div>
    </div>
    
    <script>
    document.getElementById('stock-notification-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const form = this;
        const btn = form.querySelector('button[type="submit"]');
        const response = document.getElementById('stock-notification-response');
        const originalText = btn.innerHTML;
        
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
        btn.disabled = true;
        
        const formData = new FormData(form);
        
        fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: formData
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                response.innerHTML = '<div style="padding: 12px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 4px; color: #155724;"><i class="fas fa-check-circle"></i> ' + data.data.message + '</div>';
                form.querySelector('input[type="email"]').value = '';
            } else {
                response.innerHTML = '<div style="padding: 12px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 4px; color: #721c24;"><i class="fas fa-exclamation-circle"></i> ' + data.data.message + '</div>';
            }
            
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
    });
    </script>
    <?php
}

// ============================================
// SUSCRIBIRSE A NOTIFICACIONES
// ============================================

add_action('wp_ajax_subscribe_stock_notification', 'gp_subscribe_stock_notification');
add_action('wp_ajax_nopriv_subscribe_stock_notification', 'gp_subscribe_stock_notification');

function gp_subscribe_stock_notification() {
    $product_id = intval($_POST['product_id']);
    $email = sanitize_email($_POST['email']);
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Email inválido'));
    }
    
    // Obtener suscriptores actuales
    $subscribers = get_post_meta($product_id, '_stock_notification_subscribers', true);
    $subscribers = is_array($subscribers) ? $subscribers : array();
    
    // Verificar si ya está suscrito
    if (in_array($email, $subscribers)) {
        wp_send_json_success(array('message' => 'Ya estás suscrito a las notificaciones de este producto'));
    }
    
    // Agregar suscriptor
    $subscribers[] = $email;
    update_post_meta($product_id, '_stock_notification_subscribers', $subscribers);
    
    // Log de suscripción
    $log = get_option('gp_stock_notifications_log', array());
    $log[] = array(
        'product_id' => $product_id,
        'email' => $email,
        'date' => current_time('mysql'),
        'status' => 'subscribed'
    );
    update_option('gp_stock_notifications_log', $log);
    
    wp_send_json_success(array('message' => '¡Perfecto! Te avisaremos cuando este producto esté disponible'));
}

// ============================================
// ENVIAR NOTIFICACIONES CUANDO HAY STOCK
// ============================================

add_action('woocommerce_product_set_stock_status', 'gp_send_stock_notifications', 10, 3);

function gp_send_stock_notifications($product_id, $status, $product) {
    // Solo enviar si el producto vuelve a estar en stock
    if ($status !== 'instock') {
        return;
    }
    
    $subscribers = get_post_meta($product_id, '_stock_notification_subscribers', true);
    
    if (empty($subscribers) || !is_array($subscribers)) {
        return;
    }
    
    $product_obj = wc_get_product($product_id);
    
    foreach ($subscribers as $email) {
        // Enviar email
        $subject = sprintf('¡%s está de vuelta en stock!', $product_obj->get_name());
        
        $message = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #0A0A0A; color: white; padding: 30px; text-align: center; }
                .content { background: white; padding: 30px; }
                .product-image { width: 100%; max-width: 400px; height: auto; margin: 20px 0; }
                .button { display: inline-block; background: #D4AF37; color: white; padding: 15px 40px; text-decoration: none; border-radius: 4px; font-weight: 600; margin: 20px 0; }
                .footer { background: #f9f9f9; padding: 20px; text-align: center; color: #666; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1 style="margin: 0; font-family: Playfair Display, serif;">Golden Phoenix Jewelry</h1>
                </div>
                
                <div class="content">
                    <h2 style="color: #D4AF37; margin-top: 0;">¡Buenas noticias!</h2>
                    
                    <p>El producto que te interesaba <strong>' . $product_obj->get_name() . '</strong> está de vuelta en stock.</p>
                    
                    <div style="text-align: center;">
                        <img src="' . wp_get_attachment_url($product_obj->get_image_id()) . '" alt="' . $product_obj->get_name() . '" class="product-image">
                    </div>
                    
                    <p style="font-size: 24px; color: #D4AF37; font-weight: 700; text-align: center;">
                        ' . $product_obj->get_price_html() . '
                    </p>
                    
                    <p>' . $product_obj->get_short_description() . '</p>
                    
                    <div style="text-align: center;">
                        <a href="' . get_permalink($product_id) . '" class="button">
                            Ver Producto Ahora
                        </a>
                    </div>
                    
                    <p style="color: #dc3545; font-weight: 600;">⚠️ Unidades limitadas - ¡No te lo pierdas!</p>
                </div>
                
                <div class="footer">
                    <p>Recibiste este email porque solicitaste ser notificado cuando este producto estuviera disponible.</p>
                    <p>&copy; ' . date('Y') . ' Golden Phoenix Jewelry. Todos los derechos reservados.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        wp_mail($email, $subject, $message, $headers);
        
        // Log de envío
        $log = get_option('gp_stock_notifications_log', array());
        $log[] = array(
            'product_id' => $product_id,
            'email' => $email,
            'date' => current_time('mysql'),
            'status' => 'sent'
        );
        update_option('gp_stock_notifications_log', $log);
    }
    
    // Limpiar suscriptores después de enviar
    delete_post_meta($product_id, '_stock_notification_subscribers');
}

// ============================================
// PÁGINA DE ADMINISTRACIÓN
// ============================================

add_action('admin_menu', 'gp_stock_notifications_admin_menu');

function gp_stock_notifications_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Notificaciones de Stock',
        'Notificaciones Stock',
        'manage_woocommerce',
        'stock-notifications',
        'gp_stock_notifications_admin_page'
    );
}

function gp_stock_notifications_admin_page() {
    $log = get_option('gp_stock_notifications_log', array());
    $log = array_reverse($log); // Más recientes primero
    
    // Estadísticas
    $total_subscriptions = count(array_filter($log, function($item) {
        return $item['status'] === 'subscribed';
    }));
    
    $total_sent = count(array_filter($log, function($item) {
        return $item['status'] === 'sent';
    }));
    
    ?>
    <div class="wrap">
        <h1>📧 Notificaciones de Stock</h1>
        
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 30px 0;">
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Total Suscripciones</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #D4AF37;"><?php echo $total_subscriptions; ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Notificaciones Enviadas</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #28a745;"><?php echo $total_sent; ?></p>
            </div>
            
            <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #666;">Tasa de Conversión</h3>
                <p style="font-size: 36px; font-weight: 700; margin: 0; color: #0A0A0A;">
                    <?php echo $total_subscriptions > 0 ? round(($total_sent / $total_subscriptions) * 100) : 0; ?>%
                </p>
            </div>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2>Historial de Notificaciones</h2>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Producto</th>
                        <th>Email</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($log)) : ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px; color: #666;">
                                No hay notificaciones registradas aún
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach (array_slice($log, 0, 50) as $entry) : 
                            $product = wc_get_product($entry['product_id']);
                        ?>
                            <tr>
                                <td><?php echo date('d/m/Y H:i', strtotime($entry['date'])); ?></td>
                                <td>
                                    <?php if ($product) : ?>
                                        <a href="<?php echo get_edit_post_link($entry['product_id']); ?>">
                                            <?php echo $product->get_name(); ?>
                                        </a>
                                    <?php else : ?>
                                        Producto eliminado
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $entry['email']; ?></td>
                                <td>
                                    <?php if ($entry['status'] === 'subscribed') : ?>
                                        <span style="background: #fff3cd; padding: 5px 10px; border-radius: 3px; font-size: 12px;">
                                            📋 Suscrito
                                        </span>
                                    <?php else : ?>
                                        <span style="background: #d4edda; padding: 5px 10px; border-radius: 3px; font-size: 12px;">
                                            ✉️ Enviado
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

// ============================================
// PRODUCTOS CON SUSCRIPTORES ACTIVOS
// ============================================

add_action('admin_menu', 'gp_stock_notifications_pending_menu');

function gp_stock_notifications_pending_menu() {
    add_submenu_page(
        'woocommerce',
        'Productos con Suscriptores',
        '<span style="color: #D4AF37;">● Suscriptores Activos</span>',
        'manage_woocommerce',
        'pending-stock-notifications',
        'gp_pending_stock_notifications_page'
    );
}

function gp_pending_stock_notifications_page() {
    global $wpdb;
    
    // Obtener todos los productos con suscriptores
    $results = $wpdb->get_results("
        SELECT post_id, meta_value 
        FROM {$wpdb->postmeta} 
        WHERE meta_key = '_stock_notification_subscribers'
    ");
    
    ?>
    <div class="wrap">
        <h1>🔔 Productos con Suscriptores Activos</h1>
        
        <p>Estos productos tienen clientes esperando a que vuelvan a estar en stock.</p>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Stock Actual</th>
                    <th>Suscriptores</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($results)) : ?>
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: #666;">
                            No hay productos con suscriptores activos
                        </td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($results as $row) : 
                        $product = wc_get_product($row->post_id);
                        if (!$product) continue;
                        
                        $subscribers = maybe_unserialize($row->meta_value);
                        $count = is_array($subscribers) ? count($subscribers) : 0;
                    ?>
                        <tr>
                            <td>
                                <strong><?php echo $product->get_name(); ?></strong><br>
                                <small><?php echo get_permalink($row->post_id); ?></small>
                            </td>
                            <td>
                                <?php if ($product->is_in_stock()) : ?>
                                    <span style="color: #28a745;">✓ En Stock</span>
                                <?php else : ?>
                                    <span style="color: #dc3545;">✗ Agotado</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="font-size: 18px; color: #D4AF37;"><?php echo $count; ?></strong> personas
                            </td>
                            <td>
                                <a href="<?php echo get_edit_post_link($row->post_id); ?>" class="button">
                                    Editar Producto
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
