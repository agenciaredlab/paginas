<?php
/**
 * Thank You Page - Página de Agradecimiento Post-Compra
 * Con cross-sell, reviews, referidos y remarketing
 */

if (!defined('ABSPATH')) exit;

class GP_Thank_You_Page {
    
    public function __construct() {
        // Customizar página de agradecimiento WooCommerce
        add_filter('woocommerce_thankyou_order_received_text', array($this, 'custom_thank_you_text'), 10, 2);
        add_action('woocommerce_thankyou', array($this, 'custom_thank_you_content'), 20);
        
        // Añadir scripts de tracking
        add_action('woocommerce_thankyou', array($this, 'add_conversion_tracking'), 5);
        
        // Enviar a N8N
        add_action('woocommerce_thankyou', array($this, 'send_to_n8n'), 10);
    }
    
    public function custom_thank_you_text($text, $order) {
        if (!$order) return $text;
        
        $customer_name = $order->get_billing_first_name();
        
        return '
        <div style="text-align: center; padding: 40px 20px; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); border-radius: 20px; margin-bottom: 40px;">
            <div style="font-size: 80px; margin-bottom: 20px; animation: bounce 1s;">🎉</div>
            <h1 style="font-size: 48px; font-weight: 700; color: #1a1a1a; margin: 0 0 15px;">
                ¡Gracias por tu compra, ' . esc_html($customer_name) . '!
            </h1>
            <p style="font-size: 20px; color: #2d2d2d; margin: 0 0 25px;">
                Tu pedido ha sido recibido exitosamente
            </p>
            <div style="background: rgba(0,0,0,0.1); padding: 20px; border-radius: 12px; display: inline-block;">
                <p style="font-size: 16px; color: #1a1a1a; margin: 0;">
                    <strong>Número de pedido:</strong> #' . $order->get_order_number() . '
                </p>
                <p style="font-size: 16px; color: #1a1a1a; margin: 5px 0 0;">
                    <strong>Total:</strong> ' . $order->get_formatted_order_total() . '
                </p>
            </div>
        </div>
        
        <style>
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-30px); }
            60% { transform: translateY(-15px); }
        }
        </style>
        ';
    }
    
    public function custom_thank_you_content($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        
        ?>
        <div class="gp-thank-you-wrapper" style="max-width: 1200px; margin: 40px auto; padding: 0 20px;">
            
            <!-- TIMELINE DEL PEDIDO -->
            <div style="background: #fff; padding: 40px; border-radius: 20px; margin-bottom: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);">
                <h2 style="font-size: 28px; font-weight: 700; color: #1a1a1a; margin: 0 0 30px; text-align: center;">
                    📦 ¿Qué sigue?
                </h2>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    
                    <div style="text-align: center; padding: 25px; background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); border-radius: 15px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">✅</div>
                        <h3 style="font-size: 18px; font-weight: 600; color: #2e7d32; margin: 0 0 10px;">Pedido Confirmado</h3>
                        <p style="font-size: 14px; color: #4caf50; margin: 0;">Ahora mismo</p>
                    </div>
                    
                    <div style="text-align: center; padding: 25px; background: #f5f5f5; border-radius: 15px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">📧</div>
                        <h3 style="font-size: 18px; font-weight: 600; color: #666; margin: 0 0 10px;">Email de Confirmación</h3>
                        <p style="font-size: 14px; color: #999; margin: 0;">En 5 minutos</p>
                    </div>
                    
                    <div style="text-align: center; padding: 25px; background: #f5f5f5; border-radius: 15px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">📦</div>
                        <h3 style="font-size: 18px; font-weight: 600; color: #666; margin: 0 0 10px;">Preparando Envío</h3>
                        <p style="font-size: 14px; color: #999; margin: 0;">24-48 horas</p>
                    </div>
                    
                    <div style="text-align: center; padding: 25px; background: #f5f5f5; border-radius: 15px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">🚚</div>
                        <h3 style="font-size: 18px; font-weight: 600; color: #666; margin: 0 0 10px;">En Camino</h3>
                        <p style="font-size: 14px; color: #999; margin: 0;">3-5 días hábiles</p>
                    </div>
                    
                    <div style="text-align: center; padding: 25px; background: #f5f5f5; border-radius: 15px;">
                        <div style="font-size: 48px; margin-bottom: 15px;">🎁</div>
                        <h3 style="font-size: 18px; font-weight: 600; color: #666; margin: 0 0 10px;">¡Disfruta!</h3>
                        <p style="font-size: 14px; color: #999; margin: 0;">Pronto en tu puerta</p>
                    </div>
                    
                </div>
            </div>
            
            <!-- INFORMACIÓN IMPORTANTE -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-bottom: 40px;">
                
                <!-- EMAIL ENVIADO -->
                <div style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); padding: 30px; border-radius: 15px; text-align: center;">
                    <div style="font-size: 56px; margin-bottom: 15px;">📧</div>
                    <h3 style="font-size: 20px; font-weight: 700; color: #1976d2; margin: 0 0 15px;">Revisa tu Email</h3>
                    <p style="font-size: 15px; color: #1565c0; margin: 0;">
                        Hemos enviado la confirmación y detalles de tu pedido a:<br>
                        <strong><?php echo esc_html($order->get_billing_email()); ?></strong>
                    </p>
                </div>
                
                <!-- SEGUIMIENTO -->
                <div style="background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); padding: 30px; border-radius: 15px; text-align: center;">
                    <div style="font-size: 56px; margin-bottom: 15px;">📍</div>
                    <h3 style="font-size: 20px; font-weight: 700; color: #f57c00; margin: 0 0 15px;">Rastrea tu Pedido</h3>
                    <p style="font-size: 15px; color: #e65100; margin: 0 0 15px;">
                        Te enviaremos el número de rastreo cuando tu pedido sea despachado
                    </p>
                    <a href="<?php echo esc_url($order->get_view_order_url()); ?>" style="display: inline-block; background: #ff9800; color: #fff; padding: 12px 25px; border-radius: 50px; text-decoration: none; font-weight: 600;">
                        Ver Mi Pedido
                    </a>
                </div>
                
                <!-- SOPORTE -->
                <div style="background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); padding: 30px; border-radius: 15px; text-align: center;">
                    <div style="font-size: 56px; margin-bottom: 15px;">💬</div>
                    <h3 style="font-size: 20px; font-weight: 700; color: #7b1fa2; margin: 0 0 15px;">¿Necesitas Ayuda?</h3>
                    <p style="font-size: 15px; color: #6a1b9a; margin: 0 0 15px;">
                        Estamos aquí para ti 24/7
                    </p>
                    <div style="display: flex; gap: 10px; justify-content: center;">
                        <a href="https://wa.me/573001234567" style="display: inline-block; background: #25d366; color: #fff; padding: 12px 20px; border-radius: 50px; text-decoration: none; font-weight: 600;">
                            WhatsApp
                        </a>
                        <a href="mailto:soporte@goldenphoenix.com" style="display: inline-block; background: #9c27b0; color: #fff; padding: 12px 20px; border-radius: 50px; text-decoration: none; font-weight: 600;">
                            Email
                        </a>
                    </div>
                </div>
                
            </div>
            
            <!-- PRODUCTOS COMPRADOS -->
            <div style="background: #fff; padding: 40px; border-radius: 20px; margin-bottom: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);">
                <h2 style="font-size: 28px; font-weight: 700; color: #1a1a1a; margin: 0 0 30px;">
                    🛍️ Resumen de tu Compra
                </h2>
                
                <div style="display: grid; gap: 20px;">
                    <?php
                    foreach ($order->get_items() as $item_id => $item):
                        $product = $item->get_product();
                        if (!$product) continue;
                    ?>
                        <div style="display: grid; grid-template-columns: 100px 1fr auto; gap: 20px; padding: 20px; background: #f9f9f9; border-radius: 12px; align-items: center;">
                            <div>
                                <?php echo $product->get_image('thumbnail'); ?>
                            </div>
                            <div>
                                <h4 style="font-size: 18px; font-weight: 600; color: #1a1a1a; margin: 0 0 8px;">
                                    <?php echo esc_html($item->get_name()); ?>
                                </h4>
                                <p style="font-size: 14px; color: #666; margin: 0;">
                                    Cantidad: <?php echo $item->get_quantity(); ?>
                                </p>
                            </div>
                            <div style="text-align: right;">
                                <p style="font-size: 24px; font-weight: 700; color: #c9a961; margin: 0;">
                                    <?php echo wc_price($item->get_total()); ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- PROGRAMA DE REFERIDOS -->
            <div style="background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); padding: 50px; border-radius: 20px; margin-bottom: 40px; text-align: center;">
                <h2 style="font-size: 32px; font-weight: 700; color: #1a1a1a; margin: 0 0 20px;">
                    🎁 Gana $50,000 por Cada Referido
                </h2>
                <p style="font-size: 18px; color: #2d2d2d; margin: 0 0 30px;">
                    Comparte Golden Phoenix con tus amigos y ambos ganan
                </p>
                
                <div style="background: rgba(0,0,0,0.1); padding: 25px; border-radius: 15px; margin-bottom: 25px;">
                    <p style="font-size: 16px; color: #1a1a1a; margin: 0 0 15px; font-weight: 600;">
                        Tu código de referido:
                    </p>
                    <div style="background: #fff; padding: 20px; border-radius: 10px; font-size: 32px; font-weight: 700; color: #c9a961; letter-spacing: 3px;">
                        <?php echo strtoupper(substr(md5($order->get_billing_email()), 0, 8)); ?>
                    </div>
                </div>
                
                <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                    <button onclick="shareReferral('whatsapp')" style="background: #25d366; color: #fff; padding: 15px 30px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer; font-size: 16px;">
                        💬 Compartir WhatsApp
                    </button>
                    <button onclick="shareReferral('facebook')" style="background: #3b5998; color: #fff; padding: 15px 30px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer; font-size: 16px;">
                        📘 Compartir Facebook
                    </button>
                    <button onclick="copyReferralCode()" style="background: #1a1a1a; color: #fff; padding: 15px 30px; border: none; border-radius: 50px; font-weight: 600; cursor: pointer; font-size: 16px;">
                        📋 Copiar Código
                    </button>
                </div>
            </div>
            
            <!-- TAMBIÉN TE PUEDE GUSTAR -->
            <?php
            $cross_sell_ids = array();
            foreach ($order->get_items() as $item) {
                $product = $item->get_product();
                if ($product) {
                    $cross_sell_ids = array_merge($cross_sell_ids, $product->get_cross_sell_ids());
                }
            }
            
            if (!empty($cross_sell_ids)):
                $cross_sell_ids = array_unique($cross_sell_ids);
                $cross_sell_ids = array_slice($cross_sell_ids, 0, 4);
            ?>
                <div style="background: #fff; padding: 40px; border-radius: 20px; margin-bottom: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);">
                    <h2 style="font-size: 28px; font-weight: 700; color: #1a1a1a; margin: 0 0 30px; text-align: center;">
                        ✨ También Te Puede Gustar
                    </h2>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 25px;">
                        <?php
                        foreach ($cross_sell_ids as $product_id):
                            $product = wc_get_product($product_id);
                            if (!$product) continue;
                        ?>
                            <div style="border: 1px solid #e0e0e0; border-radius: 15px; overflow: hidden; transition: all 0.3s;">
                                <a href="<?php echo get_permalink($product_id); ?>">
                                    <?php echo $product->get_image('medium'); ?>
                                </a>
                                <div style="padding: 20px;">
                                    <h4 style="font-size: 18px; font-weight: 600; color: #1a1a1a; margin: 0 0 10px;">
                                        <a href="<?php echo get_permalink($product_id); ?>" style="color: #1a1a1a; text-decoration: none;">
                                            <?php echo $product->get_name(); ?>
                                        </a>
                                    </h4>
                                    <p style="font-size: 24px; font-weight: 700; color: #c9a961; margin: 0 0 15px;">
                                        <?php echo $product->get_price_html(); ?>
                                    </p>
                                    <a href="<?php echo get_permalink($product_id); ?>" style="display: block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 12px; border-radius: 50px; text-align: center; text-decoration: none; font-weight: 600;">
                                        Ver Producto
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- DEJA TU OPINIÓN -->
            <div style="background: linear-gradient(135deg, #fff9e6 0%, #fff3cc 100%); padding: 50px; border-radius: 20px; margin-bottom: 40px; text-align: center;">
                <div style="font-size: 64px; margin-bottom: 20px;">⭐⭐⭐⭐⭐</div>
                <h2 style="font-size: 32px; font-weight: 700; color: #1a1a1a; margin: 0 0 20px;">
                    ¿Qué Te Pareció Tu Experiencia?
                </h2>
                <p style="font-size: 18px; color: #666; margin: 0 0 30px;">
                    Tu opinión nos ayuda a mejorar cada día
                </p>
                <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" style="display: inline-block; background: #ffc107; color: #1a1a1a; padding: 18px 40px; border-radius: 50px; text-decoration: none; font-weight: 700; font-size: 18px;">
                    📝 Dejar Opinión (Gana 10% descuento)
                </a>
            </div>
            
            <!-- REDES SOCIALES -->
            <div style="background: #1a1a1a; padding: 50px; border-radius: 20px; text-align: center; color: #fff;">
                <h2 style="font-size: 28px; font-weight: 700; margin: 0 0 20px;">
                    Síguenos en Redes Sociales
                </h2>
                <p style="font-size: 16px; color: #999; margin: 0 0 30px;">
                    Únete a nuestra comunidad y entérate de ofertas exclusivas
                </p>
                <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                    <a href="#" style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 15px 30px; border-radius: 50px; text-decoration: none; color: #fff; font-weight: 600; transition: all 0.3s;">
                        <span style="font-size: 24px;">📘</span> Facebook
                    </a>
                    <a href="#" style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 15px 30px; border-radius: 50px; text-decoration: none; color: #fff; font-weight: 600; transition: all 0.3s;">
                        <span style="font-size: 24px;">📸</span> Instagram
                    </a>
                    <a href="#" style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.1); padding: 15px 30px; border-radius: 50px; text-decoration: none; color: #fff; font-weight: 600; transition: all 0.3s;">
                        <span style="font-size: 24px;">💬</span> WhatsApp
                    </a>
                </div>
            </div>
            
        </div>
        
        <script>
        function shareReferral(platform) {
            const code = '<?php echo strtoupper(substr(md5($order->get_billing_email()), 0, 8)); ?>';
            const message = `¡Mira estas joyas increíbles! Usa mi código ${code} y obtén $50,000 de descuento en Golden Phoenix`;
            const url = '<?php echo home_url('/'); ?>';
            
            if (platform === 'whatsapp') {
                window.open(`https://wa.me/?text=${encodeURIComponent(message + ' ' + url)}`, '_blank');
            } else if (platform === 'facebook') {
                window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(message)}`, '_blank');
            }
        }
        
        function copyReferralCode() {
            const code = '<?php echo strtoupper(substr(md5($order->get_billing_email()), 0, 8)); ?>';
            navigator.clipboard.writeText(code).then(() => {
                alert('✅ Código copiado: ' + code);
            });
        }
        </script>
        <?php
    }
    
    public function add_conversion_tracking($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        
        // Facebook Pixel
        ?>
        <script>
        // Facebook Pixel - Purchase Event
        if (typeof fbq !== 'undefined') {
            fbq('track', 'Purchase', {
                value: <?php echo $order->get_total(); ?>,
                currency: '<?php echo $order->get_currency(); ?>',
                content_ids: [<?php 
                    $product_ids = array();
                    foreach ($order->get_items() as $item) {
                        $product_ids[] = $item->get_product_id();
                    }
                    echo implode(',', $product_ids);
                ?>],
                content_type: 'product',
                num_items: <?php echo $order->get_item_count(); ?>
            });
        }
        
        // Google Analytics - Purchase Event
        if (typeof gtag !== 'undefined') {
            gtag('event', 'purchase', {
                transaction_id: '<?php echo $order->get_order_number(); ?>',
                value: <?php echo $order->get_total(); ?>,
                currency: '<?php echo $order->get_currency(); ?>',
                items: [
                    <?php
                    foreach ($order->get_items() as $item):
                        $product = $item->get_product();
                        if (!$product) continue;
                    ?>
                    {
                        id: '<?php echo $product->get_id(); ?>',
                        name: '<?php echo esc_js($item->get_name()); ?>',
                        quantity: <?php echo $item->get_quantity(); ?>,
                        price: <?php echo $product->get_price(); ?>
                    },
                    <?php endforeach; ?>
                ]
            });
        }
        </script>
        <?php
    }
    
    public function send_to_n8n($order_id) {
        $webhook_url = get_option('gp_n8n_webhook_url');
        if (empty($webhook_url)) return;
        
        $order = wc_get_order($order_id);
        if (!$order) return;
        
        $items = array();
        foreach ($order->get_items() as $item) {
            $items[] = array(
                'product_id' => $item->get_product_id(),
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'price' => $item->get_total()
            );
        }
        
        $payload = array(
            'event' => 'purchase_completed',
            'order_id' => $order_id,
            'order_number' => $order->get_order_number(),
            'total' => $order->get_total(),
            'currency' => $order->get_currency(),
            'customer' => array(
                'email' => $order->get_billing_email(),
                'name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'phone' => $order->get_billing_phone()
            ),
            'items' => $items,
            'timestamp' => current_time('mysql')
        );
        
        wp_remote_post($webhook_url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($payload),
            'timeout' => 5,
            'blocking' => false
        ));
    }
}

new GP_Thank_You_Page();
