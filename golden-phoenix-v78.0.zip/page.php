<?php
/**
 * Template para páginas individuales
 * Permite editar contenido desde WordPress
 */

get_header(); ?>

<main class="site-main editable-content">
    <?php
    while (have_posts()) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            
            <?php if (has_post_thumbnail()) : ?>
            <div class="page-featured-image">
                <?php the_post_thumbnail('large'); ?>
            </div>
            <?php endif; ?>
            
            <div class="page-content-wrapper">
                <header class="page-header">
                    <h1 class="page-title"><?php the_title(); ?></h1>
                </header>
                
                <div class="page-content">
                    <?php the_content(); ?>
                </div>
            </div>
            
        </article>
    <?php
    endwhile;
    ?>
</main>

<?php get_footer(); ?>

<style>
/* Estilos para contenido editable */
.editable-content {
    background: #0A0A0A;
    color: #FFFFFF;
    padding: 4rem 2rem;
    min-height: 60vh;
}

.page-content-wrapper {
    max-width: 1200px;
    margin: 0 auto;
}

.page-header {
    text-align: center;
    margin-bottom: 3rem;
    padding-bottom: 2rem;
    border-bottom: 2px solid #D4AF37;
}

.page-title {
    font-family: 'Playfair Display', serif;
    font-size: 3rem;
    color: #D4AF37;
    margin: 0;
    font-weight: 700;
}

.page-featured-image {
    width: 100%;
    max-height: 500px;
    overflow: hidden;
    margin-bottom: 3rem;
}

.page-featured-image img {
    width: 100%;
    height: auto;
    object-fit: cover;
}

.page-content {
    font-family: 'Poppins', sans-serif;
    font-size: 1.125rem;
    line-height: 1.8;
    color: #E0E0E0;
}

.page-content h1,
.page-content h2,
.page-content h3,
.page-content h4 {
    font-family: 'Playfair Display', serif;
    color: #D4AF37;
    margin-top: 2rem;
    margin-bottom: 1rem;
}

.page-content h1 {
    font-size: 2.5rem;
}

.page-content h2 {
    font-size: 2rem;
}

.page-content h3 {
    font-size: 1.5rem;
}

.page-content p {
    margin-bottom: 1.5rem;
}

.page-content ul,
.page-content ol {
    margin-bottom: 1.5rem;
    padding-left: 2rem;
}

.page-content li {
    margin-bottom: 0.5rem;
}

.page-content a {
    color: #D4AF37;
    text-decoration: none;
    transition: all 0.3s ease;
}

.page-content a:hover {
    color: #F4CF77;
    text-decoration: underline;
}

.page-content img {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin: 2rem 0;
}

.page-content blockquote {
    border-left: 4px solid #D4AF37;
    padding-left: 2rem;
    margin: 2rem 0;
    font-style: italic;
    color: #F4CF77;
}

/* Responsive */
@media (max-width: 768px) {
    .editable-content {
        padding: 2rem 1rem;
    }
    
    .page-title {
        font-size: 2rem;
    }
    
    .page-content {
        font-size: 1rem;
    }
    
    .page-content h1 {
        font-size: 1.75rem;
    }
    
    .page-content h2 {
        font-size: 1.5rem;
    }
}
</style>
