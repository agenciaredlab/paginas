<?php
/**
 * Golden Phoenix - Visual Builder con LOG LÍNEA POR LÍNEA
 */

if (!defined('ABSPATH')) exit;

// Logger ya cargado en functions.php, no necesitamos require_once aquí

gp_log("=== VISUAL-BUILDER.PHP INICIADO ===");
gp_log("Línea 10: Inicio del archivo");

gp_log("Línea 15: Definiendo constantes...");
// Sin constantes por ahora para evitar conflictos
gp_log("Línea 17: Constantes OK");

gp_log("Línea 20: Definiendo función gp_elementor_support");
function gp_elementor_support() {
    gp_log_function_start('gp_elementor_support');
    
    gp_log("L23: add_theme_support elementor");
    add_theme_support('elementor');
    
    gp_log("L26: add_theme_support elementor-full-width");
    add_theme_support('elementor-full-width');
    
    gp_log_function_end('gp_elementor_support');
}
gp_log("Línea 33: Función gp_elementor_support definida OK");

gp_log("Línea 36: Definiendo función gp_register_elementor_locations");
function gp_register_elementor_locations($elementor_theme_manager) {
    gp_log_function_start('gp_register_elementor_locations');
    gp_log("L39: Llamando register_all_core_location");
    // COMENTADO - Causaba crash
    // $elementor_theme_manager->register_all_core_location();
    gp_log_function_end('gp_register_elementor_locations');
}
gp_log("Línea 45: Función gp_register_elementor_locations definida OK");

gp_log("Línea 48: Definiendo función gp_gutenberg_support");
function gp_gutenberg_support() {
    gp_log_function_start('gp_gutenberg_support');
    
    gp_log("L51: add_theme_support wp-block-styles");
    add_theme_support('wp-block-styles');
    
    gp_log("L54: add_theme_support align-wide");
    add_theme_support('align-wide');
    
    gp_log("L57: add_theme_support align-full");
    add_theme_support('align-full');
    
    gp_log("L60: add_theme_support responsive-embeds");
    add_theme_support('responsive-embeds');
    
    gp_log_function_end('gp_gutenberg_support');
}
gp_log("Línea 66: Función gp_gutenberg_support definida OK");

// ============================================
// ESTILOS PARA EDITOR VISUAL
// ============================================

gp_log("Línea 73: Registrando hook wp_head para estilos");
add_action('wp_head', 'gp_visual_editor_styles');
gp_log_hook('wp_head', 'gp_visual_editor_styles', 10);

function gp_visual_editor_styles() {
    gp_log_function_start('gp_visual_editor_styles');
    ?>
    <style>
        /* Estilos básicos para editor visual */
        .elementor-element {
            transition: all 0.3s ease;
        }
    </style>
    <?php
    gp_log_function_end('gp_visual_editor_styles');
}
gp_log("Línea 89: Función gp_visual_editor_styles definida OK");

// ============================================
// CHAT WIDGET
// ============================================

gp_log("Línea 95: Registrando hook wp_footer para chat");
add_action('wp_footer', 'gp_chat_widget');
gp_log_hook('wp_footer', 'gp_chat_widget', 10);

function gp_chat_widget() {
    gp_log_function_start('gp_chat_widget');
    
    gp_log("L102: Obteniendo theme_mod gp_chat_enabled");
    $enabled = get_theme_mod('gp_chat_enabled', true);
    
    if (!$enabled) {
        gp_log("L106: Chat deshabilitado, saliendo");
        gp_log_function_end('gp_chat_widget');
        return;
    }
    
    gp_log("L111: Obteniendo configuración chat");
    $whatsapp = get_theme_mod('gp_chat_whatsapp', '573001234567');
    $message = get_theme_mod('gp_chat_message', '¡Hola! ¿En qué podemos ayudarte?');
    $position = get_theme_mod('gp_chat_position', 'bottom-right');
    $color = get_theme_mod('gp_chat_color', '#D4AF37');
    
    gp_log("L117: WhatsApp: $whatsapp");
    
    ?>
    <div class="gp-chat-widget" style="position: fixed; <?php echo esc_attr($position); ?>: 20px; z-index: 9999;">
        <a href="https://wa.me/<?php echo esc_attr($whatsapp); ?>?text=<?php echo urlencode($message); ?>" 
           target="_blank"
           style="background: <?php echo esc_attr($color); ?>; color: white; padding: 15px 20px; border-radius: 50px; text-decoration: none; display: inline-block; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
            <i class="fab fa-whatsapp"></i> Chat
        </a>
    </div>
    <?php
    
    gp_log_function_end('gp_chat_widget');
}
gp_log("Línea 133: Función gp_chat_widget definida OK");

// ============================================
// CUSTOMIZER PARA CHAT
// ============================================

gp_log("Línea 139: Registrando hook customize_register");
add_action('customize_register', 'gp_chat_customizer');
gp_log_hook('customize_register', 'gp_chat_customizer', 10);

function gp_chat_customizer($wp_customize) {
    gp_log_function_start('gp_chat_customizer');
    
    gp_log("L146: Agregando sección gp_chat_section");
    $wp_customize->add_section('gp_chat_section', array(
        'title' => '💬 Botón de Chat',
        'priority' => 35,
    ));
    
    gp_log("L152: Agregando setting gp_chat_enabled");
    $wp_customize->add_setting('gp_chat_enabled', array(
        'default' => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    
    gp_log("L158: Agregando control gp_chat_enabled");
    $wp_customize->add_control('gp_chat_enabled', array(
        'label' => 'Mostrar Botón de Chat',
        'section' => 'gp_chat_section',
        'type' => 'checkbox',
    ));
    
    gp_log("L165: Agregando setting gp_chat_whatsapp");
    $wp_customize->add_setting('gp_chat_whatsapp', array(
        'default' => '573001234567',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    gp_log("L171: Agregando control gp_chat_whatsapp");
    $wp_customize->add_control('gp_chat_whatsapp', array(
        'label' => 'Número WhatsApp',
        'section' => 'gp_chat_section',
        'type' => 'text',
    ));
    
    gp_log("L178: Agregando setting gp_chat_message");
    $wp_customize->add_setting('gp_chat_message', array(
        'default' => '¡Hola! ¿En qué podemos ayudarte?',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    gp_log("L184: Agregando control gp_chat_message");
    $wp_customize->add_control('gp_chat_message', array(
        'label' => 'Mensaje Predeterminado',
        'section' => 'gp_chat_section',
        'type' => 'text',
    ));
    
    gp_log("L191: Agregando setting gp_chat_position");
    $wp_customize->add_setting('gp_chat_position', array(
        'default' => 'bottom-right',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    gp_log("L197: Agregando control gp_chat_position");
    $wp_customize->add_control('gp_chat_position', array(
        'label' => 'Posición',
        'section' => 'gp_chat_section',
        'type' => 'select',
        'choices' => array(
            'bottom-right' => 'Abajo Derecha',
            'bottom-left' => 'Abajo Izquierda',
            'top-right' => 'Arriba Derecha',
            'top-left' => 'Arriba Izquierda',
        ),
    ));
    
    gp_log("L210: Agregando setting gp_chat_color");
    $wp_customize->add_setting('gp_chat_color', array(
        'default' => '#D4AF37',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    gp_log("L216: Agregando control gp_chat_color");
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'gp_chat_color', array(
        'label' => 'Color del Botón',
        'section' => 'gp_chat_section',
    )));
    
    gp_log_function_end('gp_chat_customizer');
}
gp_log("Línea 224: Función gp_chat_customizer definida OK");

gp_log("=== VISUAL-BUILDER.PHP COMPLETADO ===");
