<?php
/**
 * Template Name: Página de Inicio
 * Template Post Type: page
 * 
 * @package Golden_Phoenix
 */

get_header();
?>

<main class="home-page">
    
    <!-- Hero Section -->
    <section class="hero-section" style="
        background: linear-gradient(135deg, rgba(10,10,10,0.7), rgba(10,10,10,0.5)), 
                    url('https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920') center/cover;
        min-height: 90vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: white;
        position: relative;
    ">
        <div class="hero-content" style="max-width: 800px; padding: 40px 20px;">
            <h1 style="
                font-size: 64px;
                font-family: 'Playfair Display', serif;
                margin-bottom: 20px;
                font-weight: 700;
                line-height: 1.2;
            ">
                <?php echo esc_html(get_theme_mod('gp_hero_title', 'Joyas Excepcionales')); ?>
            </h1>
            
            <p style="
                font-size: 24px;
                margin-bottom: 15px;
                font-weight: 300;
                letter-spacing: 2px;
            ">
                <?php echo esc_html(get_theme_mod('gp_hero_subtitle', 'Diseñadas para Perdurar')); ?>
            </p>
            
            <p style="
                font-size: 18px;
                margin-bottom: 40px;
                opacity: 0.9;
                max-width: 600px;
                margin-left: auto;
                margin-right: auto;
            ">
                <?php echo esc_html(get_theme_mod('gp_hero_description', 'Descubre nuestra colección exclusiva de joyería de alta gama')); ?>
            </p>
            
            <div class="hero-buttons" style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                <a href="<?php echo home_url('/colecciones'); ?>" 
                   class="btn-primary"
                   style="
                       background: #D4AF37;
                       color: white;
                       padding: 18px 45px;
                       border-radius: 4px;
                       text-decoration: none;
                       font-weight: 600;
                       font-size: 16px;
                       transition: all 0.3s;
                       display: inline-block;
                   "
                   onmouseover="this.style.background='#fff'; this.style.color='#D4AF37';"
                   onmouseout="this.style.background='#D4AF37'; this.style.color='#fff';">
                    <?php echo esc_html(get_theme_mod('gp_main_button_text', 'Explorar Colección')); ?>
                </a>
                
                <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
                   style="
                       background: transparent;
                       color: white;
                       padding: 18px 45px;
                       border: 2px solid white;
                       border-radius: 4px;
                       text-decoration: none;
                       font-weight: 600;
                       font-size: 16px;
                       transition: all 0.3s;
                       display: inline-block;
                   "
                   onmouseover="this.style.background='#fff'; this.style.color='#0A0A0A';"
                   onmouseout="this.style.background='transparent'; this.style.color='#fff';">
                    Ver Tienda
                </a>
            </div>
        </div>
        
        <!-- Scroll Indicator -->
        <div style="position: absolute; bottom: 40px; left: 50%; transform: translateX(-50%); animation: bounce 2s infinite;">
            <div style="width: 30px; height: 50px; border: 2px solid rgba(255,255,255,0.5); border-radius: 20px; position: relative;">
                <div style="width: 6px; height: 10px; background: white; border-radius: 3px; position: absolute; top: 10px; left: 50%; transform: translateX(-50%); animation: scroll 2s infinite;"></div>
            </div>
        </div>
    </section>
    
    <!-- Categorías Destacadas -->
    <section class="featured-categories" style="padding: 100px 20px; background: white;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            
            <div class="section-header" style="text-align: center; margin-bottom: 60px;">
                <h2 style="font-size: 48px; font-family: 'Playfair Display', serif; margin-bottom: 15px; color: #0A0A0A;">
                    Explora Nuestras Colecciones
                </h2>
                <div style="width: 80px; height: 3px; background: #D4AF37; margin: 20px auto;"></div>
                <p style="font-size: 18px; color: #666; max-width: 600px; margin: 0 auto;">
                    Cada pieza cuenta una historia de elegancia y sofisticación
                </p>
            </div>
            
            <?php
            $featured_categories = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
                'number' => 3,
                'parent' => 0
            ));
            
            if ($featured_categories && !is_wp_error($featured_categories)) :
            ?>
            
            <div class="categories-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
                
                <?php foreach ($featured_categories as $category) : 
                    $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);
                    $image = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : 'https://via.placeholder.com/400x500/0A0A0A/D4AF37?text=' . urlencode($category->name);
                ?>
                
                <a href="<?php echo get_term_link($category); ?>" 
                   class="category-card"
                   style="position: relative; overflow: hidden; border-radius: 8px; display: block; text-decoration: none; height: 450px; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                    
                    <div style="position: absolute; inset: 0; background: url('<?php echo esc_url($image); ?>') center/cover; transition: transform 0.5s;"
                         onmouseover="this.style.transform='scale(1.1)'"
                         onmouseout="this.style.transform='scale(1)'"></div>
                    
                    <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.8), transparent); display: flex; align-items: flex-end; padding: 30px;">
                        <div>
                            <h3 style="color: white; font-size: 28px; font-family: 'Playfair Display', serif; margin-bottom: 8px;">
                                <?php echo esc_html($category->name); ?>
                            </h3>
                            <p style="color: rgba(255,255,255,0.8); font-size: 14px; margin-bottom: 15px;">
                                <?php echo $category->count; ?> Piezas Disponibles
                            </p>
                            <span style="color: #D4AF37; font-weight: 600; font-size: 14px; letter-spacing: 1px;">
                                VER COLECCIÓN →
                            </span>
                        </div>
                    </div>
                    
                </a>
                
                <?php endforeach; ?>
                
            </div>
            
            <div style="text-align: center; margin-top: 50px;">
                <a href="<?php echo home_url('/colecciones'); ?>" 
                   style="display: inline-block; background: #D4AF37; color: white; padding: 15px 40px; border-radius: 4px; text-decoration: none; font-weight: 600; transition: background 0.3s;"
                   onmouseover="this.style.background='#0A0A0A'"
                   onmouseout="this.style.background='#D4AF37'">
                    Ver Todas las Colecciones
                </a>
            </div>
            
            <?php endif; ?>
            
        </div>
    </section>
    
    <!-- Productos Destacados -->
    <?php if (function_exists('wc_get_products')) : ?>
    <section class="featured-products" style="padding: 100px 20px; background: #F8F8F8;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            
            <div class="section-header" style="text-align: center; margin-bottom: 60px;">
                <h2 style="font-size: 48px; font-family: 'Playfair Display', serif; margin-bottom: 15px; color: #0A0A0A;">
                    Productos Destacados
                </h2>
                <div style="width: 80px; height: 3px; background: #D4AF37; margin: 20px auto;"></div>
            </div>
            
            <?php
            $featured_products = wc_get_products(array(
                'limit' => 4,
                'featured' => true,
                'status' => 'publish'
            ));
            
            if (empty($featured_products)) {
                $featured_products = wc_get_products(array(
                    'limit' => 4,
                    'status' => 'publish'
                ));
            }
            
            if ($featured_products) :
            ?>
            
            <div class="products-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px;">
                
                <?php foreach ($featured_products as $product) : ?>
                
                <div class="product-card" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 15px rgba(0,0,0,0.08); transition: transform 0.3s;"
                     onmouseover="this.style.transform='translateY(-10px)'; this.style.boxShadow='0 8px 25px rgba(0,0,0,0.15)';"
                     onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 15px rgba(0,0,0,0.08)';">
                    
                    <a href="<?php echo get_permalink($product->get_id()); ?>" style="display: block;">
                        <div style="height: 350px; overflow: hidden; background: #f9f9f9;">
                            <?php echo $product->get_image('large', array('style' => 'width: 100%; height: 100%; object-fit: cover;')); ?>
                        </div>
                    </a>
                    
                    <div style="padding: 25px;">
                        <h3 style="font-size: 18px; margin-bottom: 10px; color: #0A0A0A;">
                            <a href="<?php echo get_permalink($product->get_id()); ?>" style="text-decoration: none; color: inherit;">
                                <?php echo esc_html($product->get_name()); ?>
                            </a>
                        </h3>
                        
                        <div style="color: #D4AF37; font-size: 22px; font-weight: 700; margin-bottom: 15px;">
                            <?php echo $product->get_price_html(); ?>
                        </div>
                        
                        <a href="<?php echo $product->add_to_cart_url(); ?>" 
                           class="add-to-cart"
                           style="display: block; text-align: center; background: #D4AF37; color: white; padding: 12px; border-radius: 4px; text-decoration: none; font-weight: 600; transition: background 0.3s;"
                           onmouseover="this.style.background='#0A0A0A'"
                           onmouseout="this.style.background='#D4AF37'">
                            Agregar al Carrito
                        </a>
                    </div>
                    
                </div>
                
                <?php endforeach; ?>
                
            </div>
            
            <div style="text-align: center; margin-top: 50px;">
                <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
                   style="display: inline-block; background: #0A0A0A; color: white; padding: 15px 40px; border-radius: 4px; text-decoration: none; font-weight: 600; transition: background 0.3s;"
                   onmouseover="this.style.background='#D4AF37'"
                   onmouseout="this.style.background='#0A0A0A'">
                    Ver Todos los Productos
                </a>
            </div>
            
            <?php endif; ?>
            
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Por Qué Elegirnos -->
    <section class="why-us" style="padding: 100px 20px; background: white;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            
            <div class="section-header" style="text-align: center; margin-bottom: 60px;">
                <h2 style="font-size: 48px; font-family: 'Playfair Display', serif; margin-bottom: 15px; color: #0A0A0A;">
                    Por Qué Elegirnos
                </h2>
                <div style="width: 80px; height: 3px; background: #D4AF37; margin: 20px auto;"></div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; text-align: center;">
                
                <div class="feature">
                    <div style="width: 80px; height: 80px; background: #D4AF37; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 36px;">
                        💎
                    </div>
                    <h3 style="font-size: 22px; margin-bottom: 12px; font-family: 'Playfair Display', serif;">
                        Calidad Premium
                    </h3>
                    <p style="color: #666; line-height: 1.6;">
                        Solo trabajamos con materiales de la más alta calidad certificados
                    </p>
                </div>
                
                <div class="feature">
                    <div style="width: 80px; height: 80px; background: #D4AF37; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 36px;">
                        🎨
                    </div>
                    <h3 style="font-size: 22px; margin-bottom: 12px; font-family: 'Playfair Display', serif;">
                        Diseño Exclusivo
                    </h3>
                    <p style="color: #666; line-height: 1.6;">
                        Cada pieza es única, creada por diseñadores de renombre
                    </p>
                </div>
                
                <div class="feature">
                    <div style="width: 80px; height: 80px; background: #D4AF37; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 36px;">
                        ✨
                    </div>
                    <h3 style="font-size: 22px; margin-bottom: 12px; font-family: 'Playfair Display', serif;">
                        Servicio VIP
                    </h3>
                    <p style="color: #666; line-height: 1.6;">
                        Asesoría personalizada y atención exclusiva para cada cliente
                    </p>
                </div>
                
                <div class="feature">
                    <div style="width: 80px; height: 80px; background: #D4AF37; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 36px;">
                        🔒
                    </div>
                    <h3 style="font-size: 22px; margin-bottom: 12px; font-family: 'Playfair Display', serif;">
                        Compra Segura
                    </h3>
                    <p style="color: #666; line-height: 1.6;">
                        Pago 100% seguro con PSE y garantía de satisfacción
                    </p>
                </div>
                
            </div>
            
        </div>
    </section>
    
    <?php 
    // Hook para agregar testimonios
    do_action('gp_after_features'); 
    ?>
    
    <!-- Call to Action -->
    <section class="cta-section" style="padding: 100px 20px; background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%); color: white; text-align: center;">
        <div class="container" style="max-width: 800px; margin: 0 auto;">
            
            <h2 style="font-size: 48px; font-family: 'Playfair Display', serif; margin-bottom: 20px;">
                ¿Buscas Algo Especial?
            </h2>
            
            <p style="font-size: 18px; margin-bottom: 40px; opacity: 0.9;">
                Contáctanos para diseños personalizados o asesoría especializada
            </p>
            
            <a href="<?php echo home_url('/contacto'); ?>" 
               style="display: inline-block; background: #D4AF37; color: white; padding: 18px 50px; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 16px; transition: all 0.3s;"
               onmouseover="this.style.background='#fff'; this.style.color='#D4AF37';"
               onmouseout="this.style.background='#D4AF37'; this.style.color='#fff';">
                Contactar Asesor
            </a>
            
        </div>
    </section>
    
</main>

<style>
@keyframes bounce {
    0%, 100% { transform: translateX(-50%) translateY(0); }
    50% { transform: translateX(-50%) translateY(-20px); }
}

@keyframes scroll {
    0% { opacity: 0; top: 10px; }
    50% { opacity: 1; }
    100% { opacity: 0; top: 30px; }
}

@media (max-width: 768px) {
    .hero-section h1 {
        font-size: 36px !important;
    }
    
    .hero-section p {
        font-size: 16px !important;
    }
    
    .section-header h2 {
        font-size: 32px !important;
    }
    
    .hero-buttons {
        flex-direction: column;
    }
    
    .hero-buttons a {
        width: 100%;
        text-align: center;
    }
}
</style>

<?php get_footer(); ?>
