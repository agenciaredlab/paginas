/**
 * BLOQUES GUTENBERG PERSONALIZADOS - EDITOR
 * Golden Phoenix V61
 */

(function(wp) {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls, MediaUpload, RichText, URLInput } = wp.blockEditor || wp.editor;
    const { PanelBody, RangeControl, ColorPicker, SelectControl, Button, TextControl } = wp.components;
    const { Fragment } = wp.element;
    
    // ========================================
    // BLOQUE 1: BOTÓN LUXURY
    // ========================================
    registerBlockType('golden-phoenix/luxury-button', {
        title: '✨ Botón Luxury',
        icon: 'button',
        category: 'design',
        description: 'Botón totalmente personalizable con estilo luxury',
        
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="📝 Contenido" initialOpen={true}>
                            <TextControl
                                label="Texto del botón"
                                value={attributes.text}
                                onChange={(value) => setAttributes({ text: value })}
                            />
                            <TextControl
                                label="URL del enlace"
                                value={attributes.url}
                                onChange={(value) => setAttributes({ url: value })}
                                placeholder="/producto-categoria/anillos"
                            />
                        </PanelBody>
                        
                        <PanelBody title="🎨 Colores" initialOpen={false}>
                            <p><strong>Color de texto:</strong></p>
                            <ColorPicker
                                color={attributes.textColor}
                                onChangeComplete={(value) => setAttributes({ textColor: value.hex })}
                            />
                            
                            <p><strong>Color de fondo:</strong></p>
                            <ColorPicker
                                color={attributes.backgroundColor}
                                onChangeComplete={(value) => setAttributes({ backgroundColor: value.hex })}
                            />
                            
                            <p><strong>Color del borde:</strong></p>
                            <ColorPicker
                                color={attributes.borderColor}
                                onChangeComplete={(value) => setAttributes({ borderColor: value.hex })}
                            />
                            
                            <hr />
                            
                            <p><strong>Hover - Color de texto:</strong></p>
                            <ColorPicker
                                color={attributes.hoverTextColor}
                                onChangeComplete={(value) => setAttributes({ hoverTextColor: value.hex })}
                            />
                            
                            <p><strong>Hover - Color de fondo:</strong></p>
                            <ColorPicker
                                color={attributes.hoverBackgroundColor}
                                onChangeComplete={(value) => setAttributes({ hoverBackgroundColor: value.hex })}
                            />
                        </PanelBody>
                        
                        <PanelBody title="📐 Tamaños y Forma" initialOpen={false}>
                            <RangeControl
                                label="Grosor del borde (px)"
                                value={attributes.borderWidth}
                                onChange={(value) => setAttributes({ borderWidth: value })}
                                min={0}
                                max={10}
                            />
                            
                            <RangeControl
                                label="Redondez de esquinas (px)"
                                value={attributes.borderRadius}
                                onChange={(value) => setAttributes({ borderRadius: value })}
                                min={0}
                                max={50}
                                help="0 = cuadrado, 50 = circular"
                            />
                            
                            <RangeControl
                                label="Tamaño de fuente (px)"
                                value={attributes.fontSize}
                                onChange={(value) => setAttributes({ fontSize: value })}
                                min={10}
                                max={30}
                            />
                            
                            <SelectControl
                                label="Grosor de fuente"
                                value={attributes.fontWeight}
                                options={[
                                    { label: 'Normal', value: '400' },
                                    { label: 'Semi-Bold', value: '600' },
                                    { label: 'Bold', value: '700' },
                                ]}
                                onChange={(value) => setAttributes({ fontWeight: value })}
                            />
                            
                            <RangeControl
                                label="Espaciado de letras (px)"
                                value={attributes.letterSpacing}
                                onChange={(value) => setAttributes({ letterSpacing: value })}
                                min={0}
                                max={5}
                            />
                        </PanelBody>
                        
                        <PanelBody title="📏 Espaciado" initialOpen={false}>
                            <RangeControl
                                label="Padding Superior (px)"
                                value={attributes.paddingTop}
                                onChange={(value) => setAttributes({ paddingTop: value })}
                                min={0}
                                max={50}
                            />
                            
                            <RangeControl
                                label="Padding Derecho (px)"
                                value={attributes.paddingRight}
                                onChange={(value) => setAttributes({ paddingRight: value })}
                                min={0}
                                max={100}
                            />
                            
                            <RangeControl
                                label="Padding Inferior (px)"
                                value={attributes.paddingBottom}
                                onChange={(value) => setAttributes({ paddingBottom: value })}
                                min={0}
                                max={50}
                            />
                            
                            <RangeControl
                                label="Padding Izquierdo (px)"
                                value={attributes.paddingLeft}
                                onChange={(value) => setAttributes({ paddingLeft: value })}
                                min={0}
                                max={100}
                            />
                        </PanelBody>
                        
                        <PanelBody title="⚙️ Alineación" initialOpen={false}>
                            <SelectControl
                                label="Alineación"
                                value={attributes.alignment}
                                options={[
                                    { label: 'Izquierda', value: 'left' },
                                    { label: 'Centro', value: 'center' },
                                    { label: 'Derecha', value: 'right' },
                                ]}
                                onChange={(value) => setAttributes({ alignment: value })}
                            />
                            
                            <SelectControl
                                label="Ancho del botón"
                                value={attributes.width}
                                options={[
                                    { label: 'Automático', value: 'auto' },
                                    { label: '100% (ancho completo)', value: '100%' },
                                    { label: '50%', value: '50%' },
                                ]}
                                onChange={(value) => setAttributes({ width: value })}
                            />
                        </PanelBody>
                    </InspectorControls>
                    
                    <div style={{ textAlign: attributes.alignment }}>
                        <a 
                            className="gp-luxury-button-preview"
                            style={{
                                display: 'inline-block',
                                backgroundColor: attributes.backgroundColor,
                                color: attributes.textColor,
                                border: `${attributes.borderWidth}px solid ${attributes.borderColor}`,
                                borderRadius: `${attributes.borderRadius}px`,
                                padding: `${attributes.paddingTop}px ${attributes.paddingRight}px ${attributes.paddingBottom}px ${attributes.paddingLeft}px`,
                                fontSize: `${attributes.fontSize}px`,
                                fontWeight: attributes.fontWeight,
                                letterSpacing: `${attributes.letterSpacing}px`,
                                cursor: 'pointer',
                                textDecoration: 'none',
                                width: attributes.width,
                            }}
                        >
                            {attributes.text}
                        </a>
                    </div>
                </Fragment>
            );
        },
        
        save: function() {
            return null; // Renderizado en PHP
        }
    });
    
    // ========================================
    // BLOQUE 2: TARJETA DE COLECCIÓN
    // ========================================
    registerBlockType('golden-phoenix/collection-card', {
        title: '🖼️ Tarjeta de Colección',
        icon: 'images-alt2',
        category: 'design',
        description: 'Tarjeta con imagen, título, descripción y botón',
        
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="🖼️ Imagen" initialOpen={true}>
                            <MediaUpload
                                onSelect={(media) => setAttributes({ imageUrl: media.url })}
                                type="image"
                                value={attributes.imageUrl}
                                render={({ open }) => (
                                    <Button onClick={open} isSecondary>
                                        {attributes.imageUrl ? 'Cambiar Imagen' : 'Seleccionar Imagen'}
                                    </Button>
                                )}
                            />
                            {attributes.imageUrl && (
                                <img src={attributes.imageUrl} style={{ width: '100%', marginTop: '10px' }} />
                            )}
                        </PanelBody>
                        
                        <PanelBody title="📝 Contenido" initialOpen={true}>
                            <TextControl
                                label="Título"
                                value={attributes.title}
                                onChange={(value) => setAttributes({ title: value })}
                            />
                            
                            <TextControl
                                label="Descripción"
                                value={attributes.description}
                                onChange={(value) => setAttributes({ description: value })}
                            />
                            
                            <TextControl
                                label="Texto del botón"
                                value={attributes.buttonText}
                                onChange={(value) => setAttributes({ buttonText: value })}
                            />
                            
                            <TextControl
                                label="URL del botón"
                                value={attributes.buttonUrl}
                                onChange={(value) => setAttributes({ buttonUrl: value })}
                            />
                        </PanelBody>
                        
                        <PanelBody title="🎨 Colores" initialOpen={false}>
                            <p><strong>Color del título:</strong></p>
                            <ColorPicker
                                color={attributes.titleColor}
                                onChangeComplete={(value) => setAttributes({ titleColor: value.hex })}
                            />
                            
                            <p><strong>Color de descripción:</strong></p>
                            <ColorPicker
                                color={attributes.descColor}
                                onChangeComplete={(value) => setAttributes({ descColor: value.hex })}
                            />
                            
                            <p><strong>Color de fondo:</strong></p>
                            <ColorPicker
                                color={attributes.backgroundColor}
                                onChangeComplete={(value) => setAttributes({ backgroundColor: value.hex })}
                            />
                            
                            <p><strong>Color del borde:</strong></p>
                            <ColorPicker
                                color={attributes.borderColor}
                                onChangeComplete={(value) => setAttributes({ borderColor: value.hex })}
                            />
                        </PanelBody>
                        
                        <PanelBody title="📐 Espaciado" initialOpen={false}>
                            <RangeControl
                                label="Grosor del borde (px)"
                                value={attributes.borderWidth}
                                onChange={(value) => setAttributes({ borderWidth: value })}
                                min={0}
                                max={10}
                            />
                            
                            <RangeControl
                                label="Padding interno (px)"
                                value={attributes.padding}
                                onChange={(value) => setAttributes({ padding: value })}
                                min={0}
                                max={50}
                            />
                        </PanelBody>
                    </InspectorControls>
                    
                    <div 
                        className="gp-collection-card-preview"
                        style={{
                            backgroundColor: attributes.backgroundColor,
                            border: `${attributes.borderWidth}px solid ${attributes.borderColor}`,
                            padding: `${attributes.padding}px`,
                            textAlign: 'center'
                        }}
                    >
                        {attributes.imageUrl && <img src={attributes.imageUrl} style={{ width: '100%' }} />}
                        <h3 style={{ color: attributes.titleColor, margin: '20px 0 10px' }}>{attributes.title}</h3>
                        <p style={{ color: attributes.descColor, margin: '0 0 20px' }}>{attributes.description}</p>
                        <span style={{ display: 'inline-block', padding: '12px 35px', border: `1px solid ${attributes.titleColor}`, color: attributes.titleColor }}>
                            {attributes.buttonText}
                        </span>
                    </div>
                </Fragment>
            );
        },
        
        save: function() {
            return null; // Renderizado en PHP
        }
    });
    
})(window.wp);
