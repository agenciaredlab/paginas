/**
 * Maison Luxe Jewelry - Main JavaScript
 * @package Maison_Luxe
 */

(function($) {
    'use strict';

    /**
     * Document Ready
     */
    $(document).ready(function() {
        
        // Inicializar funciones
        initPreloader();
        initHeaderScroll();
        initSmoothScroll();
        initParallax();
        initProductQuickView();
        initWishlist();
        initNewsletterForm();
        initMobileMenu();
        initSearchOverlay();
        initBackToTop();
        initAnimations();
        initProductGallery();
        
    });

    /**
     * Preloader
     */
    function initPreloader() {
        $(window).on('load', function() {
            setTimeout(function() {
                $('.luxury-loader').fadeOut(500);
            }, 1000);
        });
    }

    /**
     * Header Scroll Effect
     */
    function initHeaderScroll() {
        let lastScroll = 0;
        const header = $('.site-header');
        
        $(window).on('scroll', function() {
            const currentScroll = $(this).scrollTop();
            
            if (currentScroll > 100) {
                header.addClass('scrolled');
            } else {
                header.removeClass('scrolled');
            }
            
            // Hide header on scroll down, show on scroll up
            if (currentScroll > lastScroll && currentScroll > 500) {
                header.css('transform', 'translateY(-100%)');
            } else {
                header.css('transform', 'translateY(0)');
            }
            
            lastScroll = currentScroll;
        });
    }

    /**
     * Smooth Scroll
     */
    function initSmoothScroll() {
        $('a[href^="#"]').not('[href="#"]').on('click', function(e) {
            e.preventDefault();
            
            const target = $(this.getAttribute('href'));
            
            if (target.length) {
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 100
                }, 1000, 'easeInOutExpo');
            }
        });
    }

    /**
     * Parallax Effect
     */
    function initParallax() {
        const parallaxSections = $('.parallax-section');
        
        if (parallaxSections.length) {
            $(window).on('scroll', function() {
                const scrolled = $(window).scrollTop();
                
                parallaxSections.each(function() {
                    const $this = $(this);
                    const parallaxBg = $this.find('.parallax-bg');
                    const sectionTop = $this.offset().top;
                    const sectionHeight = $this.outerHeight();
                    
                    if (scrolled > sectionTop - $(window).height() && scrolled < sectionTop + sectionHeight) {
                        const offset = (scrolled - sectionTop) * 0.5;
                        parallaxBg.css('transform', 'translateY(' + offset + 'px)');
                    }
                });
            });
        }
    }

    /**
     * Product Quick View
     */
    function initProductQuickView() {
        $('.product-quick-view').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productCard = $(this).closest('.product-card');
            const productName = productCard.find('.product-name').text();
            const productPrice = productCard.find('.product-price').text();
            const productImage = productCard.find('.product-image').attr('src');
            
            // Aquí puedes abrir un modal con los detalles del producto
            console.log('Quick view:', productName);
            
            // Ejemplo de modal simple
            showQuickViewModal(productName, productPrice, productImage);
        });
    }

    /**
     * Show Quick View Modal
     */
    function showQuickViewModal(name, price, image) {
        const modal = `
            <div class="quick-view-modal" id="quickViewModal">
                <div class="quick-view-overlay"></div>
                <div class="quick-view-content">
                    <button class="quick-view-close">&times;</button>
                    <div class="quick-view-grid">
                        <div class="quick-view-image">
                            <img src="${image}" alt="${name}">
                        </div>
                        <div class="quick-view-info">
                            <h2>${name}</h2>
                            <p class="quick-view-price">${price}</p>
                            <div class="quick-view-actions">
                                <button class="btn-luxury">Agregar a la Bolsa</button>
                                <button class="btn-luxury btn-outline">Ver Detalles</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modal);
        
        setTimeout(() => {
            $('#quickViewModal').addClass('active');
        }, 10);
        
        // Cerrar modal
        $('.quick-view-close, .quick-view-overlay').on('click', function() {
            $('#quickViewModal').removeClass('active');
            setTimeout(() => {
                $('#quickViewModal').remove();
            }, 300);
        });
    }

    /**
     * Wishlist Functionality
     */
    function initWishlist() {
        let wishlistItems = [];
        
        $('.product-wishlist').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $this = $(this);
            const productCard = $this.closest('.product-card');
            const productId = productCard.data('product-id') || Date.now();
            
            if ($this.hasClass('active')) {
                // Remove from wishlist
                $this.removeClass('active');
                $this.html('♡');
                wishlistItems = wishlistItems.filter(id => id !== productId);
            } else {
                // Add to wishlist
                $this.addClass('active');
                $this.html('♥');
                wishlistItems.push(productId);
                
                // Animación
                $this.addClass('animate-heart');
                setTimeout(() => {
                    $this.removeClass('animate-heart');
                }, 600);
            }
            
            // Update counter
            updateWishlistCounter(wishlistItems.length);
            
            // Save to localStorage
            localStorage.setItem('maisonLuxeWishlist', JSON.stringify(wishlistItems));
        });
        
        // Load wishlist from localStorage
        const savedWishlist = localStorage.getItem('maisonLuxeWishlist');
        if (savedWishlist) {
            wishlistItems = JSON.parse(savedWishlist);
            updateWishlistCounter(wishlistItems.length);
            
            // Mark saved items
            wishlistItems.forEach(id => {
                $(`.product-card[data-product-id="${id}"] .product-wishlist`).addClass('active').html('♥');
            });
        }
    }

    /**
     * Update Wishlist Counter
     */
    function updateWishlistCounter(count) {
        const counter = $('.wishlist-count');
        counter.text(count);
        
        if (count > 0) {
            counter.addClass('has-items');
        } else {
            counter.removeClass('has-items');
        }
    }

    /**
     * Newsletter Form
     */
    function initNewsletterForm() {
        $('.newsletter-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $input = $form.find('input[type="email"]');
            const $button = $form.find('button[type="submit"]');
            const email = $input.val();
            
            if (!isValidEmail(email)) {
                showNotification('Por favor ingresa un email válido', 'error');
                return;
            }
            
            // Disable button
            $button.prop('disabled', true).text('Procesando...');
            
            // AJAX request
            $.ajax({
                url: maisonLuxeData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'newsletter_subscribe',
                    nonce: maisonLuxeData.nonce,
                    email: email
                },
                success: function(response) {
                    if (response.success) {
                        showNotification(response.data.message, 'success');
                        $input.val('');
                    } else {
                        showNotification(response.data.message, 'error');
                    }
                },
                error: function() {
                    showNotification('Hubo un error. Por favor intenta de nuevo.', 'error');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Suscribirse');
                }
            });
        });
    }

    /**
     * Validate Email
     */
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    /**
     * Show Notification
     */
    function showNotification(message, type) {
        const notification = `
            <div class="luxury-notification ${type}">
                <span>${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `;
        
        $('body').append(notification);
        
        setTimeout(() => {
            $('.luxury-notification').addClass('show');
        }, 10);
        
        // Auto hide
        setTimeout(() => {
            hideNotification();
        }, 5000);
        
        // Close button
        $('.notification-close').on('click', hideNotification);
    }

    /**
     * Hide Notification
     */
    function hideNotification() {
        $('.luxury-notification').removeClass('show');
        setTimeout(() => {
            $('.luxury-notification').remove();
        }, 300);
    }

    /**
     * Mobile Menu
     */
    function initMobileMenu() {
        $('.mobile-menu-toggle').on('click', function() {
            $('#mobileMenu').addClass('active');
            $('body').css('overflow', 'hidden');
        });
        
        $('.mobile-menu-close').on('click', function() {
            $('#mobileMenu').removeClass('active');
            $('body').css('overflow', '');
        });
        
        // Close on overlay click
        $('#mobileMenu').on('click', function(e) {
            if ($(e.target).is('#mobileMenu')) {
                $(this).removeClass('active');
                $('body').css('overflow', '');
            }
        });
    }

    /**
     * Search Overlay
     */
    function initSearchOverlay() {
        $('.search-toggle').on('click', function() {
            $('#searchOverlay').addClass('active');
            setTimeout(() => {
                $('.search-input-overlay').focus();
            }, 300);
        });
        
        $('.search-close, .search-overlay').on('click', function(e) {
            if ($(e.target).is('.search-overlay') || $(e.target).is('.search-close')) {
                $('#searchOverlay').removeClass('active');
            }
        });
        
        // Close with ESC key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('#searchOverlay').removeClass('active');
                $('#mobileMenu').removeClass('active');
                $('body').css('overflow', '');
            }
        });
    }

    /**
     * Back to Top
     */
    function initBackToTop() {
        const backToTop = $('#backToTop');
        
        $(window).on('scroll', function() {
            if ($(this).scrollTop() > 500) {
                backToTop.addClass('visible');
            } else {
                backToTop.removeClass('visible');
            }
        });
        
        backToTop.on('click', function() {
            $('html, body').animate({ scrollTop: 0 }, 1000, 'easeInOutExpo');
        });
    }

    /**
     * Scroll Animations
     */
    function initAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };
        
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver(function(entries) {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        $(entry.target).addClass('fade-in-up');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);
            
            $('.collection-card, .product-card, .testimonial-card').each(function() {
                observer.observe(this);
            });
        } else {
            // Fallback for older browsers
            $('.collection-card, .product-card, .testimonial-card').addClass('fade-in-up');
        }
    }

    /**
     * Product Gallery (si usas WooCommerce)
     */
    function initProductGallery() {
        if (typeof $.fn.zoom !== 'undefined') {
            $('.woocommerce-product-gallery__image').zoom();
        }
    }

    /**
     * Add easing function
     */
    $.extend($.easing, {
        easeInOutExpo: function(x, t, b, c, d) {
            if (t == 0) return b;
            if (t == d) return b + c;
            if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
            return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
        }
    });

})(jQuery);

/**
 * Vanilla JS - Stats Counter Animation
 */
document.addEventListener('DOMContentLoaded', function() {
    const stats = document.querySelectorAll('.stat-number');
    
    if (stats.length > 0 && 'IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        stats.forEach(stat => observer.observe(stat));
    }
});

function animateCounter(element) {
    const finalValue = element.textContent;
    const isYear = finalValue.includes('1892');
    const hasPlus = finalValue.includes('+');
    const hasK = finalValue.includes('k');
    const numericValue = parseInt(finalValue.replace(/\D/g, ''));
    
    let currentValue = 0;
    const increment = isYear ? 10 : Math.ceil(numericValue / 50);
    const duration = 2000;
    const stepTime = duration / (numericValue / increment);
    
    const counter = setInterval(() => {
        currentValue += increment;
        if (currentValue >= numericValue) {
            currentValue = numericValue;
            clearInterval(counter);
        }
        
        let displayValue = currentValue.toString();
        if (hasK) displayValue += 'k';
        if (hasPlus) displayValue += '+';
        
        element.textContent = displayValue;
    }, stepTime);
}

/**
 * Add CSS for animations
 */
const style = document.createElement('style');
style.textContent = `
    /* Quick View Modal */
    .quick-view-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99999;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
    }
    
    .quick-view-modal.active {
        opacity: 1;
        visibility: visible;
    }
    
    .quick-view-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(10, 10, 10, 0.95);
    }
    
    .quick-view-content {
        position: relative;
        z-index: 2;
        max-width: 1000px;
        margin: 5% auto;
        background: var(--white-pure);
        padding: 3rem;
        transform: scale(0.9);
        transition: transform 0.3s ease;
    }
    
    .quick-view-modal.active .quick-view-content {
        transform: scale(1);
    }
    
    .quick-view-close {
        position: absolute;
        top: 1rem;
        right: 1rem;
        background: none;
        border: none;
        font-size: 2rem;
        color: var(--gold-primary);
        cursor: pointer;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.3s ease;
    }
    
    .quick-view-close:hover {
        transform: rotate(90deg);
    }
    
    .quick-view-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 3rem;
    }
    
    .quick-view-image img {
        width: 100%;
        height: auto;
    }
    
    .quick-view-info h2 {
        font-family: var(--font-heading);
        color: var(--black-deep);
        margin-bottom: 1rem;
    }
    
    .quick-view-price {
        font-family: var(--font-accent);
        font-size: 2rem;
        color: var(--gold-primary);
        margin-bottom: 2rem;
    }
    
    .quick-view-actions {
        display: flex;
        gap: 1rem;
        flex-direction: column;
    }
    
    /* Notification */
    .luxury-notification {
        position: fixed;
        top: 100px;
        right: -400px;
        max-width: 350px;
        background: var(--white-pure);
        padding: 1.5rem 2rem;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        transition: right 0.3s ease;
        border-left: 4px solid var(--gold-primary);
    }
    
    .luxury-notification.show {
        right: 2rem;
    }
    
    .luxury-notification.error {
        border-left-color: #E74C3C;
    }
    
    .luxury-notification.success {
        border-left-color: #2ECC71;
    }
    
    .notification-close {
        background: none;
        border: none;
        font-size: 1.5rem;
        color: var(--black-soft);
        cursor: pointer;
        opacity: 0.5;
        transition: opacity 0.3s ease;
    }
    
    .notification-close:hover {
        opacity: 1;
    }
    
    /* Wishlist Animation */
    @keyframes heartBeat {
        0%, 100% { transform: scale(1); }
        25% { transform: scale(1.3); }
        50% { transform: scale(1.1); }
        75% { transform: scale(1.2); }
    }
    
    .product-wishlist.animate-heart {
        animation: heartBeat 0.6s ease;
    }
    
    .product-wishlist.active {
        color: var(--gold-primary);
    }
`;
document.head.appendChild(style);
