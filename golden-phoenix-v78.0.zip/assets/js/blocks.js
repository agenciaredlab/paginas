/**
 * Golden Phoenix Jewelry - Bloques de Gutenberg
 * Registro de bloques personalizados para el editor
 */

(function() {
    const { registerBlockType } = wp.blocks;
    const { InspectorControls, MediaUpload, RichText } = wp.blockEditor || wp.editor;
    const { PanelBody, TextControl, ToggleControl, SelectControl, RangeControl, Button } = wp.components;
    const { Fragment } = wp.element;

    /**
     * Bloque: Hero Section
     */
    registerBlockType('golden-phoenix/hero', {
        title: 'Hero Section Luxury',
        icon: 'format-image',
        category: 'golden-phoenix',
        attributes: {
            title: { type: 'string', default: 'Elegancia Eterna' },
            subtitle: { type: 'string', default: 'Colección Exclusiva 2025' },
            description: { type: 'string', default: 'Descubre piezas únicas...' },
            backgroundImage: { type: 'string', default: '' },
            buttonText: { type: 'string', default: 'Explorar Colección' },
            buttonUrl: { type: 'string', default: '#collections' }
        },
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="Configuración del Hero">
                            <TextControl
                                label="Subtítulo"
                                value={attributes.subtitle}
                                onChange={(value) => setAttributes({ subtitle: value })}
                            />
                            <TextControl
                                label="Título"
                                value={attributes.title}
                                onChange={(value) => setAttributes({ title: value })}
                            />
                            <TextControl
                                label="Descripción"
                                value={attributes.description}
                                onChange={(value) => setAttributes({ description: value })}
                            />
                            <TextControl
                                label="Texto del Botón"
                                value={attributes.buttonText}
                                onChange={(value) => setAttributes({ buttonText: value })}
                            />
                            <TextControl
                                label="URL del Botón"
                                value={attributes.buttonUrl}
                                onChange={(value) => setAttributes({ buttonUrl: value })}
                            />
                            <MediaUpload
                                onSelect={(media) => setAttributes({ backgroundImage: media.url })}
                                type="image"
                                value={attributes.backgroundImage}
                                render={({ open }) => (
                                    <Button onClick={open} isDefault>
                                        {attributes.backgroundImage ? 'Cambiar Imagen' : 'Seleccionar Imagen'}
                                    </Button>
                                )}
                            />
                        </PanelBody>
                    </InspectorControls>

                    <div className="gp-hero-block-preview" style={{
                        backgroundImage: attributes.backgroundImage ? `url(${attributes.backgroundImage})` : 'none',
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        minHeight: '400px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        padding: '40px',
                        position: 'relative'
                    }}>
                        <div style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            background: 'rgba(0,0,0,0.5)'
                        }}></div>
                        <div style={{ position: 'relative', textAlign: 'center', zIndex: 2 }}>
                            <p style={{ fontSize: '14px', letterSpacing: '0.3em', textTransform: 'uppercase', color: '#D4AF37' }}>
                                {attributes.subtitle}
                            </p>
                            <h1 style={{ fontSize: '48px', margin: '20px 0' }}>{attributes.title}</h1>
                            <p style={{ fontSize: '18px', marginBottom: '30px' }}>{attributes.description}</p>
                            <button style={{
                                background: 'linear-gradient(135deg, #D4AF37, #B8941E)',
                                color: '#0A0A0A',
                                padding: '15px 40px',
                                border: 'none',
                                fontSize: '14px',
                                letterSpacing: '0.2em',
                                textTransform: 'uppercase'
                            }}>
                                {attributes.buttonText}
                            </button>
                        </div>
                    </div>
                </Fragment>
            );
        },
        save: function() {
            return null; // Renderizado dinámico desde PHP
        }
    });

    /**
     * Bloque: Productos Destacados
     */
    registerBlockType('golden-phoenix/featured-products', {
        title: 'Productos Destacados',
        icon: 'products',
        category: 'golden-phoenix',
        attributes: {
            limit: { type: 'number', default: 8 },
            columns: { type: 'number', default: 4 },
            showQuickView: { type: 'boolean', default: true },
            showWishlist: { type: 'boolean', default: true }
        },
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="Configuración de Productos">
                            <RangeControl
                                label="Número de Productos"
                                value={attributes.limit}
                                onChange={(value) => setAttributes({ limit: value })}
                                min={1}
                                max={20}
                            />
                            <RangeControl
                                label="Columnas"
                                value={attributes.columns}
                                onChange={(value) => setAttributes({ columns: value })}
                                min={1}
                                max={6}
                            />
                            <ToggleControl
                                label="Mostrar Quick View"
                                checked={attributes.showQuickView}
                                onChange={(value) => setAttributes({ showQuickView: value })}
                            />
                            <ToggleControl
                                label="Mostrar Wishlist"
                                checked={attributes.showWishlist}
                                onChange={(value) => setAttributes({ showWishlist: value })}
                            />
                        </PanelBody>
                    </InspectorControls>

                    <div className="gp-products-block-preview" style={{ padding: '20px', background: '#f0f0f0', textAlign: 'center' }}>
                        <h3>📦 Productos Destacados</h3>
                        <p>Mostrando {attributes.limit} productos en {attributes.columns} columnas</p>
                        <p><small>La vista previa se mostrará en el frontend</small></p>
                    </div>
                </Fragment>
            );
        },
        save: function() {
            return null;
        }
    });

    /**
     * Bloque: Colecciones Grid
     */
    registerBlockType('golden-phoenix/collections-grid', {
        title: 'Grid de Colecciones',
        icon: 'grid-view',
        category: 'golden-phoenix',
        attributes: {
            limit: { type: 'number', default: 3 },
            layout: { type: 'string', default: 'grid' }
        },
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="Configuración de Colecciones">
                            <RangeControl
                                label="Número de Colecciones"
                                value={attributes.limit}
                                onChange={(value) => setAttributes({ limit: value })}
                                min={1}
                                max={12}
                            />
                            <SelectControl
                                label="Layout"
                                value={attributes.layout}
                                options={[
                                    { label: 'Grid', value: 'grid' },
                                    { label: 'Slider', value: 'slider' }
                                ]}
                                onChange={(value) => setAttributes({ layout: value })}
                            />
                        </PanelBody>
                    </InspectorControls>

                    <div style={{ padding: '20px', background: '#f0f0f0', textAlign: 'center' }}>
                        <h3>💎 Grid de Colecciones</h3>
                        <p>Mostrando {attributes.limit} colecciones en layout {attributes.layout}</p>
                    </div>
                </Fragment>
            );
        },
        save: function() {
            return null;
        }
    });

    /**
     * Bloque: Newsletter
     */
    registerBlockType('golden-phoenix/newsletter', {
        title: 'Newsletter Luxury',
        icon: 'email',
        category: 'golden-phoenix',
        attributes: {
            title: { type: 'string', default: 'Únete a Nuestro Círculo Exclusivo' },
            description: { type: 'string', default: 'Recibe acceso anticipado...' },
            placeholder: { type: 'string', default: 'Tu correo electrónico' }
        },
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="Configuración del Newsletter">
                            <TextControl
                                label="Título"
                                value={attributes.title}
                                onChange={(value) => setAttributes({ title: value })}
                            />
                            <TextControl
                                label="Descripción"
                                value={attributes.description}
                                onChange={(value) => setAttributes({ description: value })}
                            />
                            <TextControl
                                label="Placeholder del Input"
                                value={attributes.placeholder}
                                onChange={(value) => setAttributes({ placeholder: value })}
                            />
                        </PanelBody>
                    </InspectorControls>

                    <div style={{ background: '#0A0A0A', color: 'white', padding: '60px 20px', textAlign: 'center' }}>
                        <h2 style={{ color: 'white', marginBottom: '20px' }}>{attributes.title}</h2>
                        <p style={{ marginBottom: '30px' }}>{attributes.description}</p>
                        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', maxWidth: '600px', margin: '0 auto' }}>
                            <input type="email" placeholder={attributes.placeholder} style={{ flex: 1, padding: '15px', background: 'rgba(255,255,255,0.1)', border: '1px solid #D4AF37', color: 'white' }} />
                            <button style={{ padding: '15px 40px', background: '#D4AF37', color: '#0A0A0A', border: 'none' }}>Suscribirse</button>
                        </div>
                    </div>
                </Fragment>
            );
        },
        save: function() {
            return null;
        }
    });

    /**
     * Bloque: Botón Luxury
     */
    registerBlockType('golden-phoenix/button', {
        title: 'Botón Luxury',
        icon: 'button',
        category: 'golden-phoenix',
        attributes: {
            text: { type: 'string', default: 'Ver Más' },
            url: { type: 'string', default: '#' },
            style: { type: 'string', default: 'primary' },
            size: { type: 'string', default: 'medium' }
        },
        edit: function(props) {
            const { attributes, setAttributes } = props;
            
            return (
                <Fragment>
                    <InspectorControls>
                        <PanelBody title="Configuración del Botón">
                            <TextControl
                                label="Texto"
                                value={attributes.text}
                                onChange={(value) => setAttributes({ text: value })}
                            />
                            <TextControl
                                label="URL"
                                value={attributes.url}
                                onChange={(value) => setAttributes({ url: value })}
                            />
                            <SelectControl
                                label="Estilo"
                                value={attributes.style}
                                options={[
                                    { label: 'Primario (Dorado)', value: 'primary' },
                                    { label: 'Outline', value: 'outline' },
                                    { label: 'Negro', value: 'dark' }
                                ]}
                                onChange={(value) => setAttributes({ style: value })}
                            />
                            <SelectControl
                                label="Tamaño"
                                value={attributes.size}
                                options={[
                                    { label: 'Pequeño', value: 'small' },
                                    { label: 'Mediano', value: 'medium' },
                                    { label: 'Grande', value: 'large' }
                                ]}
                                onChange={(value) => setAttributes({ size: value })}
                            />
                        </PanelBody>
                    </InspectorControls>

                    <div style={{ padding: '20px', textAlign: 'center' }}>
                        <button style={{
                            background: attributes.style === 'primary' ? 'linear-gradient(135deg, #D4AF37, #B8941E)' : 
                                       attributes.style === 'outline' ? 'transparent' : '#0A0A0A',
                            color: attributes.style === 'outline' ? '#D4AF37' : '#0A0A0A',
                            border: attributes.style === 'outline' ? '2px solid #D4AF37' : 'none',
                            padding: attributes.size === 'small' ? '10px 25px' : 
                                    attributes.size === 'large' ? '20px 60px' : '15px 40px',
                            fontSize: attributes.size === 'small' ? '12px' : 
                                     attributes.size === 'large' ? '16px' : '14px',
                            letterSpacing: '0.2em',
                            textTransform: 'uppercase',
                            cursor: 'pointer'
                        }}>
                            {attributes.text}
                        </button>
                    </div>
                </Fragment>
            );
        },
        save: function() {
            return null;
        }
    });

})();
