<?php
/**
 * V76 - PRE-ORDERS
 * Permite pre-ordenar productos no disponibles
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_product_options_inventory_product_data', function() {
    woocommerce_wp_checkbox(array(
        'id' => '_allow_preorder',
        'label' => 'Permitir Pre-Orden',
        'description' => 'Vender aunque no esté en stock'
    ));
    
    woocommerce_wp_text_input(array(
        'id' => '_preorder_date',
        'label' => 'Fecha Disponibilidad',
        'type' => 'date',
        'description' => 'Cuándo estará disponible'
    ));
});

add_action('woocommerce_process_product_meta', function($post_id) {
    update_post_meta($post_id, '_allow_preorder', isset($_POST['_allow_preorder']) ? 'yes' : 'no');
    update_post_meta($post_id, '_preorder_date', sanitize_text_field($_POST['_preorder_date']));
});

add_filter('woocommerce_product_is_in_stock', function($is_in_stock, $product) {
    if (get_post_meta($product->get_id(), '_allow_preorder', true) === 'yes') {
        return true;
    }
    return $is_in_stock;
}, 10, 2);

add_action('woocommerce_before_add_to_cart_button', function() {
    global $product;
    
    if (get_post_meta($product->get_id(), '_allow_preorder', true) === 'yes') {
        $date = get_post_meta($product->get_id(), '_preorder_date', true);
        ?>
        <div style="background: #FFF3CD; border-left: 4px solid #FFC107; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
            <strong>📅 Pre-Orden</strong>
            <p style="margin: 5px 0 0 0;">Este producto estará disponible el <?php echo date('d/m/Y', strtotime($date)); ?></p>
        </div>
        <?php
    }
});
