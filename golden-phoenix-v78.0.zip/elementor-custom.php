<?php
/**
 * WIDGETS ELEMENTOR PERSONALIZADOS - GOLDEN PHOENIX V61
 * Widgets 100% editables para Elementor FREE
 */

if (!defined('ABSPATH')) exit;

// Registrar widgets personalizados de Elementor
add_action('elementor/widgets/register', 'gp_register_elementor_widgets');

function gp_register_elementor_widgets($widgets_manager) {
    
    // Widget 1: Botón Luxury
    require_once(__DIR__ . '/elementor-widgets/luxury-button.php');
    $widgets_manager->register(new \GP_Elementor_Luxury_Button());
    
    // Widget 2: Tarjeta de Colección
    require_once(__DIR__ . '/elementor-widgets/collection-card.php');
    $widgets_manager->register(new \GP_Elementor_Collection_Card());
    
    // Widget 3: Hero Section
    require_once(__DIR__ . '/elementor-widgets/hero-section.php');
    $widgets_manager->register(new \GP_Elementor_Hero_Section());
}

// Agregar categoría personalizada en Elementor
add_action('elementor/elements/categories_registered', function($elements_manager) {
    $elements_manager->add_category(
        'golden-phoenix',
        [
            'title' => '✨ Golden Phoenix',
            'icon' => 'fa fa-gem',
        ]
    );
});
