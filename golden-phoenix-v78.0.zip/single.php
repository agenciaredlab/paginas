<?php
/**
 * Single Post Template
 * Plantilla para post individual de blog
 */

get_header();
?>

<?php while (have_posts()): the_post(); ?>

<article class="single-post-wrapper" style="background: #1a1a1a; min-height: 100vh; padding: 80px 0;">
    
    <div class="container" style="max-width: 900px; margin: 0 auto; padding: 0 20px;">
        
        <!-- HEADER DEL POST -->
        <header class="post-header" style="margin-bottom: 40px; text-align: center;">
            
            <!-- CATEGORÍA -->
            <div class="post-categories" style="margin-bottom: 20px;">
                <?php
                $categories = get_the_category();
                if ($categories) {
                    foreach ($categories as $category) {
                        echo '<a href="' . get_category_link($category->term_id) . '" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 8px 20px; border-radius: 50px; text-decoration: none; font-size: 13px; font-weight: 600; margin: 0 5px;">' . esc_html($category->name) . '</a>';
                    }
                }
                ?>
            </div>
            
            <!-- TÍTULO -->
            <h1 class="post-title" style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 25px; line-height: 1.2;">
                <?php the_title(); ?>
            </h1>
            
            <!-- META -->
            <div class="post-meta" style="display: flex; justify-content: center; gap: 30px; color: #999; font-size: 15px;">
                <span>📅 <?php echo get_the_date(); ?></span>
                <span>👤 <?php the_author(); ?></span>
                <span>💬 <?php comments_number('0 comentarios', '1 comentario', '% comentarios'); ?></span>
                <span>⏱️ <?php echo ceil(str_word_count(get_the_content()) / 200); ?> min lectura</span>
            </div>
            
        </header>
        
        <!-- IMAGEN DESTACADA -->
        <?php if (has_post_thumbnail()): ?>
            <div class="post-featured-image" style="margin-bottom: 50px; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto; display: block;')); ?>
            </div>
        <?php endif; ?>
        
        <!-- CONTENIDO -->
        <div class="post-content" style="color: #ccc; font-size: 18px; line-height: 1.8; margin-bottom: 60px;">
            <?php the_content(); ?>
        </div>
        
        <!-- TAGS -->
        <?php if (has_tag()): ?>
            <div class="post-tags" style="margin-bottom: 40px; padding: 30px; background: rgba(255,255,255,0.05); border-radius: 15px;">
                <h4 style="color: #c9a961; font-size: 16px; margin: 0 0 15px;">🏷️ Etiquetas:</h4>
                <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                    <?php
                    $tags = get_the_tags();
                    if ($tags) {
                        foreach ($tags as $tag) {
                            echo '<a href="' . get_tag_link($tag->term_id) . '" style="background: rgba(201,169,97,0.2); color: #c9a961; padding: 8px 16px; border-radius: 50px; text-decoration: none; font-size: 14px; transition: all 0.3s;">' . esc_html($tag->name) . '</a>';
                        }
                    }
                    ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- COMPARTIR -->
        <div class="post-share" style="margin-bottom: 60px; padding: 30px; background: rgba(255,255,255,0.05); border-radius: 15px; text-align: center;">
            <h4 style="color: #fff; font-size: 18px; margin: 0 0 20px;">Compartir este artículo</h4>
            <div style="display: flex; justify-content: center; gap: 15px;">
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" style="background: #3b5998; color: #fff; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 20px; transition: all 0.3s;">
                    📘
                </a>
                <a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>&text=<?php the_title(); ?>" target="_blank" style="background: #1da1f2; color: #fff; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 20px; transition: all 0.3s;">
                    🐦
                </a>
                <a href="https://wa.me/?text=<?php the_title(); ?> <?php the_permalink(); ?>" target="_blank" style="background: #25d366; color: #fff; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 20px; transition: all 0.3s;">
                    💬
                </a>
                <a href="mailto:?subject=<?php the_title(); ?>&body=<?php the_permalink(); ?>" style="background: #c9a961; color: #1a1a1a; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 20px; transition: all 0.3s;">
                    ✉️
                </a>
            </div>
        </div>
        
        <!-- NAVEGACIÓN POSTS -->
        <div class="post-navigation" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 60px;">
            
            <?php
            $prev_post = get_previous_post();
            $next_post = get_next_post();
            ?>
            
            <?php if ($prev_post): ?>
                <a href="<?php echo get_permalink($prev_post->ID); ?>" style="background: rgba(255,255,255,0.05); padding: 25px; border-radius: 15px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                    <div style="color: #c9a961; font-size: 13px; margin-bottom: 8px;">← Anterior</div>
                    <div style="color: #fff; font-size: 16px; font-weight: 600;"><?php echo get_the_title($prev_post->ID); ?></div>
                </a>
            <?php endif; ?>
            
            <?php if ($next_post): ?>
                <a href="<?php echo get_permalink($next_post->ID); ?>" style="background: rgba(255,255,255,0.05); padding: 25px; border-radius: 15px; text-decoration: none; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1); text-align: right;">
                    <div style="color: #c9a961; font-size: 13px; margin-bottom: 8px;">Siguiente →</div>
                    <div style="color: #fff; font-size: 16px; font-weight: 600;"><?php echo get_the_title($next_post->ID); ?></div>
                </a>
            <?php endif; ?>
            
        </div>
        
        <!-- COMENTARIOS -->
        <?php if (comments_open() || get_comments_number()): ?>
            <div class="post-comments" style="background: rgba(255,255,255,0.05); padding: 40px; border-radius: 15px;">
                <?php comments_template(); ?>
            </div>
        <?php endif; ?>
        
    </div>
    
</article>

<?php endwhile; ?>

<?php get_footer(); ?>
