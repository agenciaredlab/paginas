<?php
/**
 * V77 - VIRTUAL TRY-ON
 * Probador virtual básico con cámara
 */
if (!defined('ABSPATH')) exit;

add_action('woocommerce_product_thumbnails', function() {
    global $product;
    
    if (!has_term('anillos', 'product_cat', $product->get_id())) {
        return;
    }
    ?>
    
    <button type="button" onclick="document.getElementById('gp-virtual-tryon').style.display='flex'" style="width: 100%; padding: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; margin: 15px 0;">
        📸 Probador Virtual
    </button>
    
    <div id="gp-virtual-tryon" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 99999; align-items: center; justify-content: center; flex-direction: column; padding: 20px;">
        <button onclick="document.getElementById('gp-virtual-tryon').style.display='none'" style="position: absolute; top: 20px; right: 20px; background: white; border: none; width: 40px; height: 40px; border-radius: 50%; font-size: 24px; cursor: pointer;">×</button>
        
        <div style="background: white; padding: 30px; border-radius: 12px; max-width: 500px; text-align: center;">
            <h2 style="margin-top: 0;">📸 Probador Virtual</h2>
            
            <video id="gp-camera" autoplay style="width: 100%; border-radius: 8px; margin: 20px 0;"></video>
            
            <button onclick="gpStartCamera()" style="padding: 12px 30px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer; margin: 5px;">
                Activar Cámara
            </button>
            
            <button onclick="gpTakePhoto()" style="padding: 12px 30px; background: #D4AF37; color: white; border: none; border-radius: 6px; cursor: pointer; margin: 5px;">
                Tomar Foto
            </button>
            
            <canvas id="gp-canvas" style="display: none;"></canvas>
            <img id="gp-photo" style="width: 100%; border-radius: 8px; margin-top: 20px; display: none;">
        </div>
    </div>
    
    <script>
    var stream;
    
    function gpStartCamera() {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(s) {
                stream = s;
                document.getElementById('gp-camera').srcObject = stream;
            })
            .catch(function(err) {
                alert('Error al acceder a la cámara: ' + err);
            });
    }
    
    function gpTakePhoto() {
        var video = document.getElementById('gp-camera');
        var canvas = document.getElementById('gp-canvas');
        var photo = document.getElementById('gp-photo');
        
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        
        photo.src = canvas.toDataURL('image/png');
        photo.style.display = 'block';
        
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
    }
    </script>
    
    <?php
});
