<?php
/**
 * Archive Template
 * Plantilla para archivos de posts/categorías
 */

get_header();
?>

<div class="archive-wrapper" style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); min-height: 100vh; padding: 80px 0;">
    
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
        
        <!-- HEADER ARCHIVO -->
        <header class="archive-header" style="text-align: center; margin-bottom: 60px;">
            
            <?php if (is_category()): ?>
                <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 15px;">
                    📁 <?php single_cat_title(); ?>
                </h1>
                <p style="font-size: 18px; color: #999;">
                    <?php echo category_description(); ?>
                </p>
            
            <?php elseif (is_tag()): ?>
                <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 15px;">
                    🏷️ <?php single_tag_title(); ?>
                </h1>
            
            <?php elseif (is_author()): ?>
                <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 15px;">
                    👤 <?php echo get_the_author(); ?>
                </h1>
            
            <?php elseif (is_date()): ?>
                <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 15px;">
                    📅 <?php echo get_the_date('F Y'); ?>
                </h1>
            
            <?php else: ?>
                <h1 style="font-size: 48px; font-weight: 700; color: #fff; margin: 0 0 15px;">
                    📰 Archivo
                </h1>
            <?php endif; ?>
            
        </header>
        
        <?php if (have_posts()): ?>
            
            <!-- GRID DE POSTS -->
            <div class="posts-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 30px; margin-bottom: 60px;">
                
                <?php while (have_posts()): the_post(); ?>
                    
                    <article class="post-card" style="background: rgba(255,255,255,0.05); border-radius: 15px; overflow: hidden; transition: all 0.3s; border: 1px solid rgba(255,255,255,0.1);">
                        
                        <?php if (has_post_thumbnail()): ?>
                            <div class="post-thumbnail" style="height: 250px; overflow: hidden;">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s;')); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="post-content" style="padding: 25px;">
                            
                            <div class="post-meta" style="display: flex; gap: 15px; margin-bottom: 15px; font-size: 13px; color: #999;">
                                <span>📅 <?php echo get_the_date(); ?></span>
                                <span>👤 <?php the_author(); ?></span>
                            </div>
                            
                            <h2 class="post-title" style="font-size: 22px; font-weight: 600; margin: 0 0 15px;">
                                <a href="<?php the_permalink(); ?>" style="color: #fff; text-decoration: none; transition: color 0.3s;">
                                    <?php the_title(); ?>
                                </a>
                            </h2>
                            
                            <div class="post-excerpt" style="color: #ccc; font-size: 15px; line-height: 1.6; margin-bottom: 20px;">
                                <?php echo wp_trim_words(get_the_excerpt(), 20); ?>
                            </div>
                            
                            <a href="<?php the_permalink(); ?>" class="read-more" style="display: inline-block; background: linear-gradient(135deg, #c9a961 0%, #d4af37 100%); color: #1a1a1a; padding: 10px 25px; border-radius: 50px; text-decoration: none; font-weight: 600; font-size: 14px; transition: all 0.3s;">
                                Leer Más →
                            </a>
                            
                        </div>
                        
                    </article>
                    
                <?php endwhile; ?>
                
            </div>
            
            <!-- PAGINACIÓN -->
            <div class="pagination" style="display: flex; justify-content: center; gap: 10px;">
                <?php
                echo paginate_links(array(
                    'prev_text' => '← Anterior',
                    'next_text' => 'Siguiente →',
                    'type' => 'list',
                ));
                ?>
            </div>
            
        <?php else: ?>
            
            <!-- NO HAY POSTS -->
            <div style="text-align: center; padding: 80px 20px;">
                <div style="font-size: 64px; margin-bottom: 20px;">📭</div>
                <h2 style="color: #fff; font-size: 28px; margin: 0 0 15px;">No se encontraron publicaciones</h2>
                <p style="color: #999; font-size: 16px;">Intenta buscar algo diferente</p>
            </div>
            
        <?php endif; ?>
        
    </div>
    
</div>

<?php get_footer(); ?>
