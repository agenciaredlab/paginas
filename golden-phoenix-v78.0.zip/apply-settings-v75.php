<?php
/**
 * V75 - APLICAR CONFIGURACIONES DEL PANEL
 * Conecta el panel de settings con todas las funciones
 */

if (!defined('ABSPATH')) exit;

// ========================================
// WHATSAPP - Respetar configuración
// ========================================

add_filter('gp_whatsapp_enabled_check', function() {
    return get_option('gp_whatsapp_enabled', true);
});

add_filter('gp_whatsapp_number', function($default) {
    return get_option('gp_whatsapp_number', $default);
});

// ========================================
// BUNDLE DISCOUNTS - Usar % configurados
// ========================================

add_filter('gp_bundle_discount_percent', function($default, $quantity) {
    if (!get_option('gp_bundle_discount_enabled', true)) {
        return 0;
    }
    
    if ($quantity >= 5) {
        return get_option('gp_bundle_5_percent', 15);
    } elseif ($quantity >= 3) {
        return get_option('gp_bundle_3_percent', 10);
    } elseif ($quantity >= 2) {
        return get_option('gp_bundle_2_percent', 5);
    }
    
    return 0;
}, 10, 2);

// Actualizar función bundle discounts
remove_action('woocommerce_cart_calculate_fees', 'gp_apply_bundle_discount');

add_action('woocommerce_cart_calculate_fees', function($cart) {
    if (!get_option('gp_bundle_discount_enabled', true)) {
        return;
    }
    
    $item_count = $cart->get_cart_contents_count();
    $percent = apply_filters('gp_bundle_discount_percent', 0, $item_count);
    
    if ($percent > 0) {
        $discount = $cart->get_subtotal() * ($percent / 100);
        $cart->add_fee(sprintf('Descuento %d+ piezas (%d%%)', $item_count, $percent), -$discount);
    }
});

// ========================================
// ENGRAVING - Precio configurable
// ========================================

add_filter('gp_engraving_price', function($default) {
    return get_option('gp_engraving_price', 50000);
});

// ========================================
// MULTI-CURRENCY - On/Off
// ========================================

add_action('wp_head', function() {
    if (!get_option('gp_multicurrency_enabled', true)) {
        ?>
        <style>
        #gp-currency-header {
            display: none !important;
        }
        </style>
        <?php
    }
}, 999);

// ========================================
// ANALYTICS - Ocultar si desactivado
// ========================================

add_action('admin_menu', function() {
    if (!get_option('gp_analytics_enabled', true)) {
        remove_menu_page('gp-analytics');
    }
}, 999);

// ========================================
// CUSTOM BUILDER - Redirect si desactivado
// ========================================

add_action('template_redirect', function() {
    if (is_page('custom-jewelry-builder') && !get_option('gp_custom_builder_enabled', true)) {
        wp_redirect(home_url());
        exit;
    }
});

// ========================================
// GIFT FINDER - Redirect si desactivado
// ========================================

add_action('template_redirect', function() {
    if (is_page('gift-finder') && !get_option('gp_gift_finder_enabled', true)) {
        wp_redirect(home_url());
        exit;
    }
});

// ========================================
// NOTICE: CONFIGURAR EN PANEL
// ========================================

add_action('admin_notices', function() {
    $screen = get_current_screen();
    
    if ($screen->base === 'dashboard' && !get_option('gp_v75_configured')) {
        ?>
        <div class="notice notice-info is-dismissible">
            <h3>⚙️ Golden Phoenix V75 - Panel de Configuración</h3>
            <p>Todas las funciones ahora se configuran desde un solo lugar.</p>
            <p>
                <a href="<?php echo admin_url('admin.php?page=golden-phoenix-settings'); ?>" class="button button-primary">
                    Ir a Configuración
                </a>
                <a href="#" onclick="jQuery(this).closest('.notice').fadeOut(); jQuery.post(ajaxurl, {action: 'gp_dismiss_v75_notice'}); return false;" class="button">
                    Cerrar
                </a>
            </p>
        </div>
        <?php
    }
});

add_action('wp_ajax_gp_dismiss_v75_notice', function() {
    update_option('gp_v75_configured', true);
    wp_die();
});
