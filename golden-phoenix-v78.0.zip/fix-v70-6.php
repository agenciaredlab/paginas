<?php
/**
 * Golden Phoenix V70.6 - FIX CUSTOMIZER Y THEME BUILDER
 * Arregla: Variables CSS sincronizadas, Customizer guarda cambios, Theme Builder funcional
 */

if (!defined('ABSPATH')) exit;

// ========================================
// FIX 1: CUSTOMIZER CSS CON VARIABLES CORRECTAS
// ========================================

// Remover CSS antiguo que usa variables incorrectas
remove_action('wp_head', 'gp_customizer_css');

// Agregar nuevo CSS con variables correctas
add_action('wp_head', 'gp_v70_6_customizer_css_fixed', 999);

function gp_v70_6_customizer_css_fixed() {
    $primary_color = get_theme_mod('gp_primary_color', '#D4AF37');
    $secondary_color = get_theme_mod('gp_secondary_color', '#0A0A0A');
    $background_color = get_theme_mod('gp_background_color', '#FAF9F6');
    $header_bg = get_theme_mod('gp_header_bg_color', '#FFFFFF');
    $footer_bg = get_theme_mod('gp_footer_bg_color', '#0A0A0A');
    $button_color = get_theme_mod('gp_button_color', '#D4AF37');
    $link_color = get_theme_mod('gp_link_color', '#D4AF37');
    
    $font_headings = get_theme_mod('gp_font_headings', 'Playfair Display');
    $font_body = get_theme_mod('gp_font_body', 'Montserrat');
    
    ?>
    <style type="text/css" id="gp-v70-6-customizer-css">
    /* V70.6 - Customizer CSS SOLO si hay cambios */
    
    /* Variables CSS - SOLO sobrescribir si son diferentes */
    :root {
        <?php if ($primary_color !== '#D4AF37'): ?>
        --gold-primary: <?php echo esc_attr($primary_color); ?>;
        <?php endif; ?>
        <?php if ($secondary_color !== '#0A0A0A'): ?>
        --black-deep: <?php echo esc_attr($secondary_color); ?>;
        --gold-dark: <?php echo esc_attr($secondary_color); ?>;
        <?php endif; ?>
    }
    
    /* Body background - SOLO si es diferente del default */
    <?php if ($background_color !== '#FAF9F6' && $background_color !== '#FFFFFF'): ?>
    body {
        background-color: <?php echo esc_attr($background_color); ?>;
    }
    <?php endif; ?>
    
    /* Header */
    <?php if ($header_bg !== '#FFFFFF'): ?>
    .site-header {
        background-color: <?php echo esc_attr($header_bg); ?>;
    }
    <?php endif; ?>
    
    /* Footer */
    <?php if ($footer_bg !== '#0A0A0A'): ?>
    .site-footer {
        background-color: <?php echo esc_attr($footer_bg); ?>;
    }
    <?php endif; ?>
    
    /* Botones - SOLO si cambiaron */
    <?php if ($button_color !== '#D4AF37'): ?>
    .button,
    .btn-primary,
    .woocommerce button.button,
    .add_to_cart_button {
        background-color: <?php echo esc_attr($button_color); ?>;
        border-color: <?php echo esc_attr($button_color); ?>;
    }
    <?php endif; ?>
    
    /* Enlaces - SOLO si cambiaron */
    <?php if ($link_color !== '#D4AF37'): ?>
    a {
        color: <?php echo esc_attr($link_color); ?>;
    }
    <?php endif; ?>
    
    /* Fuentes - SOLO si cambiaron */
    <?php if ($font_headings !== 'Playfair Display'): ?>
    h1, h2, h3, h4, h5, h6 {
        font-family: '<?php echo esc_attr($font_headings); ?>', serif;
    }
    <?php endif; ?>
    
    <?php if ($font_body !== 'Montserrat'): ?>
    body, p {
        font-family: '<?php echo esc_attr($font_body); ?>', sans-serif;
    }
    <?php endif; ?>
    </style>
    <?php
}

// ========================================
// FIX 2: HERO IMAGE CUSTOMIZABLE
// ========================================

add_action('customize_register', 'gp_v70_6_hero_customizer');

function gp_v70_6_hero_customizer($wp_customize) {
    
    if (!$wp_customize->get_section('gp_hero_section')) {
        $wp_customize->add_section('gp_hero_section', array(
            'title' => '🌅 Hero / Banner',
            'priority' => 35,
            'description' => 'Personaliza la imagen del banner principal'
        ));
    }
    
    $wp_customize->add_setting('gp_hero_bg_image', array(
        'default' => 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920',
        'sanitize_callback' => 'esc_url_raw',
        'transport' => 'refresh',
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'gp_hero_bg_image', array(
        'label' => 'Imagen de Fondo Hero',
        'section' => 'gp_hero_section',
    )));
}

add_action('wp_head', 'gp_v70_6_hero_image_css', 1000);

function gp_v70_6_hero_image_css() {
    $hero_image = get_theme_mod('gp_hero_bg_image', 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920');
    ?>
    <style id="gp-v70-6-hero-image">
    .hero-section {
        background-image: linear-gradient(135deg, rgba(10,10,10,0.7), rgba(10,10,10,0.5)), url('<?php echo esc_url($hero_image); ?>');
        background-size: cover;
        background-position: center;
    }
    </style>
    <?php
}

// ========================================
// FIX 3: THEME BUILDER BOTONES FUNCIONALES
// ========================================

add_action('wp_footer', 'gp_v70_6_theme_builder_fix', 99999);

function gp_v70_6_theme_builder_fix() {
    if (!current_user_can('edit_theme_options')) return;
    ?>
    <script id="gp-v70-6-builder-fix">
    (function($) {
        'use strict';
        
        // Asegurar que jQuery esté disponible
        if (typeof jQuery === 'undefined') {
            console.error('jQuery no disponible para Theme Builder');
            return;
        }
        
        $(document).ready(function() {
            console.log('Theme Builder V70.6 cargado');
            
            // Sobrescribir o crear gpThemeBuilder
            window.gpThemeBuilder = {
                apply: function() {
                    console.log('Aplicando cambios...');
                    
                    try {
                        const primary = $('#gp-color-primary').val();
                        const secondary = $('#gp-color-secondary').val();
                        const text = $('#gp-color-text').val();
                        
                        if (!primary || !secondary || !text) {
                            alert('⚠️ Por favor selecciona todos los colores primero');
                            return;
                        }
                        
                        // Aplicar a variables CSS
                        const root = document.documentElement;
                        root.style.setProperty('--gold-primary', primary);
                        root.style.setProperty('--black-deep', secondary);
                        root.style.setProperty('--black-soft', text);
                        
                        // Guardar en localStorage
                        localStorage.setItem('gp_theme_colors', JSON.stringify({
                            primary: primary,
                            secondary: secondary,
                            text: text,
                            timestamp: new Date().toISOString()
                        }));
                        
                        alert('✅ Cambios aplicados correctamente!\n\nPara que sean permanentes, ve a:\nApariencia → Personalizar\ny cambia los colores ahí.');
                        
                    } catch (error) {
                        console.error('Error:', error);
                        alert('❌ Error al aplicar cambios: ' + error.message);
                    }
                },
                
                export: function() {
                    console.log('Exportando tema...');
                    
                    try {
                        const theme = {
                            version: '70.6',
                            name: 'Golden Phoenix Custom Theme',
                            colors: {
                                primary: $('#gp-color-primary').val() || '#D4AF37',
                                secondary: $('#gp-color-secondary').val() || '#0A0A0A',
                                text: $('#gp-color-text').val() || '#1A1A1A',
                            },
                            typography: {
                                heading: $('#gp-font-heading').val() || 'Playfair Display',
                                size: $('#gp-font-size').val() || '16',
                            },
                            spacing: {
                                sectionPadding: $('#gp-section-padding').val() || '80',
                                elementGap: $('#gp-element-gap').val() || '30',
                            },
                            exported: new Date().toISOString(),
                            exportedBy: '<?php echo wp_get_current_user()->user_login; ?>'
                        };
                        
                        const json = JSON.stringify(theme, null, 2);
                        const blob = new Blob([json], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'golden-phoenix-theme-' + Date.now() + '.json';
                        $('body').append(a);
                        a.click();
                        $(a).remove();
                        URL.revokeObjectURL(url);
                        
                        alert('✅ Tema exportado correctamente!');
                        
                    } catch (error) {
                        console.error('Error:', error);
                        alert('❌ Error al exportar: ' + error.message);
                    }
                }
            };
            
            // Restaurar colores guardados
            const saved = localStorage.getItem('gp_theme_colors');
            if (saved) {
                try {
                    const colors = JSON.parse(saved);
                    const root = document.documentElement;
                    if (colors.primary) root.style.setProperty('--gold-primary', colors.primary);
                    if (colors.secondary) root.style.setProperty('--black-deep', colors.secondary);
                    if (colors.text) root.style.setProperty('--black-soft', colors.text);
                    console.log('Colores restaurados desde localStorage');
                } catch (error) {
                    console.error('Error restaurando colores:', error);
                }
            }
            
            console.log('Theme Builder ready:', window.gpThemeBuilder);
        });
        
    })(jQuery);
    </script>
    <?php
}

// ========================================
// FIX 4: BOTÓN CONFIGURACIÓN EN CUSTOMIZER
// ========================================

// Agregar script para customizer preview
add_action('customize_preview_init', 'gp_v70_6_customizer_preview');

function gp_v70_6_customizer_preview() {
    ?>
    <script>
    (function($) {
        wp.customize('gp_primary_color', function(value) {
            value.bind(function(to) {
                $(':root').css('--gold-primary', to);
            });
        });
        
        wp.customize('gp_secondary_color', function(value) {
            value.bind(function(to) {
                $(':root').css('--black-deep', to);
            });
        });
        
        wp.customize('gp_background_color', function(value) {
            value.bind(function(to) {
                $('body').css('background-color', to);
            });
        });
    })(jQuery);
    </script>
    <?php
}
