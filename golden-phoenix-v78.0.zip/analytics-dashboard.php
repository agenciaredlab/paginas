<?php
/**
 * Golden Phoenix V73 - ANALYTICS DASHBOARD
 * Dashboard completo de ventas, conversión y clientes
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'gp_analytics_dashboard_menu');

function gp_analytics_dashboard_menu() {
    add_menu_page(
        'Analytics Dashboard',
        'Analytics',
        'manage_woocommerce',
        'gp-analytics',
        'gp_analytics_dashboard_page',
        'dashicons-chart-line',
        25
    );
}

function gp_analytics_dashboard_page() {
    // Obtener datos
    $today_sales = gp_get_sales_today();
    $month_sales = gp_get_sales_month();
    $total_orders = gp_get_total_orders();
    $conversion_rate = gp_get_conversion_rate();
    $top_products = gp_get_top_products(5);
    $recent_orders = gp_get_recent_orders(10);
    ?>
    
    <div class="wrap">
        <h1>📊 Analytics Dashboard - Golden Phoenix</h1>
        
        <!-- KPIs -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 30px 0;">
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; opacity: 0.9;">Ventas Hoy</div>
                <div style="font-size: 36px; font-weight: 700; margin: 10px 0;">$<?php echo number_format($today_sales, 0, ',', '.'); ?></div>
                <div style="font-size: 12px; opacity: 0.8;">📈 Actualizado</div>
            </div>
            
            <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; opacity: 0.9;">Ventas Este Mes</div>
                <div style="font-size: 36px; font-weight: 700; margin: 10px 0;">$<?php echo number_format($month_sales, 0, ',', '.'); ?></div>
                <div style="font-size: 12px; opacity: 0.8;">📅 <?php echo date('F Y'); ?></div>
            </div>
            
            <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; opacity: 0.9;">Total Pedidos</div>
                <div style="font-size: 36px; font-weight: 700; margin: 10px 0;"><?php echo $total_orders; ?></div>
                <div style="font-size: 12px; opacity: 0.8;">🛍️ Completados</div>
            </div>
            
            <div style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="font-size: 14px; opacity: 0.9;">Conversión</div>
                <div style="font-size: 36px; font-weight: 700; margin: 10px 0;"><?php echo number_format($conversion_rate, 1); ?>%</div>
                <div style="font-size: 12px; opacity: 0.8;">📊 Promedio</div>
            </div>
            
        </div>
        
        <!-- Gráficos -->
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin: 30px 0;">
            
            <!-- Top Productos -->
            <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                <h2 style="margin-top: 0;">🏆 Top 5 Productos</h2>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Ventas</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($top_products as $product): ?>
                        <tr>
                            <td><strong><?php echo esc_html($product['name']); ?></strong></td>
                            <td><?php echo $product['quantity']; ?> unidades</td>
                            <td>$<?php echo number_format($product['total'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pedidos Recientes -->
            <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                <h2 style="margin-top: 0;">🔔 Últimos Pedidos</h2>
                <?php foreach ($recent_orders as $order): ?>
                <div style="padding: 15px; border-bottom: 1px solid #f0f0f0;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong>#<?php echo $order->get_id(); ?></strong>
                            <div style="font-size: 12px; color: #666;">
                                <?php echo $order->get_billing_first_name(); ?>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: 600; color: #D4AF37;">
                                $<?php echo number_format($order->get_total(), 0, ',', '.'); ?>
                            </div>
                            <div style="font-size: 11px; color: #999;">
                                <?php echo $order->get_date_created()->date('d/m H:i'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
        </div>
        
    </div>
    
    <?php
}

// Funciones auxiliares
function gp_get_sales_today() {
    $args = array(
        'status' => array('wc-completed', 'wc-processing'),
        'date_created' => '>' . strtotime('today midnight'),
        'return' => 'ids',
    );
    
    $orders = wc_get_orders($args);
    $total = 0;
    
    foreach ($orders as $order_id) {
        $order = wc_get_order($order_id);
        $total += $order->get_total();
    }
    
    return $total;
}

function gp_get_sales_month() {
    $args = array(
        'status' => array('wc-completed', 'wc-processing'),
        'date_created' => '>=' . date('Y-m-01'),
        'return' => 'ids',
    );
    
    $orders = wc_get_orders($args);
    $total = 0;
    
    foreach ($orders as $order_id) {
        $order = wc_get_order($order_id);
        $total += $order->get_total();
    }
    
    return $total;
}

function gp_get_total_orders() {
    $args = array(
        'status' => array('wc-completed'),
        'return' => 'ids',
    );
    
    return count(wc_get_orders($args));
}

function gp_get_conversion_rate() {
    // Simplificado: órdenes / visitas (requeriría tracking real)
    return 2.5; // Placeholder
}

function gp_get_top_products($limit = 5) {
    global $wpdb;
    
    $results = $wpdb->get_results("
        SELECT 
            p.ID,
            p.post_title as name,
            SUM(oi.order_item_qty) as quantity,
            SUM(oi.order_item_total) as total
        FROM {$wpdb->prefix}posts p
        INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oi.order_item_name = p.post_title
        WHERE p.post_type = 'product'
        GROUP BY p.ID
        ORDER BY total DESC
        LIMIT {$limit}
    ");
    
    return $results ?: array();
}

function gp_get_recent_orders($limit = 10) {
    return wc_get_orders(array(
        'limit' => $limit,
        'orderby' => 'date',
        'order' => 'DESC',
    ));
}
