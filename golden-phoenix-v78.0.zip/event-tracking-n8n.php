<?php
/**
 * GOLDEN PHOENIX V66 - EVENT TRACKING PARA N8N
 * Captura TODOS los eventos del sitio y envía a N8N
 */

if (!defined('ABSPATH')) exit;

class GP_Event_Tracking_N8N {
    
    private $enabled = false;
    private $webhook_url = '';
    
    public function __construct() {
        $this->enabled = get_option('gp_n8n_tracking_enabled', false);
        $this->webhook_url = get_option('gp_n8n_webhook_url', '');
        
        if (!$this->enabled || empty($this->webhook_url)) return;
        
        // HOOKS DE WORDPRESS
        add_action('wp_footer', array($this, 'inject_tracking_script'));
        
        // HOOKS DE WOOCOMMERCE
        add_action('woocommerce_add_to_cart', array($this, 'track_add_to_cart'), 10, 6);
        add_action('woocommerce_remove_cart_item', array($this, 'track_remove_from_cart'), 10, 2);
        add_action('woocommerce_checkout_order_processed', array($this, 'track_order_completed'), 10, 3);
        add_action('woocommerce_order_status_completed', array($this, 'track_order_status_change'), 10, 1);
        add_action('woocommerce_payment_complete', array($this, 'track_payment_complete'), 10, 1);
        
        // HOOKS DE USUARIOS
        add_action('user_register', array($this, 'track_user_registration'), 10, 1);
        add_action('wp_login', array($this, 'track_user_login'), 10, 2);
        add_action('wp_logout', array($this, 'track_user_logout'), 10, 1);
        
        // HOOKS DE FORMULARIOS
        add_action('wpcf7_mail_sent', array($this, 'track_contact_form_submit'), 10, 1);
        add_action('gform_after_submission', array($this, 'track_gravity_form_submit'), 10, 2);
        
        // AJAX HANDLERS para eventos del frontend
        add_action('wp_ajax_gp_track_event', array($this, 'handle_ajax_track'));
        add_action('wp_ajax_nopriv_gp_track_event', array($this, 'handle_ajax_track'));
    }
    
    // =============================================
    // SCRIPT DE TRACKING EN FRONTEND
    // =============================================
    public function inject_tracking_script() {
        ?>
        <script>
        // GOLDEN PHOENIX EVENT TRACKING
        const gpTracker = {
            endpoint: '<?php echo admin_url('admin-ajax.php'); ?>',
            sessionId: '<?php echo session_id() ?: uniqid('gp_'); ?>',
            userId: '<?php echo get_current_user_id(); ?>',
            userEmail: '<?php echo wp_get_current_user()->user_email; ?>',
            
            // Enviar evento a WordPress → N8N
            track: function(eventName, eventData = {}) {
                const payload = {
                    action: 'gp_track_event',
                    event: eventName,
                    data: eventData,
                    meta: {
                        session_id: this.sessionId,
                        user_id: this.userId,
                        user_email: this.userEmail,
                        page_url: window.location.href,
                        page_title: document.title,
                        referrer: document.referrer,
                        timestamp: new Date().toISOString(),
                        user_agent: navigator.userAgent,
                        screen_resolution: window.screen.width + 'x' + window.screen.height,
                        viewport: window.innerWidth + 'x' + window.innerHeight
                    }
                };
                
                // Enviar via AJAX
                fetch(this.endpoint, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: new URLSearchParams(payload)
                }).catch(err => console.error('Tracking error:', err));
            },
            
            // Inicializar tracking automático
            init: function() {
                // 1. PAGE VIEW
                this.track('page_view', {
                    page_type: document.body.className
                });
                
                // 2. CLICKS EN BOTONES
                document.addEventListener('click', (e) => {
                    const button = e.target.closest('button, a.button, .btn, [role="button"]');
                    if (button) {
                        this.track('button_click', {
                            button_text: button.textContent.trim(),
                            button_id: button.id || 'no-id',
                            button_class: button.className,
                            button_href: button.href || null,
                            button_type: button.tagName.toLowerCase()
                        });
                    }
                });
                
                // 3. CLICKS EN PRODUCTOS
                document.addEventListener('click', (e) => {
                    const product = e.target.closest('.product, .woocommerce-LoopProduct-link, [data-product-id]');
                    if (product) {
                        this.track('product_click', {
                            product_id: product.dataset.productId || product.querySelector('[data-product-id]')?.dataset.productId,
                            product_name: product.querySelector('.woocommerce-loop-product__title, h2, h3')?.textContent.trim(),
                            product_price: product.querySelector('.price, .amount')?.textContent.trim()
                        });
                    }
                });
                
                // 4. ADD TO CART (botones)
                document.addEventListener('click', (e) => {
                    const addToCart = e.target.closest('.add_to_cart_button, .single_add_to_cart_button');
                    if (addToCart) {
                        this.track('add_to_cart_button_click', {
                            product_id: addToCart.dataset.productId,
                            product_name: addToCart.dataset.productName || document.querySelector('.product_title')?.textContent.trim(),
                            quantity: document.querySelector('input.qty')?.value || 1
                        });
                    }
                });
                
                // 5. SUBMIT DE FORMULARIOS
                document.addEventListener('submit', (e) => {
                    const form = e.target;
                    if (form.tagName === 'FORM') {
                        const formData = new FormData(form);
                        const data = {};
                        formData.forEach((value, key) => {
                            // No enviar contraseñas
                            if (!key.includes('password') && !key.includes('pwd')) {
                                data[key] = value;
                            }
                        });
                        
                        this.track('form_submit', {
                            form_id: form.id || 'no-id',
                            form_class: form.className,
                            form_action: form.action,
                            form_data: data
                        });
                    }
                });
                
                // 6. SCROLL DEPTH
                let maxScroll = 0;
                const trackScroll = () => {
                    const scrollPercent = Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100);
                    if (scrollPercent > maxScroll) {
                        maxScroll = scrollPercent;
                        if ([25, 50, 75, 100].includes(scrollPercent)) {
                            this.track('scroll_depth', {
                                depth_percent: scrollPercent
                            });
                        }
                    }
                };
                window.addEventListener('scroll', () => {
                    clearTimeout(window.scrollTimeout);
                    window.scrollTimeout = setTimeout(trackScroll, 500);
                });
                
                // 7. TIME ON PAGE
                let timeOnPage = 0;
                setInterval(() => {
                    timeOnPage += 30;
                    if ([30, 60, 120, 300].includes(timeOnPage)) {
                        this.track('time_on_page', {
                            seconds: timeOnPage
                        });
                    }
                }, 30000); // cada 30 segundos
                
                // 8. VIDEO PLAY (YouTube, Vimeo)
                document.addEventListener('click', (e) => {
                    const video = e.target.closest('iframe[src*="youtube"], iframe[src*="vimeo"], video');
                    if (video) {
                        this.track('video_interaction', {
                            video_src: video.src || video.currentSrc,
                            action: 'play_attempt'
                        });
                    }
                });
                
                // 9. SEARCH
                const searchForm = document.querySelector('form[role="search"], .search-form');
                if (searchForm) {
                    searchForm.addEventListener('submit', (e) => {
                        const searchInput = searchForm.querySelector('input[type="search"], input[name="s"]');
                        this.track('search', {
                            query: searchInput?.value
                        });
                    });
                }
                
                // 10. FILTROS DE PRODUCTOS
                document.addEventListener('change', (e) => {
                    const filter = e.target.closest('.woocommerce-ordering, [name="orderby"], [data-filter]');
                    if (filter) {
                        this.track('product_filter', {
                            filter_type: filter.name,
                            filter_value: filter.value
                        });
                    }
                });
                
                // 11. WISHLIST
                document.addEventListener('click', (e) => {
                    const wishlist = e.target.closest('.add_to_wishlist, [data-action="add-to-wishlist"]');
                    if (wishlist) {
                        this.track('wishlist_add', {
                            product_id: wishlist.dataset.productId
                        });
                    }
                });
                
                // 12. QUICK VIEW
                document.addEventListener('click', (e) => {
                    const quickView = e.target.closest('.quick-view, [data-action="quick-view"]');
                    if (quickView) {
                        this.track('quick_view', {
                            product_id: quickView.dataset.productId
                        });
                    }
                });
                
                // 13. COMPARAR PRODUCTOS
                document.addEventListener('click', (e) => {
                    const compare = e.target.closest('.compare, [data-action="compare"]');
                    if (compare) {
                        this.track('product_compare', {
                            product_id: compare.dataset.productId
                        });
                    }
                });
                
                // 14. CAMBIO DE CANTIDAD EN CARRITO
                document.addEventListener('change', (e) => {
                    const qtyInput = e.target.closest('.qty, input[name="quantity"]');
                    if (qtyInput) {
                        this.track('cart_quantity_change', {
                            new_quantity: qtyInput.value
                        });
                    }
                });
                
                // 15. APLICAR CUPÓN
                document.addEventListener('submit', (e) => {
                    const couponForm = e.target.closest('form.checkout_coupon, form.woocommerce-form-coupon');
                    if (couponForm) {
                        this.track('coupon_apply', {
                            coupon_code: couponForm.querySelector('input[name="coupon_code"]')?.value
                        });
                    }
                });
                
                // 16. CHECKOUT START
                if (document.body.classList.contains('woocommerce-checkout')) {
                    this.track('checkout_start', {
                        cart_total: document.querySelector('.order-total .amount')?.textContent
                    });
                }
                
                // 17. EXIT INTENT
                let exitTracked = false;
                document.addEventListener('mouseout', (e) => {
                    if (!exitTracked && e.clientY < 0) {
                        exitTracked = true;
                        this.track('exit_intent', {});
                    }
                });
                
                // 18. PHONE CLICK
                document.addEventListener('click', (e) => {
                    const phoneLink = e.target.closest('a[href^="tel:"]');
                    if (phoneLink) {
                        this.track('phone_click', {
                            phone_number: phoneLink.href.replace('tel:', '')
                        });
                    }
                });
                
                // 19. EMAIL CLICK
                document.addEventListener('click', (e) => {
                    const emailLink = e.target.closest('a[href^="mailto:"]');
                    if (emailLink) {
                        this.track('email_click', {
                            email: emailLink.href.replace('mailto:', '')
                        });
                    }
                });
                
                // 20. WHATSAPP CLICK
                document.addEventListener('click', (e) => {
                    const whatsapp = e.target.closest('a[href*="wa.me"], a[href*="whatsapp"]');
                    if (whatsapp) {
                        this.track('whatsapp_click', {
                            url: whatsapp.href
                        });
                    }
                });
                
                // 21. SOCIAL MEDIA CLICKS
                document.addEventListener('click', (e) => {
                    const social = e.target.closest('a[href*="facebook.com"], a[href*="instagram.com"], a[href*="twitter.com"], a[href*="linkedin.com"]');
                    if (social) {
                        const platform = social.href.includes('facebook') ? 'facebook' :
                                       social.href.includes('instagram') ? 'instagram' :
                                       social.href.includes('twitter') ? 'twitter' : 'linkedin';
                        this.track('social_click', {
                            platform: platform,
                            url: social.href
                        });
                    }
                });
                
                // 22. DOWNLOAD CLICKS
                document.addEventListener('click', (e) => {
                    const download = e.target.closest('a[download], a[href$=".pdf"], a[href$=".zip"], a[href$=".doc"]');
                    if (download) {
                        this.track('download_click', {
                            file_url: download.href,
                            file_name: download.download || download.href.split('/').pop()
                        });
                    }
                });
                
                // 23. EXTERNAL LINKS
                document.addEventListener('click', (e) => {
                    const link = e.target.closest('a');
                    if (link && link.href && !link.href.includes(window.location.hostname) && !link.href.startsWith('#')) {
                        this.track('external_link_click', {
                            url: link.href,
                            text: link.textContent.trim()
                        });
                    }
                });
                
                // 24. IMAGE CLICKS (galerías)
                document.addEventListener('click', (e) => {
                    const image = e.target.closest('.woocommerce-product-gallery__image a, .gallery-item a');
                    if (image) {
                        this.track('image_click', {
                            image_url: image.href,
                            image_alt: image.querySelector('img')?.alt
                        });
                    }
                });
                
                // 25. TAB CHANGES
                document.addEventListener('click', (e) => {
                    const tab = e.target.closest('.wc-tabs li a, [role="tab"]');
                    if (tab) {
                        this.track('tab_change', {
                            tab_name: tab.textContent.trim(),
                            tab_id: tab.href?.split('#')[1]
                        });
                    }
                });
            }
        };
        
        // Inicializar cuando carga la página
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => gpTracker.init());
        } else {
            gpTracker.init();
        }
        </script>
        <?php
    }
    
    // =============================================
    // HANDLE AJAX TRACKING
    // =============================================
    public function handle_ajax_track() {
        $event = sanitize_text_field($_POST['event']);
        $data = isset($_POST['data']) ? $_POST['data'] : array();
        $meta = isset($_POST['meta']) ? $_POST['meta'] : array();
        
        // Sanitizar datos
        array_walk_recursive($data, function(&$value) {
            $value = sanitize_text_field($value);
        });
        
        // Enviar a N8N
        $this->send_to_n8n($event, $data, $meta);
        
        wp_send_json_success();
    }
    
    // =============================================
    // WOOCOMMERCE EVENTS
    // =============================================
    
    public function track_add_to_cart($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
        $product = wc_get_product($product_id);
        
        $this->send_to_n8n('woo_add_to_cart', array(
            'product_id' => $product_id,
            'product_name' => $product->get_name(),
            'product_price' => $product->get_price(),
            'quantity' => $quantity,
            'cart_total' => WC()->cart->get_cart_total()
        ));
    }
    
    public function track_remove_from_cart($cart_item_key, $cart) {
        $this->send_to_n8n('woo_remove_from_cart', array(
            'cart_item_key' => $cart_item_key
        ));
    }
    
    public function track_order_completed($order_id, $posted_data, $order) {
        $this->send_to_n8n('woo_order_completed', array(
            'order_id' => $order_id,
            'order_total' => $order->get_total(),
            'order_currency' => $order->get_currency(),
            'customer_email' => $order->get_billing_email(),
            'customer_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'customer_phone' => $order->get_billing_phone(),
            'payment_method' => $order->get_payment_method_title(),
            'items_count' => $order->get_item_count(),
            'items' => array_map(function($item) {
                return array(
                    'name' => $item->get_name(),
                    'quantity' => $item->get_quantity(),
                    'total' => $item->get_total()
                );
            }, $order->get_items())
        ));
    }
    
    public function track_order_status_change($order_id) {
        $order = wc_get_order($order_id);
        
        $this->send_to_n8n('woo_order_status_change', array(
            'order_id' => $order_id,
            'new_status' => $order->get_status(),
            'order_total' => $order->get_total()
        ));
    }
    
    public function track_payment_complete($order_id) {
        $this->send_to_n8n('woo_payment_complete', array(
            'order_id' => $order_id
        ));
    }
    
    // =============================================
    // USER EVENTS
    // =============================================
    
    public function track_user_registration($user_id) {
        $user = get_userdata($user_id);
        
        $this->send_to_n8n('user_registered', array(
            'user_id' => $user_id,
            'user_email' => $user->user_email,
            'user_name' => $user->display_name,
            'registration_date' => $user->user_registered
        ));
    }
    
    public function track_user_login($user_login, $user) {
        $this->send_to_n8n('user_login', array(
            'user_id' => $user->ID,
            'user_email' => $user->user_email,
            'user_name' => $user->display_name
        ));
    }
    
    public function track_user_logout($user_id) {
        $this->send_to_n8n('user_logout', array(
            'user_id' => $user_id
        ));
    }
    
    // =============================================
    // FORM EVENTS
    // =============================================
    
    public function track_contact_form_submit($contact_form) {
        $submission = WPCF7_Submission::get_instance();
        
        $this->send_to_n8n('contact_form_submit', array(
            'form_id' => $contact_form->id(),
            'form_title' => $contact_form->title(),
            'posted_data' => $submission->get_posted_data()
        ));
    }
    
    public function track_gravity_form_submit($entry, $form) {
        $this->send_to_n8n('gravity_form_submit', array(
            'form_id' => $form['id'],
            'form_title' => $form['title'],
            'entry_data' => $entry
        ));
    }
    
    // =============================================
    // SEND TO N8N
    // =============================================
    
    private function send_to_n8n($event, $data = array(), $meta = array()) {
        if (empty($this->webhook_url)) return;
        
        $current_user = wp_get_current_user();
        
        $payload = array(
            'event' => $event,
            'data' => $data,
            'meta' => array_merge(array(
                'site_url' => get_site_url(),
                'site_name' => get_bloginfo('name'),
                'timestamp' => current_time('mysql'),
                'user_id' => get_current_user_id(),
                'user_email' => $current_user->user_email,
                'user_ip' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT']
            ), $meta),
            'source' => 'golden_phoenix_tracking'
        );
        
        // Enviar
        wp_remote_post($this->webhook_url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($payload),
            'timeout' => 5,
            'blocking' => false // No bloquear ejecución
        ));
    }
}

new GP_Event_Tracking_N8N();
