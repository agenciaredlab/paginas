<?php
/**
 * Golden Phoenix V72 - INSTAGRAM SHOP SYNC
 * Sincronización automática con Instagram Shopping
 */

if (!defined('ABSPATH')) exit;

class GP_Instagram_Shop {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));
        add_action('save_post_product', array(__CLASS__, 'sync_product_to_instagram'), 10, 2);
    }
    
    public static function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Instagram Shop',
            'Instagram Shop',
            'manage_woocommerce',
            'gp-instagram-shop',
            array(__CLASS__, 'admin_page')
        );
    }
    
    public static function admin_page() {
        ?>
        <div class="wrap">
            <h1>📸 Instagram Shop Sync</h1>
            
            <div class="notice notice-info">
                <p><strong>Cómo configurar Instagram Shopping:</strong></p>
                <ol>
                    <li>Conecta tu cuenta de Instagram Business</li>
                    <li>Crea un catálogo de productos en Facebook</li>
                    <li>Vincula tu catálogo con Instagram</li>
                    <li>Los productos se sincronizarán automáticamente</li>
                </ol>
            </div>
            
            <h2>Estado de la Sincronización</h2>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Estado Instagram</th>
                        <th>Última Sync</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $products = wc_get_products(array('limit' => 20));
                    foreach ($products as $product):
                        $instagram_id = get_post_meta($product->get_id(), '_instagram_product_id', true);
                        $last_sync = get_post_meta($product->get_id(), '_instagram_last_sync', true);
                    ?>
                    <tr>
                        <td><?php echo $product->get_name(); ?></td>
                        <td>
                            <?php if ($instagram_id): ?>
                                <span style="color: green;">✓ Sincronizado</span>
                            <?php else: ?>
                                <span style="color: orange;">⏳ Pendiente</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $last_sync ? date('Y-m-d H:i', $last_sync) : 'Nunca'; ?></td>
                        <td>
                            <button class="button button-small gp-sync-instagram" data-product-id="<?php echo $product->get_id(); ?>">
                                Sincronizar
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <script>
            jQuery(document).ready(function($) {
                $('.gp-sync-instagram').on('click', function() {
                    var productId = $(this).data('product-id');
                    var btn = $(this);
                    
                    btn.text('Sincronizando...');
                    
                    $.post(ajaxurl, {
                        action: 'gp_sync_instagram_product',
                        product_id: productId
                    }, function(response) {
                        if (response.success) {
                            alert('Producto sincronizado con Instagram');
                            location.reload();
                        } else {
                            alert('Error: ' + response.data);
                            btn.text('Sincronizar');
                        }
                    });
                });
            });
            </script>
        </div>
        <?php
    }
    
    public static function sync_product_to_instagram($post_id, $post) {
        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }
        
        $product = wc_get_product($post_id);
        
        if (!$product) {
            return;
        }
        
        // Datos para Instagram
        $instagram_data = array(
            'name' => $product->get_name(),
            'description' => $product->get_short_description(),
            'price' => $product->get_price(),
            'currency' => 'COP',
            'url' => $product->get_permalink(),
            'image_url' => wp_get_attachment_url($product->get_image_id()),
            'availability' => $product->is_in_stock() ? 'in stock' : 'out of stock',
        );
        
        // Aquí iría la API de Facebook/Instagram
        // Por ahora solo simulamos
        update_post_meta($post_id, '_instagram_product_data', $instagram_data);
        update_post_meta($post_id, '_instagram_last_sync', time());
        update_post_meta($post_id, '_instagram_product_id', 'IG_' . $post_id);
    }
}

GP_Instagram_Shop::init();

// AJAX sync manual
add_action('wp_ajax_gp_sync_instagram_product', 'gp_ajax_sync_instagram_product');

function gp_ajax_sync_instagram_product() {
    $product_id = intval($_POST['product_id']);
    $product = wc_get_product($product_id);
    
    if (!$product) {
        wp_send_json_error('Producto no encontrado');
    }
    
    GP_Instagram_Shop::sync_product_to_instagram($product_id, get_post($product_id));
    
    wp_send_json_success();
}
