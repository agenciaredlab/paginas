<?php
/**
 * GOLDEN PHOENIX V65 - INTEGRACIONES
 * N8N + Chatwoot + Webhooks
 */

if (!defined('ABSPATH')) exit;

class GP_Chat_Integrations {
    
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_gp_test_n8n_connection', array($this, 'test_n8n_connection'));
        add_action('wp_ajax_gp_test_chatwoot_connection', array($this, 'test_chatwoot_connection'));
        add_action('gp_new_message', array($this, 'send_to_n8n'), 10, 2);
        add_action('gp_transfer_to_human', array($this, 'notify_n8n'), 10, 1);
    }
    
    // =============================================
    // CONFIGURACIÓN
    // =============================================
    public function register_settings() {
        register_setting('gp_integrations', 'gp_n8n_webhook_url');
        register_setting('gp_integrations', 'gp_n8n_enabled');
        register_setting('gp_integrations', 'gp_chatwoot_url');
        register_setting('gp_integrations', 'gp_chatwoot_api_key');
        register_setting('gp_integrations', 'gp_chatwoot_inbox_id');
        register_setting('gp_integrations', 'gp_chatwoot_enabled');
    }
    
    // =============================================
    // N8N INTEGRATION
    // =============================================
    public function send_to_n8n($conversation_id, $message) {
        if (!get_option('gp_n8n_enabled')) return;
        
        $webhook_url = get_option('gp_n8n_webhook_url');
        if (empty($webhook_url)) return;
        
        global $wpdb;
        $table_conversations = $wpdb->prefix . 'gp_conversations';
        
        $conversation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_conversations WHERE id = %d",
            $conversation_id
        ));
        
        $payload = array(
            'event' => 'new_message',
            'conversation_id' => $conversation_id,
            'session_id' => $conversation->session_id,
            'user_name' => $conversation->user_name,
            'user_email' => $conversation->user_email,
            'user_phone' => $conversation->user_phone,
            'message' => $message,
            'timestamp' => current_time('mysql'),
            'source' => 'golden_phoenix_chat'
        );
        
        $this->send_webhook($webhook_url, $payload);
    }
    
    public function notify_n8n($conversation_id) {
        if (!get_option('gp_n8n_enabled')) return;
        
        $webhook_url = get_option('gp_n8n_webhook_url');
        if (empty($webhook_url)) return;
        
        $payload = array(
            'event' => 'transfer_to_human',
            'conversation_id' => $conversation_id,
            'timestamp' => current_time('mysql')
        );
        
        $this->send_webhook($webhook_url, $payload);
    }
    
    private function send_webhook($url, $data) {
        $response = wp_remote_post($url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            error_log('N8N Webhook Error: ' . $response->get_error_message());
            return false;
        }
        
        return true;
    }
    
    public function test_n8n_connection() {
        $webhook_url = get_option('gp_n8n_webhook_url');
        
        if (empty($webhook_url)) {
            wp_send_json_error(array('message' => 'URL del webhook no configurada'));
        }
        
        $test_payload = array(
            'event' => 'test_connection',
            'timestamp' => current_time('mysql'),
            'source' => 'golden_phoenix_chat'
        );
        
        $response = wp_remote_post($webhook_url, array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($test_payload),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Error: ' . $response->get_error_message()));
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code >= 200 && $status_code < 300) {
            wp_send_json_success(array('message' => '✅ Conexión exitosa con N8N'));
        } else {
            wp_send_json_error(array('message' => 'Error HTTP ' . $status_code));
        }
    }
    
    // =============================================
    // CHATWOOT INTEGRATION
    // =============================================
    public function send_to_chatwoot($conversation_id) {
        if (!get_option('gp_chatwoot_enabled')) return false;
        
        $api_url = get_option('gp_chatwoot_url');
        $api_key = get_option('gp_chatwoot_api_key');
        $inbox_id = get_option('gp_chatwoot_inbox_id');
        
        if (empty($api_url) || empty($api_key) || empty($inbox_id)) return false;
        
        global $wpdb;
        $table_conversations = $wpdb->prefix . 'gp_conversations';
        $table_messages = $wpdb->prefix . 'gp_messages';
        
        $conversation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_conversations WHERE id = %d",
            $conversation_id
        ));
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_messages WHERE conversation_id = %d ORDER BY created_at ASC",
            $conversation_id
        ));
        
        // 1. Crear contacto en Chatwoot
        $contact_data = array(
            'inbox_id' => $inbox_id,
            'name' => $conversation->user_name ?: 'Usuario Anónimo',
            'email' => $conversation->user_email,
            'phone_number' => $conversation->user_phone,
            'custom_attributes' => array(
                'session_id' => $conversation->session_id,
                'source' => 'Golden Phoenix Chat'
            )
        );
        
        $contact_response = $this->chatwoot_api_request('POST', '/api/v1/accounts/1/contacts', $contact_data, $api_key);
        
        if (!$contact_response || !isset($contact_response['payload']['contact']['id'])) {
            return false;
        }
        
        $contact_id = $contact_response['payload']['contact']['id'];
        
        // 2. Crear conversación en Chatwoot
        $conversation_data = array(
            'source_id' => $conversation->session_id,
            'inbox_id' => $inbox_id,
            'contact_id' => $contact_id,
            'status' => 'open'
        );
        
        $conv_response = $this->chatwoot_api_request('POST', '/api/v1/accounts/1/conversations', $conversation_data, $api_key);
        
        if (!$conv_response || !isset($conv_response['id'])) {
            return false;
        }
        
        $chatwoot_conv_id = $conv_response['id'];
        
        // 3. Enviar mensajes históricos
        foreach ($messages as $msg) {
            $message_data = array(
                'content' => $msg->message,
                'message_type' => $msg->sender_type === 'user' ? 'incoming' : 'outgoing',
                'private' => false
            );
            
            $this->chatwoot_api_request('POST', "/api/v1/accounts/1/conversations/{$chatwoot_conv_id}/messages", $message_data, $api_key);
            
            sleep(0.5); // Evitar rate limiting
        }
        
        // 4. Guardar ID de Chatwoot en metadatos
        update_option('gp_chatwoot_conv_' . $conversation_id, $chatwoot_conv_id);
        
        return true;
    }
    
    private function chatwoot_api_request($method, $endpoint, $data, $api_key) {
        $api_url = get_option('gp_chatwoot_url');
        $url = rtrim($api_url, '/') . $endpoint;
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Content-Type' => 'application/json',
                'api_access_token' => $api_key
            ),
            'timeout' => 15
        );
        
        if ($method === 'POST' || $method === 'PUT') {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            error_log('Chatwoot API Error: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        return json_decode($body, true);
    }
    
    public function test_chatwoot_connection() {
        $api_url = get_option('gp_chatwoot_url');
        $api_key = get_option('gp_chatwoot_api_key');
        
        if (empty($api_url) || empty($api_key)) {
            wp_send_json_error(array('message' => 'URL o API Key no configurados'));
        }
        
        $response = $this->chatwoot_api_request('GET', '/api/v1/profile', array(), $api_key);
        
        if ($response && isset($response['id'])) {
            wp_send_json_success(array(
                'message' => '✅ Conexión exitosa con Chatwoot',
                'user' => $response['name']
            ));
        } else {
            wp_send_json_error(array('message' => 'Error al conectar con Chatwoot'));
        }
    }
}

new GP_Chat_Integrations();


// =============================================
// PÁGINA DE CONFIGURACIÓN DE INTEGRACIONES
// =============================================
function gp_render_integrations_settings() {
    if (!current_user_can('manage_options')) return;
    
    if (isset($_POST['gp_save_integrations'])) {
        update_option('gp_n8n_enabled', isset($_POST['n8n_enabled']));
        update_option('gp_n8n_webhook_url', sanitize_url($_POST['n8n_webhook_url']));
        update_option('gp_n8n_auth_header', sanitize_text_field($_POST['n8n_auth_header']));
        update_option('gp_n8n_auth_value', sanitize_text_field($_POST['n8n_auth_value']));
        update_option('gp_n8n_tracking_enabled', isset($_POST['n8n_tracking_enabled']));
        update_option('gp_chatwoot_enabled', isset($_POST['chatwoot_enabled']));
        update_option('gp_chatwoot_url', sanitize_url($_POST['chatwoot_url']));
        update_option('gp_chatwoot_api_key', sanitize_text_field($_POST['chatwoot_api_key']));
        update_option('gp_chatwoot_inbox_id', sanitize_text_field($_POST['chatwoot_inbox_id']));
        
        echo '<div class="updated"><p>✅ Configuración guardada correctamente</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>🔌 Configuración de Integraciones</h1>
        
        <div class="notice notice-info">
            <p><strong>💡 Guía rápida:</strong> Conecta tu servidor N8N para automatizar respuestas, notificaciones y más. 
            <a href="<?php echo get_template_directory_uri(); ?>/GUIA-N8N-COMPLETA.md" target="_blank">Ver guía completa</a></p>
        </div>
        
        <form method="post">
            
            <!-- ========================================= -->
            <!-- N8N CONFIGURATION -->
            <!-- ========================================= -->
            <div class="gp-config-section" style="background: #fff; padding: 20px; margin: 20px 0; border-left: 4px solid #D4AF37; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">🔄 N8N - Automatizaciones</h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="n8n_enabled">Estado</label>
                        </th>
                        <td>
                            <label style="display: flex; align-items: center; gap: 10px;">
                                <input type="checkbox" name="n8n_enabled" id="n8n_enabled" <?php checked(get_option('gp_n8n_enabled')); ?>>
                                <span style="font-weight: 600;">Habilitar integración con N8N</span>
                            </label>
                            <p class="description">
                                Envía eventos del chat a tu servidor N8N para automatizar acciones
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="n8n_webhook_url">URL del Webhook *</label>
                        </th>
                        <td>
                            <input type="url" 
                                   name="n8n_webhook_url" 
                                   id="n8n_webhook_url"
                                   value="<?php echo esc_attr(get_option('gp_n8n_webhook_url')); ?>" 
                                   class="regular-text" 
                                   placeholder="https://n8n.tudominio.com/webhook/golden-phoenix-chat"
                                   style="width: 100%; max-width: 600px;">
                            
                            <div style="margin-top: 15px; padding: 15px; background: #f0f0f1; border-radius: 4px;">
                                <p style="margin: 0 0 10px; font-weight: 600;">📝 Cómo obtener la URL:</p>
                                <ol style="margin: 0; padding-left: 20px;">
                                    <li>Abre tu servidor N8N</li>
                                    <li>Crea un nuevo workflow</li>
                                    <li>Añade nodo "Webhook"</li>
                                    <li>Configura: Método = POST, Path = golden-phoenix-chat</li>
                                    <li>Copia la URL que aparece (ej: https://n8n.tudominio.com/webhook/golden-phoenix-chat)</li>
                                    <li>Pégala arriba ⬆️</li>
                                </ol>
                                <p style="margin: 10px 0 0;">
                                    <a href="#" onclick="document.getElementById('n8n-guide').style.display='block'; return false;" style="text-decoration: none;">
                                        📖 Ver guía completa con capturas de pantalla
                                    </a>
                                </p>
                            </div>
                            
                            <div id="n8n-guide" style="display: none; margin-top: 15px; padding: 20px; background: #fff; border: 2px solid #D4AF37; border-radius: 8px;">
                                <h3 style="margin-top: 0;">📖 Guía Visual Paso a Paso</h3>
                                
                                <div style="margin-bottom: 20px;">
                                    <h4>Paso 1: Acceder a N8N</h4>
                                    <code style="background: #f0f0f1; padding: 5px 10px; border-radius: 3px;">https://n8n.tudominio.com</code>
                                    <p>Abre tu instalación de N8N en el navegador</p>
                                </div>
                                
                                <div style="margin-bottom: 20px;">
                                    <h4>Paso 2: Crear Workflow</h4>
                                    <p>Clic en <strong>"+ Nuevo Workflow"</strong></p>
                                    <p>Nombre sugerido: <code>Golden Phoenix - Chat</code></p>
                                </div>
                                
                                <div style="margin-bottom: 20px;">
                                    <h4>Paso 3: Añadir Webhook</h4>
                                    <p>1. Clic en el botón <strong>"+"</strong> para añadir nodo</p>
                                    <p>2. Buscar: <code>webhook</code></p>
                                    <p>3. Seleccionar: <strong>Webhook</strong></p>
                                </div>
                                
                                <div style="margin-bottom: 20px;">
                                    <h4>Paso 4: Configurar Webhook</h4>
                                    <table style="width: 100%; border-collapse: collapse;">
                                        <tr style="background: #f0f0f1;">
                                            <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Opción</th>
                                            <th style="padding: 8px; text-align: left; border: 1px solid #ddd;">Valor</th>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; border: 1px solid #ddd;">HTTP Method</td>
                                            <td style="padding: 8px; border: 1px solid #ddd;"><strong>POST</strong></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; border: 1px solid #ddd;">Path</td>
                                            <td style="padding: 8px; border: 1px solid #ddd;"><code>golden-phoenix-chat</code></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 8px; border: 1px solid #ddd;">Response Mode</td>
                                            <td style="padding: 8px; border: 1px solid #ddd;">Respond to Webhook</td>
                                        </tr>
                                    </table>
                                </div>
                                
                                <div style="margin-bottom: 20px;">
                                    <h4>Paso 5: Copiar URL</h4>
                                    <p>Verás la URL del webhook:</p>
                                    <div style="background: #f0f0f1; padding: 10px; border-radius: 4px; font-family: monospace;">
                                        Production: https://n8n.tudominio.com/webhook/golden-phoenix-chat<br>
                                        Test: https://n8n.tudominio.com/webhook-test/golden-phoenix-chat
                                    </div>
                                    <p style="margin-top: 10px;"><strong>⚠️ Usa la URL de Production</strong></p>
                                </div>
                                
                                <div style="background: #d4edda; padding: 15px; border-radius: 4px; border-left: 4px solid #28a745;">
                                    <p style="margin: 0;"><strong>✅ ¡Listo!</strong> Ahora puedes pegar esa URL arriba y probar la conexión.</p>
                                </div>
                                
                                <p style="margin-top: 15px;">
                                    <a href="#" onclick="document.getElementById('n8n-guide').style.display='none'; return false;">❌ Cerrar guía</a>
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label>Autenticación</label>
                        </th>
                        <td>
                            <p style="margin: 0 0 10px;">
                                <label style="display: inline-flex; align-items: center; gap: 5px;">
                                    <input type="checkbox" id="n8n_use_auth" onchange="toggleN8nAuth()">
                                    Mi webhook requiere autenticación
                                </label>
                            </p>
                            
                            <div id="n8n-auth-fields" style="display: none; padding: 15px; background: #f9f9f9; border-radius: 4px;">
                                <p><strong>Header de autenticación:</strong></p>
                                <input type="text" 
                                       name="n8n_auth_header" 
                                       value="<?php echo esc_attr(get_option('gp_n8n_auth_header', 'Authorization')); ?>" 
                                       placeholder="Authorization"
                                       class="regular-text"
                                       style="margin-bottom: 10px;">
                                
                                <p><strong>Valor:</strong></p>
                                <input type="text" 
                                       name="n8n_auth_value" 
                                       value="<?php echo esc_attr(get_option('gp_n8n_auth_value')); ?>" 
                                       placeholder="Bearer tu-token-aqui"
                                       class="regular-text">
                                
                                <p class="description" style="margin-top: 10px;">
                                    Ejemplo: <code>Bearer abc123def456</code> o <code>Basic dXNlcjpwYXNz</code>
                                </p>
                            </div>
                            
                            <script>
                            function toggleN8nAuth() {
                                const checkbox = document.getElementById('n8n_use_auth');
                                const fields = document.getElementById('n8n-auth-fields');
                                fields.style.display = checkbox.checked ? 'block' : 'none';
                            }
                            // Mostrar si ya hay configuración
                            <?php if (get_option('gp_n8n_auth_header')): ?>
                            document.getElementById('n8n_use_auth').checked = true;
                            toggleN8nAuth();
                            <?php endif; ?>
                            </script>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Eventos Enviados</th>
                        <td>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
                                <div style="padding: 15px; background: #f0f0f1; border-radius: 4px; border-left: 3px solid #2196F3;">
                                    <h4 style="margin: 0 0 10px; color: #2196F3;">📨 new_message</h4>
                                    <p style="margin: 0; font-size: 13px;">Cada vez que un cliente envía un mensaje</p>
                                </div>
                                
                                <div style="padding: 15px; background: #f0f0f1; border-radius: 4px; border-left: 3px solid #FF9800;">
                                    <h4 style="margin: 0 0 10px; color: #FF9800;">🔄 transfer_to_human</h4>
                                    <p style="margin: 0; font-size: 13px;">Cuando el bot transfiere a un agente humano</p>
                                </div>
                                
                                <div style="padding: 15px; background: #f0f0f1; border-radius: 4px; border-left: 3px solid #4CAF50;">
                                    <h4 style="margin: 0 0 10px; color: #4CAF50;">✅ conversation_closed</h4>
                                    <p style="margin: 0; font-size: 13px;">Cuando se cierra una conversación</p>
                                </div>
                            </div>
                            
                            <p style="margin-top: 15px;">
                                <a href="#" onclick="document.getElementById('event-examples').style.display='block'; return false;">
                                    📄 Ver ejemplos de JSON
                                </a>
                            </p>
                            
                            <div id="event-examples" style="display: none; margin-top: 15px; padding: 15px; background: #282c34; color: #abb2bf; border-radius: 4px; font-family: monospace; font-size: 13px; overflow-x: auto;">
<pre style="margin: 0;">{
  "event": "new_message",
  "conversation_id": 123,
  "session_id": "abc123",
  "user_name": "María González",
  "user_email": "maria@email.com",
  "user_phone": "+573001234567",
  "message": "Hola, necesito ayuda",
  "timestamp": "2024-12-05 15:30:00",
  "admin_url": "https://tudominio.com/wp-admin/..."
}</pre>
                                <p style="margin: 15px 0 0;">
                                    <a href="#" onclick="document.getElementById('event-examples').style.display='none'; return false;" style="color: #61afef;">❌ Cerrar</a>
                                </p>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Probar Conexión</th>
                        <td>
                            <button type="button" onclick="testN8N()" class="button button-secondary" style="padding: 8px 20px;">
                                🧪 Probar Conexión con N8N
                            </button>
                            <span id="n8n-test-result" style="margin-left: 15px; font-weight: 600;"></span>
                            
                            <p class="description" style="margin-top: 10px;">
                                Envía un evento de prueba a tu servidor N8N para verificar que todo funciona correctamente.
                            </p>
                        </td>
                    </tr>
                </table>
                
                <!-- TEMPLATES SECTION -->
                <div style="margin-top: 30px; padding: 20px; background: #fffbea; border-radius: 8px; border: 2px dashed #D4AF37;">
                    <h3 style="margin-top: 0; color: #D4AF37;">🎁 Templates Listos para Usar</h3>
                    <p>Tenemos 6 workflows pre-configurados que puedes importar en N8N:</p>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-top: 15px;">
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">📧 Email Notificación</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Envía email cuando llega mensaje nuevo</p>
                        </div>
                        
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">💬 Slack Alert</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Notifica en Slack al transferir a humano</p>
                        </div>
                        
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">📊 Google Sheets</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Guarda conversaciones automáticamente</p>
                        </div>
                        
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">📱 WhatsApp</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Notifica por WhatsApp Business</p>
                        </div>
                        
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">🎫 Zendesk</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Crea tickets automáticamente</p>
                        </div>
                        
                        <div style="padding: 15px; background: #fff; border-radius: 4px; border: 1px solid #D4AF37;">
                            <h4 style="margin: 0 0 5px;">🎯 Multi-Canal</h4>
                            <p style="margin: 0; font-size: 13px; color: #666;">Todo en uno: Email + Slack + Sheets</p>
                        </div>
                    </div>
                    
                    <p style="margin: 15px 0 0;">
                        <a href="<?php echo get_template_directory_uri(); ?>/n8n-templates.json" download class="button button-primary">
                            ⬇️ Descargar Templates (JSON)
                        </a>
                        <span style="margin-left: 10px; color: #666;">Luego importar en N8N → Settings → Import</span>
                    </p>
                </div>
            </div>
            
            <!-- ========================================= -->
            <!-- EVENT TRACKING -->
            <!-- ========================================= -->
            <div class="gp-config-section" style="background: #fff; padding: 20px; margin: 20px 0; border-left: 4px solid #4CAF50; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2 style="margin-top: 0;">📊 Event Tracking - Automatizaciones Avanzadas</h2>
                
                <div style="background: #e8f5e9; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
                    <p style="margin: 0; font-weight: 600;">🎯 Captura TODOS los eventos del sitio y envíalos a N8N para automatizar:</p>
                    <ul style="margin: 10px 0 0; columns: 2;">
                        <li>Clics en botones</li>
                        <li>Visitas a productos</li>
                        <li>Add to cart</li>
                        <li>Compras completadas</li>
                        <li>Registros de usuarios</li>
                        <li>Envíos de formularios</li>
                        <li>Scroll depth</li>
                        <li>Tiempo en página</li>
                        <li>Clics en WhatsApp</li>
                        <li>Clics en redes sociales</li>
                        <li>Descargas de archivos</li>
                        <li>Y 15+ eventos más!</li>
                    </ul>
                </div>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="n8n_tracking_enabled">Habilitar Tracking</label>
                        </th>
                        <td>
                            <label style="display: flex; align-items: center; gap: 10px;">
                                <input type="checkbox" name="n8n_tracking_enabled" id="n8n_tracking_enabled" <?php checked(get_option('gp_n8n_tracking_enabled')); ?>>
                                <span style="font-weight: 600;">Activar tracking de eventos (Requiere N8N configurado arriba)</span>
                            </label>
                            <p class="description">
                                Todos los eventos se enviarán al mismo webhook de N8N configurado arriba
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Eventos Disponibles</th>
                        <td>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 10px;">
                                
                                <!-- Frontend Events -->
                                <div style="background: #f0f0f1; padding: 15px; border-radius: 4px;">
                                    <h4 style="margin: 0 0 10px; color: #2196F3;">🖱️ Interacciones Frontend (25)</h4>
                                    <ul style="margin: 0; padding-left: 20px; font-size: 13px;">
                                        <li>page_view</li>
                                        <li>button_click</li>
                                        <li>product_click</li>
                                        <li>form_submit</li>
                                        <li>scroll_depth (25%, 50%, 75%, 100%)</li>
                                        <li>time_on_page (30s, 60s, 2m, 5m)</li>
                                        <li>video_interaction</li>
                                        <li>search</li>
                                        <li>product_filter</li>
                                        <li>wishlist_add</li>
                                        <li>quick_view</li>
                                        <li>product_compare</li>
                                        <li>cart_quantity_change</li>
                                        <li>coupon_apply</li>
                                        <li>checkout_start</li>
                                        <li>exit_intent</li>
                                        <li>phone_click</li>
                                        <li>email_click</li>
                                        <li>whatsapp_click</li>
                                        <li>social_click</li>
                                        <li>download_click</li>
                                        <li>external_link_click</li>
                                        <li>image_click</li>
                                        <li>tab_change</li>
                                        <li>add_to_cart_button_click</li>
                                    </ul>
                                </div>
                                
                                <!-- WooCommerce Events -->
                                <div style="background: #f0f0f1; padding: 15px; border-radius: 4px;">
                                    <h4 style="margin: 0 0 10px; color: #9C27B0;">🛒 WooCommerce (6)</h4>
                                    <ul style="margin: 0; padding-left: 20px; font-size: 13px;">
                                        <li>woo_add_to_cart</li>
                                        <li>woo_remove_from_cart</li>
                                        <li>woo_order_completed</li>
                                        <li>woo_order_status_change</li>
                                        <li>woo_payment_complete</li>
                                        <li>woo_checkout_start</li>
                                    </ul>
                                </div>
                                
                                <!-- User Events -->
                                <div style="background: #f0f0f1; padding: 15px; border-radius: 4px;">
                                    <h4 style="margin: 0 0 10px; color: #FF9800;">👤 Usuarios (3)</h4>
                                    <ul style="margin: 0; padding-left: 20px; font-size: 13px;">
                                        <li>user_registered</li>
                                        <li>user_login</li>
                                        <li>user_logout</li>
                                    </ul>
                                </div>
                                
                                <!-- Chat Events -->
                                <div style="background: #f0f0f1; padding: 15px; border-radius: 4px;">
                                    <h4 style="margin: 0 0 10px; color: #4CAF50;">💬 Chat (3)</h4>
                                    <ul style="margin: 0; padding-left: 20px; font-size: 13px;">
                                        <li>new_message</li>
                                        <li>transfer_to_human</li>
                                        <li>conversation_closed</li>
                                    </ul>
                                </div>
                                
                            </div>
                            
                            <div style="margin-top: 15px; padding: 15px; background: #fff3cd; border-radius: 4px; border-left: 4px solid #ffc107;">
                                <p style="margin: 0; font-weight: 600;">📊 TOTAL: 37+ eventos diferentes</p>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Estructura de Evento</th>
                        <td>
                            <p>Cada evento enviado a N8N tiene esta estructura:</p>
                            <div style="background: #282c34; color: #abb2bf; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 13px; overflow-x: auto;">
<pre style="margin: 0;">{
  "event": "button_click",
  "data": {
    "button_text": "Añadir al carrito",
    "button_id": "add-to-cart-123",
    "button_class": "btn btn-primary"
  },
  "meta": {
    "session_id": "abc123",
    "user_id": 5,
    "user_email": "cliente@email.com",
    "page_url": "https://tudominio.com/producto",
    "page_title": "Anillo de Oro",
    "timestamp": "2024-12-05 16:30:00",
    "user_agent": "Mozilla/5.0...",
    "screen_resolution": "1920x1080",
    "user_ip": "192.168.1.1"
  },
  "source": "golden_phoenix_tracking"
}</pre>
                            </div>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Casos de Uso</th>
                        <td>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                
                                <div style="background: #e3f2fd; padding: 15px; border-radius: 4px; border-left: 3px solid #2196F3;">
                                    <h4 style="margin: 0 0 10px;">📧 Email Marketing Inteligente</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Si:</strong> Usuario ve 3+ productos sin comprar<br>
                                        <strong>Entonces:</strong> Enviar email con descuento 10%
                                    </p>
                                </div>
                                
                                <div style="background: #f3e5f5; padding: 15px; border-radius: 4px; border-left: 3px solid #9C27B0;">
                                    <h4 style="margin: 0 0 10px;">🎯 Remarketing Automático</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Si:</strong> Abandona carrito con $500+<br>
                                        <strong>Entonces:</strong> Crear audiencia en Facebook Ads
                                    </p>
                                </div>
                                
                                <div style="background: #fff3e0; padding: 15px; border-radius: 4px; border-left: 3px solid #FF9800;">
                                    <h4 style="margin: 0 0 10px;">💬 WhatsApp Automático</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Si:</strong> Cliente pasa 5+ min en página<br>
                                        <strong>Entonces:</strong> Mensaje WhatsApp "¿Te ayudo?"
                                    </p>
                                </div>
                                
                                <div style="background: #e8f5e9; padding: 15px; border-radius: 4px; border-left: 3px solid #4CAF50;">
                                    <h4 style="margin: 0 0 10px;">📊 Lead Scoring</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Calcular:</strong> Score basado en interacciones<br>
                                        <strong>Si score > 80:</strong> Alertar vendedor VIP
                                    </p>
                                </div>
                                
                                <div style="background: #fce4ec; padding: 15px; border-radius: 4px; border-left: 3px solid #E91E63;">
                                    <h4 style="margin: 0 0 10px;">🔔 Slack Alerts</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Si:</strong> Compra > $1,000 completada<br>
                                        <strong>Entonces:</strong> Notificar #ventas en Slack
                                    </p>
                                </div>
                                
                                <div style="background: #e0f2f1; padding: 15px; border-radius: 4px; border-left: 3px solid #009688;">
                                    <h4 style="margin: 0 0 10px;">📈 Analytics Personalizado</h4>
                                    <p style="margin: 0; font-size: 13px;">
                                        <strong>Guardar:</strong> Todos los eventos en Google Sheets<br>
                                        <strong>Analizar:</strong> Comportamiento de usuarios
                                    </p>
                                </div>
                                
                            </div>
                        </td>
                    </tr>
                </table>
                
                <div style="margin-top: 20px; padding: 20px; background: #fffbea; border-radius: 8px; border: 2px dashed #ffc107;">
                    <h3 style="margin-top: 0;">💡 Ejemplo Completo: Recuperación de Carrito Abandonado</h3>
                    <div style="background: #fff; padding: 15px; border-radius: 4px; margin-top: 10px;">
                        <pre style="margin: 0; font-family: monospace; font-size: 13px; line-height: 1.6;">
N8N Workflow:

1. Webhook recibe: woo_add_to_cart
   └─ Guardar: user_email, cart_total, timestamp

2. Wait 30 minutos

3. IF no recibe: woo_order_completed
   └─ Email: "¡Tu carrito te espera! 10% descuento"
   └─ WhatsApp: "Hola, ¿necesitas ayuda con tu compra?"
   └─ Slack: "Carrito abandonado: $500"

4. Wait 24 horas

5. IF sigue sin comprar
   └─ Email: "¡Último día! 15% descuento"
   └─ Facebook: Crear audiencia remarketing
                        </pre>
                    </div>
                </div>
            </div>
            
            <hr>
            
            <!-- CHATWOOT -->
            <h2>💬 Chatwoot - Chat en Vivo</h2>
            <table class="form-table">
                <tr>
                    <th>Habilitar Chatwoot</th>
                    <td>
                        <label>
                            <input type="checkbox" name="chatwoot_enabled" <?php checked(get_option('gp_chatwoot_enabled')); ?>>
                            Transferir conversaciones a Chatwoot
                        </label>
                    </td>
                </tr>
                <tr>
                    <th>URL de Chatwoot</th>
                    <td>
                        <input type="url" name="chatwoot_url" value="<?php echo esc_attr(get_option('gp_chatwoot_url')); ?>" class="regular-text" placeholder="https://app.chatwoot.com">
                        <p class="description">URL base de tu instancia de Chatwoot</p>
                    </td>
                </tr>
                <tr>
                    <th>API Access Token</th>
                    <td>
                        <input type="password" name="chatwoot_api_key" value="<?php echo esc_attr(get_option('gp_chatwoot_api_key')); ?>" class="regular-text">
                        <p class="description">
                            Obtén tu token en: Chatwoot → Settings → Integrations → API Access Tokens
                        </p>
                    </td>
                </tr>
                <tr>
                    <th>Inbox ID</th>
                    <td>
                        <input type="text" name="chatwoot_inbox_id" value="<?php echo esc_attr(get_option('gp_chatwoot_inbox_id')); ?>" class="regular-text">
                        <p class="description">
                            ID del inbox donde se crearán las conversaciones (Ej: 1, 2, 3...)
                        </p>
                        <button type="button" onclick="testChatwoot()" class="button">🧪 Probar Conexión</button>
                        <span id="chatwoot-test-result"></span>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <input type="submit" name="gp_save_integrations" class="button button-primary" value="Guardar Configuración">
            </p>
        </form>
        
        <hr>
        
        <h2>📖 Guías de Configuración</h2>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div style="background: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
                <h3>🔄 Configurar N8N</h3>
                <ol>
                    <li>Instala N8N: <code>npm install -g n8n</code></li>
                    <li>Ejecuta: <code>n8n start</code></li>
                    <li>Abre: http://localhost:5678</li>
                    <li>Crea nuevo workflow</li>
                    <li>Añade nodo "Webhook"</li>
                    <li>Configura método: POST</li>
                    <li>Copia la URL generada</li>
                    <li>Pégala arriba</li>
                    <li>Añade nodos adicionales (Email, Slack, etc)</li>
                    <li>Activa el workflow</li>
                </ol>
                <p><strong>Casos de uso:</strong></p>
                <ul>
                    <li>✅ Notificar por email cada mensaje</li>
                    <li>✅ Enviar a Slack cuando bot transfiere a humano</li>
                    <li>✅ Guardar conversaciones en Google Sheets</li>
                    <li>✅ Crear tickets en Zendesk</li>
                </ul>
            </div>
            
            <div style="background: #fff; padding: 20px; border: 1px solid #ccc; border-radius: 8px;">
                <h3>💬 Configurar Chatwoot</h3>
                <ol>
                    <li>Regístrate en: https://app.chatwoot.com</li>
                    <li>Crea una cuenta</li>
                    <li>Settings → Inboxes → Add Inbox</li>
                    <li>Selecciona "Website"</li>
                    <li>Copia el Inbox ID (número)</li>
                    <li>Settings → Integrations → API</li>
                    <li>Crea Access Token</li>
                    <li>Copia el token</li>
                    <li>Pega ambos arriba</li>
                    <li>Prueba la conexión</li>
                </ol>
                <p><strong>Ventajas:</strong></p>
                <ul>
                    <li>✅ Chat en vivo profesional</li>
                    <li>✅ Apps móviles para agentes</li>
                    <li>✅ Respuestas predefinidas</li>
                    <li>✅ Métricas y reportes</li>
                    <li>✅ Integraciones con Slack, WhatsApp, etc</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script>
    function testN8N() {
        const btn = event.target;
        const result = document.getElementById('n8n-test-result');
        btn.disabled = true;
        result.textContent = '⏳ Probando...';
        
        fetch(ajaxurl + '?action=gp_test_n8n_connection')
            .then(r => r.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    result.innerHTML = '<span style="color: green;">' + data.data.message + '</span>';
                } else {
                    result.innerHTML = '<span style="color: red;">' + data.data.message + '</span>';
                }
            });
    }
    
    function testChatwoot() {
        const btn = event.target;
        const result = document.getElementById('chatwoot-test-result');
        btn.disabled = true;
        result.textContent = '⏳ Probando...';
        
        fetch(ajaxurl + '?action=gp_test_chatwoot_connection')
            .then(r => r.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    result.innerHTML = '<span style="color: green;">' + data.data.message + (data.data.user ? ' (Usuario: ' + data.data.user + ')' : '') + '</span>';
                } else {
                    result.innerHTML = '<span style="color: red;">' + data.data.message + '</span>';
                }
            });
    }
    </script>
    <?php
}
