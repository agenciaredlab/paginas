<?php
/**
 * Golden Phoenix - Sistema Avanzado de Reviews
 * Reviews con fotos, verificación de compra, respuestas de tienda
 * 
 * @package Golden_Phoenix
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================
// PERMITIR SUBIR FOTOS EN REVIEWS
// ============================================

add_action('comment_form_logged_in_after', 'gp_review_image_upload');
add_action('comment_form_after_fields', 'gp_review_image_upload');

function gp_review_image_upload() {
    if (!is_product()) {
        return;
    }
    ?>
    <p class="comment-form-images">
        <label for="review_images">Agregar Fotos (Opcional)</label>
        <input type="file" name="review_images[]" id="review_images" accept="image/*" multiple style="width: 100%; padding: 10px; border: 2px dashed #D4AF37; border-radius: 4px;">
        <small style="color: #666; display: block; margin-top: 5px;">
            Puedes subir hasta 3 fotos de tu producto (JPG, PNG, máx. 5MB c/u)
        </small>
    </p>
    
    <style>
    #review_images:hover {
        border-color: #0A0A0A;
        background: #f9f9f9;
    }
    </style>
    <?php
}

// ============================================
// GUARDAR IMÁGENES DE REVIEW
// ============================================

add_action('comment_post', 'gp_save_review_images');

function gp_save_review_images($comment_id) {
    if (!isset($_FILES['review_images'])) {
        return;
    }
    
    $files = $_FILES['review_images'];
    $uploaded_images = array();
    
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    
    for ($i = 0; $i < count($files['name']); $i++) {
        if ($i >= 3) break; // Máximo 3 imágenes
        
        if ($files['error'][$i] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        $file = array(
            'name' => $files['name'][$i],
            'type' => $files['type'][$i],
            'tmp_name' => $files['tmp_name'][$i],
            'error' => $files['error'][$i],
            'size' => $files['size'][$i]
        );
        
        $_FILES = array('review_image' => $file);
        
        $attachment_id = media_handle_upload('review_image', 0);
        
        if (!is_wp_error($attachment_id)) {
            $uploaded_images[] = $attachment_id;
        }
    }
    
    if (!empty($uploaded_images)) {
        update_comment_meta($comment_id, 'review_images', $uploaded_images);
    }
}

// ============================================
// MOSTRAR REVIEWS CON IMÁGENES
// ============================================

add_filter('woocommerce_product_review_comment_text', 'gp_display_review_images', 10, 2);

function gp_display_review_images($comment_text, $comment) {
    $images = get_comment_meta($comment->comment_ID, 'review_images', true);
    
    if (empty($images)) {
        return $comment_text;
    }
    
    $html = '<div class="review-images" style="margin-top: 15px; display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 10px;">';
    
    foreach ($images as $image_id) {
        $image_url = wp_get_attachment_url($image_id);
        $image_full = wp_get_attachment_image_src($image_id, 'full')[0];
        
        $html .= '<a href="' . $image_full . '" data-lightbox="review-' . $comment->comment_ID . '" style="display: block; border-radius: 8px; overflow: hidden; border: 2px solid #f0f0f0; transition: border-color 0.3s;"
                    onmouseover="this.style.borderColor=\'#D4AF37\'"
                    onmouseout="this.style.borderColor=\'#f0f0f0\'">
                    <img src="' . $image_url . '" alt="Foto de cliente" style="width: 100%; height: 100px; object-fit: cover; display: block;">
                </a>';
    }
    
    $html .= '</div>';
    
    return $comment_text . $html;
}

// ============================================
// BADGE DE COMPRA VERIFICADA
// ============================================

add_filter('woocommerce_review_display_meta', 'gp_verified_purchase_badge', 10, 3);

function gp_verified_purchase_badge($meta_html, $comment, $verified) {
    if ($verified) {
        $meta_html .= '<span style="display: inline-block; background: #28a745; color: white; padding: 4px 10px; border-radius: 12px; font-size: 11px; margin-left: 10px; font-weight: 600;">
            <i class="fas fa-check-circle"></i> COMPRA VERIFICADA
        </span>';
    }
    
    return $meta_html;
}

// ============================================
// SISTEMA DE RESPUESTAS DE LA TIENDA
// ============================================

add_action('woocommerce_review_before_comment_meta', 'gp_store_reply_form');

function gp_store_reply_form($comment) {
    // Solo mostrar para administradores
    if (!current_user_can('manage_woocommerce')) {
        return;
    }
    
    $reply = get_comment_meta($comment->comment_ID, 'store_reply', true);
    
    ?>
    <div class="store-reply-section" style="margin-top: 15px; padding: 15px; background: #f0f8ff; border-left: 4px solid #D4AF37; border-radius: 4px;">
        <?php if ($reply) : ?>
            <div style="margin-bottom: 15px;">
                <strong style="color: #D4AF37; display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">
                    <i class="fas fa-store"></i> Respuesta de Golden Phoenix:
                </strong>
                <p style="margin: 0; color: #0A0A0A;"><?php echo esc_html($reply); ?></p>
            </div>
            <button onclick="editStoreReply(<?php echo $comment->comment_ID; ?>)" class="button button-small">
                Editar Respuesta
            </button>
        <?php else : ?>
            <form class="store-reply-form" data-comment-id="<?php echo $comment->comment_ID; ?>" style="display: none;">
                <textarea name="store_reply" rows="3" placeholder="Escribe una respuesta a este cliente..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 10px;"></textarea>
                <button type="submit" class="button button-primary">Enviar Respuesta</button>
                <button type="button" onclick="this.closest('.store-reply-form').style.display='none'" class="button">Cancelar</button>
            </form>
            <button onclick="this.style.display='none'; this.nextElementSibling.style.display='block'" class="button button-small">
                Responder como Tienda
            </button>
        <?php endif; ?>
    </div>
    
    <script>
    function editStoreReply(commentId) {
        // Implementar edición
        alert('Función de edición - Implementar según necesidad');
    }
    
    document.querySelectorAll('.store-reply-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const commentId = this.dataset.commentId;
            const reply = this.querySelector('textarea').value;
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=save_store_reply&comment_id=${commentId}&reply=${encodeURIComponent(reply)}`
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            });
        });
    });
    </script>
    <?php
}

// AJAX guardar respuesta
add_action('wp_ajax_save_store_reply', 'gp_save_store_reply');

function gp_save_store_reply() {
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error();
    }
    
    $comment_id = intval($_POST['comment_id']);
    $reply = sanitize_textarea_field($_POST['reply']);
    
    update_comment_meta($comment_id, 'store_reply', $reply);
    
    wp_send_json_success();
}

// ============================================
// GALERÍA DE FOTOS DE CLIENTES
// ============================================

add_shortcode('customer_photos', 'gp_customer_photos_gallery');

function gp_customer_photos_gallery($atts) {
    global $product;
    
    if (!$product) {
        $product_id = isset($atts['product_id']) ? intval($atts['product_id']) : 0;
        if (!$product_id) return '';
        $product = wc_get_product($product_id);
    }
    
    // Obtener todos los reviews con imágenes
    $comments = get_comments(array(
        'post_id' => $product->get_id(),
        'status' => 'approve',
        'type' => 'review',
        'meta_key' => 'review_images'
    ));
    
    if (empty($comments)) {
        return '';
    }
    
    ob_start();
    ?>
    <div class="customer-photos-gallery" style="margin: 60px 0;">
        <h2 style="text-align: center; font-size: 36px; font-family: 'Playfair Display', serif; margin-bottom: 40px;">
            📸 Fotos de Nuestros Clientes
        </h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
            <?php
            foreach ($comments as $comment) {
                $images = get_comment_meta($comment->comment_ID, 'review_images', true);
                
                if (!$images) continue;
                
                foreach ($images as $image_id) {
                    $image_url = wp_get_attachment_url($image_id);
                    $image_full = wp_get_attachment_image_src($image_id, 'full')[0];
                    $rating = get_comment_meta($comment->comment_ID, 'rating', true);
                    
                    ?>
                    <div class="customer-photo-item" style="position: relative; overflow: hidden; border-radius: 12px; aspect-ratio: 1; cursor: pointer;"
                         onclick="openPhotoModal('<?php echo $image_full; ?>', '<?php echo esc_js($comment->comment_author); ?>', <?php echo $rating; ?>)">
                        
                        <img src="<?php echo $image_url; ?>" alt="Foto de <?php echo $comment->comment_author; ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s;"
                             onmouseover="this.style.transform='scale(1.1)'"
                             onmouseout="this.style.transform='scale(1)'">
                        
                        <!-- Overlay con info -->
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to top, rgba(0,0,0,0.8), transparent); padding: 15px; color: white; opacity: 0; transition: opacity 0.3s;"
                             onmouseenter="this.style.opacity='1'"
                             onmouseleave="this.style.opacity='0'">
                            <div style="font-weight: 600; margin-bottom: 5px;">
                                <?php echo $comment->comment_author; ?>
                            </div>
                            <div style="color: #D4AF37; font-size: 14px;">
                                <?php for ($i = 1; $i <= 5; $i++) echo $i <= $rating ? '★' : '☆'; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </div>
    
    <!-- Modal para foto ampliada -->
    <div id="photo-modal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.95); z-index: 999999; align-items: center; justify-content: center; padding: 20px;" onclick="this.style.display='none'">
        <div style="max-width: 800px; max-height: 90vh; position: relative;">
            <button onclick="event.stopPropagation(); document.getElementById('photo-modal').style.display='none'" style="position: absolute; top: -40px; right: 0; background: white; border: none; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; font-size: 24px;">×</button>
            
            <img id="modal-photo" src="" alt="" style="max-width: 100%; max-height: 80vh; border-radius: 8px;">
            
            <div id="modal-info" style="background: white; padding: 20px; margin-top: 20px; border-radius: 8px; text-align: center;">
                <div id="modal-author" style="font-weight: 700; font-size: 18px; margin-bottom: 10px;"></div>
                <div id="modal-rating" style="color: #D4AF37; font-size: 20px;"></div>
            </div>
        </div>
    </div>
    
    <script>
    function openPhotoModal(imageUrl, author, rating) {
        event.stopPropagation();
        
        document.getElementById('modal-photo').src = imageUrl;
        document.getElementById('modal-author').textContent = author;
        
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += i <= rating ? '★' : '☆';
        }
        document.getElementById('modal-rating').innerHTML = stars;
        
        document.getElementById('photo-modal').style.display = 'flex';
    }
    </script>
    
    <style>
    @media (max-width: 768px) {
        .customer-photos-gallery > div {
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)) !important;
        }
    }
    </style>
    <?php
    
    return ob_get_clean();
}

// ============================================
// WIDGET DE REVIEWS DESTACADOS
// ============================================

add_shortcode('featured_reviews', 'gp_featured_reviews_widget');

function gp_featured_reviews_widget() {
    $args = array(
        'status' => 'approve',
        'type' => 'review',
        'meta_query' => array(
            array(
                'key' => 'rating',
                'value' => '5',
                'compare' => '='
            )
        ),
        'number' => 6
    );
    
    $reviews = get_comments($args);
    
    if (empty($reviews)) {
        return '';
    }
    
    ob_start();
    ?>
    <div class="featured-reviews" style="margin: 80px 0; background: #f9f9f9; padding: 60px 20px;">
        <div class="container" style="max-width: 1200px; margin: 0 auto;">
            
            <h2 style="text-align: center; font-size: 42px; font-family: 'Playfair Display', serif; margin-bottom: 20px;">
                ⭐ Lo Que Dicen Nuestros Clientes
            </h2>
            <div style="width: 80px; height: 3px; background: #D4AF37; margin: 0 auto 50px;"></div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 30px;">
                <?php foreach ($reviews as $review) : 
                    $product_id = $review->comment_post_ID;
                    $product = wc_get_product($product_id);
                    $verified = wc_customer_bought_product($review->comment_author_email, $review->user_id, $product_id);
                ?>
                
                <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    <!-- Rating -->
                    <div style="color: #D4AF37; font-size: 24px; margin-bottom: 15px;">
                        ★★★★★
                    </div>
                    
                    <!-- Comentario -->
                    <p style="color: #0A0A0A; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
                        "<?php echo esc_html($review->comment_content); ?>"
                    </p>
                    
                    <!-- Autor -->
                    <div style="display: flex; align-items: center; gap: 15px; padding-top: 20px; border-top: 1px solid #eee;">
                        <div style="width: 50px; height: 50px; border-radius: 50%; background: #D4AF37; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 20px;">
                            <?php echo strtoupper(substr($review->comment_author, 0, 1)); ?>
                        </div>
                        <div>
                            <div style="font-weight: 700; margin-bottom: 5px;">
                                <?php echo $review->comment_author; ?>
                                <?php if ($verified) : ?>
                                    <span style="color: #28a745; font-size: 12px; margin-left: 5px;">✓</span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size: 13px; color: #666;">
                                <?php echo $product ? $product->get_name() : ''; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <style>
    @media (max-width: 768px) {
        .featured-reviews > div > div {
            grid-template-columns: 1fr !important;
        }
    }
    </style>
    <?php
    
    return ob_get_clean();
}

// Agregar automáticamente en homepage
add_action('woocommerce_after_main_content', 'gp_auto_featured_reviews');

function gp_auto_featured_reviews() {
    if (is_front_page()) {
        echo do_shortcode('[featured_reviews]');
    }
}
