<?php
/**
 * Template Name: Carrito Personalizado
 * Página del Carrito de Compras
 * 
 * @package Golden_Phoenix
 */

get_header();
?>

<div class="custom-cart-page" style="padding: 60px 20px; background: #F8F8F8; min-height: 70vh;">
    <div class="container" style="max-width: 1200px; margin: 0 auto;">
        
        <h1 style="font-size: 42px; margin-bottom: 40px; text-align: center; font-family: 'Playfair Display', serif;">
            <?php echo gp_get_text('gp_cart_text', 'Carrito de Compras'); ?>
        </h1>
        
        <?php if (function_exists('WC')) : ?>
            
            <?php 
            $cart = WC()->cart;
            
            if ($cart->is_empty()) : 
            ?>
            
            <!-- Carrito Vacío -->
            <div class="empty-cart" style="background: white; padding: 80px 40px; border-radius: 8px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                <div style="font-size: 80px; margin-bottom: 20px; opacity: 0.3;">🛒</div>
                <h2 style="font-size: 28px; margin-bottom: 15px; color: #0A0A0A;">Tu carrito está vacío</h2>
                <p style="color: #666; font-size: 16px; margin-bottom: 30px;">
                    Descubre nuestras exclusivas colecciones y encuentra la joya perfecta para ti.
                </p>
                <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
                   style="background: #D4AF37; color: white; padding: 18px 50px; border-radius: 4px; text-decoration: none; font-weight: 600; display: inline-block; transition: background 0.3s;"
                   onmouseover="this.style.background='#0A0A0A'"
                   onmouseout="this.style.background='#D4AF37'">
                    Ir a la Tienda
                </a>
            </div>
            
            <?php else : ?>
            
            <!-- Carrito con Productos -->
            <div class="cart-content" style="display: grid; grid-template-columns: 1fr 400px; gap: 30px;">
                
                <!-- Lista de Productos -->
                <div class="cart-items" style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    
                    <h2 style="font-size: 24px; margin-bottom: 30px; padding-bottom: 15px; border-bottom: 2px solid #D4AF37;">
                        Productos (<?php echo $cart->get_cart_contents_count(); ?>)
                    </h2>
                    
                    <?php foreach ($cart->get_cart() as $cart_item_key => $cart_item) : 
                        $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                        
                        if ($_product && $_product->exists() && $cart_item['quantity'] > 0) :
                            $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                    ?>
                    
                    <div class="cart-item" style="display: flex; gap: 20px; padding: 20px 0; border-bottom: 1px solid #eee;">
                        
                        <!-- Imagen del Producto -->
                        <div class="item-image" style="flex-shrink: 0;">
                            <?php
                            $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(array(120, 120)), $cart_item, $cart_item_key);
                            
                            if (!$product_permalink) {
                                echo $thumbnail;
                            } else {
                                printf('<a href="%s">%s</a>', esc_url($product_permalink), $thumbnail);
                            }
                            ?>
                        </div>
                        
                        <!-- Info del Producto -->
                        <div class="item-details" style="flex-grow: 1;">
                            <h3 style="font-size: 18px; margin-bottom: 8px;">
                                <?php
                                if (!$product_permalink) {
                                    echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key));
                                } else {
                                    echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s" style="color: #0A0A0A; text-decoration: none;">%s</a>', esc_url($product_permalink), $_product->get_name()), $cart_item, $cart_item_key));
                                }
                                ?>
                            </h3>
                            
                            <!-- Precio Unitario -->
                            <p style="color: #D4AF37; font-size: 16px; font-weight: 600; margin-bottom: 15px;">
                                <?php echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key); ?>
                            </p>
                            
                            <!-- Cantidad -->
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <label style="font-size: 14px; color: #666;">Cantidad:</label>
                                <input type="number" 
                                       value="<?php echo esc_attr($cart_item['quantity']); ?>" 
                                       min="1" 
                                       max="<?php echo esc_attr($_product->get_max_purchase_quantity()); ?>"
                                       style="width: 70px; padding: 8px; border: 1px solid #ddd; border-radius: 4px; text-align: center;"
                                       onchange="updateCartQuantity('<?php echo esc_js($cart_item_key); ?>', this.value)">
                                
                                <button onclick="removeFromCart('<?php echo esc_js($cart_item_key); ?>')" 
                                        style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; font-size: 14px; transition: background 0.3s;"
                                        onmouseover="this.style.background='#c82333'"
                                        onmouseout="this.style.background='#dc3545'">
                                    Eliminar
                                </button>
                            </div>
                        </div>
                        
                        <!-- Subtotal -->
                        <div class="item-total" style="text-align: right; min-width: 100px;">
                            <p style="font-size: 20px; font-weight: 700; color: #0A0A0A;">
                                <?php echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key); ?>
                            </p>
                        </div>
                        
                    </div>
                    
                    <?php endif; endforeach; ?>
                    
                </div>
                
                <!-- Resumen del Pedido -->
                <div class="cart-totals" style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); height: fit-content; position: sticky; top: 100px;">
                    
                    <h2 style="font-size: 24px; margin-bottom: 30px; padding-bottom: 15px; border-bottom: 2px solid #D4AF37;">
                        Resumen del Pedido
                    </h2>
                    
                    <!-- Subtotal -->
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                        <span style="color: #666;">Subtotal:</span>
                        <span style="font-weight: 600;"><?php echo WC()->cart->get_cart_subtotal(); ?></span>
                    </div>
                    
                    <!-- Descuentos -->
                    <?php if (WC()->cart->get_discount_total() > 0) : ?>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                        <span style="color: #666;">Descuento:</span>
                        <span style="font-weight: 600; color: #28a745;">-<?php echo wc_price(WC()->cart->get_discount_total()); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Envío -->
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee;">
                        <span style="color: #666;">Envío:</span>
                        <span style="font-weight: 600;">
                            <?php if (WC()->cart->needs_shipping() && WC()->cart->show_shipping()) : ?>
                                Calculado en checkout
                            <?php else : ?>
                                Gratis
                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <!-- Total -->
                    <div style="display: flex; justify-content: space-between; margin-bottom: 30px; padding: 20px 0; border-top: 2px solid #D4AF37;">
                        <span style="font-size: 20px; font-weight: 700;">Total:</span>
                        <span style="font-size: 24px; font-weight: 700; color: #D4AF37;">
                            <?php echo WC()->cart->get_total(); ?>
                        </span>
                    </div>
                    
                    <!-- Botón Checkout -->
                    <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" 
                       style="display: block; background: #D4AF37; color: white; text-align: center; padding: 18px; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 16px; margin-bottom: 15px; transition: background 0.3s;"
                       onmouseover="this.style.background='#0A0A0A'"
                       onmouseout="this.style.background='#D4AF37'">
                        <?php echo gp_get_text('gp_checkout_text', 'Finalizar Compra'); ?> →
                    </a>
                    
                    <!-- Continuar Comprando -->
                    <a href="<?php echo get_permalink(wc_get_page_id('shop')); ?>" 
                       style="display: block; background: transparent; color: #0A0A0A; text-align: center; padding: 12px; border: 2px solid #0A0A0A; border-radius: 4px; text-decoration: none; font-weight: 600; transition: all 0.3s;"
                       onmouseover="this.style.background='#0A0A0A'; this.style.color='white';"
                       onmouseout="this.style.background='transparent'; this.style.color='#0A0A0A';">
                        ← Continuar Comprando
                    </a>
                    
                    <!-- Métodos de Pago -->
                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; text-align: center;">
                        <p style="font-size: 12px; color: #999; margin-bottom: 10px;">Métodos de pago aceptados:</p>
                        <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; opacity: 0.7;">
                            <span style="padding: 5px 10px; background: #f0f0f0; border-radius: 4px; font-size: 11px;">💳 PSE</span>
                            <span style="padding: 5px 10px; background: #f0f0f0; border-radius: 4px; font-size: 11px;">💰 Wompi</span>
                            <span style="padding: 5px 10px; background: #f0f0f0; border-radius: 4px; font-size: 11px;">📱 Mercado Pago</span>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            <?php endif; ?>
            
        <?php else : ?>
            
            <!-- WooCommerce no instalado -->
            <div style="background: white; padding: 60px 40px; border-radius: 8px; text-align: center;">
                <h2 style="font-size: 28px; margin-bottom: 20px; color: #dc3545;">WooCommerce no está instalado</h2>
                <p style="color: #666; margin-bottom: 30px;">
                    Para usar el carrito de compras, necesitas instalar y activar WooCommerce.
                </p>
                <a href="<?php echo admin_url('plugin-install.php?s=woocommerce&tab=search'); ?>" 
                   style="background: #D4AF37; color: white; padding: 15px 40px; border-radius: 4px; text-decoration: none; display: inline-block;">
                    Instalar WooCommerce
                </a>
            </div>
            
        <?php endif; ?>
        
    </div>
</div>

<script>
// Actualizar cantidad del producto
function updateCartQuantity(cartItemKey, quantity) {
    const formData = new FormData();
    formData.append('action', 'update_cart_quantity');
    formData.append('cart_item_key', cartItemKey);
    formData.append('quantity', quantity);
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

// Eliminar producto del carrito
function removeFromCart(cartItemKey) {
    if (!confirm('¿Estás seguro de eliminar este producto?')) return;
    
    const formData = new FormData();
    formData.append('action', 'remove_cart_item');
    formData.append('cart_item_key', cartItemKey);
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}
</script>

<style>
@media (max-width: 968px) {
    .cart-content {
        grid-template-columns: 1fr !important;
    }
    
    .cart-totals {
        position: static !important;
    }
}

@media (max-width: 600px) {
    .cart-item {
        flex-direction: column;
    }
    
    .item-total {
        text-align: left !important;
    }
}
</style>

<?php get_footer(); ?>
